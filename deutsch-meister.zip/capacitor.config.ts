import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.deutschmeister.app',
  appName: 'Deutsch Meister',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
