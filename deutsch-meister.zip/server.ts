import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey || 'dummy-key' });

app.post('/api/ai-chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey === 'dummy-key') {
      return res.json({
        reply: `(AI Simülasyon Yanıtı): "${message}" konusunda harika ilerliyorsun! Almancada pratik yapmak ve kelime hazinesini geliştirmek için günlük tekrar çok önemlidir. Başka ne öğrenmek istersin?`
      });
    }

    const chatHistory = Array.isArray(history)
      ? history.map((h: any) => ({
          role: h.sender === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }]
        }))
      : [];

    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: [
        {
          role: 'user',
          parts: [{ text: 'Sen profesyonel bir Almanca öğretmeni ve koçusun (Deutsch Meister). Kullanıcıya A1-C1 seviyelerinde Almanca öğretir, hatalarını nazikçe düzeltir, Türkçe açıklamalar yapar ve kısa örnekler verirsin. Lütfen her zaman bu rolü koru.' }]
        },
        {
          role: 'model',
          parts: [{ text: 'Verstanden! Ich bin bereit, als dein Deutschlehrer zu helfen. Wie kann ich dir heute helfen?' }]
        },
        ...chatHistory
      ]
    });

    const result = await chat.sendMessage({ message });
    const reply = result.text || 'Entschuldigung, ich habe das nicht verstanden.';

    res.json({ reply });
  } catch (error: any) {
    console.error('AI Chat Error:', error);
    res.status(500).json({
      reply: 'Entschuldigung, momentan gibt es ein technisches Problem. Lütfen tekrar deneyin.'
    });
  }
});

export default app;
