import React, { createContext, useContext, useState, useEffect } from 'react';
import { Word, Lesson, GrammarTopic, ExamQuestion, Badge, UserStats, UserProfile, CEFRLevel } from '../types';
import { INITIAL_WORDS } from '../data/vocabData';
import { INITIAL_LESSONS } from '../data/lessonData';
import { INITIAL_GRAMMAR_TOPICS } from '../data/grammarData';
import { INITIAL_EXAMS } from '../data/examData';
import { INITIAL_BADGES } from '../data/badgeData';
import { calculateSafeStats } from '../utils/analytics';

interface AppContextType {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedLevel: CEFRLevel;
  setSelectedLevel: (level: CEFRLevel) => void;
  words: Word[];
  lessons: Lesson[];
  grammarTopics: GrammarTopic[];
  exams: ExamQuestion[];
  badges: Badge[];
  stats: UserStats;
  profile: UserProfile;
  updateProfile: (updates: Partial<UserProfile>) => void;
  updateWordLeitner: (wordId: string, boxDelta: number) => void;
  toggleWordLearned: (wordId: string) => void;
  addWord: (word: Omit<Word, 'id' | 'leitnerBox' | 'learned'>) => void;
  completeLesson: (lessonId: string, score: number) => void;
  completeGrammar: (topicId: string) => void;
  speakText: (text: string) => void;
  resetAllData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  WORDS: 'deutsch_meister_words_v2',
  LESSONS: 'deutsch_meister_lessons_v2',
  GRAMMAR: 'deutsch_meister_grammar_v2',
  BADGES: 'deutsch_meister_badges_v2',
  STATS: 'deutsch_meister_stats_v2',
  PROFILE: 'deutsch_meister_profile_v2',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedLevel, setSelectedLevel] = useState<CEFRLevel>('A1');

  // Load words with error handling and fallback
  const [words, setWords] = useState<Word[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.WORDS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading words from localStorage:', e);
    }
    return INITIAL_WORDS;
  });

  // Load lessons
  const [lessons, setLessons] = useState<Lesson[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LESSONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading lessons:', e);
    }
    return INITIAL_LESSONS;
  });

  // Load grammar
  const [grammarTopics, setGrammarTopics] = useState<GrammarTopic[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.GRAMMAR);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading grammar:', e);
    }
    return INITIAL_GRAMMAR_TOPICS;
  });

  // Exams static
  const [exams] = useState<ExamQuestion[]>(INITIAL_EXAMS);

  // Load badges
  const [badges, setBadges] = useState<Badge[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BADGES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Error loading badges:', e);
    }
    return INITIAL_BADGES;
  });

  // Load profile
  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            name: parsed.name || 'Almanca Öğrencisi',
            level: parsed.level || 'A1',
            theme: parsed.theme || 'light',
            soundEnabled: parsed.soundEnabled ?? true,
            speechSpeed: parsed.speechSpeed || 1.0,
          };
        }
      }
    } catch (e) {
      console.error('Error loading profile:', e);
    }
    return {
      name: 'Almanca Öğrencisi',
      level: 'A1',
      theme: 'light',
      soundEnabled: true,
      speechSpeed: 1.0,
    };
  });

  // Load stats with safe pct guarantee
  const [stats, setStats] = useState<UserStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return calculateSafeStats(parsed, words, lessons);
      }
    } catch (e) {
      console.error('Error loading stats:', e);
    }
    return calculateSafeStats(null, words, lessons);
  });

  // Persist state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.WORDS, JSON.stringify(words));
      localStorage.setItem(STORAGE_KEYS.LESSONS, JSON.stringify(lessons));
      localStorage.setItem(STORAGE_KEYS.GRAMMAR, JSON.stringify(grammarTopics));
      localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(badges));
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
      const computed = calculateSafeStats(stats, words, lessons);
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(computed));
    } catch (e) {
      console.error('Error saving state to localStorage:', e);
    }
  }, [words, lessons, grammarTopics, badges, profile, stats]);

  const updateProfile = (updates: Partial<UserProfile>) => {
    setProfile(prev => ({ ...prev, ...updates }));
  };

  const updateWordLeitner = (wordId: string, boxDelta: number) => {
    setWords(prev =>
      prev.map(w => {
        if (w.id === wordId) {
          const newBox = Math.max(1, Math.min(5, (w.leitnerBox || 1) + boxDelta));
          return {
            ...w,
            leitnerBox: newBox,
            learned: newBox >= 3 ? true : w.learned,
          };
        }
        return w;
      })
    );
    setStats(prev => ({
      ...prev,
      totalXp: prev.totalXp + 10,
    }));
  };

  const toggleWordLearned = (wordId: string) => {
    setWords(prev =>
      prev.map(w => (w.id === wordId ? { ...w, learned: !w.learned } : w))
    );
  };

  const addWord = (newWord: Omit<Word, 'id' | 'leitnerBox' | 'learned'>) => {
    const word: Word = {
      ...newWord,
      id: `w_${Date.now()}`,
      leitnerBox: 1,
      learned: false,
    };
    setWords(prev => [word, ...prev]);
    setStats(prev => ({ ...prev, totalXp: prev.totalXp + 15 }));
  };

  const completeLesson = (lessonId: string, score: number) => {
    setLessons(prev =>
      prev.map(l => (l.id === lessonId ? { ...l, completed: true, score } : l))
    );
    setStats(prev => ({
      ...prev,
      lessonsCompleted: prev.lessonsCompleted + 1,
      totalXp: prev.totalXp + 50,
    }));
  };

  const completeGrammar = (topicId: string) => {
    setGrammarTopics(prev =>
      prev.map(g => (g.id === topicId ? { ...g, completed: true } : g))
    );
    setStats(prev => ({ ...prev, totalXp: prev.totalXp + 30 }));
  };

  const speakText = (text: string) => {
    if (!profile.soundEnabled) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      utterance.rate = profile.speechSpeed || 1.0;
      window.speechSynthesis.speak(utterance);
    }
  };

  const resetAllData = () => {
    localStorage.clear();
    setWords(INITIAL_WORDS);
    setLessons(INITIAL_LESSONS);
    setGrammarTopics(INITIAL_GRAMMAR_TOPICS);
    setBadges(INITIAL_BADGES);
    setStats(calculateSafeStats(null, INITIAL_WORDS, INITIAL_LESSONS));
    setProfile({
      name: 'Almanca Öğrencisi',
      level: 'A1',
      theme: 'light',
      soundEnabled: true,
      speechSpeed: 1.0,
    });
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedLevel,
        setSelectedLevel,
        words,
        lessons,
        grammarTopics,
        exams,
        badges,
        stats,
        profile,
        updateProfile,
        updateWordLeitner,
        toggleWordLearned,
        addWord,
        completeLesson,
        completeGrammar,
        speakText,
        resetAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
