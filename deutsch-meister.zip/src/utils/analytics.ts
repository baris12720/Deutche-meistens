import { UserStats, Word, Lesson } from '../types';

export function calculateSafeStats(savedStats?: Partial<UserStats> | null, words: Word[] = [], lessons: Lesson[] = []): UserStats {
  const defaultStats: UserStats = {
    streak: 1,
    lastActiveDate: new Date().toISOString().split('T')[0],
    totalXp: 120,
    wordsLearned: 0,
    lessonsCompleted: 0,
    examsCompleted: 0,
    pct: 0,
    studyMinutesToday: 15,
    dailyGoalMinutes: 20,
  };

  if (!savedStats) {
    return computePct(defaultStats, words, lessons);
  }

  const merged: UserStats = {
    ...defaultStats,
    ...savedStats,
    streak: typeof savedStats.streak === 'number' && !isNaN(savedStats.streak) ? savedStats.streak : defaultStats.streak,
    totalXp: typeof savedStats.totalXp === 'number' && !isNaN(savedStats.totalXp) ? savedStats.totalXp : defaultStats.totalXp,
    wordsLearned: typeof savedStats.wordsLearned === 'number' && !isNaN(savedStats.wordsLearned) ? savedStats.wordsLearned : defaultStats.wordsLearned,
    lessonsCompleted: typeof savedStats.lessonsCompleted === 'number' && !isNaN(savedStats.lessonsCompleted) ? savedStats.lessonsCompleted : defaultStats.lessonsCompleted,
    examsCompleted: typeof savedStats.examsCompleted === 'number' && !isNaN(savedStats.examsCompleted) ? savedStats.examsCompleted : defaultStats.examsCompleted,
    studyMinutesToday: typeof savedStats.studyMinutesToday === 'number' && !isNaN(savedStats.studyMinutesToday) ? savedStats.studyMinutesToday : defaultStats.studyMinutesToday,
    dailyGoalMinutes: typeof savedStats.dailyGoalMinutes === 'number' && !isNaN(savedStats.dailyGoalMinutes) ? savedStats.dailyGoalMinutes : defaultStats.dailyGoalMinutes,
    lastActiveDate: savedStats.lastActiveDate || defaultStats.lastActiveDate,
    pct: 0,
  };

  return computePct(merged, words, lessons);
}

function computePct(stats: UserStats, words: Word[] = [], lessons: Lesson[] = []): UserStats {
  try {
    const totalWords = Array.isArray(words) && words.length > 0 ? words.length : 1;
    const learnedWords = Array.isArray(words) ? words.filter(w => w?.learned || (w?.leitnerBox && w.leitnerBox > 1)).length : 0;
    const wordPct = (learnedWords / totalWords) * 50;

    const totalLessons = Array.isArray(lessons) && lessons.length > 0 ? lessons.length : 1;
    const completedLessons = Array.isArray(lessons) ? lessons.filter(l => l?.completed).length : 0;
    const lessonPct = (completedLessons / totalLessons) * 50;

    const rawPct = Math.round(wordPct + lessonPct);
    const safePct = isNaN(rawPct) ? 0 : Math.max(0, Math.min(100, rawPct));

    return {
      ...stats,
      wordsLearned: learnedWords > 0 ? learnedWords : stats.wordsLearned,
      lessonsCompleted: completedLessons > 0 ? completedLessons : stats.lessonsCompleted,
      pct: safePct,
    };
  } catch (e) {
    console.error('Error computing pct stats:', e);
    return {
      ...stats,
      pct: typeof stats.pct === 'number' && !isNaN(stats.pct) ? stats.pct : 0,
    };
  }
}

export function formatStudyTime(minutes: number): string {
  if (isNaN(minutes) || minutes < 0) return '0 dk';
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs === 0) return `${mins} dk`;
  return `${hrs} sa ${mins} dk`;
}
