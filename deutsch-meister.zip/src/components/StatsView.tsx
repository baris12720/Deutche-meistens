import React from 'react';
import { useApp } from '../context/AppContext';
import { Award, Flame, BookOpen, CheckCircle2, TrendingUp, Trophy } from 'lucide-react';

export const StatsView: React.FC = () => {
  const { stats, badges } = useApp();

  const safeStats = stats || {
    streak: 1,
    totalXp: 120,
    wordsLearned: 0,
    lessonsCompleted: 0,
    examsCompleted: 0,
    pct: 0,
    studyMinutesToday: 15,
  };

  const safePct = typeof safeStats.pct === 'number' && !isNaN(safeStats.pct) ? Math.max(0, Math.min(100, safeStats.pct)) : 0;

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">İstatistikler ve Başarılar</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">Öğrenme performansınız ve kazanılan rozetler</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/50 flex items-center justify-center text-amber-500">
              <Flame className="w-5 h-5 fill-amber-500" />
            </div>
            <div>
              <div className="text-xs text-slate-400 font-semibold">Çalışma Serisi</div>
              <div className="text-xl font-bold text-slate-900 dark:text-slate-100">{safeStats.streak} Gün</div>
            </div>
          </div>
          <div className="text-xs text-emerald-600 font-medium">Seri devam ediyor! 🔥</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 dark:bg-orange-950/50 flex items-center justify-center text-orange-500">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400 font-semibold">Toplam XP</div>
              <div className="text-xl font-bold text-slate-900 dark:text-slate-100">{safeStats.totalXp} XP</div>
            </div>
          </div>
          <div className="text-xs text-orange-600 font-medium">Seviye atlıyorsun 🚀</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-500">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400 font-semibold">Öğrenilen Kelime</div>
              <div className="text-xl font-bold text-slate-900 dark:text-slate-100">{safeStats.wordsLearned}</div>
            </div>
          </div>
          <div className="text-xs text-emerald-600 font-medium">Kelime dağarcığı genişliyor</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 flex items-center justify-center text-cyan-500">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400 font-semibold">Tamamlanan Ders</div>
              <div className="text-xl font-bold text-slate-900 dark:text-slate-100">{safeStats.lessonsCompleted}</div>
            </div>
          </div>
          <div className="text-xs text-cyan-600 font-medium">Harika ilerleme 🎯</div>
        </div>
      </div>

      {/* Badges Section */}
      <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-orange-50 dark:bg-orange-950/50 flex items-center justify-center text-orange-500">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg">Başarı Rozetleri</h3>
            <p className="text-xs text-slate-500">Hedeflere ulaştıkça rozetleri açın</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {badges.map(badge => (
            <div
              key={badge.id}
              className={`p-5 rounded-2xl border transition flex flex-col items-center text-center ${
                badge.unlocked
                  ? 'bg-orange-50/50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-900/50'
                  : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-700 opacity-60'
              }`}
            >
              <div className="text-4xl mb-3">{badge.icon}</div>
              <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm mb-1">{badge.title}</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">{badge.description}</p>
              <span
                className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                  badge.unlocked
                    ? 'bg-orange-500 text-white'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {badge.unlocked ? 'Kazanıldı ✓' : 'Kilitli'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
