import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lesson } from '../types';
import { CheckCircle2, Clock, BookOpen, ArrowRight, Award, Volume2, RotateCcw } from 'lucide-react';

export const LessonsView: React.FC = () => {
  const { lessons, selectedLevel, completeLesson, speakText } = useApp();
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const filteredLessons = lessons.filter(l => l.level === selectedLevel);

  const handleQuizSubmit = () => {
    if (!activeLesson) return;
    let correctCount = 0;
    activeLesson.content.quiz.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctAnswer) {
        correctCount++;
      }
    });
    const score = Math.round((correctCount / activeLesson.content.quiz.length) * 100);
    setQuizScore(score);
    setQuizSubmitted(true);
    completeLesson(activeLesson.id, score);
  };

  const closeLessonModal = () => {
    setActiveLesson(null);
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  if (activeLesson) {
    return (
      <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
        <div className="flex items-center justify-between">
          <button
            onClick={closeLessonModal}
            className="flex items-center gap-2 text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-orange-500 transition"
          >
            ← Derslere Dön
          </button>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
            {activeLesson.level} • {activeLesson.category}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-2">{activeLesson.title}</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">{activeLesson.description}</p>
          </div>

          {/* Theory Section */}
          <div className="bg-orange-50/60 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900/40 rounded-2xl p-5">
            <h3 className="font-bold text-orange-800 dark:text-orange-300 mb-2 text-sm uppercase tracking-wide">Konu Anlatımı</h3>
            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{activeLesson.content.theory}</p>
          </div>

          {/* Examples */}
          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-3 text-sm uppercase tracking-wide">Örnek Cümleler</h3>
            <div className="space-y-3">
              {activeLesson.content.examples.map((ex, idx) => (
                <div key={idx} className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm">{ex.de}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{ex.tr}</div>
                  </div>
                  <button
                    onClick={() => speakText(ex.de)}
                    className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-300 flex items-center justify-center hover:scale-105 transition"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Quiz Section */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-4 text-sm uppercase tracking-wide">Ders Değerlendirme Testi</h3>

            {activeLesson.content.quiz.map((q, qIdx) => (
              <div key={qIdx} className="mb-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700">
                <p className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-3">
                  {qIdx + 1}. {q.question}
                </p>
                <div className="space-y-2">
                  {q.options.map((opt, oIdx) => {
                    const isSelected = quizAnswers[qIdx] === oIdx;
                    const isCorrect = q.correctAnswer === oIdx;
                    let btnStyle = 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300';
                    if (quizSubmitted) {
                      if (isCorrect) btnStyle = 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold';
                      else if (isSelected && !isCorrect) btnStyle = 'bg-red-50 dark:bg-red-950/40 border-red-500 text-red-700 dark:text-red-300';
                    } else if (isSelected) {
                      btnStyle = 'bg-orange-50 dark:bg-orange-950/40 border-orange-500 text-orange-700 dark:text-orange-300 font-bold';
                    }

                    return (
                      <button
                        key={oIdx}
                        disabled={quizSubmitted}
                        onClick={() => setQuizAnswers(prev => ({ ...prev, [qIdx]: oIdx }))}
                        className={`w-full text-left px-4 py-2.5 rounded-xl border text-sm transition ${btnStyle}`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
                {quizSubmitted && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 italic">
                    Açıklama: {q.explanation}
                  </p>
                )}
              </div>
            ))}

            {!quizSubmitted ? (
              <button
                onClick={handleQuizSubmit}
                className="w-full py-3.5 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-2xl transition shadow-lg shadow-orange-500/20"
              >
                Testi Tamamla ve Puanı Gör
              </button>
            ) : (
              <div className="text-center p-6 bg-orange-50 dark:bg-orange-950/30 rounded-2xl border border-orange-100 dark:border-orange-900/40 space-y-2">
                <div className="text-2xl font-black text-orange-600 dark:text-orange-400">
                  Puanınız: %{quizScore}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Ders başarıyla kaydedildi! XP puanınız eklendi.
                </p>
                <button
                  onClick={closeLessonModal}
                  className="mt-4 px-6 py-2.5 bg-orange-500 text-white rounded-xl font-semibold text-sm hover:bg-orange-600 transition"
                >
                  Derslere Geri Dön
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Ders Modülleri ({selectedLevel})</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">A1-C1 arası kapsamlı konu anlatımları ve pratikler</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredLessons.map(lesson => (
          <div
            key={lesson.id}
            onClick={() => setActiveLesson(lesson)}
            className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-orange-500/50 transition cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
                  {lesson.category.toUpperCase()}
                </span>
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{lesson.durationMinutes} dk</span>
                </div>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-2 group-hover:text-orange-600 transition">
                {lesson.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                {lesson.description}
              </p>
            </div>

            <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-semibold">
                {lesson.completed ? (
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" /> Tamamlandı (%{lesson.score || 100})
                  </span>
                ) : (
                  <span className="text-slate-400">Başlanmadı</span>
                )}
              </div>
              <div className="flex items-center gap-1 text-xs font-bold text-orange-600 group-hover:translate-x-1 transition-transform">
                <span>Dersi Aç</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
