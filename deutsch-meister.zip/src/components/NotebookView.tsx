import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bookmark, Volume2, Search, Trash2 } from 'lucide-react';

export const NotebookView: React.FC = () => {
  const { words, toggleWordLearned, speakText } = useApp();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredWords = words.filter(
    w =>
      w.german.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.turkish.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Kelime Defterim</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">Kaydettiğiniz ve öğrendiğiniz tüm Almanca kelimeler</p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-4 top-3.5 w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Kelime veya Türkçe anlam ara..."
          className="w-full pl-11 pr-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-sm"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredWords.map(word => (
          <div
            key={word.id}
            className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
                  {word.level} • {word.category}
                </span>
                <button
                  onClick={() => speakText(`${word.article || ''} ${word.german}`)}
                  className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-orange-50 hover:text-orange-600 transition"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-baseline gap-2 mb-1">
                {word.article && <span className="text-xs font-bold text-orange-500">{word.article}</span>}
                <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">{word.german}</h3>
              </div>
              <div className="text-sm font-semibold text-orange-600 dark:text-orange-400 mb-3">
                {word.turkish}
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 italic mb-4">
                "{word.exampleGerman}" ({word.exampleTurkish})
              </p>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-semibold text-slate-400">Leitner Kutu #{word.leitnerBox}</span>
              <button
                onClick={() => toggleWordLearned(word.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  word.learned
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {word.learned ? 'Öğrenildi ✓' : 'Öğrenilmedi'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
