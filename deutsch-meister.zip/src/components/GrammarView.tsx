import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GrammarTopic } from '../types';
import { FileText, CheckCircle2, ChevronRight, Volume2 } from 'lucide-react';

export const GrammarView: React.FC = () => {
  const { grammarTopics, selectedLevel, completeGrammar, speakText } = useApp();
  const [activeTopic, setActiveTopic] = useState<GrammarTopic | null>(null);

  const filteredTopics = grammarTopics.filter(g => g.level === selectedLevel);

  if (activeTopic) {
    return (
      <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
        <button
          onClick={() => setActiveTopic(null)}
          className="flex items-center gap-2 text-sm font-semibold text-slate-600 dark:text-slate-400 hover:text-orange-500 transition"
        >
          ← Gramer Konularına Dön
        </button>

        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
              {activeTopic.level} Gramer
            </span>
            <button
              onClick={() => {
                completeGrammar(activeTopic.id);
                alert('Konu tamamlandı olarak işaretlendi! XP kazandınız.');
              }}
              className="px-4 py-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-xl font-semibold text-xs hover:bg-emerald-100 transition flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Öğrendim İşaretle</span>
            </button>
          </div>

          <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{activeTopic.title}</h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">{activeTopic.summary}</p>

          <div className="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-2xl border border-slate-200/60 dark:border-slate-700">
            <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-2 text-sm uppercase tracking-wide">Detaylı Açıklama</h3>
            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{activeTopic.details}</p>
          </div>

          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-3 text-sm uppercase tracking-wide">Temel Kurallar</h3>
            <ul className="space-y-2">
              {activeTopic.rules.map((rule, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-700 dark:text-slate-300">
                  <span className="w-5 h-5 rounded-full bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-200 mb-3 text-sm uppercase tracking-wide">Örnekler</h3>
            <div className="space-y-3">
              {activeTopic.examples.map((ex, idx) => (
                <div key={idx} className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm">{ex.de}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{ex.tr}</div>
                  </div>
                  <button
                    onClick={() => speakText(ex.de)}
                    className="w-9 h-9 rounded-xl bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-300 flex items-center justify-center hover:scale-105 transition"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Gramer Rehberi ({selectedLevel})</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">Almanca dilbilgisi kuralları ve örnek tablolar</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTopics.map(topic => (
          <div
            key={topic.id}
            onClick={() => setActiveTopic(topic)}
            className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-orange-500/50 transition cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
                  {topic.level} Gramer
                </span>
                {topic.completed && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                )}
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-2 group-hover:text-orange-600 transition">
                {topic.title}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                {topic.summary}
              </p>
            </div>

            <div className="flex items-center justify-end pt-4 mt-4 border-t border-slate-100 dark:border-slate-800 text-xs font-bold text-orange-600 group-hover:translate-x-1 transition-transform">
              <span>Konuyu İncele</span>
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
