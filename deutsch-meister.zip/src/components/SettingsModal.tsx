import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Volume2, Moon, Sun, RotateCcw, Download, Sparkles } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { profile, updateProfile, resetAllData, speakText } = useApp();

  if (!isOpen) return null;

  const handleReset = () => {
    if (window.confirm('Tüm ilerlemeniz ve verileriniz sıfırlanacak. Emin misiniz?')) {
      resetAllData();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 dark:border-slate-800 relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Uygulama Ayarları</h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-6 space-y-6">
          {/* Profile Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Kullanıcı Adı
            </label>
            <input
              type="text"
              value={profile.name}
              onChange={e => updateProfile({ name: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-medium text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>

          {/* Theme selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Tema Modu
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => updateProfile({ theme: 'light' })}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-medium text-sm border transition ${
                  profile.theme === 'light'
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Aydınlık</span>
              </button>
              <button
                onClick={() => updateProfile({ theme: 'dark' })}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-medium text-sm border transition ${
                  profile.theme === 'dark'
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Karanlık</span>
              </button>
            </div>
          </div>

          {/* Audio settings */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                Ses ve Telaffuz
              </label>
              <button
                onClick={() => speakText('Guten Tag! Willkommen bei Deutsch Meister.')}
                className="text-xs text-orange-600 dark:text-orange-400 font-medium flex items-center gap-1 hover:underline"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Test Et</span>
              </button>
            </div>
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Sesli Telaffuz Efektleri</span>
              <input
                type="checkbox"
                checked={profile.soundEnabled}
                onChange={e => updateProfile({ soundEnabled: e.target.checked })}
                className="w-4 h-4 text-orange-600 rounded focus:ring-orange-500 border-slate-300 cursor-pointer"
              />
            </div>
          </div>

          {/* Danger Zone */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={handleReset}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-red-600 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 dark:hover:bg-red-900/40 font-medium text-sm transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Tüm Verileri Sıfırla</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
