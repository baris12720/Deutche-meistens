import React from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle, Clock, Target, ArrowRight } from 'lucide-react';

export const DailyPlan: React.FC = () => {
  const { stats, setActiveTab } = useApp();

  const safeMinutes = stats?.studyMinutesToday ?? 15;
  const goalMinutes = stats?.dailyGoalMinutes ?? 20;
  const progressPct = Math.min(100, Math.round((safeMinutes / goalMinutes) * 100));

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-100 dark:border-slate-800 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-50 dark:bg-orange-950/50 flex items-center justify-center text-orange-600 dark:text-orange-400">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Günlük Çalışma Hedefi</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Bugünkü hedefini tamamla, serini koru!</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
          <Clock className="w-3.5 h-3.5" />
          <span>{safeMinutes} / {goalMinutes} dk</span>
        </div>
      </div>

      <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 mb-5 overflow-hidden">
        <div
          className="bg-orange-500 h-full rounded-full transition-all duration-500"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => setActiveTab('vocab')}
          className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/30 border border-slate-200/60 dark:border-slate-700 transition group text-left"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-100 dark:bg-orange-900/50 flex items-center justify-center text-orange-600 dark:text-orange-300 text-sm">
              📚
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">5 Kelime Tekrarı</div>
              <div className="text-[11px] text-slate-500">Leitner kutusu</div>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-orange-500 transition-transform group-hover:translate-x-0.5" />
        </button>

        <button
          onClick={() => setActiveTab('lessons')}
          className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/30 border border-slate-200/60 dark:border-slate-700 transition group text-left"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center text-emerald-600 dark:text-emerald-300 text-sm">
              🎯
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">1 Ders Tamamla</div>
              <div className="text-[11px] text-slate-500">A1-C1 modülleri</div>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 transition-transform group-hover:translate-x-0.5" />
        </button>

        <button
          onClick={() => setActiveTab('ai')}
          className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/30 border border-slate-200/60 dark:border-slate-700 transition group text-left"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center text-indigo-600 dark:text-indigo-300 text-sm">
              🤖
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">AI Pratik Yap</div>
              <div className="text-[11px] text-slate-500">Yapay zekâ öğretmeni</div>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-500 transition-transform group-hover:translate-x-0.5" />
        </button>
      </div>
    </div>
  );
};
