import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Flame, Award, Settings, Sparkles, Volume2 } from 'lucide-react';
import { SettingsModal } from './SettingsModal';
import { CEFRLevel } from '../types';

export const Navbar: React.FC = () => {
  const { stats, selectedLevel, setSelectedLevel, profile } = useApp();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white font-black text-xl shadow-md shadow-orange-500/20">
              DM
            </div>
            <div>
              <h1 className="font-bold text-base sm:text-lg text-slate-900 dark:text-slate-100 leading-tight">
                Deutsch Meister
              </h1>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Profesyonel Almanca Platformu
              </p>
            </div>
          </div>

          {/* Level Selector */}
          <div className="hidden md:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {levels.map(lvl => (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  selectedLevel === lvl
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          {/* Stats & Settings */}
          <div className="flex items-center gap-3">
            {/* Streak */}
            <div className="flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 px-3 py-1.5 rounded-full text-xs font-bold border border-amber-200/60 dark:border-amber-900/50">
              <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
              <span>{stats?.streak ?? 1} Gün</span>
            </div>

            {/* XP */}
            <div className="hidden sm:flex items-center gap-1.5 bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 px-3 py-1.5 rounded-full text-xs font-bold border border-orange-200/60 dark:border-orange-900/50">
              <Award className="w-4 h-4" />
              <span>{stats?.totalXp ?? 0} XP</span>
            </div>

            {/* Settings Button */}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              title="Ayarlar"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
    </>
  );
};
