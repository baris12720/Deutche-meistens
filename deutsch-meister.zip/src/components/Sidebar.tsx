import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, BookOpen, GraduationCap, FileText, CheckSquare, MessageSquareText, Bookmark, BarChart3, Sparkles } from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  const navItems = [
    { id: 'home', label: 'Ana Sayfa', icon: Home },
    { id: 'vocab', label: 'Kelimeler', icon: BookOpen },
    { id: 'lessons', label: 'Dersler', icon: GraduationCap },
    { id: 'grammar', label: 'Gramer', icon: FileText },
    { id: 'exams', label: 'Sınavlar', icon: CheckSquare },
    { id: 'ai', label: 'AI Öğretmen', icon: Sparkles },
    { id: 'notebook', label: 'Kelime Defteri', icon: Bookmark },
    { id: 'stats', label: 'İstatistikler', icon: BarChart3 },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 p-4 space-y-2 bg-white/60 dark:bg-slate-900/60 backdrop-blur-md border-r border-slate-200/80 dark:border-slate-800 min-h-[calc(100vh-4rem)]">
        <div className="px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
          Menü
        </div>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-semibold text-sm transition ${
                isActive
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </aside>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-2 flex items-center justify-around shadow-lg">
        {navItems.slice(0, 5).map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-1 p-2 rounded-xl transition ${
                isActive
                  ? 'text-orange-500'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => setActiveTab('ai')}
          className={`flex flex-col items-center gap-1 p-2 rounded-xl transition ${
            activeTab === 'ai' ? 'text-orange-500' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span className="text-[10px] font-medium">AI Pratik</span>
        </button>
      </div>
    </>
  );
};
