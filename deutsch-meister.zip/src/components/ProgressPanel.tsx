import React from 'react';
import { useApp } from '../context/AppContext';
import { Award, Flame, BookOpen, CheckCircle2, TrendingUp } from 'lucide-react';

export const ProgressPanel: React.FC = () => {
  const { stats } = useApp();

  // Bulletproof safety checks as requested by user for 'pct' and stats
  const safeStats = stats || {
    streak: 1,
    totalXp: 120,
    wordsLearned: 0,
    lessonsCompleted: 0,
    examsCompleted: 0,
    pct: 0,
    studyMinutesToday: 15,
    dailyGoalMinutes: 20,
  };

  const safePct = typeof safeStats.pct === 'number' && !isNaN(safeStats.pct)
    ? Math.max(0, Math.min(100, safeStats.pct))
    : 0;

  return (
    <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
      <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full blur-xl pointer-events-none" />
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium w-fit mb-2">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Genel İlerleme Durumu</span>
          </div>
          <h2 className="text-2xl font-bold">Harika Gidiyorsun!</h2>
          <p className="text-white/80 text-sm mt-1">
            Almanca öğrenme yolculuğunda %{safePct} tamamlandı. Hedefine her gün biraz daha yaklaşıyorsun.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full md:w-auto">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 text-amber-200 mb-1">
              <Flame className="w-4 h-4 fill-amber-200" />
              <span className="text-xs font-semibold">Seri</span>
            </div>
            <div className="text-xl font-bold">{safeStats.streak} Gün</div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 text-yellow-200 mb-1">
              <Award className="w-4 h-4" />
              <span className="text-xs font-semibold">XP Puan</span>
            </div>
            <div className="text-xl font-bold">{safeStats.totalXp}</div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 text-emerald-200 mb-1">
              <BookOpen className="w-4 h-4" />
              <span className="text-xs font-semibold">Kelime</span>
            </div>
            <div className="text-xl font-bold">{safeStats.wordsLearned}</div>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 text-cyan-200 mb-1">
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-xs font-semibold">Ders</span>
            </div>
            <div className="text-xl font-bold">{safeStats.lessonsCompleted}</div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <div className="flex justify-between text-xs font-medium mb-1.5 text-white/90">
          <span>Seviye İlerleme Çubuğu</span>
          <span>%{safePct}</span>
        </div>
        <div className="w-full bg-black/20 rounded-full h-3 overflow-hidden p-0.5 border border-white/10">
          <div
            className="bg-white h-full rounded-full transition-all duration-700 shadow-sm"
            style={{ width: `${safePct}%` }}
          />
        </div>
      </div>
    </div>
  );
};
