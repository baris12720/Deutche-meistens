import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Volume2, ChevronLeft, ChevronRight, Check, RotateCw, Plus } from 'lucide-react';

export const VocabView: React.FC = () => {
  const { words, selectedLevel, updateWordLeitner, speakText, addWord } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // New word form state
  const [newGerman, setNewGerman] = useState('');
  const [newArticle, setNewArticle] = useState<'der' | 'die' | 'das'>('der');
  const [newTurkish, setNewTurkish] = useState('');
  const [newCategory, setNewCategory] = useState('Genel');
  const [newExampleDe, setNewExampleDe] = useState('');
  const [newExampleTr, setNewExampleTr] = useState('');

  const filteredWords = words.filter(w => w.level === selectedLevel);
  const currentWord = filteredWords[currentIndex] || filteredWords[0];

  const handleNext = (boxDelta: number) => {
    if (currentWord) {
      updateWordLeitner(currentWord.id, boxDelta);
    }
    setIsFlipped(false);
    if (currentIndex < filteredWords.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGerman.trim() || !newTurkish.trim()) return;
    addWord({
      german: newGerman.trim(),
      article: newArticle,
      turkish: newTurkish.trim(),
      level: selectedLevel,
      category: newCategory.trim() || 'Genel',
      exampleGerman: newExampleDe.trim() || `${newArticle} ${newGerman} ist gut.`,
      exampleTurkish: newExampleTr.trim() || `${newTurkish} iyidir.`,
    });
    setNewGerman('');
    setNewTurkish('');
    setNewExampleDe('');
    setNewExampleTr('');
    setShowAddModal(false);
  };

  if (!filteredWords || filteredWords.length === 0) {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800">
        <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-2">Bu seviyede kelime bulunamadı</h3>
        <p className="text-slate-500 text-sm mb-4">Yeni kelime ekleyerek kelime defterinizi zenginleştirebilirsiniz.</p>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-orange-500 text-white rounded-xl font-semibold text-sm hover:bg-orange-600 transition"
        >
          Kelime Ekle
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Kelime Kartları ({selectedLevel})</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">Leitner kutusu ile akıllı kelime tekrar sistemi</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm transition shadow-md shadow-orange-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>Yeni Kelime</span>
        </button>
      </div>

      {/* Flashcard container */}
      <div className="max-w-xl mx-auto">
        <div
          onClick={() => setIsFlipped(!isFlipped)}
          className={`bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-100 dark:border-slate-800 shadow-xl cursor-pointer min-h-[320px] flex flex-col items-center justify-center text-center relative transition-all duration-300 transform hover:scale-[1.01]`}
        >
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-orange-50 dark:bg-orange-950/50 text-orange-600 dark:text-orange-400">
              Kutu #{currentWord.leitnerBox}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
              {currentIndex + 1} / {filteredWords.length}
            </span>
          </div>

          <button
            onClick={e => {
              e.stopPropagation();
              speakText(`${currentWord.article || ''} ${currentWord.german}`);
            }}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-orange-50 hover:text-orange-600 transition"
          >
            <Volume2 className="w-5 h-5" />
          </button>

          {!isFlipped ? (
            <div className="space-y-3">
              {currentWord.article && (
                <div className="text-sm font-bold text-orange-500 uppercase tracking-widest">
                  {currentWord.article}
                </div>
              )}
              <h3 className="text-4xl font-black text-slate-900 dark:text-slate-100">
                {currentWord.german}
              </h3>
              {currentWord.plural && (
                <p className="text-xs text-slate-400">Plural: {currentWord.plural}</p>
              )}
              <p className="text-xs text-slate-400 pt-6">Anlamı görmek için karta tıklayın</p>
            </div>
          ) : (
            <div className="space-y-4 animate-in fade-in">
              <h3 className="text-3xl font-bold text-orange-600 dark:text-orange-400">
                {currentWord.turkish}
              </h3>
              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl max-w-md mx-auto text-left border border-slate-100 dark:border-slate-700">
                <p className="text-sm text-slate-800 dark:text-slate-200 font-medium">
                  {currentWord.exampleGerman}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  {currentWord.exampleTurkish}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 mt-6">
          <button
            onClick={() => handleNext(-1)}
            className="py-3 px-4 rounded-2xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-bold text-sm hover:bg-red-100 transition border border-red-200/60"
          >
            ❌ Yeniden Çalış (-1 Kutu)
          </button>
          <button
            onClick={() => handleNext(1)}
            className="py-3 px-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-bold text-sm hover:bg-emerald-100 transition border border-emerald-200/60"
          >
            ✅ Bildim (+1 Kutu)
          </button>
        </div>
      </div>

      {/* Add Word Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 dark:border-slate-800">
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4">Yeni Kelime Ekle</h3>
            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Artikül</label>
                  <select
                    value={newArticle}
                    onChange={e => setNewArticle(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium"
                  >
                    <option value="der">der</option>
                    <option value="die">die</option>
                    <option value="das">das</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Almanca Kelime</label>
                  <input
                    type="text"
                    required
                    value={newGerman}
                    onChange={e => setNewGerman(e.target.value)}
                    placeholder="örn. Apfel"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Türkçe Anlamı</label>
                <input
                  type="text"
                  required
                  value={newTurkish}
                  onChange={e => setNewTurkish(e.target.value)}
                  placeholder="örn. Elma"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Örnek Cümle (Almanca)</label>
                <input
                  type="text"
                  value={newExampleDe}
                  onChange={e => setNewExampleDe(e.target.value)}
                  placeholder="örn. Ich esse einen Apfel."
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 mb-1">Örnek Cümle (Türkçe)</label>
                <input
                  type="text"
                  value={newExampleTr}
                  onChange={e => setNewExampleTr(e.target.value)}
                  placeholder="örn. Bir elma yiyorum."
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm font-medium"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-sm hover:bg-slate-200 transition"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-orange-500 text-white font-semibold text-sm hover:bg-orange-600 transition shadow-md shadow-orange-500/20"
                >
                  Kaydet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
