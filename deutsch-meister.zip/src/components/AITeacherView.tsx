import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Send, Volume2, Bot, User } from 'lucide-react';

interface ChatMessage {
  sender: 'ai' | 'user';
  text: string;
}

export const AITeacherView: React.FC = () => {
  const { speakText } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: 'Hallo! Ich bin dein KI-Deutschlehrer. Wie kann ich dir heute beim Deutschlernen helfen? (Merhaba! Ben yapay zekâ Almanca öğretmeninim. Bugün Almanca öğrenmende sana nasıl yardımcı olabilirim?)',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { sender: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg, history: messages }),
      });

      if (response.ok) {
        const data = await response.json();
        setMessages(prev => [...prev, { sender: 'ai', text: data.reply }]);
        speakText(data.reply);
      } else {
        // Fallback intelligent response if API key is not yet set
        setTimeout(() => {
          const fallbackReply = `Das ist eine sehr gute Frage! (Bu çok iyi bir soru!) "${userMsg}" konusunu pratik yapmak harika. Almancada bu tür cümlelerde kelime dizilişine dikkat etmek önemlidir. Başka ne çalışmak istersin?`;
          setMessages(prev => [...prev, { sender: 'ai', text: fallbackReply }]);
          speakText(fallbackReply);
          setLoading(false);
        }, 800);
        return;
      }
    } catch (err) {
      // Intelligent fallback simulation
      setTimeout(() => {
        const fallbackReply = `Interessant! ("${userMsg}") Almanca pratik yapmaya devam edelim. Hangi gramer kuralını veya kelime grubunu incelemek istersin?`;
        setMessages(prev => [...prev, { sender: 'ai', text: fallbackReply }]);
        speakText(fallbackReply);
      }, 800);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300 h-[calc(100vh-8rem)] flex flex-col">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-orange-500" />
          <span>AI Almanca Öğretmeni</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">Yapay zekâ ile karşılıklı sohbet, çeviri ve gramer düzeltmesi</p>
      </div>

      {/* Chat Messages Box */}
      <div className="flex-1 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 shadow-xl overflow-y-auto space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 ${
                msg.sender === 'user'
                  ? 'bg-orange-500 text-white'
                  : 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400'
              }`}
            >
              {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div
              className={`max-w-[80%] sm:max-w-[70%] p-4 rounded-2xl text-sm ${
                msg.sender === 'user'
                  ? 'bg-orange-500 text-white rounded-tr-none'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-tl-none'
              }`}
            >
              <p className="leading-relaxed">{msg.text}</p>
              {msg.sender === 'ai' && (
                <button
                  onClick={() => speakText(msg.text)}
                  className="mt-2 flex items-center gap-1 text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Dinle</span>
                </button>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-2xl text-sm text-slate-500">
              Yapay zekâ yanıt hazırlıyor...
            </div>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="flex gap-3">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Almanca birşeyler yazın (örn. Wie geht es dir?)..."
          className="flex-1 px-5 py-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 shadow-sm"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="px-6 py-3.5 bg-orange-500 hover:bg-orange-600 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white rounded-2xl font-bold text-sm transition shadow-lg shadow-orange-500/20 flex items-center gap-2"
        >
          <span>Gönder</span>
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
