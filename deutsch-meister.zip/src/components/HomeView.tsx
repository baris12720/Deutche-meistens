import React from 'react';
import { useApp } from '../context/AppContext';
import { ProgressPanel } from './ProgressPanel';
import { DailyPlan } from './DailyPlan';
import { BookOpen, GraduationCap, FileText, CheckSquare, Sparkles, ArrowRight, Volume2 } from 'lucide-react';

export const HomeView: React.FC = () => {
  const { setActiveTab, words, lessons, speakText, selectedLevel } = useApp();

  const levelWords = words.filter(w => w.level === selectedLevel);
  const levelLessons = lessons.filter(l => l.level === selectedLevel);

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <ProgressPanel />

      <DailyPlan />

      {/* Quick Access Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setActiveTab('vocab')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-orange-500/50 transition cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-2xl bg-orange-50 dark:bg-orange-950/50 flex items-center justify-center text-orange-600 dark:text-orange-400 mb-4 group-hover:scale-110 transition-transform">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">Kelime Kartları</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            {selectedLevel} seviyesinde {levelWords.length} kelime seni bekliyor.
          </p>
          <div className="flex items-center gap-1 text-xs font-semibold text-orange-600 dark:text-orange-400 group-hover:translate-x-1 transition-transform">
            <span>Çalışmaya Başla</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        <div
          onClick={() => setActiveTab('lessons')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-emerald-500/50 transition cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
            <GraduationCap className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">Ders Modülleri</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            {levelLessons.length} interaktif ders ve test modülü.
          </p>
          <div className="flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform">
            <span>Derslere Git</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        <div
          onClick={() => setActiveTab('exams')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-cyan-500/50 transition cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 flex items-center justify-center text-cyan-600 dark:text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
            <CheckSquare className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">Goethe & DTZ Sınavları</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Gerçek sınav formatında okuma ve dinleme testleri.
          </p>
          <div className="flex items-center gap-1 text-xs font-semibold text-cyan-600 dark:text-cyan-400 group-hover:translate-x-1 transition-transform">
            <span>Sınav Simülasyonu</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        <div
          onClick={() => setActiveTab('ai')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm hover:border-indigo-500/50 transition cursor-pointer group"
        >
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center text-indigo-600 dark:text-indigo-400 mb-4 group-hover:scale-110 transition-transform">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">AI Almanca Öğretmeni</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Yapay zekâ ile karşılıklı diyalog ve telaffuz pratiği.
          </p>
          <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform">
            <span>Sohbet Başlat</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Featured Word of the Day */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-orange-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-orange-400 text-xs font-semibold uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Günün Örnek Kelimesi</span>
            </div>
            <div className="flex items-baseline gap-2">
              <h2 className="text-3xl font-ext500 font-bold">das Haus</h2>
              <span className="text-slate-400 text-sm">(Ev)</span>
            </div>
            <p className="text-slate-300 text-sm mt-2 italic">
              "Das Haus ist groß und modern." (Ev büyük ve modern.)
            </p>
          </div>
          <button
            onClick={() => speakText('Das Haus ist groß und modern.')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm transition shadow-lg shadow-orange-500/20"
          >
            <Volume2 className="w-4 h-4" />
            <span>Telaffuz Et</span>
          </button>
        </div>
      </div>
    </div>
  );
};
