import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CheckSquare, Award, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';

export const ExamView: React.FC = () => {
  const { exams, selectedLevel } = useApp();
  const [selectedExamId, setSelectedExamId] = useState<string | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const filteredExams = exams.filter(e => e.level === selectedLevel);
  const currentExam = exams.find(e => e.id === selectedExamId) || filteredExams[0];

  return (
    <div className="space-y-6 pb-20 lg:pb-6 animate-in fade-in duration-300">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Goethe & DTZ Sınav Simülasyonu</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">Resmi sınav formatında okuma, dinleme ve yazma alıştırmaları</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Exam List */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Sınav Soruları</h3>
          {exams.map(exam => (
            <div
              key={exam.id}
              onClick={() => {
                setSelectedExamId(exam.id);
                setSelectedAnswer(null);
                setSubmitted(false);
              }}
              className={`p-4 rounded-2xl border transition cursor-pointer ${
                (!selectedExamId && exam.id === exams[0].id) || selectedExamId === exam.id
                  ? 'bg-orange-50 dark:bg-orange-950/40 border-orange-500 shadow-sm'
                  : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-orange-100 dark:bg-orange-900/50 text-orange-600 dark:text-orange-300 uppercase">
                  {exam.type} • {exam.section}
                </span>
                <span className="text-[11px] font-semibold text-slate-500">{exam.level}</span>
              </div>
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">{exam.title}</h4>
            </div>
          ))}
        </div>

        {/* Active Exam Details */}
        <div className="md:col-span-2 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-xl space-y-6">
          {currentExam ? (
            <>
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div>
                  <span className="text-xs font-bold text-orange-600 uppercase tracking-wider">
                    {currentExam.type.toUpperCase()} - {currentExam.section}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100 mt-0.5">{currentExam.title}</h3>
                </div>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                  {currentExam.level}
                </span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200/60 dark:border-slate-700 whitespace-pre-line text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                {currentExam.prompt}
              </div>

              {currentExam.options && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Seçenekler</h4>
                  {currentExam.options.map((opt, idx) => {
                    const isSelected = selectedAnswer === idx;
                    const isCorrect = currentExam.correctAnswer === idx;
                    let btnStyle = 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300';
                    if (submitted) {
                      if (isCorrect) btnStyle = 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold';
                      else if (isSelected && !isCorrect) btnStyle = 'bg-red-50 dark:bg-red-950/40 border-red-500 text-red-700 dark:text-red-300';
                    } else if (isSelected) {
                      btnStyle = 'bg-orange-50 dark:bg-orange-950/40 border-orange-500 text-orange-700 dark:text-orange-300 font-bold';
                    }

                    return (
                      <button
                        key={idx}
                        disabled={submitted}
                        onClick={() => setSelectedAnswer(idx)}
                        className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition ${btnStyle}`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              )}

              {currentExam.sampleAnswer && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Örnek Yanıt / Çözüm</h4>
                  <div className="p-4 rounded-2xl bg-orange-50/60 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900/40 text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line font-medium">
                    {currentExam.sampleAnswer}
                  </div>
                </div>
              )}

              {currentExam.options && !submitted && (
                <button
                  disabled={selectedAnswer === null}
                  onClick={() => setSubmitted(true)}
                  className={`w-full py-3 rounded-2xl font-bold text-sm text-white transition shadow-lg ${
                    selectedAnswer === null
                      ? 'bg-slate-300 dark:bg-slate-800 cursor-not-allowed'
                      : 'bg-orange-500 hover:bg-orange-600 shadow-orange-500/20'
                  }`}
                >
                  Cevabı Kontrol Et
                </button>
              )}

              {submitted && currentExam.explanation && (
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300">
                  <span className="font-bold text-slate-800 dark:text-slate-100">Açıklama: </span>
                  {currentExam.explanation}
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 text-slate-400">Lütfen bir sınav sorusu seçin.</div>
          )}
        </div>
      </div>
    </div>
  );
};
