export type CEFRLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export interface Word {
  id: string;
  german: string;
  article?: 'der' | 'die' | 'das';
  plural?: string;
  turkish: string;
  level: CEFRLevel;
  category: string;
  exampleGerman: string;
  exampleTurkish: string;
  leitnerBox: number; // 1 to 5
  learned: boolean;
  notes?: string;
}

export interface Lesson {
  id: string;
  level: CEFRLevel;
  title: string;
  description: string;
  category: 'kelime' | 'gramer' | 'okuma' | 'dinleme' | 'konusma';
  durationMinutes: number;
  completed: boolean;
  score?: number;
  content: {
    theory: string;
    examples: { de: string; tr: string }[];
    quiz: {
      question: string;
      options: string[];
      correctAnswer: number;
      explanation: string;
    }[];
  };
}

export interface GrammarTopic {
  id: string;
  level: CEFRLevel;
  title: string;
  summary: string;
  details: string;
  rules: string[];
  examples: { de: string; tr: string }[];
  completed: boolean;
}

export interface ExamQuestion {
  id: string;
  type: 'goethe' | 'dtz';
  level: CEFRLevel;
  section: 'Lesen' | 'Hören' | 'Schreiben' | 'Sprechanregung';
  title: string;
  prompt: string;
  options?: string[];
  correctAnswer?: number | string;
  sampleAnswer?: string;
  explanation: string;
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
}

export interface DailyTask {
  id: string;
  title: string;
  target: number;
  current: number;
  completed: boolean;
  rewardXp: number;
}

export interface UserStats {
  streak: number;
  lastActiveDate: string;
  totalXp: number;
  wordsLearned: number;
  lessonsCompleted: number;
  examsCompleted: number;
  pct: number; // Safe overall completion percentage (0-100)
  studyMinutesToday: number;
  dailyGoalMinutes: number;
}

export interface UserProfile {
  name: string;
  level: CEFRLevel;
  theme: 'light' | 'dark' | 'system';
  soundEnabled: boolean;
  speechSpeed: number;
}
