/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { HomeView } from './components/HomeView';
import { VocabView } from './components/VocabView';
import { LessonsView } from './components/LessonsView';
import { GrammarView } from './components/GrammarView';
import { ExamView } from './components/ExamView';
import { AITeacherView } from './components/AITeacherView';
import { NotebookView } from './components/NotebookView';
import { StatsView } from './components/StatsView';

function MainLayout() {
  const { activeTab, profile } = useApp();

  // Apply dark mode class to html root if profile.theme is dark
  React.useEffect(() => {
    if (profile.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [profile.theme]);

  const renderView = () => {
    switch (activeTab) {
      case 'home':
        return <HomeView />;
      case 'vocab':
        return <VocabView />;
      case 'lessons':
        return <LessonsView />;
      case 'grammar':
        return <GrammarView />;
      case 'exams':
        return <ExamView />;
      case 'ai':
        return <AITeacherView />;
      case 'notebook':
        return <NotebookView />;
      case 'stats':
        return <StatsView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white">
      <Navbar />
      <div className="max-w-7xl mx-auto w-full flex-1 flex">
        <Sidebar />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {renderView()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
