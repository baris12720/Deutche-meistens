import { GrammarTopic } from '../types';

export const INITIAL_GRAMMAR_TOPICS: GrammarTopic[] = [
  {
    id: 'g1',
    level: 'A1',
    title: 'İsimler ve Artikeller (der, die, das)',
    summary: 'Almancada her ismin bir cinsiyeti (maskulin, feminin, nötr) vardır.',
    details: 'Almancada isimlerin başındaki artikeller kelimenin cinsiyetini belirtir. Erkekler için der, kadınlar için die, nötrler için das kullanılır. Çoğullarda her zaman die kullanılır.',
    rules: [
      'Erkek meslekler ve günler/aylar genellikle "der" alır.',
      'Dişil kelimeler genellikle -e ile biter ve "die" alır.',
      'Küçültme ekleri (-chen, -lein) ve renkler "das" alır.'
    ],
    examples: [
      { de: 'der Tisch (masa)', tr: 'Erkek cinsiyetli nesne' },
      { de: 'die Lampe (lamba)', tr: 'Dişil cinsiyetli nesne' },
      { de: 'das Auto (araba)', tr: 'Nötr cinsiyetli nesne' }
    ],
    completed: true,
  },
  {
    id: 'g2',
    level: 'A2',
    title: 'Yön ve Yer Edatları (Wechselpräpositionen)',
    summary: 'Dativ ve Akkusativ alan çift yönlü edatlar (an, auf, in vb.).',
    details: 'Bu edatlar "Wohin? (Nereye?)" sorusuna cevap verirse Akkusativ, "Wo? (Nerede?)" sorusuna cevap verirse Dativ ile kullanılır.',
    rules: [
      'Wo? -> Dativ (Bulunma)',
      'Wohin? -> Akkusativ (Yönelme)'
    ],
    examples: [
      { de: 'Ich bin in dem Zimmer. (Wo?)', tr: 'Odadayım.' },
      { de: 'Ich gehe in das Zimmer. (Wohin?)', tr: 'Odaya gidiyorum.' }
    ],
    completed: false,
  },
  {
    id: 'g3',
    level: 'B1',
    title: 'Bağlaçlar: deshalb, trotzdem, obwohl',
    summary: 'Yan cümle ve koordinasyon bağlaçları ile karmaşık cümleler kurma.',
    details: 'Almancada sebep, sonuç ve zıtlık bildirmek için farklı bağlaçlar kullanılır. Bazıları kelime sırasını değiştirmezken (deshalb bağlacı özneden önce gelebilir), obwohl yan cümlenin sonuna fiili atar.',
    rules: [
      'obwohl: ... rağmen (Fiil sona gider)',
      'deshalb: bu yüzden (Cümle başı veya özne-fiil yer değişimi)'
    ],
    examples: [
      { de: 'Obwohl es regnet, spiele ich Fußball.', tr: 'Yağmur yağmasına rağmen futbol oynuyorum.' }
    ],
    completed: false,
  }
];
