import { ExamQuestion, Badge } from '../types';

export const INITIAL_EXAMS: ExamQuestion[] = [
  {
    id: 'e1',
    type: 'goethe',
    level: 'A2',
    section: 'Lesen',
    title: 'E-Mail Anlaşma ve Duyurular',
    prompt: 'Metni okuyun ve doğru seçeneği işaretleyin:\n"Liebe Anna, ich kann leider am Freitag nicht zum Geburtstag kommen, weil ich arbeiten muss. Tut mir leid!"',
    options: [
      'Anna hat Geburtstag und feiert am Freitag.',
      'Der Schreiber kann am Freitag wegen der Arbeit nicht kommen.',
      'Anna arbeitet am Freitag.'
    ],
    correctAnswer: 1,
    explanation: 'Metinde yazarın işi olduğu için cuma günü katılamayacağı belirtilmektedir.'
  },
  {
    id: 'e2',
    type: 'dtz',
    level: 'B1',
    section: 'Hören',
    title: 'İstasyon Anonsu (Ansage am Bahnhof)',
    prompt: 'Dinleme simülasyonu: "Achtung auf Gleis 4! Der ICE 582 nach München hat 20 Minuten Verspätung."',
    options: [
      'Tren zamanında kalkıyor.',
      'Münih treni 20 dakika gecikmeli.',
      'Tren 4 numaralı perondan kalkmıyor.'
    ],
    correctAnswer: 1,
    explanation: 'Anansta 20 Minuten Verspätung (20 dakika gecikme) olduğu söylenmektedir.'
  },
  {
    id: 'e3',
    type: 'goethe',
    level: 'B1',
    section: 'Schreiben',
    title: 'Resmi Olmayan Mektup (E-Mail schreiben)',
    prompt: 'Arkadaşınıza hafta sonu planınız hakkında Almanca kısa bir e-posta yazın (en az 30 kelime).',
    sampleAnswer: 'Liebe Maria,\nwie geht es dir? Am Wochenende möchte ich einen Ausflug in die Berge machen. Hast du am Samstag Zeit und Lust, mitzukommen?\nViele Grüße,\nMehmet',
    explanation: 'Selamlama, davet nedeni, zaman ve kapanış cümleleri eksiksiz olmalıdır.'
  }
];

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'b1',
    title: 'İlk Adım',
    description: 'İlk Almanca dersini başarıyla tamamla.',
    icon: '🎯',
    unlocked: true,
    unlockedAt: '2026-11-01'
  },
  {
    id: 'b2',
    title: 'Kelime Avcısı',
    description: 'Koleksiyonuna 10 yeni kelime ekle.',
    icon: '📚',
    unlocked: true,
    unlockedAt: '2026-11-05'
  },
  {
    id: 'b3',
    title: 'Seri Ustası',
    description: '5 gün üst üste kesintisiz çalış.',
    icon: '🔥',
    unlocked: false
  },
  {
    id: 'b4',
    title: 'Goethe Uzmanı',
    description: 'B1 Sınav simülasyonundan %80 ve üzeri al.',
    icon: '🎓',
    unlocked: false
  }
];
