import { Lesson } from '../types';

export const INITIAL_LESSONS: Lesson[] = [
  {
    id: 'l1',
    level: 'A1',
    title: 'Alfabe ve Telaffuz (Alphabet & Aussprache)',
    description: 'Almanca sesler, özel harfler (ä, ö, ü, ß) ve temel tanışma kalıpları.',
    category: 'kelime',
    durationMinutes: 10,
    completed: true,
    score: 100,
    content: {
      theory: 'Almanca alfabesinde 26 standart harfin yanı sıra Ä, Ö, Ü ve ß (Eszett) karakterleri bulunur. Harfler genellikle yazıldığı gibi okunur.',
      examples: [
        { de: 'Guten Tag! Wie geht es Ihnen?', tr: 'İyi günler! Nasılsınız?' },
        { de: 'Ich heiße Mehmet.', tr: 'Benim adım Mehmet.' },
        { de: 'Freut mich.', tr: 'Memnun oldum.' }
      ],
      quiz: [
        {
          question: 'Almanca "ß" harfi hangi ses grubuna karşılık gelir?',
          options: ['ss', 'ch', 'sch', 'st'],
          correctAnswer: 0,
          explanation: 'ß harfi uzun ünlülerin ardından çift s (ss) sesi verir.'
        },
        {
          question: '"Guten Morgen" ne anlama gelir?',
          options: ['İyi akşamlar', 'Günaydın', 'İyi geceler', 'Hoşça kal'],
          correctAnswer: 1,
          explanation: 'Guten Morgen sabah saatlerinde söylenen günaydın demektir.'
        }
      ]
    }
  },
  {
    id: 'l2',
    level: 'A1',
    title: 'Fiil Çekimleri (Präsens - Geniş Zaman)',
    description: 'Düzenli ve düzensiz fiillerin şimdiki zaman/geniş zaman çekimleri.',
    category: 'gramer',
    durationMinutes: 15,
    completed: true,
    score: 90,
    content: {
      theory: 'Almancada düzenli fiiller şhıs zamirlerine göre -e, -st, -t, -en, -t, -en eklerini alarak çekimlenir. Örn: lernen (öğrenmek).',
      examples: [
        { de: 'Ich lerne Deutsch.', tr: 'Ben Almanca öğreniyorum.' },
        { de: 'Du sprichst gut Englisch.', tr: 'Sen iyi İngilizce konuşuyorsun.' },
        { de: 'Er wohnt in Berlin.', tr: 'O, Berlin’de yaşıyor.' }
      ],
      quiz: [
        {
          question: '"Wir (kommen) aus der Türkei" cümlesinde fiilin doğru çekimi nedir?',
          options: ['komme', 'kommst', 'kommen', 'kommt'],
          correctAnswer: 2,
          explanation: 'Wir (biz) zamiri ile fiil mastar haliyle (kommen) aynı kalır.'
        }
      ]
    }
  },
  {
    id: 'l3',
    level: 'A2',
    title: 'Geçmiş Zaman: Perfekt',
    description: 'Geçmişte yapılmış eylemleri anlatmak için haben / sein ve Partizip II yapısı.',
    category: 'gramer',
    durationMinutes: 20,
    completed: false,
    content: {
      theory: 'Perfekt zaman, yardımcı fiil (haben veya sein) ve ana fiilin 3. hali (Partizip II) ile kurulur. Genellikle hareket bildiren veya durum değişimi olan fiiller "sein" ile çekimlenir.',
      examples: [
        { de: 'Ich habe gestern ein Buch gelesen.', tr: 'Dün bir kitap okudum.' },
        { de: 'Wir sind nach München gefahren.', tr: 'Münih’e gittik (seyahat ettik).' }
      ],
      quiz: [
        {
          question: '"gehen" fiili Perfekt yapılırken hangi yardımcı fiili alır?',
          options: ['haben', 'sein', 'werden', 'tun'],
          correctAnswer: 1,
          explanation: 'Yer değiştiren ve hareket bildiren intransitif fiiller sein ile çekimlenir.'
        }
      ]
    }
  },
  {
    id: 'l4',
    level: 'B1',
    title: 'İlgi Cümlecikleri (Relativsätze)',
    description: 'İsimleri niteleyen yan cümleler ve Nominativ, Akkusativ, Dativ durumları.',
    category: 'gramer',
    durationMinutes: 25,
    completed: false,
    content: {
      theory: 'Relativsätze (İlgi Cümlecikleri), ana cümledeki bir ismi daha ayrıntılı açıklamak için kullanılır. Fiil her zaman yan cümlenin en sonuna gider.',
      examples: [
        { de: 'Das ist der Mann, den ich gestern gesehen habe.', tr: 'Bu, dün gördüğüm adamdır.' },
        { de: 'Das Buch, das auf dem Tisch liegt, ist interessant.', tr: 'Masa üzerinde duran kitap ilginçtir.' }
      ],
      quiz: [
        {
          question: '"Der Computer, ... ich gekauft habe, ist schnell." boşluğa ne gelmelidir?',
          options: ['der', 'den', 'dem', 'das'],
          correctAnswer: 1,
          explanation: 'Der Computer kelimesi Akkusativ durumda erkek nesne olduğu için "den" zamiri gelir.'
        }
      ]
    }
  },
  {
    id: 'l5',
    level: 'B2',
    title: 'Dilek ve Şart Kipi: Konjunktiv II',
    description: 'Nezaket ifadeleri, varsayımlar ve gerçekleşmemiş geçmiş durumlar.',
    category: 'gramer',
    durationMinutes: 30,
    completed: false,
    content: {
      theory: 'Konjunktiv II, kibar isteklerte (hätte, wäre, würde) ve hipotetik durumlarda kullanılır.',
      examples: [
        { de: 'Ich hätte gerne einen Kaffee, bitte.', tr: 'Bir kahve alabilir miyim lütfen (Kibarca).' },
        { de: 'Wenn ich Zeit hätte, würde ich nach Paris reisen.', tr: 'Vaktim olsaydı Paris’e seyahat ederdim.' }
      ],
      quiz: [
        {
          question: '"haben" fiilinin Konjunktiv II (ich) karşılığı nedir?',
          options: ['hatte', 'hätte', 'habe', 'hast'],
          correctAnswer: 1,
          explanation: '"hätte" şeklindedir.'
        }
      ]
    }
  }
];
