import { Badge } from '../types';

export const INITIAL_BADGES: Badge[] = [
  {
    id: 'b1',
    title: 'İlk Adım',
    description: 'İlk Almanca dersini başarıyla tamamla.',
    icon: '🎯',
    unlocked: true,
    unlockedAt: '2026-11-01'
  },
  {
    id: 'b2',
    title: 'Kelime Avcısı',
    description: 'Koleksiyonuna 10 yeni kelime ekle.',
    icon: '📚',
    unlocked: true,
    unlockedAt: '2026-11-05'
  },
  {
    id: 'b3',
    title: 'Seri Ustası',
    description: '5 gün üst üste kesintisiz çalış.',
    icon: '🔥',
    unlocked: false
  },
  {
    id: 'b4',
    title: 'Goethe Uzmanı',
    description: 'B1 Sınav simülasyonundan %80 ve üzeri al.',
    icon: '🎓',
    unlocked: false
  }
];
