import { CEFRLevel } from '../types';

export type SyntaxRuleCategory =
  | 'V2 (Fiil 2. Sırada)'
  | 'Nebensatz (Yan Cümle - Fiil Sona)'
  | 'Modalverb (Cümle Çerçevesi)'
  | 'Inversion (Devrik Dizilim)';

export interface SyntaxExercise {
  id: string;
  level: CEFRLevel;
  category: SyntaxRuleCategory;
  turkishPrompt: string;
  correctGermanSentence: string;
  acceptedVariants?: string[];
  scrambledWords: string[];
  ruleHintTr: string;
  explanationTr: string;
  /** Key conjugated verb expected in position 2 or end, for smart diagnostics */
  targetVerb?: string;
  subordinatingConjunction?: string;
}

export const SYNTAX_EXERCISES: SyntaxExercise[] = [
  {
    id: 'syn_1',
    level: 'A1',
    category: 'V2 (Fiil 2. Sırada)',
    turkishPrompt: 'Bugün Berlin\'e trenle gidiyorum.',
    correctGermanSentence: 'Heute fahre ich mit dem Zug nach Berlin.',
    acceptedVariants: ['Ich fahre heute mit dem Zug nach Berlin.'],
    scrambledWords: ['Heute', 'fahre', 'ich', 'mit', 'dem', 'Zug', 'nach', 'Berlin.'],
    ruleHintTr: 'Cümle zaman zarfı (Heute) ile başlasa bile çekimli fiil (fahre) 2. sırada olmalıdır.',
    explanationTr: 'Almanca düz cümlelerde çekimli fiil her zaman 2. pozisyonda kalır. "Heute" 1. sırayı alınca fiil hemen ardına gelir, özne (ich) 3. sıraya geçer.',
    targetVerb: 'fahre',
  },
  {
    id: 'syn_2',
    level: 'A1',
    category: 'V2 (Fiil 2. Sırada)',
    turkishPrompt: 'Yarın akşam sinemada yeni bir film izliyoruz.',
    correctGermanSentence: 'Morgen Abend sehen wir einen neuen Film im Kino.',
    acceptedVariants: ['Wir sehen morgen Abend einen neuen Film im Kino.'],
    scrambledWords: ['Morgen Abend', 'sehen', 'wir', 'einen', 'neuen', 'Film', 'im Kino.'],
    ruleHintTr: '"Morgen Abend" tek bir zaman ögesidir (1. sıra); hemen ardından çekimli fiil "sehen" gelmelidir.',
    explanationTr: '"Morgen Abend" 1. ögedir. Çekimli fiil "sehen" 2. sırada yer alır, özne "wir" ise 3. sıraya yerleşir.',
    targetVerb: 'sehen',
  },
  {
    id: 'syn_3',
    level: 'A2',
    category: 'Modalverb (Cümle Çerçevesi)',
    turkishPrompt: 'Hafta sonu Almanca sınavım için çalışmam gerekiyor.',
    correctGermanSentence: 'Am Wochenende muss ich für meine Deutschprüfung lernen.',
    acceptedVariants: ['Ich muss am Wochenende für meine Deutschprüfung lernen.'],
    scrambledWords: ['Am Wochenende', 'muss', 'ich', 'für', 'meine', 'Deutschprüfung', 'lernen.'],
    ruleHintTr: 'Modal fiil (muss) 2. sırada çekimlenir, asıl fiil (lernen) mastar halinde en sona gider.',
    explanationTr: 'Modal fiilli cümlelerde "Satzklammer" (cümle çerçevesi) oluşur: çekimli modal fiil 2. sırada, asıl fiil (lernen) cümlenin en sonunda bulunur.',
    targetVerb: 'lernen',
  },
  {
    id: 'syn_4',
    level: 'A2',
    category: 'Nebensatz (Yan Cümle - Fiil Sona)',
    turkishPrompt: 'Eve kalıyorum çünkü bugün çok yorgunum.',
    correctGermanSentence: 'Ich bleibe zu Hause, weil ich heute sehr müde bin.',
    scrambledWords: ['Ich', 'bleibe', 'zu Hause,', 'weil', 'ich', 'heute', 'sehr', 'müde', 'bin.'],
    ruleHintTr: '"weil" bağlacı yan cümle kurar ve çekimli fiili (bin) yan cümlenin en sonuna gönderir.',
    explanationTr: '"weil" bağlacından sonra çekimli fiil (bin) cümlenin en sonuna gitmelidir. Bu kural "dass", "obwohl" ve "wenn" için de geçerlidir.',
    targetVerb: 'bin',
    subordinatingConjunction: 'weil',
  },
  {
    id: 'syn_5',
    level: 'B1',
    category: 'Nebensatz (Yan Cümle - Fiil Sona)',
    turkishPrompt: 'Yarın vaktinde gelebileceğini umuyorum.',
    correctGermanSentence: 'Ich hoffe, dass du morgen pünktlich kommen kannst.',
    scrambledWords: ['Ich', 'hoffe,', 'dass', 'du', 'morgen', 'pünktlich', 'kommen', 'kannst.'],
    ruleHintTr: '"dass" yan cümlesinde önce mastar fiil (kommen), en sonda ise çekimli modal fiil (kannst) yer alır.',
    explanationTr: '"dass" bağlacı fiili sona atar. Yan cümlede bir modal fiil (kannst) varsa, çekimli olan modal fiil en sona gider.',
    targetVerb: 'kannst',
    subordinatingConjunction: 'dass',
  },
  {
    id: 'syn_6',
    level: 'B1',
    category: 'Inversion (Devrik Dizilim)',
    turkishPrompt: 'Yağmur yağmasına rağmen dışarıda koşmaya gidiyoruz.',
    correctGermanSentence: 'Obwohl es regnet, gehen wir draußen laufen.',
    scrambledWords: ['Obwohl', 'es', 'regnet,', 'gehen', 'wir', 'draußen', 'laufen.'],
    ruleHintTr: 'Cümle yan cümleyle (Obwohl es regnet,) başlarsa, ana cümle hemen fiille (gehen) devam eder!',
    explanationTr: 'Yan cümle 1. sırayı kapladığı için ana cümlenin çekimli fiili (gehen) virgülden hemen sonra gelir (fiil-fiil kuralı).',
    targetVerb: 'gehen',
    subordinatingConjunction: 'obwohl',
  },
  {
    id: 'syn_7',
    level: 'B1',
    category: 'V2 (Fiil 2. Sırada)',
    turkishPrompt: 'Çok yorgun olduğum için (bu nedenle) erken uyuyorum.',
    correctGermanSentence: 'Ich bin sehr müde, deshalb gehe ich früh schlafen.',
    scrambledWords: ['Ich', 'bin', 'sehr', 'müde,', 'deshalb', 'gehe', 'ich', 'früh', 'schlafen.'],
    ruleHintTr: '"deshalb" yan cümle bağlacı değildir; 1. sırayı alır ve fiili (gehe) hemen peşinden 2. sıraya çeker.',
    explanationTr: '"weil" fiili sona atarken, "deshalb" (bu yüzden) fiili hemen kendisinden sonra 2. sıraya çeker ve özne (ich) 3. sıraya geçer.',
    targetVerb: 'gehe',
  },
  {
    id: 'syn_8',
    level: 'B2',
    category: 'Nebensatz (Yan Cümle - Fiil Sona)',
    turkishPrompt: 'Daha çok Almanca konuşabilmem için her gün pratik yapıyorum.',
    correctGermanSentence: 'Ich übe jeden Tag, damit ich flüssiger Deutsch sprechen kann.',
    scrambledWords: ['Ich', 'übe', 'jeden Tag,', 'damit', 'ich', 'flüssiger', 'Deutsch', 'sprechen', 'kann.'],
    ruleHintTr: '"damit" (diye/için) yan cümle bağlacıdır; çekimli fiil (kann) cümlenin en sonuna gitmelidir.',
    explanationTr: '"damit" amaç bildiren bir yan cümle kurar ve çekimli fiil olan "kann"ı en sona gönderir.',
    targetVerb: 'kann',
    subordinatingConjunction: 'damit',
  },
  {
    id: 'syn_9',
    level: 'B2',
    category: 'Inversion (Devrik Dizilim)',
    turkishPrompt: 'Toplantıdan sonra yeni projeyi detaylıca tartışabiliriz.',
    correctGermanSentence: 'Nach der Besprechung können wir das neue Projekt ausführlich diskutieren.',
    acceptedVariants: ['Wir können nach der Besprechung das neue Projekt ausführlich diskutieren.'],
    scrambledWords: ['Nach der Besprechung', 'können', 'wir', 'das neue Projekt', 'ausführlich', 'diskutieren.'],
    ruleHintTr: 'Zaman ögesi başta olduğunda modal fiil "können" 2. sırada, asıl fiil "diskutieren" ise en sonda olmalıdır.',
    explanationTr: 'Inversion + Satzklammer bir arada: zaman ögesi 1. sırada, çekimli modal fiil 2. sırada, mastar fiil ise cümle sonundadır.',
    targetVerb: 'diskutieren',
  },
  {
    id: 'syn_10',
    level: 'C1',
    category: 'Nebensatz (Yan Cümle - Fiil Sona)',
    turkishPrompt: 'Ne kadar erken başvurursan, şansın o kadar yüksek olur.',
    correctGermanSentence: 'Je früher du dich bewirbst, desto höher sind deine Chancen.',
    scrambledWords: ['Je', 'früher', 'du', 'dich', 'bewirbst,', 'desto', 'höher', 'sind', 'deine', 'Chancen.'],
    ruleHintTr: '"Je ..." kısmında fiil (bewirbst) virgülden hemen önce sona gider; "desto ..." kısmında fiil (sind) sıfattan hemen sonra gelir.',
    explanationTr: '"Je ... desto ..." yapısında ilk cümle yan cümle dizilimiyle (fiil sonda: bewirbst), ikinci cümle ise "desto + sıfat + fiil + özne" düzeniyle kurulur.',
    targetVerb: 'bewirbst',
    subordinatingConjunction: 'je',
  },
];

export function explainSyntaxMistakeTr(ex: SyntaxExercise, userTokens: string[]): string {
  const cleanTokens = userTokens.map((t) => t.replace(/[.,!?]/g, '').toLowerCase());
  const conj = ex.subordinatingConjunction?.toLowerCase();

  if (conj && cleanTokens.includes(conj)) {
    const conjIndex = cleanTokens.indexOf(conj);
    const verbLower = ex.targetVerb?.toLowerCase();
    const afterConj = cleanTokens.slice(conjIndex + 1);
    if (verbLower && afterConj.length > 0 && afterConj[afterConj.length - 1] !== verbLower) {
      const displayConj = conj.charAt(0).toUpperCase() + conj.slice(1);
      return `${displayConj} bağlacından sonra çekimli fiil (${ex.targetVerb}) cümlenin en sonuna gitmelidir.`;
    }
  }

  if (ex.category.startsWith('Modalverb') && ex.targetVerb) {
    const lastToken = cleanTokens[cleanTokens.length - 1] || '';
    if (lastToken !== ex.targetVerb.toLowerCase()) {
      return `Modal fiilli cümlede çekimli modal fiil 2. sırada kalır, asıl mastar fiil (${ex.targetVerb}) cümlenin en sonuna gider.`;
    }
  }

  if (ex.category.startsWith('V2') || ex.category.startsWith('Inversion')) {
    return `${ex.ruleHintTr} (${ex.explanationTr})`;
  }

  return ex.explanationTr;
}
