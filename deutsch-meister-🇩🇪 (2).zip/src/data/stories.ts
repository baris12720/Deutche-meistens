import { ArticleType, CEFRLevel } from '../types';

export interface StoryWordEntry {
  base: string;
  turkish: string;
  article: ArticleType;
  plural?: string;
  category?: string;
  exampleDe?: string;
  exampleTr?: string;
}

export interface StoryDialogueLine {
  id: string;
  speaker: string;
  german: string;
  turkish: string;
}

export interface StoryQuestion {
  id: string;
  questionTr: string;
  options: string[];
  correctAnswer: string;
  explanationTr: string;
}

export interface Story {
  id: string;
  level: CEFRLevel;
  titleTr: string;
  titleDe: string;
  scenarioTag: string;
  emoji: string;
  durationMin: number;
  summaryTr: string;
  xpReward: number;
  lines: StoryDialogueLine[];
  vocabularyMap: Record<string, StoryWordEntry>;
  questions: StoryQuestion[];
}

export const STORIES: Story[] = [
  {
    id: 'story_a1_bakery',
    level: 'A1',
    titleTr: 'Fırında Sabah Kahvaltısı',
    titleDe: 'In der Bäckerei',
    scenarioTag: 'Fırında',
    emoji: '🥐',
    durationMin: 3,
    summaryTr: 'Sabah fırından taze ekmek, poğaça ve kahve sipariş etmeyi öğren.',
    xpReward: 25,
    lines: [
      {
        id: 'b1',
        speaker: 'Bäckerin',
        german: 'Guten Morgen! Was darf es heute sein?',
        turkish: 'Günaydın! Bugün ne arzu edersiniz?',
      },
      {
        id: 'b2',
        speaker: 'Elif',
        german: 'Guten Morgen! Ich hätte gern zwei Brötchen und ein Croissant.',
        turkish: 'Günaydın! İki adet küçük ekmek ve bir kruvasan rica ediyorum.',
      },
      {
        id: 'b3',
        speaker: 'Bäckerin',
        german: 'Möchten Sie auch einen Kaffee oder eine Brezel dazu?',
        turkish: 'Yanına bir kahve veya simit (Brezel) de ister misiniz?',
      },
      {
        id: 'b4',
        speaker: 'Elif',
        german: 'Ja, bitte! Eine Tasse Kaffee mit Milch und das Brot dort.',
        turkish: 'Evet, lütfen! Sütlü bir fincan kahve ve şuradaki ekmek.',
      },
      {
        id: 'b5',
        speaker: 'Bäckerin',
        german: 'Das macht zusammen sechs Euro fünfzig. Bar oder mit Karte?',
        turkish: 'Hepsi toplam altı euro elli cent yapıyor. Nakit mi kartla mı?',
      },
      {
        id: 'b6',
        speaker: 'Elif',
        german: 'Mit Karte, bitte. Danke und einen schönen Tag!',
        turkish: 'Kartla, lütfen. Teşekkürler ve iyi günler!',
      },
    ],
    vocabularyMap: {
      bäckerei: { base: 'Bäckerei', turkish: 'fırın / pastane', article: 'die', plural: 'die Bäckereien', category: 'Alışveriş' },
      morgen: { base: 'Morgen', turkish: 'sabah', article: 'der', plural: 'die Morgen', category: 'Zaman' },
      brötchen: { base: 'Brötchen', turkish: 'küçük sandviç ekmeği', article: 'das', plural: 'die Brötchen', category: 'Yiyecek' },
      croissant: { base: 'Croissant', turkish: 'kruvasan', article: 'das', plural: 'die Croissants', category: 'Yiyecek' },
      kaffee: { base: 'Kaffee', turkish: 'kahve', article: 'der', plural: 'die Kaffees', category: 'İçecek' },
      brezel: { base: 'Brezel', turkish: 'Alman simidi (brezel)', article: 'die', plural: 'die Brezeln', category: 'Yiyecek' },
      tasse: { base: 'Tasse', turkish: 'fincan', article: 'die', plural: 'die Tassen', category: 'Mutfak' },
      milch: { base: 'Milch', turkish: 'süt', article: 'die', plural: '— (çoğulu yok)', category: 'İçecek' },
      brot: { base: 'Brot', turkish: 'ekmek', article: 'das', plural: 'die Brote', category: 'Yiyecek' },
      karte: { base: 'Karte', turkish: 'kart (banka kartı)', article: 'die', plural: 'die Karten', category: 'Ödeme' },
      tag: { base: 'Tag', turkish: 'gün', article: 'der', plural: 'die Tage', category: 'Zaman' },
      hätte: { base: 'haben (Konjunktiv II: hätte gern)', turkish: 'rica etmek / istemek', article: 'none', category: 'Fiil' },
      zusammen: { base: 'zusammen', turkish: 'toplam / birlikte', article: 'none', category: 'Zarf' },
      bar: { base: 'bar', turkish: 'nakit', article: 'none', category: 'Ödeme' },
    },
    questions: [
      {
        id: 'bq1',
        questionTr: 'Elif ilk olarak ne sipariş ediyor?',
        options: ['İki küçük ekmek ve bir kruvasan', 'İki fincan çay ve bir pasta', 'Bir simit ve meyve suyu'],
        correctAnswer: 'İki küçük ekmek ve bir kruvasan',
        explanationTr: 'Elif "Ich hätte gern zwei Brötchen und ein Croissant" diyerek sipariş veriyor.',
      },
      {
        id: 'bq2',
        questionTr: 'Elif kahvesini nasıl istiyor?',
        options: ['Şekerli', 'Sütlü', 'Sade'],
        correctAnswer: 'Sütlü',
        explanationTr: '"Eine Tasse Kaffee mit Milch" = Sütlü bir fincan kahve.',
      },
      {
        id: 'bq3',
        questionTr: 'Elif ödemeyi nasıl yapıyor?',
        options: ['Nakit ödüyor', 'Kartla ödüyor', 'Sonra ödeyeceğini söylüyor'],
        correctAnswer: 'Kartla ödüyor',
        explanationTr: '"Mit Karte, bitte." cümlesiyle kartla ödeyeceğini belirtiyor.',
      },
    ],
  },
  {
    id: 'story_a1_station',
    level: 'A1',
    titleTr: 'Tren İstasyonunda Bilet',
    titleDe: 'Am Bahnhof',
    scenarioTag: 'Tren İstasyonunda',
    emoji: '🚆',
    durationMin: 3,
    summaryTr: 'Gişeden tren bileti almayı, peron ve saat sormayı keşfet.',
    xpReward: 25,
    lines: [
      {
        id: 's1',
        speaker: 'Mert',
        german: 'Entschuldigung, wann fährt der nächste Zug nach Hamburg?',
        turkish: 'Affedersiniz, Hamburg\'a bir sonraki tren ne zaman kalkıyor?',
      },
      {
        id: 's2',
        speaker: 'Mitarbeiter',
        german: 'Der Zug fährt um zehn Uhr zwanzig ab.',
        turkish: 'Tren saat on yirmide kalkıyor.',
      },
      {
        id: 's3',
        speaker: 'Mert',
        german: 'Auf welchem Gleis fährt er und brauche ich eine Fahrkarte?',
        turkish: 'Hangi perondan kalkıyor ve bilete ihtiyacım var mı?',
      },
      {
        id: 's4',
        speaker: 'Mitarbeiter',
        german: 'Auf Gleis vier. Ja, hier ist Ihre Fahrkarte. Gute Reise!',
        turkish: 'Dördüncü perondan. Evet, buyurun biletiniz. İyi yolculuklar!',
      },
    ],
    vocabularyMap: {
      bahnhof: { base: 'Bahnhof', turkish: 'tren istasyonu', article: 'der', plural: 'die Bahnhöfe', category: 'Ulaşım' },
      zug: { base: 'Zug', turkish: 'tren', article: 'der', plural: 'die Züge', category: 'Ulaşım' },
      gleis: { base: 'Gleis', turkish: 'peron / ray', article: 'das', plural: 'die Gleise', category: 'Ulaşım' },
      fahrkarte: { base: 'Fahrkarte', turkish: 'bilet (ulaşım)', article: 'die', plural: 'die Fahrkarten', category: 'Ulaşım' },
      reise: { base: 'Reise', turkish: 'yolculuk / seyahat', article: 'die', plural: 'die Reisen', category: 'Seyahat' },
      uhr: { base: 'Uhr', turkish: 'saat', article: 'die', plural: 'die Uhren', category: 'Zaman' },
      entschuldigung: { base: 'Entschuldigung', turkish: 'affedersiniz / özür', article: 'die', plural: 'die Entschuldigungen', category: 'İletişim' },
      fährt: { base: 'fahren (er/sie fährt)', turkish: 'gitmek / hareket etmek (araçla)', article: 'none', category: 'Fiil' },
      wann: { base: 'wann', turkish: 'ne zaman', article: 'none', category: 'Soru' },
    },
    questions: [
      {
        id: 'sq1',
        questionTr: 'Mert nereye gitmek istiyor?',
        options: ['Berlin\'e', 'Hamburg\'a', 'Münih\'e'],
        correctAnswer: 'Hamburg\'a',
        explanationTr: '"...der nächste Zug nach Hamburg?" sorusu Hamburg trenini soruyor.',
      },
      {
        id: 'sq2',
        questionTr: 'Tren saat kaçta hareket ediyor?',
        options: ['10:20', '10:04', '04:20'],
        correctAnswer: '10:20',
        explanationTr: '"um zehn Uhr zwanzig" = saat 10:20.',
      },
      {
        id: 'sq3',
        questionTr: 'Tren hangi perondan kalkıyor?',
        options: ['Gleis 2', 'Gleis 4', 'Gleis 10'],
        correctAnswer: 'Gleis 4',
        explanationTr: '"Auf Gleis vier." = 4 numaralı peronda.',
      },
    ],
  },
  {
    id: 'story_a2_apartment',
    level: 'A2',
    titleTr: 'Almanya\'da Ev Arama',
    titleDe: 'Die Wohnungssuche',
    scenarioTag: 'Ev Aramada',
    emoji: '🏠',
    durationMin: 4,
    summaryTr: 'Kiralık daire gezerken oda sayısı, kira ve yan giderleri konuş.',
    xpReward: 30,
    lines: [
      {
        id: 'w1',
        speaker: 'Vermieter',
        german: 'Willkommen! Das ist die Wohnung. Sie hat zwei Zimmer, eine Küche und ein Bad.',
        turkish: 'Hoş geldiniz! Daire burası. İki odası, bir mutfağı ve bir banyosu var.',
      },
      {
        id: 'w2',
        speaker: 'Can',
        german: 'Die Wohnung ist sehr hell! Gibt es auch einen Balkon?',
        turkish: 'Daire çok aydınlık! Bir balkonu da var mı?',
      },
      {
        id: 'w3',
        speaker: 'Vermieter',
        german: 'Ja, im Wohnzimmer ist der Balkon. Die Kaltmiete beträgt siebenhundert Euro.',
        turkish: 'Evet, oturma odasında balkon var. Soğuk kira (aidatsız kira) yedi yüz euro.',
      },
      {
        id: 'w4',
        speaker: 'Can',
        german: 'Und wie hoch sind die Nebenkosten? Ist eine Waschmaschine im Keller?',
        turkish: 'Peki yan giderler ne kadar? Bodrumda çamaşır makinesi var mı?',
      },
      {
        id: 'w5',
        speaker: 'Vermieter',
        german: 'Die Nebenkosten sind hundertfünfzig Euro. Der Keller bietet viel Platz.',
        turkish: 'Yan giderler yüz elli euro. Bodrum geniş alan sunuyor.',
      },
    ],
    vocabularyMap: {
      wohnung: { base: 'Wohnung', turkish: 'daire / ev', article: 'die', plural: 'die Wohnungen', category: 'Ev' },
      zimmer: { base: 'Zimmer', turkish: 'oda', article: 'das', plural: 'die Zimmer', category: 'Ev' },
      küche: { base: 'Küche', turkish: 'mutfak', article: 'die', plural: 'die Küchen', category: 'Ev' },
      bad: { base: 'Bad', turkish: 'banyo', article: 'das', plural: 'die Bäder', category: 'Ev' },
      balkon: { base: 'Balkon', turkish: 'balkon', article: 'der', plural: 'die Balkone', category: 'Ev' },
      wohnzimmer: { base: 'Wohnzimmer', turkish: 'oturma odası', article: 'das', plural: 'die Wohnzimmer', category: 'Ev' },
      kaltmiete: { base: 'Kaltmiete', turkish: 'yan gidersiz kira (soğuk kira)', article: 'die', plural: 'die Kaltmieten', category: 'Ev' },
      nebenkosten: { base: 'Nebenkosten', turkish: 'yan giderler / aidat (çoğul)', article: 'die', plural: 'die Nebenkosten', category: 'Ev' },
      waschmaschine: { base: 'Waschmaschine', turkish: 'çamaşır makinesi', article: 'die', plural: 'die Waschmaschinen', category: 'Ev' },
      keller: { base: 'Keller', turkish: 'bodrum / kiler', article: 'der', plural: 'die Keller', category: 'Ev' },
      platz: { base: 'Platz', turkish: 'yer / alan', article: 'der', plural: 'die Plätze', category: 'Mekan' },
      hell: { base: 'hell', turkish: 'aydınlık / ferah', article: 'none', category: 'Sıfat' },
    },
    questions: [
      {
        id: 'wq1',
        questionTr: 'Dairede kaç oda var?',
        options: ['1 oda', '2 oda', '3 oda'],
        correctAnswer: '2 oda',
        explanationTr: '"Sie hat zwei Zimmer..." = İki odası var.',
      },
      {
        id: 'wq2',
        questionTr: 'Balkon nerede bulunuyor?',
        options: ['Mutfakta', 'Oturma odasında', 'Banyoda'],
        correctAnswer: 'Oturma odasında',
        explanationTr: '"im Wohnzimmer ist der Balkon" = Balkon oturma odasında.',
      },
      {
        id: 'wq3',
        questionTr: 'Kaltmiete + Nebenkosten toplam ne kadar tutuyor?',
        options: ['700 Euro', '850 Euro', '150 Euro'],
        correctAnswer: '850 Euro',
        explanationTr: '700 Euro (Kaltmiete) + 150 Euro (Nebenkosten) = 850 Euro.',
      },
    ],
  },
  {
    id: 'story_b1_doctor',
    level: 'B1',
    titleTr: 'Doktorda Muayene',
    titleDe: 'Beim Arzt',
    scenarioTag: 'Doktorda',
    emoji: '🩺',
    durationMin: 4,
    summaryTr: 'Sağlık şikayetlerini anlatmayı, reçete ve rapor almayı öğren.',
    xpReward: 35,
    lines: [
      {
        id: 'd1',
        speaker: 'Ärztin',
        german: 'Guten Tag! Was fehlt Ihnen denn? Seit wann haben Sie die Beschwerden?',
        turkish: 'İyi günler! Neyiniz var? Şikayetleriniz ne zamandan beri sürüyor?',
      },
      {
        id: 'd2',
        speaker: 'Deniz',
        german: 'Seit drei Tagen habe ich starke Halsschmerzen und leichtes Fieber.',
        turkish: 'Üç gündür şiddetli boğaz ağrım ve hafif ateşim var.',
      },
      {
        id: 'd3',
        speaker: 'Ärztin',
        german: 'Haben Sie auch Husten oder Kopfschmerzen? Ich untersuche Sie kurz.',
        turkish: 'Öksürük veya baş ağrınız da var mı? Sizi kısaca muayene edeyim.',
      },
      {
        id: 'd4',
        speaker: 'Deniz',
        german: 'Ja, abends tut mir der Kopf weh. Brauche ich ein Rezept für die Apotheke?',
        turkish: 'Evet, akşamları başım ağrıyor. Eczane için reçeteye ihtiyacım var mı?',
      },
      {
        id: 'd5',
        speaker: 'Ärztin',
        german: 'Es ist nur eine Erkältung. Ich schreibe Ihnen ein Medikament auf und gebe Ihnen eine Krankschreibung für zwei Tage.',
        turkish: 'Sadece bir soğuk algınlığı. Size bir ilaç yazıyorum ve iki günlük iş göremezlik raporu veriyorum.',
      },
    ],
    vocabularyMap: {
      arzt: { base: 'Arzt', turkish: 'doktor (erkek)', article: 'der', plural: 'die Ärzte', category: 'Sağlık' },
      ärztin: { base: 'Ärztin', turkish: 'doktor (kadın)', article: 'die', plural: 'die Ärztinnen', category: 'Sağlık' },
      beschwerden: { base: 'Beschwerden', turkish: 'şikayetler / rahatsızlık', article: 'die', plural: 'die Beschwerden', category: 'Sağlık' },
      halsschmerzen: { base: 'Halsschmerzen', turkish: 'boğaz ağrısı', article: 'die', plural: 'die Halsschmerzen', category: 'Sağlık' },
      fieber: { base: 'Fieber', turkish: 'ateş', article: 'das', plural: '—', category: 'Sağlık' },
      husten: { base: 'Husten', turkish: 'öksürük', article: 'der', plural: '—', category: 'Sağlık' },
      kopfschmerzen: { base: 'Kopfschmerzen', turkish: 'baş ağrısı', article: 'die', plural: 'die Kopfschmerzen', category: 'Sağlık' },
      kopf: { base: 'Kopf', turkish: 'baş / kafa', article: 'der', plural: 'die Köpfe', category: 'Vücut' },
      rezept: { base: 'Rezept', turkish: 'reçete (veya yemek tarifi)', article: 'das', plural: 'die Rezepte', category: 'Sağlık' },
      apotheke: { base: 'Apotheke', turkish: 'eczane', article: 'die', plural: 'die Apotheken', category: 'Sağlık' },
      erkältung: { base: 'Erkältung', turkish: 'soğuk algınlığı', article: 'die', plural: 'die Erkältungen', category: 'Sağlık' },
      medikament: { base: 'Medikament', turkish: 'ilaç', article: 'das', plural: 'die Medikamente', category: 'Sağlık' },
      krankschreibung: { base: 'Krankschreibung', turkish: 'sağlık raporu / istirahat belgesi', article: 'die', plural: 'die Krankschreibungen', category: 'Sağlık' },
      untersuche: { base: 'untersuchen', turkish: 'muayene etmek / incelemek', article: 'none', category: 'Fiil' },
    },
    questions: [
      {
        id: 'dq1',
        questionTr: 'Deniz\'in şikayetleri ne zamandan beri var?',
        options: ['Dünden beri', 'Üç gündür', 'Bir haftadır'],
        correctAnswer: 'Üç gündür',
        explanationTr: '"Seit drei Tagen" = Üç gündür.',
      },
      {
        id: 'dq2',
        questionTr: 'Doktor muayene sonunda nasıl bir teşhis koyuyor?',
        options: ['Soğuk algınlığı', 'Kırık kol', 'Alerji'],
        correctAnswer: 'Soğuk algınlığı',
        explanationTr: '"Es ist nur eine Erkältung." = Sadece bir soğuk algınlığı.',
      },
      {
        id: 'dq3',
        questionTr: 'Doktor kaç günlük rapor (Krankschreibung) veriyor?',
        options: ['1 gün', '2 gün', '5 gün'],
        correctAnswer: '2 gün',
        explanationTr: '"eine Krankschreibung für zwei Tage" = İki günlük hastalık raporu.',
      },
    ],
  },
  {
    id: 'story_b2_interview',
    level: 'B2',
    titleTr: 'İş Görüşmesinde Kendini Tanıtma',
    titleDe: 'Im Vorstellungsgespräch',
    scenarioTag: 'İş Görüşmesinde',
    emoji: '💼',
    durationMin: 5,
    summaryTr: 'Deneyimlerinden, güçlü yanlarından ve ekip çalışmasından profesyonelce bahset.',
    xpReward: 40,
    lines: [
      {
        id: 'i1',
        speaker: 'Personalchef',
        german: 'Herzlich willkommen! Warum haben Sie sich bei unserem Unternehmen beworben?',
        turkish: 'Hoş geldiniz! Neden şirketimize başvurdunuz?',
      },
      {
        id: 'i2',
        speaker: 'Selin',
        german: 'Vielen Dank für die Einladung. Mich begeistert besonders Ihre innovative Projektkultur.',
        turkish: 'Davet için çok teşekkürler. Özellikle yenilikçi proje kültürünüz beni çok heyecanlandırıyor.',
      },
      {
        id: 'i3',
        speaker: 'Personalchef',
        german: 'Welche Berufserfahrung bringen Sie mit und was sind Ihre Stärken?',
        turkish: 'Hangi iş tecrübesine sahipsiniz ve güçlü yönleriniz neler?',
      },
      {
        id: 'i4',
        speaker: 'Selin',
        german: 'Ich habe vier Jahre Erfahrung in der Softwareentwicklung. Meine Teamfähigkeit und Zuverlässigkeit helfen mir sehr.',
        turkish: 'Yazılım geliştirmede dört yıllık deneyimim var. Ekip çalışmasına yatkınlığım ve güvenilirliğim bana çok yardımcı oluyor.',
      },
      {
        id: 'i5',
        speaker: 'Personalchef',
        german: 'Das klingt überzeugend! Wann könnten Sie frühestens anfangen?',
        turkish: 'Kulağa ikna edici geliyor! En erken ne zaman başlayabilirsiniz?',
      },
    ],
    vocabularyMap: {
      vorstellungsgespräch: { base: 'Vorstellungsgespräch', turkish: 'iş görüşmesi / mülakat', article: 'das', plural: 'die Vorstellungsgespräche', category: 'Kariyer' },
      unternehmen: { base: 'Unternehmen', turkish: 'şirket / işletme', article: 'das', plural: 'die Unternehmen', category: 'İş' },
      einladung: { base: 'Einladung', turkish: 'davet', article: 'die', plural: 'die Einladungen', category: 'İletişim' },
      projektkultur: { base: 'Projektkultur', turkish: 'proje kültürü', article: 'die', plural: 'die Projektkulturen', category: 'İş' },
      berufserfahrung: { base: 'Berufserfahrung', turkish: 'mesleki deneyim', article: 'die', plural: 'die Berufserfahrungen', category: 'Kariyer' },
      teamfähigkeit: { base: 'Teamfähigkeit', turkish: 'ekip çalışmasına yatkınlık', article: 'die', plural: '—', category: 'Kariyer' },
      zuverlässigkeit: { base: 'Zuverlässigkeit', turkish: 'güvenilirlik', article: 'die', plural: '—', category: 'Özellik' },
      softwareentwicklung: { base: 'Softwareentwicklung', turkish: 'yazılım geliştirme', article: 'die', plural: '—', category: 'Teknoloji' },
      personalchef: { base: 'Personalchef', turkish: 'insan kaynakları müdürü', article: 'der', plural: 'die Personalchefs', category: 'Kariyer' },
      beworben: { base: 'sich bewerben', turkish: 'başvurmak', article: 'none', category: 'Fiil' },
      überzeugend: { base: 'überzeugend', turkish: 'ikna edici', article: 'none', category: 'Sıfat' },
    },
    questions: [
      {
        id: 'iq1',
        questionTr: 'Selin bu şirkete neden başvurduğunu söylüyor?',
        options: ['Evine yakın olduğu için', 'Yenilikçi proje kültürünü beğendiği için', 'Maaşı yüksek olduğu için'],
        correctAnswer: 'Yenilikçi proje kültürünü beğendiği için',
        explanationTr: '"Mich begeistert besonders Ihre innovative Projektkultur." ifadesiyle bunu vurguluyor.',
      },
      {
        id: 'iq2',
        questionTr: 'Selin\'in yazılım geliştirmede kaç yıllık deneyimi var?',
        options: ['2 yıl', '4 yıl', '6 yıl'],
        correctAnswer: '4 yıl',
        explanationTr: '"vier Jahre Erfahrung in der Softwareentwicklung".',
      },
      {
        id: 'iq3',
        questionTr: 'Selin güçlü yönleri olarak neleri sayıyor?',
        options: ['Hızlı yazma ve sabır', 'Ekip çalışması ve güvenilirlik', 'Yabancı dil ve liderlik'],
        correctAnswer: 'Ekip çalışması ve güvenilirlik',
        explanationTr: '"Teamfähigkeit und Zuverlässigkeit" = ekip yatkınlığı ve güvenilirlik.',
      },
    ],
  },
  {
    id: 'story_c1_digital',
    level: 'C1',
    titleTr: 'Yapay Zeka ve İş Dünyasının Geleceği',
    titleDe: 'Künstliche Intelligenz im Arbeitsalltag',
    scenarioTag: 'Akademik & İş',
    emoji: '🧠',
    durationMin: 5,
    summaryTr: 'İleri düzey bağlaçlar ve soyut kavramlarla çalışma hayatındaki dönüşümü tartış.',
    xpReward: 45,
    lines: [
      {
        id: 'c1',
        speaker: 'Dr. Weber',
        german: 'Obwohl die Automatisierung viele Routineaufgaben übernimmt, bleibt der Mensch unverzichtbar.',
        turkish: 'Otomasyon birçok rutin görevi devralmasına rağmen, insan vazgeçilmez olmaya devam ediyor.',
      },
      {
        id: 'c2',
        speaker: 'Klara',
        german: 'Das stimmt, vorausgesetzt, die Weiterbildung wird kontinuierlich gefördert.',
        turkish: 'Bu doğru; yeter ki sürekli mesleki gelişim (eğitim) desteklensin.',
      },
      {
        id: 'c3',
        speaker: 'Dr. Weber',
        german: 'Außerdem erfordert die Transformation ein Umdenken in der Führungskultur.',
        turkish: 'Ayrıca bu dönüşüm, liderlik kültüründe bir zihniyet değişimi gerektiriyor.',
      },
      {
        id: 'c4',
        speaker: 'Klara',
        german: 'Je transparenter die Entscheidung in einem Unternehmen ist, desto höher ist die Akzeptanz im Team.',
        turkish: 'Bir şirkette karar ne kadar şeffaf olursa, ekipteki kabul de o kadar yüksek olur.',
      },
    ],
    vocabularyMap: {
      automatisierung: { base: 'Automatisierung', turkish: 'otomasyon', article: 'die', plural: 'die Automatisierungen', category: 'Teknoloji' },
      routineaufgaben: { base: 'Routineaufgabe', turkish: 'rutin görev', article: 'die', plural: 'die Routineaufgaben', category: 'İş' },
      weiterbildung: { base: 'Weiterbildung', turkish: 'ileri eğitim / mesleki gelişim', article: 'die', plural: 'die Weiterbildungen', category: 'Eğitim' },
      transformation: { base: 'Transformation', turkish: 'dönüşüm', article: 'die', plural: 'die Transformationen', category: 'İş' },
      umdenken: { base: 'Umdenken', turkish: 'düşünce / zihniyet değişimi', article: 'das', plural: '—', category: 'Kavram' },
      führungskultur: { base: 'Führungskultur', turkish: 'liderlik kültürü', article: 'die', plural: 'die Führungskulturen', category: 'İş' },
      entscheidung: { base: 'Entscheidung', turkish: 'karar', article: 'die', plural: 'die Entscheidungen', category: 'Kavram' },
      akzeptanz: { base: 'Akzeptanz', turkish: 'kabul / benimseme', article: 'die', plural: '—', category: 'Kavram' },
      unverzichtbar: { base: 'unverzichtbar', turkish: 'vazgeçilmez', article: 'none', category: 'Sıfat' },
      vorausgesetzt: { base: 'vorausgesetzt', turkish: '... şartıyla / yeter ki', article: 'none', category: 'Bağlaç' },
    },
    questions: [
      {
        id: 'cq1',
        questionTr: 'Dr. Weber\'e göre otomasyona rağmen kim vazgeçilmezdir?',
        options: ['İnsan (der Mensch)', 'Yalnızca yazılımcılar', 'Sadece yöneticiler'],
        correctAnswer: 'İnsan (der Mensch)',
        explanationTr: '"...bleibt der Mensch unverzichtbar." = İnsan vazgeçilmez kalır.',
      },
      {
        id: 'cq2',
        questionTr: 'Klara bunun gerçekleşmesi için hangi şartı öne sürüyor?',
        options: ['Çalışma saatlerinin artırılması', 'Sürekli eğitimin (Weiterbildung) desteklenmesi', 'Tüm ofislerin kapatılması'],
        correctAnswer: 'Sürekli eğitimin (Weiterbildung) desteklenmesi',
        explanationTr: '"vorausgesetzt, die Weiterbildung wird kontinuierlich gefördert."',
      },
      {
        id: 'cq3',
        questionTr: '"Je transparenter ..., desto höher ..." kalıbı metinde neyi anlatıyor?',
        options: ['Kararlar ne kadar şeffafsa ekipte kabul o kadar yüksektir', 'Maaş arttıkça stres de artar', 'Teknoloji büyüdükçe iletişim azalır'],
        correctAnswer: 'Kararlar ne kadar şeffafsa ekipte kabul o kadar yüksektir',
        explanationTr: 'Je... desto... yapısı doğru orantı kurar: şeffaflık arttıkça ekip içi kabul artar.',
      },
    ],
  },
];
