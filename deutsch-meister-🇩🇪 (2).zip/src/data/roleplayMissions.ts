import { CEFRLevel } from '../types';
import { AiCorrection } from '../utils/aiClient';

export interface RoleplayMissionGoal {
  id: string;
  labelTr: string;
  keywords: string[];
}

export interface RoleplayMission {
  id: string;
  level: CEFRLevel;
  titleTr: string;
  characterName: string;
  characterRole: string;
  emoji: string;
  xpReward: number;
  missionDescriptionTr: string;
  openingDe: string;
  openingTr: string;
  suggestedStartersDe: string[];
  goals: RoleplayMissionGoal[];
}

export const ROLEPLAY_MISSIONS: RoleplayMission[] = [
  {
    id: 'rp_cafe_order',
    level: 'A1',
    titleTr: 'Kafede Sipariş & Kartla Ödeme',
    characterName: 'Lukas (Barista)',
    characterRole: 'Kafe Baristası',
    emoji: '☕',
    xpReward: 35,
    missionDescriptionTr:
      'Görev: Kafede bir kahve ve bir kruvasan sipariş et, ardından hesabı kartla ödemek istediğini söyle.',
    openingDe: 'Hallo und herzlich willkommen im Café Sonnenschein! Was möchten Sie bestellen?',
    openingTr: 'Merhaba ve Sonnenschein Kafe\'ye hoş geldiniz! Ne sipariş etmek istersiniz?',
    suggestedStartersDe: [
      'Ich hätte gern einen Kaffee und ein Croissant.',
      'Was kostet das zusammen?',
      'Ich möchte mit Karte bezahlen, bitte.',
    ],
    goals: [
      { id: 'g_coffee', labelTr: 'Bir kahve sipariş et (einen Kaffee)', keywords: ['kaffee', 'espresso', 'cappuccino', 'latte'] },
      { id: 'g_croissant', labelTr: 'Bir kruvasan veya atıştırmalık iste (ein Croissant)', keywords: ['croissant', 'kuchen', 'brötchen'] },
      { id: 'g_card', labelTr: 'Kartla ödemek istediğini söyle (mit Karte)', keywords: ['karte', 'ec-karte', 'kreditkarte', 'kart'] },
    ],
  },
  {
    id: 'rp_train_ticket',
    level: 'A2',
    titleTr: 'İstasyonda Tren Bileti & Peron',
    characterName: 'Frau Weber',
    characterRole: 'DB Gişe Görevlisi',
    emoji: '🚆',
    xpReward: 40,
    missionDescriptionTr:
      'Görev: Berlin\'e gidiş-dönüş (hin und zurück) tren bileti sor, kalkış saatini ve hangi perondan (Gleis) kalktığını öğren.',
    openingDe: 'Guten Tag! Sie sind am DB-Schalter. Wohin möchten Sie heute reisen?',
    openingTr: 'İyi günler! DB gişesindesiniz. Bugün nereye seyahat etmek istiyorsunuz?',
    suggestedStartersDe: [
      'Ich möchte eine Fahrkarte nach Berlin, hin und zurück.',
      'Wann fährt der nächste Zug ab?',
      'Auf welchem Gleis fährt der Zug?',
    ],
    goals: [
      { id: 'g_dest', labelTr: 'Gitmek istediğin şehri ve bileti belirt (nach ... / Fahrkarte)', keywords: ['berlin', 'münchen', 'hamburg', 'fahrkarte', 'ticket'] },
      { id: 'g_time', labelTr: 'Saat veya gidiş-dönüş sor (wann / hin und zurück)', keywords: ['wann', 'uhr', 'hin', 'zurück', 'nächste'] },
      { id: 'g_gleis', labelTr: 'Peronu sor (welchem Gleis)', keywords: ['gleis', 'abfahrt', 'bahnsteig'] },
    ],
  },
  {
    id: 'rp_doctor_visit',
    level: 'B1',
    titleTr: 'Doktorda Şikayet & Rapor Talebi',
    characterName: 'Dr. Becker',
    characterRole: 'Aile Hekimi',
    emoji: '🩺',
    xpReward: 45,
    missionDescriptionTr:
      'Görev: İki gündür boğaz ağrın/ateşin olduğunu anlat, reçete iste ve iş yerin için hastalık raporu (Krankschreibung) talep et.',
    openingDe: 'Guten Tag, nehmen Sie bitte Platz. Was führt Sie heute in meine Praxis?',
    openingTr: 'İyi günler, lütfen oturun. Bugün sizi muayenehaneme getiren şikayet nedir?',
    suggestedStartersDe: [
      'Ich habe seit zwei Tagen Halsschmerzen und Fieber.',
      'Könnten Sie mir bitte ein Rezept für die Apotheke geben?',
      'Ich brauche auch eine Krankschreibung für meine Arbeit.',
    ],
    goals: [
      { id: 'g_symptom', labelTr: 'Şikayetini ve süresini anlat (Halsschmerzen / Fieber / seit ...)', keywords: ['schmerz', 'fieber', 'husten', 'krank', 'seit'] },
      { id: 'g_rezept', labelTr: 'İlaç veya reçete sor (Medikament / Rezept)', keywords: ['rezept', 'medikament', 'tablette', 'apotheke'] },
      { id: 'g_note', labelTr: 'Hastalık raporu iste (Krankschreibung / Attest)', keywords: ['krankschreibung', 'krankmeldung', 'attest', 'arbeit'] },
    ],
  },
  {
    id: 'rp_job_interview',
    level: 'B2',
    titleTr: 'İş Görüşmesinde Güçlü Yönler',
    characterName: 'Herr Hoffmann',
    characterRole: 'İK Yöneticisi',
    emoji: '💼',
    xpReward: 50,
    missionDescriptionTr:
      'Görev: İş deneyimini anlat, neden bu şirketi seçtiğini belirt ve maaş/başlangıç tarihi hakkında kibar bir soru sor.',
    openingDe: 'Guten Tag und danke für Ihre Bewerbung! Erzählen Sie mir bitte kurz über Ihre Berufserfahrung.',
    openingTr: 'İyi günler ve başvurunuz için teşekkürler! Lütfen bana kısaca iş deneyiminizden bahsedin.',
    suggestedStartersDe: [
      'Ich habe drei Jahre Erfahrung und arbeite gern im Team.',
      'Ich habe mich beworben, weil Ihr Unternehmen sehr innovativ ist.',
      'Ab wann könnte ich anfangen und wie hoch ist das Gehalt?',
    ],
    goals: [
      { id: 'g_exp', labelTr: 'Deneyimini ve güçlü yanını belirt (Erfahrung / Team)', keywords: ['erfahrung', 'jahre', 'team', 'stärke', 'arbeite'] },
      { id: 'g_why', labelTr: 'Başvuru sebebini anlat (weil / beworben / Unternehmen)', keywords: ['weil', 'unternehmen', 'firma', 'beworben', 'projekt'] },
      { id: 'g_cond', labelTr: 'Başlangıç veya şartları sor (Gehalt / anfangen / Urlaub)', keywords: ['gehalt', 'anfangen', 'wann', 'urlaub', 'arbeitszeit'] },
    ],
  },
];

export interface LocalRoleplayEvalResult {
  replyDe: string;
  replyTr: string;
  followUpDe?: string;
  tipTr?: string;
  correction: AiCorrection | null;
}

/**
 * Checks common German learner mistakes (articles, capitalization of nouns, verb order after weil/dass, coffee/croissant cases)
 * and crafts an authentic in-character response for offline / non-backend play.
 */
export function evaluateRoleplayTurnOffline(
  mission: RoleplayMission,
  userText: string,
  newlyCompletedGoals: string[],
  remainingGoals: RoleplayMissionGoal[]
): LocalRoleplayEvalResult {
  const raw = userText.trim();
  const lower = raw.toLowerCase();
  let correction: AiCorrection | null = null;

  // Common learner grammar/article checks
  if (/\bdas kaffee\b|\bdie kaffee\b|\bein kaffee\b/.test(lower)) {
    const fixed = raw
      .replace(/\bdas kaffee\b/gi, 'den Kaffee')
      .replace(/\bdie kaffee\b/gi, 'den Kaffee')
      .replace(/\bein kaffee\b/gi, 'einen Kaffee');
    correction = {
      original: raw,
      corrected: fixed,
      explanationTr: '"Kaffee" kelimesinin artikeli "der"dir. Sipariş verirken Akkusativ (ismin -i hali) kullanıldığı için "einen Kaffee" veya "den Kaffee" demelisin.',
      errorType: 'artikel',
    };
  } else if (/\bder croissant\b|\bdie croissant\b|\beinen croissant\b/.test(lower)) {
    const fixed = raw
      .replace(/\bder croissant\b/gi, 'ein Croissant')
      .replace(/\bdie croissant\b/gi, 'ein Croissant')
      .replace(/\beinen croissant\b/gi, 'ein Croissant');
    correction = {
      original: raw,
      corrected: fixed,
      explanationTr: '"Croissant" kelimesinin artikeli nötrdür (das Croissant). Bu nedenle belirsiz artikel olarak "ein Croissant" kullanmalısın.',
      errorType: 'artikel',
    };
  } else if (/\bich will\b/.test(lower) && (mission.id === 'rp_cafe_order' || mission.id === 'rp_train_ticket')) {
    correction = {
      original: raw,
      corrected: raw.replace(/\bich will\b/gi, 'Ich möchte'),
      explanationTr: 'Restoran, kafe veya gişede "Ich will" biraz sert kaçar; daha kibar olan "Ich möchte" veya "Ich hätte gern" kalıbını tercih etmelisin.',
      errorType: 'nezaket',
    };
  } else if (/\bweil\s+\w+\s+(ist|bin|sind|habe|hat|kann|möchte)\b/.test(lower)) {
    correction = {
      original: raw,
      corrected: raw,
      explanationTr: '"weil" bağlacından sonra çekimli fiil cümlenin en sonuna gitmelidir (Örn: "...weil ich krank bin").',
      errorType: 'sözdizimi',
    };
  } else if (/\bmit der karte\b/.test(lower)) {
    correction = {
      original: raw,
      corrected: raw.replace(/\bmit der karte\b/gi, 'mit Karte'),
      explanationTr: 'Kartla ödeme kalıbı Almancada artikelsiz olarak "mit Karte" şeklinde kullanılır.',
      errorType: 'kalıp',
    };
  } else if (/\bich habe seit\b/.test(lower) && /\btag\b/.test(lower)) {
    // subtle hint only if missing plural
  } else if (raw.length > 0 && raw[0] === raw[0].toLowerCase() && /[a-zäöüß]/.test(raw[0])) {
    correction = {
      original: raw,
      corrected: raw.charAt(0).toUpperCase() + raw.slice(1),
      explanationTr: 'Almancada cümle başları ve tüm isimler mutlaka büyük harfle başlar.',
      errorType: 'yazım',
    };
  }

  // Contextual character response
  let replyDe = '';
  let replyTr = '';
  let followUpDe: string | undefined;

  if (mission.id === 'rp_cafe_order') {
    if (lower.includes('karte') || lower.includes('bezahlen')) {
      replyDe = 'Sehr gern! Hier ist das Kartenlesegerät. Das macht zusammen 6,80 Euro.';
      replyTr = 'Memnuniyetle! Buyurun kart okuyucu cihaz. Toplam 6,80 Euro tutuyor.';
      followUpDe = remainingGoals.length > 0 ? 'Möchten Sie sonst noch etwas bestellen?' : 'Vielen Dank und einen wunderschönen Tag noch!';
    } else if (lower.includes('kaffee') && lower.includes('croissant')) {
      replyDe = 'Alles klar! Ein frisch gebrühter Kaffee und ein warmes Croissant kommen sofort.';
      replyTr = 'Anlaşıldı! Taze demlenmiş bir kahve ve sıcak bir kruvasan hemen geliyor.';
      followUpDe = 'Möchten Sie bar oder mit Karte bezahlen?';
    } else if (lower.includes('kaffee')) {
      replyDe = 'Gern! Einen großen oder einen kleinen Kaffee?';
      replyTr = 'Tabii! Büyük boy mu yoksa küçük boy kahve mi istersiniz?';
      followUpDe = 'Möchten Sie auch ein Croissant oder ein Stück Kuchen dazu?';
    } else {
      replyDe = 'Verstanden! Was kann ich Ihnen noch bringen?';
      replyTr = 'Anladım! Size başka ne getirebilirim?';
      followUpDe = remainingGoals[0]
        ? 'Haben Sie alles gewählt oder möchten Sie schon bezahlen?'
        : 'Möchten Sie bar oder mit Karte bezahlen?';
    }
  } else if (mission.id === 'rp_train_ticket') {
    if (lower.includes('gleis')) {
      replyDe = 'Der ICE fährt heute pünktlich um 14:15 Uhr von Gleis 7 ab.';
      replyTr = 'ICE treni bugün tam zamanında saat 14:15\'te 7. perondan kalkıyor.';
      followUpDe = remainingGoals.length === 0 ? 'Hier ist Ihr Ticket. Gute Fahrt!' : 'Brauchen Sie sonst noch Informationen?';
    } else if (lower.includes('fahrkarte') || lower.includes('ticket') || lower.includes('berlin')) {
      replyDe = 'Sehr gern! Eine Hin- und Rückfahrt kostet 79 Euro.';
      replyTr = 'Memnuniyetle! Gidiş-dönüş bilet 79 Euro tutuyor.';
      followUpDe = 'Soll ich Ihnen auch sagen, von welchem Gleis der Zug abfährt?';
    } else {
      replyDe = 'Ich schaue gern im System nach. Welcher Zug passt Ihnen am besten?';
      replyTr = 'Sistemden memnuniyetle kontrol ediyorum. Hangi tren size en uygun?';
    }
  } else if (mission.id === 'rp_doctor_visit') {
    if (lower.includes('krankschreibung') || lower.includes('attest')) {
      replyDe = 'Natürlich, ich stelle Ihnen eine Krankschreibung für drei Tage aus.';
      replyTr = 'Elbette, size üç günlük hastalık raporu düzenliyorum.';
      followUpDe = 'Ruhen Sie sich gut aus und trinken Sie viel Tee!';
    } else if (lower.includes('rezept') || lower.includes('medikament')) {
      replyDe = 'Hier ist Ihr Rezept. Sie können die Halstabletten direkt in der Apotheke holen.';
      replyTr = 'İşte reçeteniz. Pastilleri doğrudan eczaneden alabilirsiniz.';
      followUpDe = remainingGoals.some((g) => g.id === 'g_note')
        ? 'Brauchen Sie auch eine Krankschreibung für Ihren Arbeitgeber?'
        : 'Gute Besserung!';
    } else {
      replyDe = 'Ich verstehe, das klingt nach einer Erkältung. Ich verschreibe Ihnen etwas dagegen.';
      replyTr = 'Anlıyorum, bu bir soğuk algınlığına benziyor. Bunun için size bir ilaç yazacağım.';
      followUpDe = 'Brauchen Sie noch ein Rezept oder eine Krankschreibung?';
    }
  } else {
    if (lower.includes('gehalt') || lower.includes('anfangen') || lower.includes('wann')) {
      replyDe = 'Wir können ab dem ersten nächsten Monats starten. Das Einstiegsgehalt liegt im branchenüblichen Rahmen.';
      replyTr = 'Gelecek ayın birinden itibaren başlayabiliriz. Başlangıç maaşı sektör ortalaması çerçevesindedir.';
      followUpDe = 'Vielen Dank für das angenehme Gespräch!';
    } else if (lower.includes('weil') || lower.includes('unternehmen')) {
      replyDe = 'Das freut mich sehr zu hören! Genau solche motivierten Kolleginnen und Kollegen suchen wir.';
      replyTr = 'Bunu duymak beni çok mutlu etti! Tam olarak böyle motive çalışma arkadaşları arıyoruz.';
      followUpDe = 'Haben Sie noch Fragen zu den Arbeitszeiten oder zum Starttermin?';
    } else {
      replyDe = 'Sehr interessant! Ihre Qualifikationen passen gut zu unserer Abteilung.';
      replyTr = 'Çok ilginç! Nitelikleriniz departmanımıza oldukça uygun.';
      followUpDe = 'Warum möchten Sie gerade bei unserem Unternehmen arbeiten?';
    }
  }

  return {
    replyDe,
    replyTr,
    followUpDe,
    tipTr:
      newlyCompletedGoals.length > 0
        ? `Harika! ${newlyCompletedGoals.length} görev adımını tamamladın.`
        : remainingGoals[0]
        ? `İpucu: Sıradaki adım -> ${remainingGoals[0].labelTr}`
        : undefined,
    correction,
  };
}
