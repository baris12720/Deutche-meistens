import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { ALL_BADGES } from '../data/badges';
import {
  ActivityDay,
  AiMistake,
  ArticleType,
  CEFRLevel,
  Skill,
  ThemePreference,
  UserProfile,
  UserWordCard,
  VocabularyWord,
} from '../types';
import { playLevelUpSound } from '../utils/audio';

const STORAGE_KEY = 'DEUTSCH_MEISTER_USER_STATE_V1';
const LEGACY_STORAGE_KEYS = [
  'deutsch_meister_user_state',
  'DEUTSCH_MEISTER_USER_STATE',
  'deutsch_meister_profile',
  'dm_profile_v1',
];

const getTodayString = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const createDefaultProfile = (): UserProfile => ({
  name: 'Almanca Kaşifi',
  xp: 0,
  streak: 0,
  lastActiveDate: '',
  dailyGoalXp: 30,
  todayXp: 0,
  completedLessons: [],
  unlockedBadges: [],
  wordCards: {},
  soundEnabled: true,
  speechSpeed: 0.9,
  activeDates: [],
  currentLevel: 'A1',
  themePreference: 'system',
  favoriteWords: [],
  wordNotes: {},
  customWords: [],
  streakFreezes: 0,
  lastFreezeUsedDate: '',
  completedStories: [],
  completedRoleplayMissions: [],
  schemaVersion: 2,
});

const isRecord = (value: unknown): value is Record<string, any> =>
  !!value && typeof value === 'object' && !Array.isArray(value);

const isLevel = (value: unknown): value is CEFRLevel =>
  value === 'A1' || value === 'A2' || value === 'B1' || value === 'B2' || value === 'C1';

const isArticle = (value: unknown): value is ArticleType =>
  value === 'der' || value === 'die' || value === 'das' || value === 'none';

const isDateKey = (value: unknown): value is string =>
  typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value);

const safeNumber = (value: unknown, fallback: number, min = 0, max = 10_000_000): number => {
  const parsed = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  const number = typeof parsed === 'number' && Number.isFinite(parsed) ? parsed : fallback;
  return Math.min(max, Math.max(min, number));
};

const hasKnownProfileKey = (value: Record<string, any>): boolean => {
  const keys = [
    'xp',
    'streak',
    'completedLessons',
    'wordCards',
    'srs',
    'activity',
    'unlockedBadges',
    'completedWordSets',
    'passedLevelExams',
    'activeDates',
    'name',
    'dailyGoalXp',
    'customWords',
    'favoriteWords',
  ];
  return keys.some((k) => k in value);
};

/** Accepts legacy, partial, or current versioned profiles without ever dropping existing progress. */
const normalizeProfile = (value: unknown): UserProfile | null => {
  if (!isRecord(value) || !hasKnownProfileKey(value)) return null;
  const defaults = createDefaultProfile();
  const skills: Skill[] = ['vocab', 'grammar', 'listening', 'speaking', 'reading', 'writing'];
  const wordCards: UserProfile['wordCards'] = {};

  if (isRecord(value.wordCards)) {
    Object.entries(value.wordCards).slice(0, 10000).forEach(([id, item]) => {
      if (!id || !isRecord(item)) return;
      wordCards[id] = {
        wordId: id,
        status: item.status === 'mastered' ? 'mastered' : 'learning',
        reviewsCount: safeNumber(item.reviewsCount, 0, 0, 1_000_000),
        lastReviewedAt: safeNumber(item.lastReviewedAt, 0, 0, 8_640_000_000_000_000),
        intervalDays: safeNumber(item.intervalDays, 1, 1, 3650),
      };
    });
  }

  const activity: NonNullable<UserProfile['activity']> = {};
  if (isRecord(value.activity)) {
    Object.entries(value.activity).slice(-90).forEach(([date, rawDay]) => {
      if (!isDateKey(date) || !isRecord(rawDay)) return;
      const daySkills: ActivityDay['skills'] = {};
      if (isRecord(rawDay.skills)) {
        skills.forEach((skill) => {
          const entry = rawDay.skills[skill];
          if (isRecord(entry)) {
            daySkills[skill] = {
              r: safeNumber(entry.r, 0, 0, 1_000_000),
              w: safeNumber(entry.w, 0, 0, 1_000_000),
            };
          }
        });
      }
      activity[date] = {
        q: safeNumber(rawDay.q, 0, 0, 1_000_000),
        secs: safeNumber(rawDay.secs, 0, 0, 100_000_000),
        rev: safeNumber(rawDay.rev, 0, 0, 1_000_000),
        skills: daySkills,
      };
    });
  }

  const srs: NonNullable<UserProfile['srs']> = {};
  if (isRecord(value.srs)) {
    Object.entries(value.srs).slice(0, 20000).forEach(([id, item]) => {
      if (!id || !isRecord(item)) return;
      srs[id] = {
        box: safeNumber(item.box, 0, 0, 5),
        due: isDateKey(item.due) ? item.due : getTodayString(),
        right: safeNumber(item.right, 0, 0, 1_000_000),
        wrong: safeNumber(item.wrong, 0, 0, 1_000_000),
        last: isDateKey(item.last) ? item.last : getTodayString(),
      };
    });
  }

  const wordNotes: Record<string, string> = {};
  if (isRecord(value.wordNotes)) {
    Object.entries(value.wordNotes).slice(0, 5000).forEach(([id, note]) => {
      if (id && typeof note === 'string' && note.trim()) {
        wordNotes[id] = note.slice(0, 500);
      }
    });
  }

  const customWords: VocabularyWord[] = Array.isArray(value.customWords)
    ? value.customWords
        .filter(isRecord)
        .slice(0, 2000)
        .map((w: any, idx: number): VocabularyWord => ({
          id: typeof w.id === 'string' && w.id ? w.id.slice(0, 100) : `custom_${idx}_${Date.now()}`,
          german: typeof w.german === 'string' ? w.german.trim().slice(0, 120) : '',
          turkish: typeof w.turkish === 'string' ? w.turkish.trim().slice(0, 200) : '',
          article: isArticle(w.article) ? w.article : 'none',
          plural: typeof w.plural === 'string' ? w.plural.trim().slice(0, 120) : undefined,
          level: isLevel(w.level) ? w.level : 'A1',
          category: typeof w.category === 'string' && w.category.trim() ? w.category.trim().slice(0, 60) : 'Kişisel Defter',
          exampleGerman: typeof w.exampleGerman === 'string' ? w.exampleGerman.trim().slice(0, 300) : '',
          exampleTurkish: typeof w.exampleTurkish === 'string' ? w.exampleTurkish.trim().slice(0, 300) : '',
        }))
        .filter((w) => w.german.length > 0 && w.turkish.length > 0)
    : [];

  const stringList = (list: unknown, maxItems = 20000): string[] =>
    Array.isArray(list)
      ? Array.from(new Set(list.filter((item): item is string => typeof item === 'string' && item.length > 0).slice(0, maxItems)))
      : [];

  const themePreference: ThemePreference =
    value.themePreference === 'light' || value.themePreference === 'dark' ? value.themePreference : 'system';

  return {
    ...defaults,
    name: typeof value.name === 'string' && value.name.trim() ? value.name.trim().slice(0, 30) : defaults.name,
    xp: safeNumber(value.xp, 0),
    streak: safeNumber(value.streak, 0, 0, 100_000),
    lastActiveDate: isDateKey(value.lastActiveDate) ? value.lastActiveDate : '',
    dailyGoalXp: safeNumber(value.dailyGoalXp, defaults.dailyGoalXp, 10, 500),
    todayXp: safeNumber(value.todayXp, 0, 0, 1_000_000),
    completedLessons: stringList(value.completedLessons),
    unlockedBadges: stringList(value.unlockedBadges, 1000),
    wordCards,
    soundEnabled: typeof value.soundEnabled === 'boolean' ? value.soundEnabled : defaults.soundEnabled,
    speechSpeed: safeNumber(value.speechSpeed, defaults.speechSpeed, 0.6, 1.2),
    activeDates: stringList(value.activeDates, 90).filter(isDateKey).sort(),
    activity,
    dailyMinutes: safeNumber(value.dailyMinutes, 15, 5, 120),
    aiMistakes: Array.isArray(value.aiMistakes)
      ? value.aiMistakes.filter(isRecord).slice(0, 100).map((mistake: any, index: number) => ({
          id: typeof mistake.id === 'string' ? mistake.id.slice(0, 100) : `imported_${index}`,
          date: isDateKey(mistake.date) ? mistake.date : getTodayString(),
          original: typeof mistake.original === 'string' ? mistake.original.slice(0, 2000) : '',
          corrected: typeof mistake.corrected === 'string' ? mistake.corrected.slice(0, 2000) : '',
          explanationTr: typeof mistake.explanationTr === 'string' ? mistake.explanationTr.slice(0, 4000) : '',
          type: typeof mistake.type === 'string' ? mistake.type.slice(0, 100) : 'grammar',
        }))
      : [],
    srs,
    completedWordSets: stringList(value.completedWordSets),
    passedLevelExams: Array.isArray(value.passedLevelExams) ? value.passedLevelExams.filter(isLevel) : [],
    placementLevel: isLevel(value.placementLevel) ? value.placementLevel : undefined,
    currentLevel: isLevel(value.currentLevel) ? value.currentLevel : (isLevel(value.placementLevel) ? value.placementLevel : 'A1'),
    themePreference,
    favoriteWords: stringList(value.favoriteWords, 10000),
    wordNotes,
    customWords,
    streakFreezes: safeNumber(value.streakFreezes, 0, 0, 20),
    lastFreezeUsedDate: isDateKey(value.lastFreezeUsedDate) ? value.lastFreezeUsedDate : '',
    completedStories: stringList(value.completedStories, 500),
    completedRoleplayMissions: stringList(value.completedRoleplayMissions, 500),
    schemaVersion: 2,
  };
};

const dayDifference = (from: string, to: string): number => {
  if (!isDateKey(from) || !isDateKey(to)) return Number.POSITIVE_INFINITY;
  const [fy, fm, fd] = from.split('-').map(Number);
  const [ty, tm, td] = to.split('-').map(Number);
  return Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(fy, fm - 1, fd)) / 86_400_000);
};

/** A study streak changes only after real learning activity, never just by opening the app. */
const markStudyDay = (profile: UserProfile, today = getTodayString()): UserProfile => {
  if (profile.lastActiveDate === today) {
    if ((profile.activeDates || []).includes(today)) return profile;
    return { ...profile, activeDates: [...(profile.activeDates || []), today].slice(-90) };
  }
  const gap = dayDifference(profile.lastActiveDate, today);
  const freezes = Math.max(0, profile.streakFreezes || 0);
  let streak = 1;
  let nextFreezes = freezes;
  let nextLastFreezeUsedDate = profile.lastFreezeUsedDate || '';

  if (!profile.lastActiveDate) {
    streak = 1;
  } else if (gap === 1) {
    streak = (profile.streak || 0) + 1;
  } else if (gap > 1 && Number.isFinite(gap) && (profile.streak || 0) > 0 && freezes >= gap - 1) {
    nextFreezes = freezes - (gap - 1);
    streak = (profile.streak || 0) + 1;
    nextLastFreezeUsedDate = today;
  }

  return {
    ...profile,
    streak,
    streakFreezes: nextFreezes,
    lastFreezeUsedDate: nextLastFreezeUsedDate,
    lastActiveDate: today,
    todayXp: 0,
    activeDates: Array.from(new Set([...(profile.activeDates || []), today])).slice(-90),
  };
};

const parseProfileFromRaw = (raw: string): UserProfile | null => {
  const parsed = JSON.parse(raw);
  const candidate = isRecord(parsed) && parsed.app === 'Deutsch Meister' ? parsed.profile : parsed;
  return normalizeProfile(candidate);
};

const loadProfile = (): UserProfile => {
  if (typeof window === 'undefined') return createDefaultProfile();
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const normalized = parseProfileFromRaw(saved);
      if (normalized) {
        return normalized.lastActiveDate === getTodayString() ? normalized : { ...normalized, todayXp: 0 };
      }
      // Never lose existing data if structure was unexpectedly modified: keep backup copy safely
      try {
        if (!window.localStorage.getItem('DEUTSCH_MEISTER_RESCUE_RAW')) {
          window.localStorage.setItem('DEUTSCH_MEISTER_RESCUE_RAW', saved);
        }
      } catch {
        /* ignore */
      }
      return createDefaultProfile();
    }

    // Attempt one-time migration from legacy storage keys if primary key does not exist yet
    for (const legacyKey of LEGACY_STORAGE_KEYS) {
      const legacyRaw = window.localStorage.getItem(legacyKey);
      if (!legacyRaw) continue;
      try {
        const migrated = parseProfileFromRaw(legacyRaw);
        if (migrated) {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
          return migrated.lastActiveDate === getTodayString() ? migrated : { ...migrated, todayXp: 0 };
        }
      } catch {
        /* try next legacy key */
      }
    }
    return createDefaultProfile();
  } catch (error) {
    console.warn('Failed to load saved user profile:', error);
    return createDefaultProfile();
  }
};

interface CompletionModalData {
  lessonTitle: string;
  earnedXp: number;
  correctCount: number;
  totalQuestions: number;
  newBadges: string[];
}

interface AppContextType {
  profile: UserProfile;
  currentLevel: CEFRLevel;
  activeTab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'stories' | 'practice' | 'profile' | 'dtz' | 'words';
  activeLessonId: string | null;
  activeGrammarId: string | null;
  activeDialogueId: string | null;
  completionData: CompletionModalData | null;
  isPlacementTestOpen: boolean;
  setCurrentLevel: (level: CEFRLevel) => void;
  setPlacementLevel: (level: CEFRLevel) => void;
  markLevelExamPassed: (level: CEFRLevel) => void;
  markWordSetDone: (setId: string) => void;
  markStoryDone: (storyId: string, xpEarned: number) => void;
  markRoleplayMissionDone: (missionId: string, xpEarned: number) => void;
  buyStreakFreeze: (cost?: number) => boolean;
  recordAnswer: (refId: string, correct: boolean) => void;
  recordActivity: (skill: Skill, correct: boolean, secs?: number) => void;
  markReviewDone: (count: number) => void;
  setDailyMinutes: (minutes: number) => void;
  addAiMistake: (m: Omit<AiMistake, 'id' | 'date'>) => void;
  navTarget: string | null;
  goTo: (tab: string, target?: string) => void;
  clearNavTarget: () => void;
  setActiveTab: (tab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'stories' | 'practice' | 'profile' | 'dtz' | 'words') => void;
  openLesson: (lessonId: string) => void;
  closeLesson: () => void;
  openGrammar: (grammarId: string) => void;
  closeGrammar: () => void;
  openDialogue: (dialogueId: string) => void;
  closeDialogue: () => void;
  openPlacementTest: () => void;
  closePlacementTest: () => void;
  closeCompletionModal: () => void;
  completeLessonSession: (lessonId: string, earnedXp: number, correct: number, total: number) => void;
  addXp: (amount: number) => void;
  updateWordStatus: (wordId: string, status: 'learning' | 'mastered') => void;
  toggleFavoriteWord: (wordId: string) => void;
  setWordNote: (wordId: string, note: string) => void;
  addCustomWord: (word: Omit<VocabularyWord, 'id'>) => VocabularyWord;
  deleteCustomWord: (wordId: string) => void;
  toggleSound: () => void;
  setSpeechSpeed: (speed: number) => void;
  setDailyGoalXp: (goal: number) => void;
  updateProfileName: (name: string) => void;
  setThemePreference: (theme: ThemePreference) => void;
  exportData: () => string;
  importData: (jsonData: string) => boolean;
  resetProgress: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<UserProfile>(loadProfile);
  const profileRef = useRef<UserProfile>(profile);
  profileRef.current = profile;

  const [currentLevel, setCurrentLevelState] = useState<CEFRLevel>(profile.currentLevel || 'A1');
  const [activeTab, setActiveTab] = useState<'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'stories' | 'practice' | 'profile' | 'dtz' | 'words'>('learn');
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [activeGrammarId, setActiveGrammarId] = useState<string | null>(null);
  const [activeDialogueId, setActiveDialogueId] = useState<string | null>(null);
  const [completionData, setCompletionData] = useState<CompletionModalData | null>(null);
  const [isPlacementTestOpen, setIsPlacementTestOpen] = useState(false);

  const persistTimerRef = useRef<number | null>(null);

  const persistNow = useCallback((target: UserProfile) => {
    if (persistTimerRef.current !== null) {
      window.clearTimeout(persistTimerRef.current);
      persistTimerRef.current = null;
    }
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(target));
    } catch (e) {
      console.warn('Failed to save profile to localStorage:', e);
    }
  }, []);

  // Sync profile to localStorage with a brief debounce so rapid answer/XP ticks don't block WebView UI thread
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (persistTimerRef.current !== null) {
      window.clearTimeout(persistTimerRef.current);
    }
    persistTimerRef.current = window.setTimeout(() => {
      persistTimerRef.current = null;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
      } catch (e) {
        console.warn('Failed to save profile to localStorage:', e);
      }
    }, 250);
    return () => {
      if (persistTimerRef.current !== null) {
        window.clearTimeout(persistTimerRef.current);
        persistTimerRef.current = null;
      }
    };
  }, [profile]);

  // Flush profile immediately when app goes to background or closes (Android WebView / mobile browsers)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const flush = () => persistNow(profileRef.current);
    const onVis = () => {
      if (document.visibilityState === 'hidden') flush();
    };
    window.addEventListener('pagehide', flush);
    document.addEventListener('visibilitychange', onVis);
    return () => {
      flush();
      window.removeEventListener('pagehide', flush);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [persistNow]);

  // Apply the selected appearance. System mode follows the device setting automatically.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const dark = profile.themePreference === 'dark' || (profile.themePreference === 'system' && media.matches);
      document.documentElement.classList.toggle('dark', dark);
      document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
    };
    apply();
    if (profile.themePreference !== 'system') return;
    media.addEventListener?.('change', apply);
    return () => media.removeEventListener?.('change', apply);
  }, [profile.themePreference]);

  // Check and unlock badges
  const checkNewBadges = (updated: UserProfile): string[] => {
    const newlyUnlocked: string[] = [];
    const currentBadges = new Set(updated.unlockedBadges || []);

    ALL_BADGES.forEach((b) => {
      if (currentBadges.has(b.id)) return;

      let shouldUnlock = false;
      if (b.id === 'first_lesson' && (updated.completedLessons || []).length >= 1) shouldUnlock = true;
      if (b.id === 'streak_3' && (updated.streak || 0) >= 3) shouldUnlock = true;
      if (b.id === 'streak_7' && (updated.streak || 0) >= 7) shouldUnlock = true;
      if (b.id === 'xp_100' && (updated.xp || 0) >= 100) shouldUnlock = true;
      if (b.id === 'xp_500' && (updated.xp || 0) >= 500) shouldUnlock = true;
      if (b.id === 'words_25' && Object.keys(updated.wordCards || {}).length >= 25) shouldUnlock = true;

      if (shouldUnlock) {
        newlyUnlocked.push(b.id);
      }
    });

    return newlyUnlocked;
  };

  const addXp = useCallback((amount: number) => {
    const earned = Math.max(0, Math.round(Number.isFinite(amount) ? amount : 0));
    if (!earned) return;
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const updated = { ...studied, xp: (studied.xp || 0) + earned, todayXp: (studied.todayXp || 0) + earned };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      return updated;
    });
  }, []);

  const completeLessonSession = useCallback((lessonId: string, earnedXp: number, correct: number, total: number) => {
    const safeEarnedXp = Math.max(0, Math.round(Number.isFinite(earnedXp) ? earnedXp : 0));
    const currentSnapshot = profileRef.current;
    const previewStudied = markStudyDay(currentSnapshot);
    const previewCompleted = (previewStudied.completedLessons || []).includes(lessonId)
      ? previewStudied.completedLessons
      : [...(previewStudied.completedLessons || []), lessonId];
    const previewUpdated: UserProfile = {
      ...previewStudied,
      completedLessons: previewCompleted,
      xp: (previewStudied.xp || 0) + safeEarnedXp,
      todayXp: (previewStudied.todayXp || 0) + safeEarnedXp,
    };
    const predictedNewBadges = checkNewBadges(previewUpdated);

    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const alreadyCompleted = (studied.completedLessons || []).includes(lessonId);
      const newCompleted = alreadyCompleted ? studied.completedLessons : [...(studied.completedLessons || []), lessonId];
      const updated: UserProfile = {
        ...studied,
        completedLessons: newCompleted,
        xp: (studied.xp || 0) + safeEarnedXp,
        todayXp: (studied.todayXp || 0) + safeEarnedXp,
      };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      }
      return updated;
    });

    // Trigger UI/audio side-effects outside setProfile updater so React StrictMode never double-fires them
    setCompletionData({
      lessonTitle: lessonId,
      earnedXp: safeEarnedXp,
      correctCount: correct,
      totalQuestions: total,
      newBadges: predictedNewBadges,
    });

    if (currentSnapshot.soundEnabled) {
      playLevelUpSound(true);
    }

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#22c55e', '#38bdf8', '#facc15', '#f43f5e'],
      });
    } catch {
      /* ignore */
    }
  }, []);

  const updateWordStatus = useCallback((wordId: string, status: 'learning' | 'mastered') => {
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const existing = (studied.wordCards || {})[wordId] || {
        wordId,
        status: 'learning',
        reviewsCount: 0,
        lastReviewedAt: Date.now(),
        intervalDays: 1,
      };

      const newInterval = status === 'mastered' ? Math.max(existing.intervalDays * 2, 3) : 1;
      const updatedCard: UserWordCard = {
        ...existing,
        status,
        reviewsCount: existing.reviewsCount + 1,
        lastReviewedAt: Date.now(),
        intervalDays: newInterval,
      };

      const updated = {
        ...studied,
        wordCards: {
          ...(studied.wordCards || {}),
          [wordId]: updatedCard,
        },
      };

      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      }

      return updated;
    });
  }, []);

  const toggleFavoriteWord = useCallback((wordId: string) => {
    setProfile((prev) => {
      const list = prev.favoriteWords || [];
      const exists = list.includes(wordId);
      return {
        ...prev,
        favoriteWords: exists ? list.filter((id) => id !== wordId) : [...list, wordId],
      };
    });
  }, []);

  const setWordNote = useCallback((wordId: string, note: string) => {
    const clean = note.slice(0, 500);
    setProfile((prev) => {
      const next = { ...(prev.wordNotes || {}) };
      if (!clean.trim()) {
        delete next[wordId];
      } else {
        next[wordId] = clean;
      }
      return { ...prev, wordNotes: next };
    });
  }, []);

  const addCustomWord = useCallback((word: Omit<VocabularyWord, 'id'>): VocabularyWord => {
    const newWord: VocabularyWord = {
      ...word,
      id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      german: word.german.trim().slice(0, 120),
      turkish: word.turkish.trim().slice(0, 200),
      category: word.category.trim().slice(0, 60) || 'Kişisel Defter',
      exampleGerman: word.exampleGerman.trim().slice(0, 300),
      exampleTurkish: word.exampleTurkish.trim().slice(0, 300),
    };
    setProfile((prev) => ({
      ...prev,
      customWords: [newWord, ...(prev.customWords || [])].slice(0, 2000),
      favoriteWords: Array.from(new Set([...(prev.favoriteWords || []), newWord.id])),
    }));
    return newWord;
  }, []);

  const deleteCustomWord = useCallback((wordId: string) => {
    setProfile((prev) => {
      const nextNotes = { ...(prev.wordNotes || {}) };
      delete nextNotes[wordId];
      return {
        ...prev,
        customWords: (prev.customWords || []).filter((w) => w.id !== wordId),
        favoriteWords: (prev.favoriteWords || []).filter((id) => id !== wordId),
        wordNotes: nextNotes,
      };
    });
  }, []);

  const setCurrentLevel = useCallback((level: CEFRLevel) => {
    setCurrentLevelState(level);
    setProfile((prev) => (prev.currentLevel === level ? prev : { ...prev, currentLevel: level }));
  }, []);

  const setPlacementLevel = useCallback((level: CEFRLevel) => {
    const order: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
    setProfile((prev) => {
      const prevIdx = prev.placementLevel ? order.indexOf(prev.placementLevel) : 0;
      if (order.indexOf(level) <= prevIdx) return prev;
      return { ...prev, placementLevel: level };
    });
  }, []);

  const markLevelExamPassed = useCallback((level: CEFRLevel) => {
    setProfile((prev) => {
      const list = prev.passedLevelExams || [];
      if (list.includes(level)) return prev;
      return { ...prev, passedLevelExams: [...list, level] };
    });
  }, []);

  // Spaced repetition (Leitner boxes): right answer moves the item up a box, a wrong answer sends it back to box 0.
  const recordAnswer = useCallback((refId: string, correct: boolean) => {
    const INTERVALS = [0, 1, 3, 7, 14, 30]; // days until next review per box (day 1, 3, 7, 14, 30)
    const fmt = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    setProfile((prev) => {
      const today = new Date();
      const old = (prev.srs || {})[refId] || { box: 0, due: fmt(today), right: 0, wrong: 0, last: fmt(today) };
      const box = correct ? Math.min(5, (old.box || 0) + 1) : 0;
      const dueDate = new Date(today);
      dueDate.setDate(today.getDate() + INTERVALS[box]);
      const entry = {
        box,
        due: fmt(dueDate),
        right: (old.right || 0) + (correct ? 1 : 0),
        wrong: (old.wrong || 0) + (correct ? 0 : 1),
        last: fmt(today),
      };
      return { ...prev, srs: { ...(prev.srs || {}), [refId]: entry } };
    });
  }, []);

  const dayKeyLocal = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  // Per-day study log: questions, estimated seconds and accuracy per skill (feeds the progress dashboard).
  const recordActivity = useCallback((skill: Skill, correct: boolean, secs = 15) => {
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const key = dayKeyLocal(new Date());
      const all = { ...(studied.activity || {}) };
      const day: ActivityDay = all[key] ? { ...all[key], skills: { ...all[key].skills } } : { q: 0, secs: 0, rev: 0, skills: {} };
      const sk = day.skills[skill] || { r: 0, w: 0 };
      day.skills[skill] = { r: (sk.r || 0) + (correct ? 1 : 0), w: (sk.w || 0) + (correct ? 0 : 1) };
      day.q = (day.q || 0) + 1;
      day.secs = (day.secs || 0) + Math.max(3, Math.min(60, Math.round(secs)));
      all[key] = day;
      // keep about 60 days
      const keys = Object.keys(all).sort();
      while (keys.length > 60) delete all[keys.shift() as string];
      const updated = { ...studied, activity: all };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      return updated;
    });
  }, []);

  const markReviewDone = useCallback((count: number) => {
    if (count <= 0) return;
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const key = dayKeyLocal(new Date());
      const all = { ...(studied.activity || {}) };
      const day: ActivityDay = all[key] ? { ...all[key] } : { q: 0, secs: 0, rev: 0, skills: {} };
      day.rev = (day.rev || 0) + count;
      all[key] = day;
      const updated = { ...studied, activity: all };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      return updated;
    });
  }, []);

  const setDailyMinutes = useCallback((minutes: number) => {
    const safeMinutes = Math.min(120, Math.max(5, Math.round(minutes)));
    setProfile((prev) => (prev.dailyMinutes === safeMinutes ? prev : { ...prev, dailyMinutes: safeMinutes }));
  }, []);

  const addAiMistake = useCallback((m: Omit<AiMistake, 'id' | 'date'>) => {
    setProfile((prev) => {
      const entry: AiMistake = { ...m, id: `ai_${Date.now()}`, date: dayKeyLocal(new Date()) };
      return { ...prev, aiMistakes: [entry, ...(prev.aiMistakes || [])].slice(0, 100) };
    });
  }, []);

  const [navTarget, setNavTarget] = useState<string | null>(null);
  const goTo = useCallback((tab: string, target?: string) => {
    setNavTarget(target || null);
    setActiveTab(tab as any);
  }, []);
  const clearNavTarget = useCallback(() => setNavTarget(null), []);

  const markWordSetDone = useCallback((setId: string) => {
    setProfile((prev) => {
      const list = prev.completedWordSets || [];
      if (list.includes(setId)) return prev;
      return { ...prev, completedWordSets: [...list, setId] };
    });
  }, []);

  const markStoryDone = useCallback((storyId: string, xpEarned: number) => {
    const safeXp = Math.max(0, Math.round(Number.isFinite(xpEarned) ? xpEarned : 0));
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const list = studied.completedStories || [];
      const completedStories = list.includes(storyId) ? list : [...list, storyId];
      const updated = {
        ...studied,
        completedStories,
        xp: (studied.xp || 0) + safeXp,
        todayXp: (studied.todayXp || 0) + safeXp,
      };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      return updated;
    });
  }, []);

  const markRoleplayMissionDone = useCallback((missionId: string, xpEarned: number) => {
    const safeXp = Math.max(0, Math.round(Number.isFinite(xpEarned) ? xpEarned : 0));
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const list = studied.completedRoleplayMissions || [];
      const completedRoleplayMissions = list.includes(missionId) ? list : [...list, missionId];
      const updated = {
        ...studied,
        completedRoleplayMissions,
        xp: (studied.xp || 0) + safeXp,
        todayXp: (studied.todayXp || 0) + safeXp,
      };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...(studied.unlockedBadges || []), ...newBadges];
      return updated;
    });
  }, []);

  const buyStreakFreeze = useCallback((cost = 100): boolean => {
    const snap = profileRef.current;
    const currentFreezes = snap.streakFreezes || 0;
    if ((snap.xp || 0) < cost || currentFreezes >= 5) return false;
    setProfile((prev) => {
      const prevFreezes = prev.streakFreezes || 0;
      if ((prev.xp || 0) < cost || prevFreezes >= 5) return prev;
      return {
        ...prev,
        xp: (prev.xp || 0) - cost,
        streakFreezes: prevFreezes + 1,
      };
    });
    return true;
  }, []);

  const toggleSound = useCallback(() => {
    setProfile((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  }, []);

  const setSpeechSpeed = useCallback((speed: number) => {
    const safeSpeed = Math.min(1.2, Math.max(0.6, speed));
    setProfile((prev) => (prev.speechSpeed === safeSpeed ? prev : { ...prev, speechSpeed: safeSpeed }));
  }, []);

  const setDailyGoalXp = useCallback((goal: number) => {
    const safeGoal = Math.min(500, Math.max(10, Math.round(goal)));
    setProfile((prev) => (prev.dailyGoalXp === safeGoal ? prev : { ...prev, dailyGoalXp: safeGoal }));
  }, []);

  const updateProfileName = useCallback((name: string) => {
    const cleanName = name.replace(/[<>]/g, '').trim().slice(0, 30) || 'Almanca Kaşifi';
    setProfile((prev) => (prev.name === cleanName ? prev : { ...prev, name: cleanName }));
  }, []);

  const setThemePreference = useCallback((theme: ThemePreference) => {
    setProfile((prev) => (prev.themePreference === theme ? prev : { ...prev, themePreference: theme }));
  }, []);

  const exportData = useCallback((): string => JSON.stringify({
    app: 'Deutsch Meister',
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    profile: profileRef.current,
  }, null, 2), []);

  const importData = useCallback((jsonData: string): boolean => {
    try {
      if (jsonData.length > 15_000_000) return false;
      const parsed = JSON.parse(jsonData);
      const candidate = isRecord(parsed) && parsed.app === 'Deutsch Meister' ? parsed.profile : parsed;
      const normalized = normalizeProfile(candidate);
      if (!normalized) return false;
      const today = getTodayString();
      const restored = normalized.lastActiveDate === today ? normalized : { ...normalized, todayXp: 0 };
      setProfile(restored);
      setCurrentLevelState(restored.currentLevel || restored.placementLevel || 'A1');
      persistNow(restored);
      return true;
    } catch {
      return false;
    }
  }, [persistNow]);

  const resetProgress = useCallback(() => {
    const fresh = createDefaultProfile();
    setProfile(fresh);
    setCurrentLevelState('A1');
    if (persistTimerRef.current !== null) {
      window.clearTimeout(persistTimerRef.current);
      persistTimerRef.current = null;
    }
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* storage may be unavailable */ }
  }, []);

  const openLesson = useCallback((lessonId: string) => setActiveLessonId(lessonId), []);
  const closeLesson = useCallback(() => setActiveLessonId(null), []);
  const openGrammar = useCallback((grammarId: string) => setActiveGrammarId(grammarId), []);
  const closeGrammar = useCallback(() => setActiveGrammarId(null), []);
  const openDialogue = useCallback((dialogueId: string) => setActiveDialogueId(dialogueId), []);
  const closeDialogue = useCallback(() => setActiveDialogueId(null), []);
  const closeCompletionModal = useCallback(() => {
    setCompletionData(null);
    setActiveLessonId(null);
  }, []);
  const openPlacementTest = useCallback(() => setIsPlacementTestOpen(true), []);
  const closePlacementTest = useCallback(() => setIsPlacementTestOpen(false), []);

  const contextValue = useMemo<AppContextType>(() => ({
    profile,
    currentLevel,
    activeTab,
    activeLessonId,
    activeGrammarId,
    activeDialogueId,
    completionData,
    isPlacementTestOpen,
    setCurrentLevel,
    setPlacementLevel,
    markLevelExamPassed,
    markWordSetDone,
    markStoryDone,
    markRoleplayMissionDone,
    buyStreakFreeze,
    recordAnswer,
    recordActivity,
    markReviewDone,
    setDailyMinutes,
    addAiMistake,
    navTarget,
    goTo,
    clearNavTarget,
    setActiveTab,
    openLesson,
    closeLesson,
    openGrammar,
    closeGrammar,
    openDialogue,
    closeDialogue,
    openPlacementTest,
    closePlacementTest,
    closeCompletionModal,
    completeLessonSession,
    addXp,
    updateWordStatus,
    toggleFavoriteWord,
    setWordNote,
    addCustomWord,
    deleteCustomWord,
    toggleSound,
    setSpeechSpeed,
    setDailyGoalXp,
    updateProfileName,
    setThemePreference,
    exportData,
    importData,
    resetProgress,
  }), [
    profile,
    currentLevel,
    activeTab,
    activeLessonId,
    activeGrammarId,
    activeDialogueId,
    completionData,
    isPlacementTestOpen,
    navTarget,
    setCurrentLevel,
    setPlacementLevel,
    markLevelExamPassed,
    markWordSetDone,
    markStoryDone,
    markRoleplayMissionDone,
    buyStreakFreeze,
    recordAnswer,
    recordActivity,
    markReviewDone,
    setDailyMinutes,
    addAiMistake,
    goTo,
    clearNavTarget,
    openLesson,
    closeLesson,
    openGrammar,
    closeGrammar,
    openDialogue,
    closeDialogue,
    openPlacementTest,
    closePlacementTest,
    closeCompletionModal,
    completeLessonSession,
    addXp,
    updateWordStatus,
    toggleFavoriteWord,
    setWordNote,
    addCustomWord,
    deleteCustomWord,
    toggleSound,
    setSpeechSpeed,
    setDailyGoalXp,
    updateProfileName,
    setThemePreference,
    exportData,
    importData,
    resetProgress,
  ]);

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
