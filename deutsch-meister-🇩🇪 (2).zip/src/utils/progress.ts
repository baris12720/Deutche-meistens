import { CEFRLevel, Lesson, Unit, UserProfile } from '../types';
import { ALL_UNITS_BY_LEVEL } from '../data/levels';

export const LEVEL_ORDER: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

export type LessonState = 'done' | 'current' | 'open' | 'locked';

const LESSONS_BY_LEVEL_CACHE = new Map<CEFRLevel, Lesson[]>();

const lessonsOf = (level: CEFRLevel): Lesson[] => {
  const cached = LESSONS_BY_LEVEL_CACHE.get(level);
  if (cached) return cached;
  const lessons = (ALL_UNITS_BY_LEVEL[level] || []).flatMap((u: Unit) => u.lessons);
  LESSONS_BY_LEVEL_CACHE.set(level, lessons);
  return lessons;
};

export type ProgressSnapshot = Pick<
  UserProfile,
  'completedLessons' | 'passedLevelExams' | 'placementLevel'
>;

const placementIndex = (profile: ProgressSnapshot): number =>
  profile.placementLevel ? Math.max(0, LEVEL_ORDER.indexOf(profile.placementLevel)) : 0;

/** True when every lesson of the level is finished. */
export function areLessonsDone(level: CEFRLevel, profile: ProgressSnapshot): boolean {
  const lessons = lessonsOf(level);
  if (lessons.length === 0) return false;
  const completedSet = new Set(profile.completedLessons || []);
  return lessons.every((l) => completedSet.has(l.id));
}

export const EXAM_PASS_RATIO = 0.7;
export const EXAM_MIN_QUESTIONS = 20;

export function isLevelExamPassed(level: CEFRLevel, profile: ProgressSnapshot): boolean {
  return (profile.passedLevelExams || []).includes(level);
}

/** A level counts as finished only when all lessons are done AND its level exam is passed (>= 70%). */
export function isLevelCompleted(level: CEFRLevel, profile: ProgressSnapshot): boolean {
  return areLessonsDone(level, profile) && isLevelExamPassed(level, profile);
}

/** A level opens when the placement exam put the user there or higher, or the previous level is finished. */
export function isLevelUnlocked(level: CEFRLevel, profile: ProgressSnapshot): boolean {
  const idx = LEVEL_ORDER.indexOf(level);
  if (idx <= placementIndex(profile)) return true;
  return isLevelCompleted(LEVEL_ORDER[idx - 1], profile);
}

/**
 * Lesson states inside a level.
 * - Levels below the placement level are open for review.
 * - Otherwise lessons unlock one after another; the first unfinished one is "current".
 */
export function getLessonStates(level: CEFRLevel, profile: ProgressSnapshot): Record<string, LessonState> {
  const lessons = lessonsOf(level);
  const states: Record<string, LessonState> = {};
  const levelIdx = LEVEL_ORDER.indexOf(level);
  const skipped = levelIdx < placementIndex(profile);
  const unlocked = isLevelUnlocked(level, profile);
  const completedSet = new Set(profile.completedLessons || []);
  let currentAssigned = false;

  lessons.forEach((l) => {
    if (completedSet.has(l.id)) {
      states[l.id] = 'done';
    } else if (!unlocked) {
      states[l.id] = 'locked';
    } else if (skipped) {
      states[l.id] = 'open';
    } else if (!currentAssigned) {
      states[l.id] = 'current';
      currentAssigned = true;
    } else {
      states[l.id] = 'locked';
    }
  });
  return states;
}
