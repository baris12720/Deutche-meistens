import { ArticleType } from '../types';

export const ARTICLE_TEXT_COLOR: Record<ArticleType, string> = {
  der: 'text-blue-500 dark:text-blue-400',
  die: 'text-rose-500 dark:text-rose-400',
  das: 'text-emerald-500 dark:text-emerald-400',
  none: 'text-slate-500 dark:text-slate-400',
};

export const ARTICLE_BADGE_CLASS: Record<ArticleType, string> = {
  der: 'bg-blue-50 text-blue-500 border-blue-200 dark:bg-blue-950/60 dark:text-blue-400 dark:border-blue-800',
  die: 'bg-rose-50 text-rose-500 border-rose-200 dark:bg-rose-950/60 dark:text-rose-400 dark:border-rose-800',
  das: 'bg-emerald-50 text-emerald-500 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-400 dark:border-emerald-800',
  none: 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
};

export const ARTICLE_BUTTON_CLASS: Record<'der' | 'die' | 'das', string> = {
  der: 'bg-blue-500 hover:bg-blue-600 text-white shadow-[0_5px_0_#1d4ed8]',
  die: 'bg-rose-500 hover:bg-rose-600 text-white shadow-[0_5px_0_#be123c]',
  das: 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-[0_5px_0_#047857]',
};

export const ARTICLE_LABEL_TR: Record<'der' | 'die' | 'das', string> = {
  der: 'Eril (der)',
  die: 'Dişil (die)',
  das: 'Nötr (das)',
};

export function splitGermanArticle(phrase: string): { article: ArticleType; word: string } {
  const trimmed = (phrase || '').trim();
  const match = /^(der|die|das)\s+(.+)$/i.exec(trimmed);
  if (!match) return { article: 'none', word: trimmed };
  const art = match[1].toLowerCase() as 'der' | 'die' | 'das';
  return { article: art, word: match[2] };
}
