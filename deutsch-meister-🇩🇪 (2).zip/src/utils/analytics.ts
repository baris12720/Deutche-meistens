import { ActivityDay, CEFRLevel, Lesson, Skill, UserProfile } from '../types';
import { dayKey } from './srs';
import { QUEST_WORDS, QuestWord } from '../data/vocab/words';
import { CONNECTOR_GROUPS } from '../data/connectors';
import { LAB_TOPICS } from '../data/grammarLab';
import { ALL_UNITS_BY_LEVEL } from '../data/levels';
import { getLevelWords, getWordSets } from '../data/vocab/builder';

const QUEST_WORD_BY_ID = new Map<string, QuestWord>(QUEST_WORDS.map((w) => [w.id, w]));
const CONNECTOR_GROUP_BY_ID = new Map(CONNECTOR_GROUPS.map((g) => [g.id, g]));
const LEVEL_LESSONS_CACHE = new Map<CEFRLevel, Lesson[]>();
const LEVEL_CONNECTORS_CACHE = new Map<CEFRLevel, typeof CONNECTOR_GROUPS>();
const LEVEL_GRAMMAR_CACHE = new Map<CEFRLevel, typeof LAB_TOPICS>();

const getLevelLessons = (level: CEFRLevel): Lesson[] => {
  const cached = LEVEL_LESSONS_CACHE.get(level);
  if (cached) return cached;
  const lessons = (ALL_UNITS_BY_LEVEL[level] || []).flatMap((u) => u.lessons);
  LEVEL_LESSONS_CACHE.set(level, lessons);
  return lessons;
};

const getLevelConnectors = (level: CEFRLevel) => {
  const cached = LEVEL_CONNECTORS_CACHE.get(level);
  if (cached) return cached;
  const filtered = CONNECTOR_GROUPS.filter((g) => g.level === level);
  LEVEL_CONNECTORS_CACHE.set(level, filtered);
  return filtered;
};

const getLevelGrammar = (level: CEFRLevel) => {
  const cached = LEVEL_GRAMMAR_CACHE.get(level);
  if (cached) return cached;
  const filtered = LAB_TOPICS.filter((t) => t.level === level);
  LEVEL_GRAMMAR_CACHE.set(level, filtered);
  return filtered;
};

export const SKILLS: { id: Skill; label: string; emoji: string; color: string }[] = [
  { id: 'vocab', label: 'Kelime bilgisi', emoji: '📚', color: 'bg-emerald-500' },
  { id: 'grammar', label: 'Gramer', emoji: '🧩', color: 'bg-sky-500' },
  { id: 'listening', label: 'Dinleme', emoji: '🎧', color: 'bg-indigo-500' },
  { id: 'speaking', label: 'Konuşma', emoji: '🎤', color: 'bg-rose-500' },
  { id: 'reading', label: 'Okuma', emoji: '📖', color: 'bg-amber-500' },
  { id: 'writing', label: 'Yazma', emoji: '✍️', color: 'bg-violet-500' },
];

export const lastDayKeys = (n: number): string[] => {
  const out: string[] = [];
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    out.push(dayKey(d));
  }
  return out;
};

const num = (v: unknown): number => {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : 0;
};

export const minutesOf = (secs: number) => (num(secs) > 0 ? Math.max(1, Math.round(num(secs) / 60)) : 0);

/** Accuracy per skill over the last N days (null = not enough data yet). Always returns every Skill key safely. */
export function skillAccuracy(profile: UserProfile | null | undefined, days = 30): Record<Skill, { pct: number | null; n: number }> {
  const res: Record<Skill, { pct: number | null; n: number }> = {
    vocab: { pct: null, n: 0 },
    grammar: { pct: null, n: 0 },
    listening: { pct: null, n: 0 },
    speaking: { pct: null, n: 0 },
    reading: { pct: null, n: 0 },
    writing: { pct: null, n: 0 },
  };
  const activity = profile?.activity;
  if (!activity || typeof activity !== 'object') return res;

  const keys = new Set(lastDayKeys(days));
  const tot: Record<string, { r: number; w: number }> = {};
  Object.entries(activity).forEach(([k, day]) => {
    if (!keys.has(k) || !day || typeof day !== 'object') return;
    if (!day.skills || typeof day.skills !== 'object') return;
    Object.entries(day.skills).forEach(([sk, v]) => {
      if (!v || typeof v !== 'object') return;
      const t = tot[sk] || { r: 0, w: 0 };
      t.r += num((v as { r?: unknown }).r);
      t.w += num((v as { w?: unknown }).w);
      tot[sk] = t;
    });
  });

  SKILLS.forEach(({ id }) => {
    const t = tot[id] || { r: 0, w: 0 };
    const n = t.r + t.w;
    res[id] = { pct: n >= 5 ? Math.round((t.r / n) * 100) : null, n };
  });
  return res;
}

export function weeklySeries(profile: UserProfile | null | undefined) {
  const labels = ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'];
  const activity = profile?.activity && typeof profile.activity === 'object' ? profile.activity : {};
  return lastDayKeys(7).map((key) => {
    const day = activity[key];
    const [y, m, d] = key.split('-').map(Number);
    const weekday = labels[new Date(y, (m || 1) - 1, d || 1).getDay()] || '';
    return { key, label: weekday, minutes: minutesOf(day?.secs || 0), q: num(day?.q) };
  });
}

export const todayActivity = (profile: UserProfile | null | undefined): ActivityDay => {
  const raw = profile?.activity && typeof profile.activity === 'object' ? profile.activity[dayKey()] : undefined;
  return {
    q: num(raw?.q),
    secs: num(raw?.secs),
    rev: num(raw?.rev),
    skills: raw?.skills && typeof raw.skills === 'object' ? raw.skills : {},
  };
};

const GRAMMAR_REF_NAMES: Record<string, string> = {
  konj: 'Fiil çekimi', plural: 'Çoğul', perfekt: 'Perfekt', satz: 'Cümle sırası', artikel: 'Artikel ve haller',
  praep: 'Edatlar', negation: 'Olumsuzluk', modal: 'Modal fiiller', trenn: 'Ayrılabilen fiiller', praet: 'Präteritum',
  futur: 'Futur', genitiv: 'Genitiv', adjekt: 'Sıfat çekimi', relativ: 'Relativsätze', konj2: 'Konjunktiv II', passiv: 'Passiv',
};

/** Weakest topics, aggregated from the memory engine (wrong answers) and AI teacher findings. */
export function weakTopics(profile: UserProfile | null | undefined): { label: string; wrong: number }[] {
  const acc: Record<string, number> = {};
  const add = (label: string, n: number) => (acc[label] = (acc[label] || 0) + n);
  Object.entries(profile?.srs || {}).forEach(([refId, e]) => {
    if (!e || typeof e !== 'object') return;
    const wrong = num(e.wrong);
    if (wrong <= 0) return;
    if (refId.startsWith('vq_')) {
      const w = QUEST_WORD_BY_ID.get(refId);
      add(`Kelime: ${w ? w.category : 'diğer'}`, wrong);
    } else if (refId.startsWith('conn:')) {
      const g = CONNECTOR_GROUP_BY_ID.get(refId.split(':')[1]);
      add(`Bağlaç: ${g ? g.titleTr : 'diğer'}`, wrong);
    } else if (refId.startsWith('gram:')) {
      add(`Gramer: ${GRAMMAR_REF_NAMES[refId.split(':')[1]] || 'diğer'}`, wrong);
    } else if (refId.startsWith('dlg:')) {
      add('Diyalog ve dinleme', wrong);
    }
  });
  (profile?.aiMistakes || []).forEach((m) => {
    if (m && typeof m === 'object') add(`AI öğretmen: ${m.type || 'genel'}`, 1);
  });
  return Object.entries(acc)
    .map(([label, wrong]) => ({ label, wrong }))
    .sort((a, b) => b.wrong - a.wrong)
    .slice(0, 6);
}

export interface TargetRow {
  label: string;
  done: number;
  total: number;
}

/** CEFR level goals: real skills (known words, grammar topics, connectors, exam), not XP. */
export function levelTargets(profile: UserProfile | null | undefined, level: CEFRLevel): TargetRow[] {
  const doneSet = new Set(Array.isArray(profile?.completedWordSets) ? profile!.completedWordSets! : []);
  const completedLessonsSet = new Set(Array.isArray(profile?.completedLessons) ? profile!.completedLessons : []);
  const passedExams = Array.isArray(profile?.passedLevelExams) ? profile!.passedLevelExams! : [];
  const srs = profile?.srs && typeof profile.srs === 'object' ? profile.srs : {};
  const lessons = getLevelLessons(level);
  const words = getLevelWords(level);
  const known = words.filter((w) => num(srs[w.id]?.box) >= 2).length;
  const sets = getWordSets(level);
  const conn = getLevelConnectors(level);
  const gram = getLevelGrammar(level);
  const rows: TargetRow[] = [
    { label: 'Dersler', done: lessons.filter((l) => completedLessonsSet.has(l.id)).length, total: lessons.length },
    { label: 'Kelime setleri', done: sets.filter((s) => doneSet.has(s.id)).length, total: sets.length },
    { label: 'Kalıcı bilinen kelime', done: known, total: words.length },
  ];
  if (conn.length) rows.push({ label: 'Bağlaç konuları', done: conn.filter((g) => doneSet.has(`conn_${g.id}`)).length, total: conn.length });
  if (gram.length) rows.push({ label: 'Gramer atölyesi', done: gram.filter((t) => doneSet.has(`gram_${t.id}`)).length, total: gram.length });
  rows.push({ label: 'Seviye sınavı (%70)', done: passedExams.includes(level) ? 1 : 0, total: 1 });
  return rows;
}

export function memoryStats(profile: UserProfile | null | undefined) {
  const entries = Object.entries(profile?.srs || {}).filter(([, e]) => !!e && typeof e === 'object');
  const vocab = entries.filter(([id]) => id.startsWith('vq_'));
  const gram = entries.filter(([id]) => id.startsWith('gram:') || id.startsWith('conn:'));
  const rate = (list: [string, { right?: unknown; wrong?: unknown }][]) => {
    const r = list.reduce((a, [, e]) => a + num(e?.right), 0);
    const w = list.reduce((a, [, e]) => a + num(e?.wrong), 0);
    return r + w >= 5 ? Math.round((r / (r + w)) * 100) : null;
  };
  return {
    wordsLearned: vocab.length,
    wordsRemembered: vocab.filter(([, e]) => num(e?.box) >= 3).length,
    grammarRate: rate(gram as [string, { right?: unknown; wrong?: unknown }][]),
    vocabRate: rate(vocab as [string, { right?: unknown; wrong?: unknown }][]),
  };
}

/** Distribution of tracked vocabulary items across Leitner memory boxes (0..5). */
export function srsBoxDistribution(profile: UserProfile | null | undefined) {
  const counts = [0, 0, 0, 0, 0, 0];
  Object.values(profile?.srs || {}).forEach((e) => {
    if (!e || typeof e !== 'object') return;
    const box = Math.max(0, Math.min(5, Math.round(num(e.box))));
    counts[box] += 1;
  });
  const labels = ['Yeni/Zayıf', '1 Gün', '3 Gün', '7 Gün', '14 Gün', 'Uzman'];
  return counts.map((count, box) => ({ box, label: labels[box], count }));
}
