import { SrsEntry, UserProfile } from '../types';

export const dayKey = (d: Date = new Date()): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export interface SrsItem {
  refId: string;
  entry: SrsEntry;
}

const isValidSrs = (e: unknown): e is SrsEntry =>
  !!e && typeof e === 'object' && typeof (e as SrsEntry).due === 'string' && typeof (e as SrsEntry).box === 'number';

/** Items that should be reviewed today, weakest and most-missed first. */
export function getDueItems(profile: UserProfile | null | undefined): SrsItem[] {
  const today = dayKey();
  return Object.entries(profile?.srs || {})
    .filter(([, e]) => isValidSrs(e) && e.due <= today)
    .map(([refId, entry]) => ({ refId, entry }))
    .sort((a, b) => (a.entry.box || 0) - (b.entry.box || 0) || (b.entry.wrong || 0) - (a.entry.wrong || 0));
}

/** Weak items that are not due yet (used to fill up a short session). */
export function getWeakItems(profile: UserProfile | null | undefined): SrsItem[] {
  const today = dayKey();
  return Object.entries(profile?.srs || {})
    .filter(([, e]) => isValidSrs(e) && e.due > today && (e.box || 0) <= 2)
    .map(([refId, entry]) => ({ refId, entry }))
    .sort((a, b) => (b.entry.wrong || 0) - (a.entry.wrong || 0) || (a.entry.box || 0) - (b.entry.box || 0));
}

export function getSrsStats(profile: UserProfile | null | undefined) {
  const all = Object.values(profile?.srs || {}).filter(isValidSrs);
  return {
    tracked: all.length,
    due: getDueItems(profile).length,
    weak: all.filter((e) => (e.box || 0) <= 1 && (e.wrong || 0) > 0).length,
    strong: all.filter((e) => (e.box || 0) >= 4).length,
  };
}

/** Memory strength (0 to 5) and number of due items for a group of word ids. */
export function groupStrength(profile: UserProfile | null | undefined, ids: string[]) {
  const srs = profile?.srs || {};
  const today = dayKey();
  let known = 0;
  let sum = 0;
  let due = 0;
  (ids || []).forEach((id) => {
    const e = srs[id];
    if (isValidSrs(e)) {
      known += 1;
      sum += e.box || 0;
      if (e.due <= today) due += 1;
    }
  });
  return { known, avg: known ? sum / Math.max(1, ids.length) : 0, due };
}
