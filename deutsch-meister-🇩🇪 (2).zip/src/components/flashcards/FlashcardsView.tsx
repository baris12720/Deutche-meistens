import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import {
  Volume2,
  RotateCw,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Star,
  Plus,
  Trash2,
  StickyNote,
  X,
  BookMarked,
} from 'lucide-react';
import { ALL_VOCABULARY_WORDS } from '../../data/flashcards';
import { useApp } from '../../context/AppContext';
import { speakGerman } from '../../utils/audio';
import { ARTICLE_BADGE_CLASS } from '../../utils/articleColors';
import { ArticleType, CEFRLevel, VocabularyWord } from '../../types';

const PAGE_SIZE = 60;

const ARTICLE_COLOR_MAP: Record<ArticleType, string> = ARTICLE_BADGE_CLASS;

interface FlashcardCardProps {
  word: VocabularyWord;
  isFlipped: boolean;
  isMastered: boolean;
  isFavorite: boolean;
  isCustom: boolean;
  note: string;
  isEditingNote: boolean;
  noteDraft: string;
  onToggleFlip: (id: string) => void;
  onSpeak: (e: React.MouseEvent, text: string) => void;
  onMarkStatus: (e: React.MouseEvent, wordId: string, status: 'learning' | 'mastered') => void;
  onToggleFavorite: (e: React.MouseEvent, wordId: string) => void;
  onDeleteCustom: (e: React.MouseEvent, wordId: string) => void;
  onOpenNoteEditor: (e: React.MouseEvent, wordId: string) => void;
  onNoteDraftChange: (value: string) => void;
  onCancelNote: () => void;
  onSaveNote: (e: React.MouseEvent, wordId: string) => void;
}

const FlashcardCard: React.FC<FlashcardCardProps> = memo(
  ({
    word,
    isFlipped,
    isMastered,
    isFavorite,
    isCustom,
    note,
    isEditingNote,
    noteDraft,
    onToggleFlip,
    onSpeak,
    onMarkStatus,
    onToggleFavorite,
    onDeleteCustom,
    onOpenNoteEditor,
    onNoteDraftChange,
    onCancelNote,
    onSaveNote,
  }) => {
    const articleColor = ARTICLE_COLOR_MAP[word.article] || ARTICLE_COLOR_MAP.none;

    return (
      <div
        onClick={() => onToggleFlip(word.id)}
        className={`relative min-h-[240px] rounded-3xl p-5 border-2 transition-all cursor-pointer shadow-xs hover:shadow-md flex flex-col justify-between ${
          isFlipped
            ? 'bg-slate-50 dark:bg-slate-800/90 border-emerald-400 dark:border-emerald-700'
            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
        }`}
      >
        {/* Top Row: Level & Favorite / Delete / Flip indicator */}
        <div className="flex items-center justify-between gap-2">
          <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 truncate">
            {word.level} • {isCustom ? 'Özel' : word.category}
          </span>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={(e) => onToggleFavorite(e, word.id)}
              aria-label={isFavorite ? 'Defterden çıkar' : 'Deftere kaydet'}
              title={isFavorite ? 'Defterimden çıkar' : 'Defterime kaydet'}
              className={`p-1.5 rounded-lg transition cursor-pointer ${
                isFavorite
                  ? 'text-amber-500 bg-amber-50 dark:bg-amber-950/40'
                  : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              <Star className={`w-3.5 h-3.5 ${isFavorite ? 'fill-amber-500' : ''}`} />
            </button>
            {isCustom && (
              <button
                type="button"
                onClick={(e) => onDeleteCustom(e, word.id)}
                aria-label="Özel kelimeyi sil"
                title="Kelimeyi sil"
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
            <span className="text-[11px] text-slate-400 flex items-center gap-0.5 ml-0.5">
              <RotateCw className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card Center: Front vs Back */}
        {!isFlipped ? (
          <div className="my-auto text-center py-2">
            <div className="flex items-center justify-center gap-2 mb-2 flex-wrap">
              {word.article !== 'none' && (
                <span className={`text-xs font-black px-2 py-0.5 rounded-lg border ${articleColor}`}>
                  {word.article}
                </span>
              )}
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white break-words">
                {word.german}
              </h3>
            </div>

            <button
              onClick={(e) =>
                onSpeak(e, `${word.article !== 'none' ? word.article + ' ' : ''}${word.german}`)
              }
              className="p-2 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 transition inline-flex items-center justify-center cursor-pointer"
              title="Telaffuzu Dinle"
            >
              <Volume2 className="w-4 h-4" />
            </button>
            {note && (
              <div className="mt-2 text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold truncate px-2">
                📝 {note}
              </div>
            )}
            <span className="block text-[11px] text-slate-400 mt-1.5">
              Anlamı görmek için dokun
            </span>
          </div>
        ) : (
          <div className="my-auto text-center py-2 space-y-1.5">
            <h4 className="text-lg font-black text-emerald-600 dark:text-emerald-400">
              {word.turkish}
            </h4>
            {word.plural && (
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Çoğul: <span className="text-slate-700 dark:text-slate-200">{word.plural}</span>
              </p>
            )}
            {word.exampleGerman && (
              <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-left text-[11px]">
                <p className="text-slate-800 dark:text-slate-200 font-medium">
                  "{word.exampleGerman}"
                </p>
                {word.exampleTurkish && (
                  <p className="text-slate-400 italic">{word.exampleTurkish}</p>
                )}
              </div>
            )}

            {/* Personal Note Box */}
            <div
              className="pt-2 border-t border-slate-200 dark:border-slate-700 text-left"
              onClick={(e) => e.stopPropagation()}
            >
              {isEditingNote ? (
                <div className="space-y-1.5">
                  <input
                    type="text"
                    value={noteDraft}
                    onChange={(e) => onNoteDraftChange(e.target.value)}
                    placeholder="Hatırlatıcı notun..."
                    maxLength={240}
                    autoFocus
                    className="w-full px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-indigo-300 dark:border-indigo-700 text-xs text-slate-900 dark:text-white"
                  />
                  <div className="flex justify-end gap-1.5">
                    <button
                      type="button"
                      onClick={onCancelNote}
                      className="px-2 py-1 rounded-md text-[11px] font-bold text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                    >
                      İptal
                    </button>
                    <button
                      type="button"
                      onClick={(e) => onSaveNote(e, word.id)}
                      className="px-2.5 py-1 rounded-md bg-indigo-600 text-white text-[11px] font-bold cursor-pointer"
                    >
                      Kaydet
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={(e) => onOpenNoteEditor(e, word.id)}
                  className="w-full text-left text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                >
                  <StickyNote className="w-3 h-3 shrink-0" />
                  <span className="truncate">{note ? note : 'Kişisel not ekle...'}</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Card Bottom: Mastery Actions */}
        <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-700/60">
          <button
            onClick={(e) => onMarkStatus(e, word.id, 'learning')}
            className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center justify-center gap-1 ${
              !isMastered
                ? 'bg-amber-50 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
                : 'border-slate-200 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-700'
            }`}
          >
            <Clock className="w-3 h-3" /> Tekrar Et
          </button>
          <button
            onClick={(e) => onMarkStatus(e, word.id, 'mastered')}
            className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center justify-center gap-1 ${
              isMastered
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                : 'border-slate-200 text-slate-500 dark:text-slate-400 hover:bg-emerald-50 hover:text-emerald-700 dark:border-slate-700 dark:hover:bg-slate-700'
            }`}
          >
            <CheckCircle2 className="w-3 h-3" /> Öğrendim
          </button>
        </div>
      </div>
    );
  }
);

export const FlashcardsView: React.FC = memo(() => {
  const {
    profile,
    updateWordStatus,
    currentLevel,
    toggleFavoriteWord,
    setWordNote,
    addCustomWord,
    deleteCustomWord,
  } = useApp();

  const [filterLevel, setFilterLevel] = useState<CEFRLevel | 'ALL'>(currentLevel);
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'LEARNING' | 'MASTERED' | 'FAVORITES'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState('');

  // Custom word form modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newGerman, setNewGerman] = useState('');
  const [newTurkish, setNewTurkish] = useState('');
  const [newArticle, setNewArticle] = useState<ArticleType>('none');
  const [newLevel, setNewLevel] = useState<CEFRLevel>(currentLevel);
  const [newCategory, setNewCategory] = useState('Kişisel Defterim');
  const [newExampleDe, setNewExampleDe] = useState('');
  const [newExampleTr, setNewExampleTr] = useState('');
  const [formError, setFormError] = useState('');

  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [filterLevel, filterStatus, searchQuery]);

  const favoriteSet = useMemo(() => new Set(profile.favoriteWords || []), [profile.favoriteWords]);
  const customWords = profile.customWords || [];
  const allWords = useMemo(() => [...customWords, ...ALL_VOCABULARY_WORDS], [customWords]);

  const filteredWords = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allWords.filter((word) => {
      if (filterLevel !== 'ALL' && word.level !== filterLevel) return false;

      const userWord = profile.wordCards?.[word.id];
      const status = userWord ? userWord.status : 'learning';

      if (filterStatus === 'LEARNING' && status !== 'learning') return false;
      if (filterStatus === 'MASTERED' && status !== 'mastered') return false;
      if (filterStatus === 'FAVORITES' && !favoriteSet.has(word.id) && !word.id.startsWith('custom_')) {
        return false;
      }

      if (q) {
        const matchDe = word.german.toLowerCase().includes(q);
        const matchTr = word.turkish.toLowerCase().includes(q);
        const matchNote = (profile.wordNotes?.[word.id] || '').toLowerCase().includes(q);
        if (!matchDe && !matchTr && !matchNote) return false;
      }

      return true;
    });
  }, [allWords, filterLevel, filterStatus, searchQuery, profile.wordCards, profile.wordNotes, favoriteSet]);

  const visibleWords = useMemo(
    () => filteredWords.slice(0, visibleCount),
    [filteredWords, visibleCount]
  );

  const toggleFlip = useCallback((id: string) => {
    setFlippedCards((prev) => ({ ...prev, [id]: !prev[id] }));
  }, []);

  const handleAudio = useCallback(
    (e: React.MouseEvent, text: string) => {
      e.stopPropagation();
      speakGerman(text, profile.speechSpeed);
    },
    [profile.speechSpeed]
  );

  const handleMarkStatus = useCallback(
    (e: React.MouseEvent, wordId: string, status: 'learning' | 'mastered') => {
      e.stopPropagation();
      updateWordStatus(wordId, status);
    },
    [updateWordStatus]
  );

  const handleToggleFavorite = useCallback(
    (e: React.MouseEvent, wordId: string) => {
      e.stopPropagation();
      toggleFavoriteWord(wordId);
    },
    [toggleFavoriteWord]
  );

  const handleDeleteCustom = useCallback(
    (e: React.MouseEvent, wordId: string) => {
      e.stopPropagation();
      deleteCustomWord(wordId);
    },
    [deleteCustomWord]
  );

  const handleOpenNoteEditor = useCallback(
    (e: React.MouseEvent, wordId: string) => {
      e.stopPropagation();
      setEditingNoteId(wordId);
      setNoteDraft(profile.wordNotes?.[wordId] || '');
    },
    [profile.wordNotes]
  );

  const handleCancelNote = useCallback(() => {
    setEditingNoteId(null);
  }, []);

  const handleSaveNote = useCallback(
    (e: React.MouseEvent, wordId: string) => {
      e.stopPropagation();
      setWordNote(wordId, noteDraft);
      setEditingNoteId(null);
    },
    [setWordNote, noteDraft]
  );

  const handleCreateCustomWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGerman.trim() || !newTurkish.trim()) {
      setFormError('Lütfen Almanca kelimeyi ve Türkçe anlamını girin.');
      return;
    }
    addCustomWord({
      german: newGerman.trim(),
      turkish: newTurkish.trim(),
      article: newArticle,
      level: newLevel,
      category: newCategory.trim() || 'Kişisel Defterim',
      exampleGerman: newExampleDe.trim(),
      exampleTurkish: newExampleTr.trim(),
    });
    setNewGerman('');
    setNewTurkish('');
    setNewArticle('none');
    setNewLevel(currentLevel);
    setNewCategory('Kişisel Defterim');
    setNewExampleDe('');
    setNewExampleTr('');
    setFormError('');
    setIsAddModalOpen(false);
    setFilterStatus('FAVORITES');
    setFilterLevel('ALL');
  };

  const totalMastered = useMemo(
    () => Object.values(profile.wordCards || {}).filter((w) => w.status === 'mastered').length,
    [profile.wordCards]
  );

  const notebookCount = useMemo(
    () =>
      new Set([
        ...(profile.favoriteWords || []),
        ...customWords.map((w) => w.id),
      ]).size,
    [profile.favoriteWords, customWords]
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 pb-28">
      {/* Top Header Card */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-blue-600 to-indigo-700 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Aralıklı Tekrar & Kişisel Kelime Defteri
          </span>
          <h2 className="text-2xl font-black mt-1">Kelime Ezberleme Kartları</h2>
          <p className="text-xs sm:text-sm text-blue-100 mt-0.5">
            Kartlara dokunup anlamını görün, favoriye ekleyin, kişisel not alın veya kendi kelimenizi kaydedin.
          </p>
        </div>

        {/* Counter */}
        <div className="flex items-center gap-2 sm:gap-3 bg-white/10 backdrop-blur-xs p-3 rounded-2xl shrink-0">
          <div className="text-center px-2.5 border-r border-white/20">
            <span className="text-xl sm:text-2xl font-black block">{totalMastered}</span>
            <span className="text-[10px] uppercase font-bold text-blue-200">Öğrenilen</span>
          </div>
          <div className="text-center px-2.5 border-r border-white/20">
            <span className="text-xl sm:text-2xl font-black block">{notebookCount}</span>
            <span className="text-[10px] uppercase font-bold text-blue-200">Defterim</span>
          </div>
          <div className="text-center px-2.5">
            <span className="text-xl sm:text-2xl font-black block">{allWords.length}</span>
            <span className="text-[10px] uppercase font-bold text-blue-200">Toplam</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Almanca, Türkçe veya notlarında ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              setNewLevel(filterLevel === 'ALL' ? currentLevel : filterLevel);
              setFormError('');
              setIsAddModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-black inline-flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" /> Yeni Kelime Ekle
          </button>
        </div>

        {/* Level Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-1 overflow-x-auto py-1">
            <span className="text-xs font-bold text-slate-400 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Seviye:
            </span>
            {(['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setFilterLevel(lvl)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filterLevel === lvl
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                }`}
              >
                {lvl === 'ALL' ? 'Tümü' : lvl}
              </button>
            ))}
          </div>

          {/* Status Tabs */}
          <div className="flex flex-wrap items-center gap-1">
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'ALL'
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setFilterStatus('LEARNING')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'LEARNING'
                  ? 'bg-amber-500 text-white'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Tekrar Edilecek
            </button>
            <button
              onClick={() => setFilterStatus('MASTERED')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'MASTERED'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Öğrenildi
            </button>
            <button
              onClick={() => setFilterStatus('FAVORITES')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer inline-flex items-center gap-1 ${
                filterStatus === 'FAVORITES'
                  ? 'bg-indigo-600 text-white'
                  : 'text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/50'
              }`}
            >
              <BookMarked className="w-3.5 h-3.5" /> Defterim ({notebookCount})
            </button>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      {filteredWords.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-3">
          <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
            {filterStatus === 'FAVORITES'
              ? 'Kişisel kelime defterinizde henüz kelime yok. Kartlardaki yıldız simgesine dokunun veya kendi kelimenizi ekleyin.'
              : 'Arama kriterlerinize uygun kelime kartı bulunamadı.'}
          </p>
          {filterStatus === 'FAVORITES' && (
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" /> İlk Kelimeni Ekle
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {visibleWords.map((word) => {
              const userCard = profile.wordCards?.[word.id];
              const isEditing = editingNoteId === word.id;
              return (
                <FlashcardCard
                  key={word.id}
                  word={word}
                  isFlipped={!!flippedCards[word.id]}
                  isMastered={userCard?.status === 'mastered'}
                  isFavorite={favoriteSet.has(word.id)}
                  isCustom={word.id.startsWith('custom_')}
                  note={profile.wordNotes?.[word.id] || ''}
                  isEditingNote={isEditing}
                  noteDraft={isEditing ? noteDraft : ''}
                  onToggleFlip={toggleFlip}
                  onSpeak={handleAudio}
                  onMarkStatus={handleMarkStatus}
                  onToggleFavorite={handleToggleFavorite}
                  onDeleteCustom={handleDeleteCustom}
                  onOpenNoteEditor={handleOpenNoteEditor}
                  onNoteDraftChange={setNoteDraft}
                  onCancelNote={handleCancelNote}
                  onSaveNote={handleSaveNote}
                />
              );
            })}
          </div>
          {filteredWords.length > visibleWords.length && (
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                className="px-6 py-3 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-black text-slate-700 dark:text-slate-200 hover:border-blue-400 transition cursor-pointer"
              >
                Daha fazla kelime göster ({filteredWords.length - visibleWords.length} kaldı)
              </button>
            </div>
          )}
        </>
      )}

      {/* Custom Word Add Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleCreateCustomWord}
            className="w-full max-w-md max-h-[90dvh] overflow-y-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Kişisel Deftere Kelime Ekle
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                aria-label="Kapat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs font-bold text-rose-700 dark:text-rose-300">
                {formError}
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Artikel</label>
                <select
                  value={newArticle}
                  onChange={(e) => setNewArticle(e.target.value as ArticleType)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                >
                  <option value="none">Yok</option>
                  <option value="der">der</option>
                  <option value="die">die</option>
                  <option value="das">das</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Almanca Kelime *</label>
                <input
                  type="text"
                  value={newGerman}
                  onChange={(e) => setNewGerman(e.target.value)}
                  placeholder="ör: der Termin / sich bewerben"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 mb-1">Türkçe Anlamı *</label>
              <input
                type="text"
                value={newTurkish}
                onChange={(e) => setNewTurkish(e.target.value)}
                placeholder="ör: randevu / başvurmak"
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Seviye</label>
                <select
                  value={newLevel}
                  onChange={(e) => setNewLevel(e.target.value as CEFRLevel)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                >
                  {(['A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
                    <option key={lvl} value={lvl}>{lvl}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Kategori</label>
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 mb-1">Örnek Cümle (Almanca)</label>
              <input
                type="text"
                value={newExampleDe}
                onChange={(e) => setNewExampleDe(e.target.value)}
                placeholder="ör: Ich habe morgen einen Termin beim Arzt."
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 mb-1">Örnek Cümle (Türkçe)</label>
              <input
                type="text"
                value={newExampleTr}
                onChange={(e) => setNewExampleTr(e.target.value)}
                placeholder="ör: Yarın doktorda randevum var."
                className="w-full px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="flex-1 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-black cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                className="flex-1 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs cursor-pointer"
              >
                Deftere Kaydet
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
});
