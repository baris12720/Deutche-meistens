import React, { useState } from 'react';
import { ShieldCheck, Snowflake, X, Zap } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { useBackHandler } from '../../utils/backStack';

interface StreakFreezeModalProps {
  onClose: () => void;
}

const FREEZE_COST_XP = 100;
const MAX_FREEZES = 5;

export const StreakFreezeModal: React.FC<StreakFreezeModalProps> = ({ onClose }) => {
  const { profile, buyStreakFreeze } = useApp();
  const [feedback, setFeedback] = useState<string | null>(null);
  useBackHandler(true, onClose);

  const freezes = profile.streakFreezes || 0;
  const canAfford = (profile.xp || 0) >= FREEZE_COST_XP;
  const atLimit = freezes >= MAX_FREEZES;

  const handleBuy = () => {
    if (atLimit) {
      setFeedback(`En fazla ${MAX_FREEZES} adet Seri Dondurma biriktirebilirsin.`);
      return;
    }
    if (!canAfford) {
      setFeedback(`Seri Dondurma almak için en az ${FREEZE_COST_XP} XP gerekli.`);
      return;
    }
    const ok = buyStreakFreeze(FREEZE_COST_XP);
    if (ok) {
      setFeedback('❄️ 1 adet Seri Dondurma satın alındı! Bir gün ara versen bile serin korunacak.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-5 pop-in">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-2 text-sky-600 dark:text-sky-400 font-black text-sm">
            <Snowflake className="w-5 h-5" />
            <span>Seri Koruması (Streak Freeze)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Kapat"
            className="p-1.5 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-center space-y-2">
          <div className="text-4xl">❄️🛡️</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">
            {freezes} / {MAX_FREEZES} Kalkan Aktif
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Bir gün çalışmayı kaçırdığında Seri Dondurma otomatik olarak devreye girer ve mevcut{' '}
            <strong>{profile.streak} günlük serinin</strong> sıfırlanmasını engeller.
          </p>
        </div>

        <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
          <div>
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block">
              Mevcut XP Bakiyen
            </span>
            <span className="text-lg font-black text-amber-600 dark:text-amber-400 inline-flex items-center gap-1 tabular-nums">
              <Zap className="w-4 h-4 fill-amber-500" /> {profile.xp} XP
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block">Birim Fiyat</span>
            <span className="text-sm font-black text-slate-900 dark:text-white">{FREEZE_COST_XP} XP</span>
          </div>
        </div>

        {feedback && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-200 text-center">
            {feedback}
          </div>
        )}

        <button
          type="button"
          onClick={handleBuy}
          disabled={!canAfford || atLimit}
          className="w-full h-13 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-sm shadow-[0_4px_0_#0369a1] active:translate-y-0.5 active:shadow-none disabled:opacity-45 transition inline-flex items-center justify-center gap-2 cursor-pointer"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>
            {atLimit
              ? `Maksimum Kalkan (${MAX_FREEZES}) Dolu`
              : canAfford
              ? `${FREEZE_COST_XP} XP ile Seri Dondurma Al`
              : `Yetersiz XP (${FREEZE_COST_XP - (profile.xp || 0)} XP eksik)`}
          </span>
        </button>
      </div>
    </div>
  );
};
