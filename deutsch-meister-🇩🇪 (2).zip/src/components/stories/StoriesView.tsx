import React, { memo, useCallback, useMemo, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  ChevronLeft,
  Clock,
  PlusCircle,
  Sparkles,
  Volume2,
  X,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { STORIES, Story, StoryWordEntry } from '../../data/stories';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { speakGerman, stopSpeaking } from '../../utils/audio';
import { ARTICLE_BADGE_CLASS, ARTICLE_TEXT_COLOR } from '../../utils/articleColors';
import { useBackHandler } from '../../utils/backStack';

interface SelectedWordState {
  token: string;
  entry: StoryWordEntry;
  lineGerman: string;
  lineTurkish: string;
}

const LEVELS: (CEFRLevel | 'ALL')[] = ['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'];

const normalizeTokenKey = (raw: string): string =>
  raw
    .replace(/^[^A-Za-zÄÖÜäöüß]+|[^A-Za-zÄÖÜäöüß]+$/g, '')
    .toLowerCase();

export const StoriesView: React.FC = memo(() => {
  const {
    profile,
    currentLevel,
    addCustomWord,
    recordAnswer,
    recordActivity,
    markStoryDone,
  } = useApp();

  const [levelFilter, setLevelFilter] = useState<CEFRLevel | 'ALL'>(currentLevel);
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [showTranslations, setShowTranslations] = useState(false);
  const [selectedWord, setSelectedWord] = useState<SelectedWordState | null>(null);
  const [savedWordsToast, setSavedWordsToast] = useState<string | null>(null);
  const [addedWordKeys, setAddedWordKeys] = useState<Set<string>>(() => new Set());

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const completedSet = useMemo(
    () => new Set(profile.completedStories || []),
    [profile.completedStories]
  );

  const filteredStories = useMemo(
    () =>
      STORIES.filter((s) => levelFilter === 'ALL' || s.level === levelFilter),
    [levelFilter]
  );

  const openStory = useCallback((story: Story) => {
    setActiveStory(story);
    setSelectedWord(null);
    setShowTranslations(false);
    setQuizAnswers({});
    setQuizSubmitted(false);
  }, []);

  const closeStory = useCallback(() => {
    void stopSpeaking();
    setActiveStory(null);
    setSelectedWord(null);
  }, []);

  useBackHandler(activeStory !== null, closeStory);

  const handleWordClick = useCallback(
    (rawToken: string, lineGerman: string, lineTurkish: string) => {
      if (!activeStory) return;
      const key = normalizeTokenKey(rawToken);
      if (!key) return;
      const entry = activeStory.vocabularyMap[key];
      if (!entry) {
        speakGerman(rawToken.replace(/[.,!?;:"'()]/g, ''), profile.speechSpeed);
        return;
      }
      speakGerman(
        entry.article !== 'none' ? `${entry.article} ${entry.base}` : entry.base,
        profile.speechSpeed
      );
      setSelectedWord({
        token: key,
        entry,
        lineGerman,
        lineTurkish,
      });
    },
    [activeStory, profile.speechSpeed]
  );

  const handleAddWordToSrs = useCallback(() => {
    if (!selectedWord || !activeStory) return;
    const { entry, lineGerman, lineTurkish, token } = selectedWord;
    const existing = (profile.customWords || []).find(
      (w) => w.german.toLowerCase() === entry.base.toLowerCase()
    );
    const created =
      existing ||
      addCustomWord({
        german: entry.base,
        turkish: entry.turkish,
        article: entry.article,
        plural: entry.plural,
        level: activeStory.level,
        category: entry.category || activeStory.scenarioTag,
        exampleGerman: entry.exampleDe || lineGerman,
        exampleTurkish: entry.exampleTr || lineTurkish,
      });
    // Put into SRS Smart Review (Box 0 so it enters active study queue immediately)
    recordAnswer(created.id, false);
    setAddedWordKeys((prev) => new Set(prev).add(token));
    setSavedWordsToast(`"${entry.article !== 'none' ? entry.article + ' ' : ''}${entry.base}" kelime listene ve Akıllı Tekrara eklendi!`);
    window.setTimeout(() => setSavedWordsToast(null), 2600);
  }, [selectedWord, activeStory, profile.customWords, addCustomWord, recordAnswer]);

  const handleSubmitQuiz = useCallback(() => {
    if (!activeStory || quizSubmitted) return;
    const total = activeStory.questions.length;
    const correctCount = activeStory.questions.filter(
      (q) => quizAnswers[q.id] === q.correctAnswer
    ).length;
    setQuizSubmitted(true);
    recordActivity('reading', correctCount >= 2, 45);
    const earned = correctCount >= 2 ? activeStory.xpReward : Math.max(10, correctCount * 8);
    markStoryDone(activeStory.id, earned);
    if (correctCount >= 2) {
      try {
        confetti({ particleCount: 95, spread: 70, origin: { y: 0.65 } });
      } catch {
        /* ignore */
      }
    }
  }, [activeStory, quizSubmitted, quizAnswers, recordActivity, markStoryDone]);

  if (activeStory) {
    const allAnswered = activeStory.questions.every((q) => !!quizAnswers[q.id]);
    const correctCount = activeStory.questions.filter(
      (q) => quizAnswers[q.id] === q.correctAnswer
    ).length;

    return (
      <div className="max-w-3xl mx-auto px-4 py-5 pb-28 space-y-5 page-enter">
        {/* Story Top Bar */}
        <div className="flex items-center justify-between gap-3 bg-white dark:bg-slate-800 p-4 rounded-3xl border-2 border-slate-200 dark:border-slate-700 shadow-xs">
          <button
            type="button"
            onClick={closeStory}
            className="inline-flex items-center gap-1.5 text-sm font-black text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
            <span>Hikayeler</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                speakGerman(
                  activeStory.lines.map((l) => l.german).join(' '),
                  profile.speechSpeed
                )
              }
              className="px-3 py-1.5 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 text-xs font-black inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-4 h-4" /> Tümünü Dinle
            </button>
            <button
              type="button"
              onClick={() => setShowTranslations((v) => !v)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                showTranslations
                  ? 'bg-amber-500 text-white'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {showTranslations ? 'Türkçeyi Gizle' : 'Türkçeyi Göster'}
            </button>
          </div>
        </div>

        {/* Story Hero */}
        <div className="p-5 sm:p-6 rounded-3xl bg-linear-to-br from-indigo-600 to-violet-700 text-white shadow-lg">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{activeStory.emoji}</span>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-lg bg-white/20 text-[11px] font-black">
                  {activeStory.level} • {activeStory.scenarioTag}
                </span>
                <span className="text-[11px] font-bold text-indigo-100">
                  +{activeStory.xpReward} XP
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black mt-1">{activeStory.titleDe}</h2>
              <p className="text-xs sm:text-sm text-indigo-100">{activeStory.titleTr}</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/20 text-xs text-indigo-100 flex items-center gap-2">
            <Sparkles className="w-4 h-4 shrink-0 text-amber-300" />
            <span>
              İpucu: Altı çizili herhangi bir Almanca kelimenin üzerine dokunarak artikelini (
              <strong className="text-blue-200">der</strong> /{' '}
              <strong className="text-rose-200">die</strong> /{' '}
              <strong className="text-emerald-200">das</strong>), çoğul halini ve anlamını gör!
            </span>
          </div>
        </div>

        {/* Interactive Word Popover Card */}
        {selectedWord && (
          <div className="sticky top-18 z-30 rounded-3xl bg-white dark:bg-slate-800 border-2 border-indigo-400 dark:border-indigo-500 p-4 shadow-2xl pop-in">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  {selectedWord.entry.article !== 'none' && (
                    <span
                      className={`text-xs font-black px-2 py-0.5 rounded-lg border ${
                        ARTICLE_BADGE_CLASS[selectedWord.entry.article]
                      }`}
                    >
                      {selectedWord.entry.article}
                    </span>
                  )}
                  <span className="text-lg font-black text-slate-900 dark:text-white">
                    {selectedWord.entry.base}
                  </span>
                  {selectedWord.entry.plural && (
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      (Çoğul: {selectedWord.entry.plural})
                    </span>
                  )}
                </div>
                <p className="text-sm font-bold text-emerald-700 dark:text-emerald-400">
                  {selectedWord.entry.turkish}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    speakGerman(
                      selectedWord.entry.article !== 'none'
                        ? `${selectedWord.entry.article} ${selectedWord.entry.base}`
                        : selectedWord.entry.base,
                      profile.speechSpeed
                    )
                  }
                  aria-label="Kelimeyi dinle"
                  className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 cursor-pointer"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedWord(null)}
                  aria-label="Kartı kapat"
                  className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-slate-100 dark:border-slate-700">
              <span className="text-[11px] font-bold text-slate-400">
                Kategori: {selectedWord.entry.category || activeStory.scenarioTag}
              </span>
              <button
                type="button"
                onClick={handleAddWordToSrs}
                disabled={addedWordKeys.has(selectedWord.token)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black inline-flex items-center gap-1.5 transition cursor-pointer ${
                  addedWordKeys.has(selectedWord.token)
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                }`}
              >
                {addedWordKeys.has(selectedWord.token) ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" /> Listene & Tekrara Eklendi
                  </>
                ) : (
                  <>
                    <PlusCircle className="w-4 h-4" /> Kelime Listeme & SRS'e Ekle
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Dialogue Lines */}
        <div className="space-y-3">
          {activeStory.lines.map((line) => {
            const tokens = line.german.split(/\s+/);
            return (
              <div
                key={line.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <span className="inline-block text-[11px] font-black uppercase tracking-wide text-indigo-600 dark:text-indigo-400 mb-1">
                      {line.speaker}
                    </span>
                    <p className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed flex flex-wrap gap-x-1.5 gap-y-1">
                      {tokens.map((tok, idx) => {
                        const key = normalizeTokenKey(tok);
                        const dictEntry = key ? activeStory.vocabularyMap[key] : undefined;
                        const isSelected = selectedWord?.token === key;
                        if (!dictEntry) {
                          return <span key={idx}>{tok}</span>;
                        }
                        const artColor =
                          dictEntry.article !== 'none'
                            ? ARTICLE_TEXT_COLOR[dictEntry.article]
                            : 'text-indigo-600 dark:text-indigo-400';
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => handleWordClick(tok, line.german, line.turkish)}
                            className={`px-1 rounded-lg border-b-2 border-dotted transition cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-100 dark:bg-indigo-950 border-indigo-500 ring-2 ring-indigo-300 dark:ring-indigo-700'
                                : 'border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700/70'
                            } ${artColor}`}
                            title="Anlamını ve artikelini görmek için dokun"
                          >
                            {tok}
                          </button>
                        );
                      })}
                    </p>
                    {showTranslations && (
                      <p className="mt-1.5 text-xs sm:text-sm text-slate-500 dark:text-slate-400 italic">
                        {line.turkish}
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => speakGerman(line.german, profile.speechSpeed)}
                    aria-label="Satırı dinle"
                    className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 shrink-0 cursor-pointer"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reading Comprehension 3-Question Test */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 space-y-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Okuduğunu Anlama Testi (3 Soru)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Hikayeyi tamamlamak ve +{activeStory.xpReward} XP kazanmak için soruları yanıtla.
              </p>
            </div>
            {quizSubmitted && (
              <span className="px-3 py-1 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-black">
                {correctCount}/{activeStory.questions.length} Doğru
              </span>
            )}
          </div>

          <div className="space-y-4">
            {activeStory.questions.map((q, qIdx) => {
              const picked = quizAnswers[q.id];
              return (
                <div
                  key={q.id}
                  className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-2.5"
                >
                  <p className="text-sm font-black text-slate-900 dark:text-white">
                    {qIdx + 1}. {q.questionTr}
                  </p>
                  <div className="grid grid-cols-1 gap-2">
                    {q.options.map((opt) => {
                      const isPicked = picked === opt;
                      const isRight = opt === q.correctAnswer;
                      return (
                        <button
                          key={opt}
                          type="button"
                          disabled={quizSubmitted}
                          onClick={() =>
                            setQuizAnswers((prev) => ({ ...prev, [q.id]: opt }))
                          }
                          className={`text-left px-3.5 py-2.5 rounded-xl border-2 text-xs sm:text-sm font-bold transition cursor-pointer ${
                            quizSubmitted
                              ? isRight
                                ? 'border-emerald-500 bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-100'
                                : isPicked
                                ? 'border-rose-500 bg-rose-100 dark:bg-rose-950 text-rose-900 dark:text-rose-100'
                                : 'border-slate-200 dark:border-slate-700 opacity-50'
                              : isPicked
                              ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-100'
                              : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {quizSubmitted && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 pt-1">
                      💡 {q.explanationTr}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          {!quizSubmitted ? (
            <button
              type="button"
              disabled={!allAnswered}
              onClick={handleSubmitQuiz}
              className="w-full h-13 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm shadow-[0_4px_0_#047857] active:translate-y-0.5 active:shadow-none disabled:opacity-40 transition cursor-pointer"
            >
              Cevapları Kontrol Et
            </button>
          ) : (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-sm font-black text-emerald-800 dark:text-emerald-200">
                🎉 Hikaye tamamlandı! {correctCount}/3 doğru ile XP kazandın.
              </div>
              <button
                type="button"
                onClick={closeStory}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-black cursor-pointer"
              >
                Diğer Hikayelere Dön
              </button>
            </div>
          )}
        </div>

        {savedWordsToast && (
          <div
            role="status"
            className="fixed left-1/2 -translate-x-1/2 bottom-24 z-50 max-w-[90vw] px-4 py-2.5 rounded-2xl bg-slate-900 text-white text-xs font-bold shadow-xl"
          >
            {savedWordsToast}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-28 space-y-6">
      <div className="p-6 rounded-3xl bg-linear-to-r from-indigo-600 to-purple-700 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Bağlam İçinde Öğrenme
          </span>
          <h2 className="text-2xl font-black mt-1">İnteraktif Kısa Hikayeler</h2>
          <p className="text-xs sm:text-sm text-indigo-100 mt-0.5">
            Günlük Almanya senaryolarını oku ve dinle. Bilmediğin kelimeye dokunup anlamını gör ve tek tıkla SRS listene ekle.
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-2xl text-center shrink-0">
          <span className="text-xl font-black block">
            {completedSet.size}/{STORIES.length}
          </span>
          <span className="text-[10px] uppercase font-bold text-indigo-100">Tamamlanan</span>
        </div>
      </div>

      {/* Level Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {LEVELS.map((lvl) => (
          <button
            key={lvl}
            type="button"
            onClick={() => setLevelFilter(lvl)}
            className={`px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer shrink-0 ${
              levelFilter === lvl
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {lvl === 'ALL' ? 'Tüm Seviyeler' : lvl}
          </button>
        ))}
      </div>

      {/* Story Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {filteredStories.map((story) => {
          const isDone = completedSet.has(story.id);
          return (
            <button
              key={story.id}
              type="button"
              onClick={() => openStory(story)}
              className="text-left p-5 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-500 transition shadow-2xs flex flex-col justify-between gap-4 cursor-pointer"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[11px] font-black">
                    {story.level} • {story.scenarioTag}
                  </span>
                  {isDone ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Okundu
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-400">
                      <Clock className="w-3.5 h-3.5" /> {story.durationMin} dk
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{story.emoji}</span>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white leading-snug">
                      {story.titleTr}
                    </h3>
                    <p className="text-xs font-semibold text-slate-400">{story.titleDe}</p>
                  </div>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed">
                  {story.summaryTr}
                </p>
              </div>
              <div className="pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs font-black text-indigo-600 dark:text-indigo-400">
                <span className="inline-flex items-center gap-1">
                  <BookOpen className="w-4 h-4" /> Hikayeyi Oku & Dinle
                </span>
                <span>+{story.xpReward} XP</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
});
