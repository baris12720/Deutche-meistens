import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  GripVertical,
  HelpCircle,
  RotateCcw,
  Sparkles,
  Volume2,
  XCircle,
} from 'lucide-react';
import {
  SYNTAX_EXERCISES,
  SyntaxExercise,
  SyntaxRuleCategory,
  explainSyntaxMistakeTr,
} from '../../data/syntaxWorkshop';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { playSuccessSound, playWrongSound, speakGerman } from '../../utils/audio';

const shuffleWords = (list: string[]): string[] => {
  const arr = [...list];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
};

const normSentence = (text: string): string =>
  text
    .trim()
    .replace(/[.,!?]+/g, '')
    .replace(/\s+/g, ' ')
    .toLowerCase();

interface TokenChip {
  id: string;
  text: string;
}

const RULE_CATEGORIES: ('ALL' | SyntaxRuleCategory)[] = [
  'ALL',
  'V2 (Fiil 2. Sırada)',
  'Modalverb (Cümle Çerçevesi)',
  'Nebensatz (Yan Cümle - Fiil Sona)',
  'Inversion (Devrik Dizilim)',
];

export const SentenceBuilder: React.FC = memo(() => {
  const { profile, currentLevel, addXp, recordActivity } = useApp();
  const [levelFilter, setLevelFilter] = useState<CEFRLevel | 'ALL'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | SyntaxRuleCategory>('ALL');
  const [index, setIndex] = useState(0);
  const [showHint, setShowHint] = useState(false);

  const pool = useMemo(() => {
    const filtered = SYNTAX_EXERCISES.filter((ex) => {
      if (levelFilter !== 'ALL' && ex.level !== levelFilter) return false;
      if (categoryFilter !== 'ALL' && ex.category !== categoryFilter) return false;
      return true;
    });
    return filtered.length > 0 ? filtered : SYNTAX_EXERCISES;
  }, [levelFilter, categoryFilter]);

  const currentEx: SyntaxExercise = pool[index % pool.length];

  const [trayTokens, setTrayTokens] = useState<TokenChip[]>([]);
  const [bankTokens, setBankTokens] = useState<TokenChip[]>([]);
  const [checked, setChecked] = useState<{ ok: boolean; messageTr: string } | null>(null);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  const resetCurrent = useCallback((ex: SyntaxExercise) => {
    const chips: TokenChip[] = shuffleWords(ex.scrambledWords).map((text, idx) => ({
      id: `${ex.id}_tok_${idx}_${text}`,
      text,
    }));
    setBankTokens(chips);
    setTrayTokens([]);
    setChecked(null);
    setShowHint(false);
    setDraggedIndex(null);
  }, []);

  useEffect(() => {
    setIndex(0);
  }, [levelFilter, categoryFilter, currentLevel]);

  useEffect(() => {
    resetCurrent(currentEx);
  }, [currentEx, resetCurrent]);

  const moveToTray = (chip: TokenChip) => {
    if (checked) return;
    setBankTokens((prev) => prev.filter((c) => c.id !== chip.id));
    setTrayTokens((prev) => [...prev, chip]);
  };

  const moveToBank = (chip: TokenChip) => {
    if (checked) return;
    setTrayTokens((prev) => prev.filter((c) => c.id !== chip.id));
    setBankTokens((prev) => [...prev, chip]);
  };

  const moveTrayTokenOrder = (fromIdx: number, toIdx: number) => {
    if (checked || fromIdx === toIdx || fromIdx < 0 || toIdx < 0) return;
    setTrayTokens((prev) => {
      if (fromIdx >= prev.length || toIdx >= prev.length) return prev;
      const next = [...prev];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return next;
    });
  };

  const handleCheck = () => {
    if (checked || trayTokens.length === 0) return;
    const built = trayTokens.map((t) => t.text).join(' ');
    const normBuilt = normSentence(built);
    const accepted = [
      currentEx.correctGermanSentence,
      ...(currentEx.acceptedVariants || []),
    ].map(normSentence);

    const isOk = accepted.includes(normBuilt);
    recordActivity('grammar', isOk, 20);

    if (isOk) {
      playSuccessSound(profile.soundEnabled);
      addXp(8);
      speakGerman(built, profile.speechSpeed);
      setChecked({
        ok: true,
        messageTr: `Harika! +8 XP kazandın. ${currentEx.explanationTr}`,
      });
    } else {
      playWrongSound(profile.soundEnabled);
      const diagnostic = explainSyntaxMistakeTr(
        currentEx,
        trayTokens.map((t) => t.text)
      );
      setChecked({
        ok: false,
        messageTr: diagnostic,
      });
    }
  };

  const handleNext = () => {
    setIndex((prev) => (prev + 1) % pool.length);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-5 pb-28 space-y-5">
      {/* Banner */}
      <div className="p-5 sm:p-6 rounded-3xl bg-linear-to-r from-emerald-600 to-teal-700 text-white shadow-lg">
        <span className="text-[11px] font-black uppercase tracking-wider bg-white/20 px-2.5 py-1 rounded-full">
          Sözdizimi Atölyesi
        </span>
        <h2 className="text-xl sm:text-2xl font-black mt-2">
          Almanca Cümle Kurma & Fiil Dizilimi
        </h2>
        <p className="text-xs sm:text-sm text-emerald-50 mt-1">
          Fiilin 2. sırada olduğu düz cümleleri, modal fiil çerçevesini ve yan cümlelerde (weil, dass, obwohl) fiilin sona gitmesini uygulamalı öğren.
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
            <button
              key={lvl}
              type="button"
              onClick={() => setLevelFilter(lvl)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition cursor-pointer shrink-0 ${
                levelFilter === lvl
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {lvl === 'ALL' ? 'Tüm Seviyeler' : lvl}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {RULE_CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold transition cursor-pointer shrink-0 ${
                categoryFilter === cat
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              {cat === 'ALL' ? 'Tüm Kurallar' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Active Exercise Card */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xs space-y-5">
        <div className="flex items-center justify-between gap-2">
          <span className="px-2.5 py-1 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 text-xs font-black">
            {currentEx.level} • {currentEx.category}
          </span>
          <span className="text-xs font-black text-slate-400 tabular-nums">
            {(index % pool.length) + 1} / {pool.length}
          </span>
        </div>

        {/* Turkish Target Prompt */}
        <div className="p-4 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
          <span className="text-[11px] font-black uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
            Kurulacak Cümle
          </span>
          <p className="text-base sm:text-lg font-black text-slate-900 dark:text-white mt-1">
            "{currentEx.turkishPrompt}"
          </p>
        </div>

        {/* Rule Hint Toggle */}
        <div>
          <button
            type="button"
            onClick={() => setShowHint((v) => !v)}
            className="text-xs font-black text-amber-600 dark:text-amber-400 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
            {showHint ? 'Kural İpucunu Gizle' : 'Kural İpucu Göster'}
          </button>
          {showHint && (
            <div className="mt-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs font-semibold text-amber-900 dark:text-amber-200">
              💡 {currentEx.ruleHintTr}
            </div>
          )}
        </div>

        {/* Sentence Construction Tray (supports click + drag reorder) */}
        <div>
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 mb-1.5">
            <span>Cümle Alanı (Sıralamayı değiştirmek için kelimeleri sürükle veya çıkar)</span>
            {trayTokens.length > 0 && !checked && (
              <button
                type="button"
                onClick={() => resetCurrent(currentEx)}
                className="inline-flex items-center gap-1 text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Sıfırla
              </button>
            )}
          </div>
          <div className="min-h-24 p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border-2 border-dashed border-slate-300 dark:border-slate-700 flex flex-wrap gap-2 items-center">
            {trayTokens.length === 0 ? (
              <span className="text-xs font-medium text-slate-400 mx-auto">
                Aşağıdaki kelime bloklarına dokunarak cümleyi kurmaya başla
              </span>
            ) : (
              trayTokens.map((chip, idx) => (
                <div
                  key={chip.id}
                  draggable={!checked}
                  onDragStart={() => setDraggedIndex(idx)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => {
                    if (draggedIndex !== null) moveTrayTokenOrder(draggedIndex, idx);
                    setDraggedIndex(null);
                  }}
                  className={`inline-flex items-center gap-1 px-3 py-2 rounded-xl font-bold text-sm border transition ${
                    checked
                      ? checked.ok
                        ? 'bg-emerald-100 dark:bg-emerald-950 border-emerald-400 text-emerald-900 dark:text-emerald-100'
                        : 'bg-rose-100 dark:bg-rose-950 border-rose-400 text-rose-900 dark:text-rose-100'
                      : 'bg-white dark:bg-slate-800 border-emerald-400 dark:border-emerald-700 text-slate-900 dark:text-white shadow-xs cursor-grab'
                  }`}
                >
                  {!checked && (
                    <GripVertical className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  )}
                  <button
                    type="button"
                    disabled={!!checked}
                    onClick={() => moveToBank(chip)}
                    className="cursor-pointer"
                    title="Geri çıkar"
                  >
                    {chip.text}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Word Bank */}
        <div className="flex flex-wrap gap-2 justify-center pt-1">
          {bankTokens.map((chip) => (
            <button
              key={chip.id}
              type="button"
              disabled={!!checked}
              onClick={() => moveToTray(chip)}
              className="px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-bold text-sm border-2 border-slate-200 dark:border-slate-700 shadow-[0_3px_0_#e2e8f0] dark:shadow-[0_3px_0_#334155] hover:border-emerald-400 active:translate-y-0.5 active:shadow-none transition cursor-pointer"
            >
              {chip.text}
            </button>
          ))}
        </div>

        {/* Evaluation Feedback Banner */}
        {checked && (
          <div
            className={`p-4 rounded-2xl border-2 space-y-2 pop-in ${
              checked.ok
                ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-700'
                : 'bg-rose-50 dark:bg-rose-950/40 border-rose-400 dark:border-rose-700'
            }`}
          >
            <div className="flex items-start gap-2.5">
              {checked.ok ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1 flex-1">
                <div
                  className={`text-sm font-black ${
                    checked.ok
                      ? 'text-emerald-800 dark:text-emerald-200'
                      : 'text-rose-800 dark:text-rose-200'
                  }`}
                >
                  {checked.ok ? 'Doğru Dizilim!' : 'Sözdizimi Hatası — Kuralı İncele'}
                </div>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed font-semibold">
                  {checked.messageTr}
                </p>
                {!checked.ok && (
                  <div className="pt-1 flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-xs font-black text-emerald-700 dark:text-emerald-300">
                      Doğru Cümle: {currentEx.correctGermanSentence}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        speakGerman(currentEx.correctGermanSentence, profile.speechSpeed)
                      }
                      className="text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" /> Dinle
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Action Button */}
        <div className="flex gap-2.5 pt-1">
          {!checked ? (
            <button
              type="button"
              disabled={trayTokens.length === 0}
              onClick={handleCheck}
              className="flex-1 h-13 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm shadow-[0_4px_0_#047857] active:translate-y-0.5 active:shadow-none disabled:opacity-40 transition inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" /> Cümleyi Kontrol Et
            </button>
          ) : (
            <>
              {!checked.ok && (
                <button
                  type="button"
                  onClick={() => resetCurrent(currentEx)}
                  className="px-5 h-13 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-black text-sm cursor-pointer"
                >
                  Tekrar Dene
                </button>
              )}
              <button
                type="button"
                onClick={handleNext}
                className="flex-1 h-13 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm shadow-[0_4px_0_#047857] active:translate-y-0.5 active:shadow-none transition inline-flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Sonraki Cümle</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
});
