import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, Heart, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { QuestWord } from '../../data/vocab/words';
import { getLevelWords } from '../../data/vocab/builder';
import { LEVEL_ORDER } from '../../utils/progress';
import { useBackHandler } from '../../utils/backStack';
import { calculateTextSimilarity, playSuccessSound, playWrongSound, speakGerman } from '../../utils/audio';
import { ARTICLE_TEXT_COLOR } from '../../utils/articleColors';
import { GermanNoun } from '../common/GermanNoun';

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};
const display = (w: QuestWord) => (w.article !== 'none' ? `${w.article} ${w.german}` : w.german);
const celebrate = () => {
  try {
    confetti({ particleCount: 110, spread: 75, origin: { y: 0.65 } });
  } catch {
    /* ignore */
  }
};

interface GameProps {
  level: CEFRLevel;
  onExit: () => void;
}

const BigButton: React.FC<{ onClick: () => void; children: React.ReactNode; color?: string; shadow?: string }> = ({
  onClick,
  children,
  color = 'bg-emerald-500',
  shadow = 'shadow-[0_5px_0_#047857]',
}) => (
  <button
    onClick={onClick}
    className={`w-full h-14 rounded-2xl ${color} text-white font-black text-base ${shadow} active:translate-y-1 active:shadow-none transition cursor-pointer`}
  >
    {children}
  </button>
);

const GameShell: React.FC<{ title: string; onExit: () => void; children: React.ReactNode }> = ({ title, onExit, children }) => (
  <div>
    <div className="flex items-center gap-2 mb-4">
      <button onClick={onExit} aria-label="Oyunlara dön" className="p-2 -ml-2 text-slate-500 cursor-pointer">
        <ChevronLeft className="w-6 h-6" />
      </button>
      <h3 className="text-lg font-black text-slate-900 dark:text-white">{title}</h3>
    </div>
    {children}
  </div>
);

/* ---------------- 1. Match pairs ---------------- */
const MatchGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const [round, setRound] = useState(0);
  const pairs = useMemo(() => shuffle(getLevelWords(level)).slice(0, 6), [level, round]);
  const left = useMemo(() => shuffle(pairs.map((w) => w.id)), [pairs]);
  const right = useMemo(() => shuffle(pairs.map((w) => w.id)), [pairs]);
  const [selL, setSelL] = useState<string | null>(null);
  const [selR, setSelR] = useState<string | null>(null);
  const [matched, setMatched] = useState<string[]>([]);
  const [wrong, setWrong] = useState<{ l: string; r: string } | null>(null);
  const [mistakes, setMistakes] = useState(0);
  const [hint, setHint] = useState<string | null>(null);
  const done = matched.length === pairs.length && pairs.length > 0;
  const byId = (id: string) => pairs.find((w) => w.id === id)!;

  useEffect(() => {
    if (!selL || !selR) return;
    if (selL === selR) {
      playSuccessSound(profile.soundEnabled);
      setMatched((m) => [...m, selL]);
      setSelL(null);
      setSelR(null);
    } else {
      playWrongSound(profile.soundEnabled);
      setMistakes((m) => m + 1);
      setWrong({ l: selL, r: selR });
      const right = pairs.find((w) => w.id === selL);
      if (right) {
        setHint(`Doğru eşleşme: ${display(right)} = ${right.turkish}`);
        setTimeout(() => setHint(null), 2600);
      }
      const t = setTimeout(() => {
        setWrong(null);
        setSelL(null);
        setSelR(null);
      }, 600);
      return () => clearTimeout(t);
    }
  }, [selL, selR]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (done) {
      addXp(Math.max(4, 14 - mistakes * 2));
      celebrate();
    }
  }, [done]); // eslint-disable-line react-hooks/exhaustive-deps

  const restart = () => {
    setRound((r) => r + 1);
    setSelL(null);
    setSelR(null);
    setMatched([]);
    setMistakes(0);
    setWrong(null);
  };

  const cell = (id: string, side: 'l' | 'r', text: string) => {
    const isMatched = matched.includes(id);
    const selected = side === 'l' ? selL === id : selR === id;
    const isWrong = wrong && (side === 'l' ? wrong.l === id : wrong.r === id);
    return (
      <button
        key={`${side}${id}`}
        disabled={isMatched || !!wrong}
        onClick={() => (side === 'l' ? setSelL(id) : setSelR(id))}
        className={`min-h-14 px-3 py-2 rounded-2xl border-2 text-sm font-bold transition cursor-pointer ${
          isMatched
            ? 'opacity-40 border-emerald-300 bg-emerald-50 dark:bg-emerald-950 text-emerald-700'
            : isWrong
            ? 'border-rose-500 bg-rose-50 dark:bg-rose-950 text-rose-700'
            : selected
            ? 'border-sky-500 bg-sky-50 dark:bg-sky-950 text-sky-800 dark:text-sky-200'
            : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100'
        }`}
      >
        {text}
      </button>
    );
  };

  return (
    <GameShell title="Eşleştir" onExit={onExit}>
      <p className="text-sm text-slate-500 mb-3">Almanca kelimeyi Türkçe karşılığıyla eşleştir. Hata: {mistakes}</p>
      {hint && (
        <div className="mb-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950 border-2 border-emerald-400 p-3 text-center text-sm font-black text-emerald-800 dark:text-emerald-200 pop-in">{hint}</div>
      )}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2.5">{left.map((id) => cell(id, 'l', display(byId(id))))}</div>
        <div className="space-y-2.5">{right.map((id) => cell(id, 'r', byId(id).turkish))}</div>
      </div>
      {done && (
        <div className="mt-5 text-center space-y-3 pop-in">
          <div className="text-3xl">🎉</div>
          <div className="font-black text-slate-900 dark:text-white">Tamamlandı! +{Math.max(4, 14 - mistakes * 2)} XP</div>
          <BigButton onClick={restart}>Yeni tur</BigButton>
        </div>
      )}
    </GameShell>
  );
};

/* ---------------- 2. Article rush ---------------- */
const ArticleGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const [round, setRound] = useState(0);
  const words = useMemo(
    () => shuffle(getLevelWords(level).filter((w) => ['der', 'die', 'das'].includes(w.article))).slice(0, 10),
    [level, round]
  );
  const [idx, setIdx] = useState(0);
  const [chosen, setChosen] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const finished = idx >= words.length;
  const w = words[idx];

  useEffect(() => {
    if (finished && words.length) {
      addXp(score * 2);
      if (score >= 7) celebrate();
    }
  }, [finished]); // eslint-disable-line react-hooks/exhaustive-deps

  const choose = (a: string) => {
    if (chosen || !w) return;
    setChosen(a);
    recordAnswer(w.id, a === w.article);
    recordActivity('grammar', a === w.article, 6);
    if (a === w.article) {
      playSuccessSound(profile.soundEnabled);
      setScore((s) => s + 1);
      setStreak((s) => s + 1);
    } else {
      playWrongSound(profile.soundEnabled);
      setStreak(0);
    }
  };
  const next = () => {
    setChosen(null);
    setIdx((i) => i + 1);
  };
  const restart = () => {
    setRound((r) => r + 1);
    setIdx(0);
    setScore(0);
    setStreak(0);
    setChosen(null);
  };
  const color: Record<string, string> = { der: 'bg-blue-500 shadow-[0_5px_0_#1d4ed8]', die: 'bg-rose-500 shadow-[0_5px_0_#be123c]', das: 'bg-emerald-500 shadow-[0_5px_0_#047857]' };

  return (
    <GameShell title="Artikel yarışı" onExit={onExit}>
      {finished ? (
        <div className="text-center space-y-3 pop-in">
          <div className="text-4xl">{score >= 7 ? '🏆' : '👍'}</div>
          <div className="font-black text-xl text-slate-900 dark:text-white">
            {score} / {words.length}
          </div>
          <div className="text-sm text-slate-500">+{score * 2} XP</div>
          <BigButton onClick={restart}>Tekrar oyna</BigButton>
        </div>
      ) : w ? (
        <div>
          <div className="h-3 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div className="h-full bg-emerald-500 transition-all" style={{ width: `${(idx / words.length) * 100}%` }} />
          </div>
          <div className="mt-1 flex justify-between text-xs font-bold text-slate-500">
            <span>
              {idx + 1}/{words.length}
            </span>
            <span>{streak >= 2 ? `🔥 ${streak} seri` : ''}</span>
          </div>
          <div className="mt-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-8 text-center">
            <div className="text-4xl font-black text-slate-900 dark:text-white">{w.german}</div>
            <div className="mt-1 text-slate-500">{w.turkish}</div>
            <button
              onClick={() => speakGerman(display(w), profile.speechSpeed)}
              className="mt-3 w-11 h-11 rounded-2xl bg-sky-500 text-white inline-flex items-center justify-center cursor-pointer"
              aria-label="Dinle"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3">
            {['der', 'die', 'das'].map((a) => (
              <button
                key={a}
                onClick={() => choose(a)}
                className={`h-16 rounded-2xl text-white text-xl font-black active:translate-y-1 active:shadow-none transition cursor-pointer ${
                  chosen && a !== w.article && a !== chosen ? 'opacity-40' : ''
                } ${chosen ? (a === w.article ? 'bg-emerald-500 shadow-[0_5px_0_#047857]' : a === chosen ? 'bg-rose-600 shadow-[0_5px_0_#9f1239]' : 'bg-slate-400') : color[a]}`}
              >
                {a}
              </button>
            ))}
          </div>
          {chosen && (
            <div className="mt-5 space-y-3 pop-in">
              <div className={`text-center font-black ${chosen === w.article ? 'text-emerald-600' : 'text-rose-600'}`}>
                {chosen === w.article ? (
                  'Doğru!'
                ) : (
                  <span>
                    Yanlış. Doğrusu: <GermanNoun article={w.article} german={w.german} />
                  </span>
                )}
              </div>
              <div className="text-center text-xs text-slate-500">
                {w.exampleGerman} ({w.exampleTurkish})
              </div>
              <BigButton onClick={next}>Devam</BigButton>
            </div>
          )}
        </div>
      ) : (
        <p className="text-slate-500">Bu seviyede yeterli isim yok.</p>
      )}
    </GameShell>
  );
};

/* ---------------- 3. Dictation ---------------- */
const DictationGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const [round, setRound] = useState(0);
  const items = useMemo(() => shuffle(getLevelWords(level)).slice(0, 5), [level, round]);
  const [idx, setIdx] = useState(0);
  const [text, setText] = useState('');
  const [result, setResult] = useState<{ ok: boolean; sim: number } | null>(null);
  const [score, setScore] = useState(0);
  const finished = idx >= items.length;
  const item = items[idx];

  useEffect(() => {
    if (!item) return;
    const t = setTimeout(() => speakGerman(item.exampleGerman, profile.speechSpeed), 350);
    return () => clearTimeout(t);
  }, [idx, round]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (finished && items.length) {
      addXp(score * 4);
      if (score >= 4) celebrate();
    }
  }, [finished]); // eslint-disable-line react-hooks/exhaustive-deps

  const check = () => {
    if (!item || result || !text.trim()) return;
    const sim = calculateTextSimilarity(text, item.exampleGerman);
    const ok = sim >= 85;
    recordAnswer(item.id, ok);
    recordActivity('listening', ok, 25);
    if (ok) {
      playSuccessSound(profile.soundEnabled);
      setScore((s) => s + 1);
    } else {
      playWrongSound(profile.soundEnabled);
    }
    setResult({ ok, sim });
  };
  const next = () => {
    setText('');
    setResult(null);
    setIdx((i) => i + 1);
  };
  const restart = () => {
    setRound((r) => r + 1);
    setIdx(0);
    setScore(0);
    setText('');
    setResult(null);
  };

  return (
    <GameShell title="Dikte" onExit={onExit}>
      {finished ? (
        <div className="text-center space-y-3 pop-in">
          <div className="text-4xl">{score >= 4 ? '🏆' : '👍'}</div>
          <div className="font-black text-xl text-slate-900 dark:text-white">
            {score} / {items.length}
          </div>
          <div className="text-sm text-slate-500">+{score * 4} XP</div>
          <BigButton onClick={restart}>Tekrar oyna</BigButton>
        </div>
      ) : item ? (
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            {idx + 1}/{items.length}. Cümleyi dinle ve duyduğunu yaz.
          </p>
          <div className="flex justify-center">
            <button
              onClick={() => speakGerman(item.exampleGerman, profile.speechSpeed)}
              className="w-20 h-20 rounded-full bg-emerald-500 text-white shadow-[0_6px_0_#047857] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center cursor-pointer"
              aria-label="Cümleyi dinle"
            >
              <Volume2 className="w-9 h-9" />
            </button>
          </div>
          <input
            type="text"
            value={text}
            disabled={!!result}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') check();
            }}
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            placeholder="Almanca cümleyi yazın..."
            className="w-full h-14 px-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
          />
          {result ? (
            <div className="space-y-3 pop-in">
              <div className={`rounded-2xl p-4 text-sm ${result.ok ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200' : 'bg-rose-50 dark:bg-rose-950 text-rose-800 dark:text-rose-200'}`}>
                <div className="font-black">{result.ok ? 'Doğru!' : 'Tam değil'} (%{result.sim})</div>
                <div className="mt-1 font-bold">{item.exampleGerman}</div>
                <div className="opacity-80">{item.exampleTurkish}</div>
              </div>
              <BigButton onClick={next}>Devam</BigButton>
            </div>
          ) : (
            <BigButton onClick={check}>Kontrol et</BigButton>
          )}
        </div>
      ) : null}
    </GameShell>
  );
};

/* ---------------- 4. Hangman ---------------- */
const LETTERS = 'abcdefghijklmnopqrstuvwxyzäöüß'.split('');
const MAX_WRONG = 7;

const HangmanGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const pool = useMemo(
    () => getLevelWords(level).filter((w) => /^[A-Za-zÄÖÜäöüß]{4,12}$/.test(w.german)),
    [level]
  );
  const [round, setRound] = useState(0);
  const word = useMemo(() => shuffle(pool)[0], [pool, round]);
  const [guessed, setGuessed] = useState<string[]>([]);
  const target = word ? word.german.toLowerCase() : '';
  const wrong = guessed.filter((g) => !target.includes(g)).length;
  const won = !!word && target.split('').every((c) => guessed.includes(c));
  const lost = wrong >= MAX_WRONG;
  const over = won || lost;

  useEffect(() => {
    if (won) {
      addXp(6 + (MAX_WRONG - wrong));
      recordAnswer(word.id, true);
      recordActivity('writing', true, 30);
      celebrate();
    }
  }, [won]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (lost && word) {
      recordAnswer(word.id, false);
      recordActivity('writing', false, 30);
    }
  }, [lost]); // eslint-disable-line react-hooks/exhaustive-deps

  const guess = (c: string) => {
    if (over || guessed.includes(c)) return;
    if (target.includes(c)) playSuccessSound(profile.soundEnabled);
    else playWrongSound(profile.soundEnabled);
    setGuessed((g) => [...g, c]);
  };
  const restart = () => {
    setRound((r) => r + 1);
    setGuessed([]);
  };
  const show = (ch: string) => (ch === 'ß' ? 'ß' : ch.toUpperCase());

  if (!word) return <GameShell title="Adam asmaca" onExit={onExit}><p className="text-slate-500">Bu seviyede uygun kelime yok.</p></GameShell>;

  return (
    <GameShell title="Adam asmaca" onExit={onExit}>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-slate-500">
            İpucu: <span className="font-bold text-slate-800 dark:text-slate-100">{word.turkish}</span>
          </div>
          <div className="flex gap-0.5" aria-label={`${MAX_WRONG - wrong} can kaldı`}>
            {Array.from({ length: MAX_WRONG }).map((_, i) => (
              <Heart key={i} className={`w-4 h-4 ${i < MAX_WRONG - wrong ? 'fill-rose-500 text-rose-500' : 'text-slate-300 dark:text-slate-600'}`} />
            ))}
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-2 py-4">
          {target.split('').map((c, i) => (
            <div
              key={i}
              className="w-9 h-12 rounded-xl border-b-4 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 inline-flex items-center justify-center text-xl font-black text-slate-900 dark:text-white"
            >
              {guessed.includes(c) || lost ? show(c) : ''}
            </div>
          ))}
        </div>
        {over ? (
          <div className="space-y-3 text-center pop-in">
            <div className="text-3xl">{won ? '🎉' : '😕'}</div>
            <div className="font-black text-slate-900 dark:text-white">
              {won ? `Bildin! +${6 + (MAX_WRONG - wrong)} XP` : 'Olmadı'}
            </div>
            <div className="text-sm text-slate-600 dark:text-slate-300">
              {display(word)} = {word.turkish}
              <br />
              <span className="text-xs text-slate-500">{word.exampleGerman}</span>
            </div>
            <BigButton onClick={restart}>Yeni kelime</BigButton>
          </div>
        ) : (
          <div className="flex flex-wrap justify-center gap-1.5">
            {LETTERS.map((c) => {
              const used = guessed.includes(c);
              const hit = used && target.includes(c);
              return (
                <button
                  key={c}
                  disabled={used}
                  onClick={() => guess(c)}
                  className={`w-9 h-11 rounded-xl text-sm font-black transition cursor-pointer ${
                    used
                      ? hit
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
                      : 'bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-600 text-slate-800 dark:text-slate-100 active:translate-y-0.5'
                  }`}
                >
                  {show(c)}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </GameShell>
  );
};


/* ---------------- 5. Speed round ---------------- */
interface SpeedQ {
  word: QuestWord;
  options: string[];
}
const ROUND_SECONDS = 60;

const SpeedGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const pool = useMemo(() => getLevelWords(level), [level]);
  const [started, setStarted] = useState(false);
  const [time, setTime] = useState(ROUND_SECONDS);
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [combo, setCombo] = useState(0);
  const [best, setBest] = useState(0);
  const [flash, setFlash] = useState<'ok' | 'bad' | null>(null);
  const [q, setQ] = useState<SpeedQ | null>(null);
  const [reveal, setReveal] = useState<string | null>(null);
  const over = started && time <= 0;

  const makeQ = (): SpeedQ => {
    const word = pool[Math.floor(Math.random() * pool.length)];
    const wrong = shuffle(Array.from(new Set(pool.filter((o) => o.turkish !== word.turkish).map((o) => o.turkish)))).slice(0, 3);
    return { word, options: shuffle([word.turkish, ...wrong]) };
  };
  const start = () => {
    setStarted(true);
    setTime(ROUND_SECONDS);
    setScore(0);
    setCorrect(0);
    setCombo(0);
    setBest(0);
    setQ(makeQ());
  };

  useEffect(() => {
    if (!started || time <= 0) return;
    const t = setTimeout(() => setTime((x) => x - 1), 1000);
    return () => clearTimeout(t);
  }, [started, time]);

  useEffect(() => {
    if (over) {
      addXp(Math.min(30, correct * 2));
      if (correct >= 10) celebrate();
    }
  }, [over]); // eslint-disable-line react-hooks/exhaustive-deps

  const answer = (opt: string) => {
    if (!q || over || reveal) return;
    if (opt === q.word.turkish) {
      playSuccessSound(profile.soundEnabled);
      const nc = combo + 1;
      setCombo(nc);
      recordActivity('vocab', true, 3);
      setBest((b) => Math.max(b, nc));
      setCorrect((c) => c + 1);
      setScore((sc) => sc + 10 + Math.min(nc, 5) * 2);
      setFlash('ok');
    } else {
      playWrongSound(profile.soundEnabled);
      recordAnswer(q.word.id, false);
      recordActivity('vocab', false, 3);
      setCombo(0);
      setTime((t) => Math.max(0, t - 2));
      setFlash('bad');
    }
    if (opt !== q.word.turkish) {
      // wrong: show the right answer for a moment before the next word
      setReveal(`${display(q.word)} = ${q.word.turkish}`);
      setTimeout(() => {
        setFlash(null);
        setReveal(null);
        setQ(makeQ());
      }, 1500);
      return;
    }
    setTimeout(() => setFlash(null), 250);
    setQ(makeQ());
  };

  return (
    <GameShell title="Zaman yarışı" onExit={onExit}>
      {!started ? (
        <div className="text-center space-y-4 pop-in">
          <div className="text-5xl">⏱️</div>
          <p className="text-sm text-slate-600 dark:text-slate-300">
            60 saniyede olabildiğince çok kelimenin anlamını bil. Seri yaptıkça puan artar, yanlış cevap 2 saniye götürür.
          </p>
          <BigButton onClick={start}>Başla</BigButton>
        </div>
      ) : over ? (
        <div className="text-center space-y-3 pop-in">
          <div className="text-4xl">{correct >= 15 ? '🏆' : correct >= 8 ? '🎉' : '👍'}</div>
          <div className="font-black text-2xl text-slate-900 dark:text-white tabular-nums">{score} puan</div>
          <div className="text-sm text-slate-500">
            {correct} doğru, en iyi seri {best}. +{Math.min(30, correct * 2)} XP
          </div>
          <BigButton onClick={start}>Tekrar oyna</BigButton>
        </div>
      ) : q ? (
        <div>
          <div className="flex items-center justify-between text-sm font-black">
            <span className={time <= 10 ? 'text-rose-600' : 'text-slate-700 dark:text-slate-200'}>⏱ {time} sn</span>
            <span className="text-orange-500">{combo >= 2 ? `🔥 ${combo}` : ''}</span>
            <span className="text-slate-700 dark:text-slate-200 tabular-nums">{score}</span>
          </div>
          <div className="mt-1 h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 ease-linear ${time <= 10 ? 'bg-rose-500' : 'bg-emerald-500'}`}
              style={{ width: `${(time / ROUND_SECONDS) * 100}%` }}
            />
          </div>
          <div
            className={`mt-5 rounded-3xl border-2 p-8 text-center transition-colors ${
              flash === 'ok'
                ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950'
                : flash === 'bad'
                ? 'border-rose-500 bg-rose-50 dark:bg-rose-950'
                : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
            }`}
          >
            <div className="text-3xl font-black text-slate-900 dark:text-white">
              <GermanNoun article={q.word.article} german={q.word.german} />
            </div>
          </div>
          {reveal && (
            <div className="mt-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950 border-2 border-emerald-400 p-3 text-center text-sm font-black text-emerald-800 dark:text-emerald-200 pop-in">
              Doğrusu: {reveal}
            </div>
          )}
          <div className="mt-4 grid grid-cols-2 gap-3">
            {q.options.map((o) => (
              <button
                key={o}
                onClick={() => answer(o)}
                className={`min-h-14 px-3 py-2 rounded-2xl border-2 text-sm font-bold active:translate-y-0.5 transition cursor-pointer ${
                  reveal && o === q.word.turkish
                    ? 'bg-emerald-100 dark:bg-emerald-950 border-emerald-500 text-emerald-900 dark:text-emerald-100'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100'
                }`}
              >
                {o}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </GameShell>
  );
};

/* ---------------- 6. Memory cards ---------------- */
interface MemCard {
  key: string;
  id: string;
  text: string;
  kind: 'de' | 'tr';
}

const MemoryGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { addXp } = useApp();
  const [round, setRound] = useState(0);
  const cards = useMemo<MemCard[]>(() => {
    const picks = shuffle(getLevelWords(level)).slice(0, 6);
    return shuffle(
      picks.flatMap((w) => [
        { key: `${w.id}-de`, id: w.id, text: display(w), kind: 'de' as const },
        { key: `${w.id}-tr`, id: w.id, text: w.turkish, kind: 'tr' as const },
      ])
    );
  }, [level, round]);
  const [open, setOpen] = useState<string[]>([]);
  const [found, setFound] = useState<string[]>([]);
  const [moves, setMoves] = useState(0);
  const done = cards.length > 0 && found.length === cards.length / 2;

  useEffect(() => {
    if (open.length !== 2) return;
    setMoves((m) => m + 1);
    const [a, b] = open.map((k) => cards.find((c) => c.key === k)!);
    if (a.id === b.id) {
      setFound((f) => [...f, a.id]);
      setOpen([]);
      return;
    }
    const t = setTimeout(() => setOpen([]), 800);
    return () => clearTimeout(t);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (done) {
      addXp(Math.max(5, 20 - moves));
      celebrate();
    }
  }, [done]); // eslint-disable-line react-hooks/exhaustive-deps

  const flip = (key: string) => {
    if (open.length >= 2 || open.includes(key)) return;
    setOpen((o) => [...o, key]);
  };
  const restart = () => {
    setRound((r) => r + 1);
    setOpen([]);
    setFound([]);
    setMoves(0);
  };

  return (
    <GameShell title="Hafıza kartları" onExit={onExit}>
      <p className="text-sm text-slate-500 mb-3">Kartları çevir, Almanca kelime ile Türkçesini eşleştir. Hamle: {moves}</p>
      <div className="grid grid-cols-3 gap-2.5">
        {cards.map((c) => {
          const isFound = found.includes(c.id);
          const isOpen = open.includes(c.key) || isFound;
          return (
            <button
              key={c.key}
              onClick={() => flip(c.key)}
              disabled={isFound}
              aria-label={isOpen ? c.text : 'Kapalı kart'}
              className={`h-20 rounded-2xl text-sm font-black px-1 transition cursor-pointer ${
                isOpen
                  ? isFound
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200 border-2 border-emerald-400 opacity-70'
                    : c.kind === 'de'
                    ? 'pop-in bg-sky-100 dark:bg-sky-950 text-sky-900 dark:text-sky-100 border-2 border-sky-400'
                    : 'pop-in bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-100 border-2 border-amber-400'
                  : 'bg-linear-to-br from-violet-500 to-indigo-600 text-white text-2xl shadow-[0_4px_0_#4338ca] active:translate-y-1 active:shadow-none'
              }`}
            >
              {isOpen ? c.text : '?'}
            </button>
          );
        })}
      </div>
      {done && (
        <div className="mt-5 text-center space-y-3 pop-in">
          <div className="text-3xl">🎉</div>
          <div className="font-black text-slate-900 dark:text-white">
            {moves} hamlede bitirdin! +{Math.max(5, 20 - moves)} XP
          </div>
          <BigButton onClick={restart}>Yeni tur</BigButton>
        </div>
      )}
    </GameShell>
  );
};


/* ---------------- 7. Shadowing (speaking practice) ---------------- */
const ShadowGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const [round, setRound] = useState(0);
  const items = useMemo(
    () => shuffle(getLevelWords(level).filter((w) => w.exampleGerman.split(' ').length >= 3)).slice(0, 5),
    [level, round]
  );
  const [idx, setIdx] = useState(0);
  const [good, setGood] = useState(0);
  const [hide, setHide] = useState(false);
  const finished = idx >= items.length;
  const item = items[idx];

  useEffect(() => {
    if (finished && items.length) {
      addXp(2 + good * 3);
      if (good >= 4) celebrate();
    }
  }, [finished]); // eslint-disable-line react-hooks/exhaustive-deps

  const rate = (ok: boolean) => {
    if (!item) return;
    recordAnswer(item.id, ok);
    recordActivity('speaking', ok, 20);
    if (ok) {
      playSuccessSound(profile.soundEnabled);
      setGood((g) => g + 1);
    }
    setIdx((i) => i + 1);
  };
  const restart = () => {
    setRound((r) => r + 1);
    setIdx(0);
    setGood(0);
  };

  return (
    <GameShell title="Konuşma çalışması" onExit={onExit}>
      {finished ? (
        <div className="text-center space-y-3 pop-in">
          <div className="text-4xl">{good >= 4 ? '🏆' : '👍'}</div>
          <div className="font-black text-xl text-slate-900 dark:text-white">
            {good} / {items.length} cümleyi rahat söyledin
          </div>
          <div className="text-sm text-slate-500">+{2 + good * 3} XP. Zor gelenler Akıllı tekrara eklendi.</div>
          <BigButton onClick={restart}>Yeni cümleler</BigButton>
        </div>
      ) : item ? (
        <div className="space-y-4">
          <p className="text-sm text-slate-500">
            {idx + 1}/{items.length}. Önce dinle, sonra cümleyi sesli tekrar et. Sesini taklit etmeye çalış.
          </p>
          <div className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 text-center">
            <div className={`text-xl font-black text-slate-900 dark:text-white leading-snug ${hide ? 'blur-md select-none' : ''}`}>{item.exampleGerman}</div>
            <div className="mt-2 text-sm text-slate-500">{item.exampleTurkish}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => speakGerman(item.exampleGerman, profile.speechSpeed)}
              className="h-14 rounded-2xl bg-sky-500 text-white font-black shadow-[0_4px_0_#0369a1] active:translate-y-1 active:shadow-none inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Volume2 className="w-5 h-5" /> Dinle
            </button>
            <button
              onClick={() => speakGerman(item.exampleGerman, 0.6)}
              className="h-14 rounded-2xl bg-indigo-500 text-white font-black shadow-[0_4px_0_#4338ca] active:translate-y-1 active:shadow-none inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Volume2 className="w-5 h-5" /> Yavaş
            </button>
          </div>
          <button onClick={() => setHide((h) => !h)} className="text-xs font-black text-slate-500 cursor-pointer">
            {hide ? 'Metni göster' : 'Metni gizle (sadece kulağınla tekrar et)'}
          </button>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button onClick={() => rate(false)} className="h-14 rounded-2xl bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-black border-2 border-rose-300 dark:border-rose-800 cursor-pointer">
              Zor geldi
            </button>
            <button onClick={() => rate(true)} className="h-14 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer">
              İyi söyledim
            </button>
          </div>
        </div>
      ) : null}
    </GameShell>
  );
};

/* ---------------- 8. Artikel Avı (60 Saniye Der-Die-Das Swipe) ---------------- */
const ARTIKEL_ROUND_SEC = 60;

const ArtikelSwipeGame: React.FC<GameProps> = ({ level, onExit }) => {
  const { profile, addXp, recordAnswer, recordActivity } = useApp();
  const nounPool = useMemo(
    () => getLevelWords(level).filter((w) => w.article === 'der' || w.article === 'die' || w.article === 'das'),
    [level]
  );

  const [started, setStarted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(ARTIKEL_ROUND_SEC);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongWords, setWrongWords] = useState<QuestWord[]>([]);
  const [wordIndex, setWordIndex] = useState(0);
  const [deck, setDeck] = useState<QuestWord[]>([]);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  // Swipe drag gesture state
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const lockRef = useRef(false);

  const currentWord = deck[wordIndex % Math.max(1, deck.length)];
  const multiplier = combo >= 10 ? 3 : combo >= 5 ? 2 : 1;
  const isOver = started && timeLeft <= 0;

  const startGame = useCallback(() => {
    setDeck(shuffle(nounPool));
    setWordIndex(0);
    setStarted(true);
    setTimeLeft(ARTIKEL_ROUND_SEC);
    setScore(0);
    setCombo(0);
    setBestCombo(0);
    setCorrectCount(0);
    setWrongWords([]);
    setFeedback(null);
    setDragOffset({ x: 0, y: 0 });
    lockRef.current = false;
  }, [nounPool]);

  useEffect(() => {
    if (!started || timeLeft <= 0) return;
    const timer = window.setTimeout(() => setTimeLeft((t) => Math.max(0, t - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [started, timeLeft]);

  useEffect(() => {
    if (isOver && correctCount > 0) {
      addXp(Math.min(45, Math.round(score / 10)));
      if (correctCount >= 10) celebrate();
    }
  }, [isOver]); // eslint-disable-line react-hooks/exhaustive-deps

  const submitArticle = useCallback(
    (chosen: 'der' | 'die' | 'das') => {
      if (!currentWord || !started || timeLeft <= 0 || lockRef.current) return;
      lockRef.current = true;
      const isOk = chosen === currentWord.article;
      recordAnswer(currentWord.id, isOk);
      recordActivity('grammar', isOk, 3);

      if (isOk) {
        playSuccessSound(profile.soundEnabled);
        const nextCombo = combo + 1;
        const mult = nextCombo >= 10 ? 3 : nextCombo >= 5 ? 2 : 1;
        setCombo(nextCombo);
        setBestCombo((b) => Math.max(b, nextCombo));
        setCorrectCount((c) => c + 1);
        setScore((s) => s + 10 * mult);
        setFeedback({
          ok: true,
          text: `${currentWord.article} ${currentWord.german} • +${10 * mult} puan`,
        });
      } else {
        playWrongSound(profile.soundEnabled);
        setCombo(0);
        setWrongWords((prev) =>
          prev.some((w) => w.id === currentWord.id) ? prev : [...prev, currentWord]
        );
        setFeedback({
          ok: false,
          text: `Doğrusu: ${currentWord.article} ${currentWord.german} (Hata defterine eklendi)`,
        });
      }

      window.setTimeout(() => {
        setFeedback(null);
        setDragOffset({ x: 0, y: 0 });
        setWordIndex((i) => i + 1);
        lockRef.current = false;
      }, isOk ? 240 : 750);
    },
    [currentWord, started, timeLeft, recordAnswer, recordActivity, profile.soundEnabled, combo]
  );

  // Keyboard shortcuts (Left=der, Up=die, Right=das)
  useEffect(() => {
    if (!started || isOver) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        submitArticle('der');
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        submitArticle('die');
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        submitArticle('das');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [started, isOver, submitArticle]);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (lockRef.current || isOver) return;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragStartRef.current || lockRef.current) return;
    setDragOffset({
      x: e.clientX - dragStartRef.current.x,
      y: e.clientY - dragStartRef.current.y,
    });
  };

  const handlePointerUp = () => {
    if (!dragStartRef.current) return;
    const { x, y } = dragOffset;
    dragStartRef.current = null;
    if (x < -55 && Math.abs(x) >= Math.abs(y)) {
      submitArticle('der');
    } else if (x > 55 && Math.abs(x) >= Math.abs(y)) {
      submitArticle('das');
    } else if (y < -50 && Math.abs(y) > Math.abs(x)) {
      submitArticle('die');
    } else {
      setDragOffset({ x: 0, y: 0 });
    }
  };

  const dragIntent: 'der' | 'die' | 'das' | null =
    dragOffset.x < -30 && Math.abs(dragOffset.x) >= Math.abs(dragOffset.y)
      ? 'der'
      : dragOffset.x > 30 && Math.abs(dragOffset.x) >= Math.abs(dragOffset.y)
      ? 'das'
      : dragOffset.y < -30 && Math.abs(dragOffset.y) > Math.abs(dragOffset.x)
      ? 'die'
      : null;

  return (
    <GameShell title="Artikel Avı (60 Saniye)" onExit={onExit}>
      {nounPool.length === 0 ? (
        <p className="text-sm text-slate-500">Bu seviyede artikel oyunu için yeterli isim bulunamadı.</p>
      ) : !started ? (
        <div className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 text-center space-y-4 pop-in">
          <div className="text-5xl">🎯</div>
          <h4 className="text-xl font-black text-slate-900 dark:text-white">
            Der · Die · Das Hız & Kaydırma Arenası
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Kartı sola (<strong className={ARTICLE_TEXT_COLOR.der}>der</strong>), yukarı (
            <strong className={ARTICLE_TEXT_COLOR.die}>die</strong>) veya sağa (
            <strong className={ARTICLE_TEXT_COLOR.das}>das</strong>) kaydır ya da butonlara dokun!
            <br />
            5x kombo = <strong>2x Puan</strong>, 10x kombo = <strong>3x Puan</strong>! Yanlışlar otomatik Hata Defteri'ne eklenir.
          </p>
          <div className="grid grid-cols-3 gap-2 text-xs font-black">
            <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-500 border border-blue-200 dark:border-blue-800">
              ← Sola: der
            </div>
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-500 border border-rose-200 dark:border-rose-800">
              ↑ Yukarı: die
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-500 border border-emerald-200 dark:border-emerald-800">
              Sağa →: das
            </div>
          </div>
          <BigButton onClick={startGame}>60 Saniyeyi Başlat</BigButton>
        </div>
      ) : isOver ? (
        <div className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 text-center space-y-4 pop-in">
          <div className="text-4xl">{score >= 150 ? '🏆' : '🎯'}</div>
          <div className="text-3xl font-black text-slate-900 dark:text-white tabular-nums">
            {score} Puan
          </div>
          <p className="text-xs sm:text-sm font-bold text-slate-500 dark:text-slate-400">
            {correctCount} doğru • En yüksek kombo: {bestCombo}x • +
            {Math.min(45, Math.round(score / 10))} XP
          </p>
          {wrongWords.length > 0 && (
            <div className="text-left p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 space-y-1.5">
              <div className="text-xs font-black text-rose-700 dark:text-rose-300">
                Hata Defterine Eklenen Kelimeler ({wrongWords.length}):
              </div>
              <div className="flex flex-wrap gap-2">
                {wrongWords.map((w) => (
                  <span
                    key={w.id}
                    className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold"
                  >
                    <GermanNoun article={w.article} german={w.german} />
                  </span>
                ))}
              </div>
            </div>
          )}
          <BigButton onClick={startGame}>Tekrar Oyna</BigButton>
        </div>
      ) : currentWord ? (
        <div className="space-y-4">
          {/* HUD */}
          <div className="flex items-center justify-between text-sm font-black">
            <span className={timeLeft <= 10 ? 'text-rose-600 animate-pulse' : 'text-slate-700 dark:text-slate-200'}>
              ⏱ {timeLeft} sn
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-xs font-black">
              🔥 {combo} Seri ({multiplier}x)
            </span>
            <span className="text-slate-900 dark:text-white tabular-nums">{score} puan</span>
          </div>

          <div className="h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 ease-linear ${
                timeLeft <= 10 ? 'bg-rose-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${(timeLeft / ARTIKEL_ROUND_SEC) * 100}%` }}
            />
          </div>

          {/* Swipeable Card */}
          <div
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={() => {
              dragStartRef.current = null;
              setDragOffset({ x: 0, y: 0 });
            }}
            style={{
              transform: `translate3d(${dragOffset.x * 0.65}px, ${dragOffset.y * 0.5}px, 0) rotate(${dragOffset.x * 0.04}deg)`,
              touchAction: 'none',
            }}
            className={`relative rounded-3xl border-2 p-8 text-center select-none cursor-grab active:cursor-grabbing transition-shadow shadow-md ${
              dragIntent === 'der'
                ? 'border-blue-500 bg-blue-50/90 dark:bg-blue-950/60'
                : dragIntent === 'die'
                ? 'border-rose-500 bg-rose-50/90 dark:bg-rose-950/60'
                : dragIntent === 'das'
                ? 'border-emerald-500 bg-emerald-50/90 dark:bg-emerald-950/60'
                : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'
            }`}
          >
            {dragIntent && (
              <div
                className={`absolute top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-xs font-black uppercase bg-white dark:bg-slate-900 shadow-sm ${ARTICLE_TEXT_COLOR[dragIntent]}`}
              >
                {dragIntent}
              </div>
            )}
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              {currentWord.category}
            </span>
            <div className="mt-2 text-4xl font-black text-slate-900 dark:text-white">
              {currentWord.german}
            </div>
            <div className="mt-1.5 text-sm font-semibold text-slate-500 dark:text-slate-300">
              {currentWord.turkish}
            </div>
            <div className="mt-3 text-[11px] text-slate-400">
              Sola (der) · Yukarı (die) · Sağa (das) kaydır veya dokun
            </div>
          </div>

          {feedback && (
            <div
              className={`rounded-2xl p-3 text-center text-xs sm:text-sm font-black pop-in ${
                feedback.ok
                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200'
                  : 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-200'
              }`}
            >
              {feedback.text}
            </div>
          )}

          {/* Tap Controls */}
          <div className="grid grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => submitArticle('der')}
              className="h-15 rounded-2xl bg-blue-500 hover:bg-blue-600 text-white font-black text-lg shadow-[0_5px_0_#1d4ed8] active:translate-y-1 active:shadow-none transition cursor-pointer"
            >
              der
              <span className="block text-[10px] font-bold opacity-85">← Eril</span>
            </button>
            <button
              type="button"
              onClick={() => submitArticle('die')}
              className="h-15 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-black text-lg shadow-[0_5px_0_#be123c] active:translate-y-1 active:shadow-none transition cursor-pointer"
            >
              die
              <span className="block text-[10px] font-bold opacity-85">↑ Dişil</span>
            </button>
            <button
              type="button"
              onClick={() => submitArticle('das')}
              className="h-15 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-lg shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition cursor-pointer"
            >
              das
              <span className="block text-[10px] font-bold opacity-85">Nötr →</span>
            </button>
          </div>
        </div>
      ) : null}
    </GameShell>
  );
};

/* ---------------- Hub ---------------- */
type GameId = 'artikel_avi' | 'match' | 'article' | 'dictation' | 'hangman' | 'speed' | 'memory' | 'shadow';

const GAMES: { id: GameId; title: string; desc: string; emoji: string }[] = [
  { id: 'artikel_avi', title: 'Artikel Avı (60 Sn)', desc: 'Der-Die-Das kaydır, kombo yap, 2x/3x puan topla!', emoji: '🎯' },
  { id: 'match', title: 'Eşleştir', desc: 'Kelimeleri Türkçe karşılıklarıyla eşleştir', emoji: '🧩' },
  { id: 'article', title: 'Artikel yarışı', desc: 'der, die, das: hızlıca seç', emoji: '⚡' },
  { id: 'dictation', title: 'Dikte', desc: 'Cümleyi dinle ve yaz', emoji: '🎧' },
  { id: 'hangman', title: 'Adam asmaca', desc: 'Harfleri tahmin ederek kelimeyi bul', emoji: '🔤' },
  { id: 'speed', title: 'Zaman yarışı', desc: '60 saniyede en çok kelimeyi bil', emoji: '⏱️' },
  { id: 'memory', title: 'Hafıza kartları', desc: 'Kartları çevir, çiftleri bul', emoji: '🃏' },
  { id: 'shadow', title: 'Konuşma çalışması', desc: 'Dinle, sesli tekrar et, kendini değerlendir', emoji: '🎤' },
];

export const GamesHub: React.FC = () => {
  const { currentLevel } = useApp();
  const [level, setLevel] = useState<CEFRLevel>(currentLevel);
  const [game, setGame] = useState<GameId | null>(null);
  useBackHandler(game !== null, () => setGame(null));

  if (game) {
    const props = { level, onExit: () => setGame(null) };
    return (
      <div className="page-enter">
        {game === 'artikel_avi' && <ArtikelSwipeGame {...props} />}
        {game === 'match' && <MatchGame {...props} />}
        {game === 'article' && <ArticleGame {...props} />}
        {game === 'dictation' && <DictationGame {...props} />}
        {game === 'hangman' && <HangmanGame {...props} />}
        {game === 'speed' && <SpeedGame {...props} />}
        {game === 'memory' && <MemoryGame {...props} />}
        {game === 'shadow' && <ShadowGame {...props} />}
      </div>
    );
  }

  return (
    <div>
      <p className="text-sm text-slate-500 dark:text-slate-400">Eğlenerek tekrar et. Oyunlar da XP kazandırır.</p>
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Oyun seviyesi">
        {LEVEL_ORDER.map((lvl) => (
          <button
            key={lvl}
            role="tab"
            aria-selected={lvl === level}
            onClick={() => setLevel(lvl)}
            className={`flex-1 min-w-[56px] h-10 rounded-2xl text-sm font-black cursor-pointer ${
              lvl === level
                ? 'bg-sky-500 text-white shadow-[0_4px_0_#0369a1]'
                : 'bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {lvl}
          </button>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        {GAMES.map((g) => (
          <button
            key={g.id}
            onClick={() => setGame(g.id)}
            className={`text-left rounded-3xl border-2 p-4 active:translate-y-0.5 transition cursor-pointer ${
              g.id === 'artikel_avi'
                ? 'col-span-2 bg-linear-to-r from-blue-50 via-rose-50 to-emerald-50 dark:from-blue-950/40 dark:via-slate-800 dark:to-emerald-950/40 border-blue-300 dark:border-blue-700'
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
            }`}
          >
            <div className="text-3xl">{g.emoji}</div>
            <div className="mt-2 font-black text-slate-900 dark:text-white">{g.title}</div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{g.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
};
