import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Lock, Sparkles, Star, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { speakGerman } from '../../utils/audio';
import { WordSet, buildSetExercises, getWordSets } from '../../data/vocab/builder';
import { QuestWord } from '../../data/vocab/words';
import { LEVEL_ORDER, isLevelUnlocked } from '../../utils/progress';
import { GamesHub } from './GamesHub';
import { groupStrength } from '../../utils/srs';
import { ConnectorsView } from './ConnectorsView';
import { ListeningLab } from './ListeningLab';
import { SpeakingHub } from './SpeakingHub';
import { useBackHandler } from '../../utils/backStack';
import { ARTICLE_TEXT_COLOR } from '../../utils/articleColors';

const ARTICLE_COLOR = ARTICLE_TEXT_COLOR;

const highlight = (w: QuestWord) => {
  const [before, after] = w.template.split(/\{[^}]+\}/);
  return (
    <>
      {before}
      <mark className="px-1 rounded bg-yellow-200 dark:bg-yellow-500/30 text-slate-900 dark:text-yellow-100 font-black">
        {w.form}
      </mark>
      {after}
    </>
  );
};

interface WordSetCardProps {
  set: WordSet;
  index: number;
  isDone: boolean;
  available: boolean;
  known: number;
  filled: number;
  due: number;
  onOpenSet: (set: WordSet, index: number) => void;
}

const WordSetCard: React.FC<WordSetCardProps> = memo(
  ({ set, index, isDone, available, known, filled, due, onOpenSet }) => (
    <button
      onClick={() => onOpenSet(set, index)}
      className={`w-full text-left rounded-2xl border-2 p-4 flex items-center gap-4 transition active:translate-y-0.5 cursor-pointer ${
        isDone
          ? 'border-amber-300 dark:border-amber-800 bg-amber-50/60 dark:bg-amber-950/20'
          : available
          ? 'border-emerald-400 bg-white dark:bg-slate-800'
          : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 opacity-70'
      }`}
    >
      <div
        className={`w-14 h-14 rounded-full shrink-0 inline-flex items-center justify-center text-white ${
          isDone
            ? 'bg-amber-400 shadow-[0_5px_0_#d97706]'
            : available
            ? 'bg-emerald-500 shadow-[0_5px_0_#047857]'
            : 'bg-slate-300 dark:bg-slate-700 shadow-[0_5px_0_#94a3b8] dark:shadow-[0_5px_0_#334155]'
        }`}
      >
        {isDone ? <Check className="w-7 h-7 stroke-4" /> : available ? <Star className="w-7 h-7 fill-white" /> : <Lock className="w-6 h-6" />}
      </div>
      <div className="min-w-0">
        <div className="text-base font-black text-slate-900 dark:text-white">Set {set.index}</div>
        <div className="text-xs text-slate-500 dark:text-slate-400 truncate">{set.topics.join(', ')}</div>
        <div className="text-xs font-bold text-slate-400 mt-0.5">{set.words.length} kelime, yaklaşık {set.words.length * 4} soru</div>
        {known > 0 && (
          <div className="mt-1 flex items-center gap-1" aria-label={`Hafıza gücü ${filled}/5`}>
            {[1, 2, 3, 4, 5].map((n) => (
              <span key={n} className={`w-2.5 h-2.5 rounded-full ${n <= filled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'}`} />
            ))}
            <span className="ml-1 text-[11px] font-bold text-slate-400">
              hafıza{due > 0 ? ` · ${due} tekrar` : ''}
            </span>
          </div>
        )}
      </div>
    </button>
  )
);

const WordSetsView: React.FC = memo(() => {
  const { profile, currentLevel, addXp, updateWordStatus, markWordSetDone, setActiveTab } = useApp();
  const [level, setLevel] = useState<CEFRLevel>(currentLevel);
  useEffect(() => {
    setLevel(currentLevel);
  }, [currentLevel]);
  const [active, setActive] = useState<WordSet | null>(null);
  const [phase, setPhase] = useState<'learn' | 'quiz'>('learn');
  const [cardIndex, setCardIndex] = useState(0);
  const [exercises, setExercises] = useState(() => [] as ReturnType<typeof buildSetExercises>);
  const [toast, setToast] = useState<string | null>(null);

  const sets = useMemo(() => getWordSets(level), [level]);
  const doneSet = useMemo(() => new Set(profile.completedWordSets || []), [profile.completedWordSets]);

  const progressSnapshot = useMemo(
    () => ({
      completedLessons: profile.completedLessons,
      passedLevelExams: profile.passedLevelExams,
      placementLevel: profile.placementLevel,
    }),
    [profile.completedLessons, profile.passedLevelExams, profile.placementLevel]
  );

  const unlockedByLevel = useMemo(() => {
    const map: Record<CEFRLevel, boolean> = { A1: true, A2: false, B1: false, B2: false, C1: false };
    for (const lvl of LEVEL_ORDER) {
      map[lvl] = isLevelUnlocked(lvl, progressSnapshot);
    }
    return map;
  }, [progressSnapshot]);

  const unlocked = unlockedByLevel[level];

  const { totalWords, learned, setCardsData } = useMemo(() => {
    let total = 0;
    let learnedCount = 0;
    const cards = sets.map((set, i) => {
      total += set.words.length;
      const isDone = doneSet.has(set.id);
      if (isDone) learnedCount += set.words.length;
      const available = unlocked && (i === 0 || doneSet.has(sets[i - 1].id) || isDone);
      const st = groupStrength(profile, set.words.map((w) => w.id));
      return {
        set,
        index: i,
        isDone,
        available,
        known: st.known,
        filled: Math.round(st.avg),
        due: st.due,
      };
    });
    return { totalWords: total, learned: learnedCount, setCardsData: cards };
  }, [sets, doneSet, unlocked, profile]);

  const awardedRef = useRef<string | null>(null);

  const openSet = useCallback(
    (set: WordSet, index: number) => {
      const prevDone = index === 0 || doneSet.has(sets[index - 1].id);
      if (!unlocked || (!prevDone && !doneSet.has(set.id))) {
        setToast(unlocked ? 'Önce bir önceki seti bitir.' : 'Bu seviye henüz kilitli.');
        setTimeout(() => setToast(null), 2200);
        return;
      }
      awardedRef.current = null;
      setActive(set);
      setPhase('learn');
      setCardIndex(0);
      setExercises(buildSetExercises(set));
    },
    [doneSet, sets, unlocked]
  );

  const close = useCallback(() => setActive(null), []);

  const handleFinish = useCallback(
    (correct: number, total: number) => {
      if (!active || awardedRef.current === active.id) return;
      const ratio = correct / Math.max(1, total);
      if (ratio >= 0.5) {
        awardedRef.current = active.id;
        addXp(10 + correct * 3);
        active.words.forEach((w) => updateWordStatus(w.id, ratio >= 0.8 ? 'mastered' : 'learning'));
        markWordSetDone(active.id);
        try {
          confetti({ particleCount: 110, spread: 75, origin: { y: 0.65 } });
        } catch {
          /* ignore */
        }
        setToast(`Set tamam: ${correct}/${total}. +${10 + correct * 3} XP. Sıradaki set açıldı.`);
        setTimeout(() => setToast(null), 7000);
      }
    },
    [active, addXp, markWordSetDone, updateWordStatus]
  );
  useBackHandler(active !== null, close);

  if (active && phase === 'quiz') {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
        <ExerciseRunner
          exercises={exercises}
          allowLengthSelect={false}
          passRatio={0.5}
          completeLabel="Seti Tamamla"
          title={`Kelime seti ${active.index} (${active.level})`}
          onExit={close}
          onFinish={handleFinish}
          onComplete={(correct, total) => {
            if (awardedRef.current !== active.id) {
              setToast(`${correct}/${total}: seti geçmek için %50 gerekli. Yanlışları tekrar çözüp yeniden dene.`);
              setTimeout(() => setToast(null), 7000);
            }
            close();
          }}
        />
      </div>
    );
  }

  if (active && phase === 'learn') {
    const w = active.words[cardIndex];
    const last = cardIndex === active.words.length - 1;
    return (
      <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
        <div className="flex items-center gap-3 px-4 h-14 shrink-0">
          <button onClick={close} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-emerald-500 rounded-full transition-all"
              style={{ width: `${((cardIndex + 1) / active.words.length) * 100}%` }}
            />
          </div>
          <span className="text-xs font-black text-slate-500 tabular-nums">
            {cardIndex + 1}/{active.words.length}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          <div className="max-w-md mx-auto mt-4 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 text-center">
            <div className="text-xs font-bold text-slate-400">{w.category}</div>
            <div className="mt-3 flex items-baseline justify-center gap-2 flex-wrap">
              {w.article !== 'none' && (
                <span className={`text-2xl font-black ${ARTICLE_COLOR[w.article]}`}>{w.article}</span>
              )}
              <span className="text-4xl font-black text-slate-900 dark:text-white">{w.german}</span>
            </div>
            <div className="mt-2 text-lg text-slate-600 dark:text-slate-300">{w.turkish}</div>
            <button
              onClick={() => speakGerman(`${w.article !== 'none' ? w.article + ' ' : ''}${w.german}`, profile.speechSpeed)}
              className="mt-4 w-12 h-12 rounded-2xl bg-sky-500 text-white shadow-[0_4px_0_#0369a1] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center cursor-pointer"
              aria-label="Kelimeyi dinle"
            >
              <Volume2 className="w-6 h-6" />
            </button>

            <div className="mt-6 rounded-2xl bg-slate-50 dark:bg-slate-900/60 p-4 text-left">
              <div className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">{highlight(w)}</div>
              <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">{w.exampleTurkish}</div>
              <button
                onClick={() => speakGerman(w.exampleGerman, profile.speechSpeed)}
                className="mt-3 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
              >
                <Volume2 className="w-4 h-4" /> Cümleyi dinle
              </button>
            </div>
          </div>
        </div>

        <div className="p-4 shrink-0 flex gap-3 max-w-md w-full mx-auto">
          <button
            disabled={cardIndex === 0}
            onClick={() => setCardIndex((i) => i - 1)}
            className="h-14 w-14 rounded-2xl border-2 border-slate-200 dark:border-slate-700 text-slate-500 disabled:opacity-40 inline-flex items-center justify-center cursor-pointer"
            aria-label="Önceki kelime"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => (last ? setPhase('quiz') : setCardIndex((i) => i + 1))}
            className="flex-1 h-14 rounded-2xl bg-emerald-500 text-white font-black text-base shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            {last ? 'Soruları başlat' : 'Sonraki kelime'} <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-xl font-black text-slate-900 dark:text-white inline-flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" /> Kelime setleri
        </h2>
        <button onClick={() => setActiveTab('flashcards')} className="text-xs font-black text-sky-600 dark:text-sky-400 cursor-pointer">
          Kelime kartları
        </button>
      </div>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Her sette 8 yeni kelime öğren, cümle içinde gör, sonra soru çöz.
      </p>

      <div className="mt-4 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Kelime seviyesi">
        {LEVEL_ORDER.map((lvl) => (
          <button
            key={lvl}
            role="tab"
            aria-selected={lvl === level}
            onClick={() => setLevel(lvl)}
            className={`flex-1 min-w-[60px] h-11 rounded-2xl text-sm font-black inline-flex items-center justify-center gap-1 cursor-pointer ${
              lvl === level
                ? 'bg-amber-500 text-white shadow-[0_4px_0_#b45309]'
                : 'bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {!unlockedByLevel[lvl] && <Lock className="w-3.5 h-3.5" />}
            {lvl}
          </button>
        ))}
      </div>

      <div className="mt-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900/60 p-4">
        <div className="flex items-center justify-between text-sm font-black text-amber-800 dark:text-amber-300">
          <span>{level} kelime ilerlemesi</span>
          <span className="tabular-nums">
            {learned}/{totalWords}
          </span>
        </div>
        <div className="mt-2 h-3 rounded-full bg-amber-200/70 dark:bg-amber-900/60 overflow-hidden">
          <div className="h-full bg-amber-500 rounded-full transition-all" style={{ width: `${(learned / Math.max(1, totalWords)) * 100}%` }} />
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {setCardsData.map((card) => (
          <WordSetCard
            key={card.set.id}
            set={card.set}
            index={card.index}
            isDone={card.isDone}
            available={card.available}
            known={card.known}
            filled={card.filled}
            due={card.due}
            onOpenSet={openSet}
          />
        ))}
      </div>

      {toast && (
        <div role="status" className="fixed left-1/2 -translate-x-1/2 bottom-28 z-40 max-w-[90vw] px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
});

export const WordQuestView: React.FC = memo(() => {
  const { navTarget, clearNavTarget } = useApp();
  const [mode, setMode] = useState<'sets' | 'connectors' | 'listening' | 'speaking' | 'games'>('sets');
  useEffect(() => {
    if (navTarget && ['sets', 'connectors', 'listening', 'speaking', 'games'].includes(navTarget)) {
      setMode(navTarget as any);
      clearNavTarget();
    }
  }, [navTarget, clearNavTarget]);
  return (
    <div>
      <div className="max-w-xl mx-auto px-4 pt-4">
        <div className="flex gap-1 p-1 overflow-x-auto rounded-2xl bg-slate-200/70 dark:bg-slate-800" role="tablist" aria-label="Kelime bölümü">
          {([['sets', 'Kelimeler'], ['connectors', 'Bağlaçlar'], ['listening', 'Dinleme'], ['speaking', 'Konuşma'], ['games', 'Oyunlar']] as const).map(([id, label]) => (
            <button
              key={id}
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
              className={`h-10 flex-1 min-w-[88px] px-2 rounded-xl text-sm font-black transition cursor-pointer ${
                mode === id ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {mode === 'sets' ? (
        <WordSetsView />
      ) : mode === 'connectors' ? (
        <ConnectorsView />
      ) : mode === 'listening' ? (
        <ListeningLab />
      ) : mode === 'speaking' ? (
        <SpeakingHub />
      ) : (
        <div className="max-w-xl mx-auto px-4 py-5 pb-28">
          <GamesHub />
        </div>
      )}
    </div>
  );
});
