import React, { memo, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { LEVEL_ORDER } from '../../utils/progress';
import {
  SKILLS,
  levelTargets,
  memoryStats,
  minutesOf,
  skillAccuracy,
  srsBoxDistribution,
  todayActivity,
  weakTopics,
  weeklySeries,
} from '../../utils/analytics';

const Bar: React.FC<{ pct: number; color: string }> = memo(({ pct, color }) => (
  <div className="h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
    <div
      className={`h-full rounded-full ${color} transition-all duration-700`}
      style={{ width: `${Math.max(0, Math.min(100, Number.isFinite(pct) ? pct : 0))}%` }}
    />
  </div>
));

const Card: React.FC<{ title: string; subtitle?: string; children: React.ReactNode }> = memo(({ title, subtitle, children }) => (
  <section className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4">
    <div className="flex items-baseline justify-between gap-2">
      <h3 className="text-sm font-black text-slate-900 dark:text-white">{title}</h3>
      {subtitle && <span className="text-[11px] font-bold text-slate-400">{subtitle}</span>}
    </div>
    <div className="mt-3">{children}</div>
  </section>
));

export const ProgressPanel: React.FC = memo(() => {
  const { profile, currentLevel } = useApp();
  const dailyGoalMins = profile?.dailyMinutes || 15;

  const {
    today,
    week,
    maxMin,
    weekTotal,
    weekQuestions,
    acc,
    mem,
    boxes,
    totalBoxes,
    weak,
    shownLevels,
    targetsByLevel,
  } = useMemo(() => {
    const t = todayActivity(profile);
    const w = weeklySeries(profile);
    const mMin = Math.max(dailyGoalMins, 5, ...w.map((d) => d.minutes));
    const wTotal = w.reduce((a, d) => a + d.minutes, 0);
    const wQuestions = w.reduce((a, d) => a + d.q, 0);
    const a = skillAccuracy(profile, 30);
    const m = memoryStats(profile);
    const b = srsBoxDistribution(profile);
    const tBoxes = Math.max(1, b.reduce((sum, item) => sum + item.count, 0));
    const wk = weakTopics(profile);
    const lvlIndex = Math.max(0, LEVEL_ORDER.indexOf(currentLevel));
    const levels = LEVEL_ORDER.slice(0, lvlIndex + 2).filter(Boolean);
    const targets = levels.map((lvl) => ({
      lvl,
      items: levelTargets(profile, lvl),
    }));

    return {
      today: t,
      week: w,
      maxMin: mMin,
      weekTotal: wTotal,
      weekQuestions: wQuestions,
      acc: a,
      mem: m,
      boxes: b,
      totalBoxes: tBoxes,
      weak: wk,
      shownLevels: levels,
      targetsByLevel: targets,
    };
  }, [profile, currentLevel, dailyGoalMins]);

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28 space-y-4">
      <div className="grid grid-cols-3 gap-3 text-center">
        {[
          ['Bugün', `${minutesOf(today.secs)} dk`],
          ['Bu hafta', `${weekTotal} dk`],
          ['Soru (bugün)', String(today.q)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 py-3">
            <div className="text-xl font-black text-slate-900 dark:text-white tabular-nums">{value}</div>
            <div className="text-[11px] font-bold text-slate-400">{label}</div>
          </div>
        ))}
      </div>

      <Card title="Haftalık çalışma süresi (dakika)" subtitle={`${weekQuestions} soru · hedef ${dailyGoalMins} dk/gün`}>
        <div className="relative flex items-end justify-between gap-2 h-32 pt-2">
          <div
            className="pointer-events-none absolute left-0 right-0 border-t border-dashed border-emerald-400/70"
            style={{ bottom: `${Math.min(92, Math.max(12, (dailyGoalMins / maxMin) * 80 + 16))}%` }}
            aria-hidden="true"
          />
          {week.map((d) => {
            const hitGoal = d.minutes >= dailyGoalMins;
            return (
              <div key={d.key} className="flex-1 flex flex-col items-center gap-1 z-10">
                <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 tabular-nums">{d.minutes || ''}</div>
                <div className="w-full flex-1 flex items-end">
                  <div
                    className={`w-full rounded-lg transition-all ${hitGoal ? 'bg-emerald-500' : 'bg-sky-500'}`}
                    style={{
                      height: `${d.minutes ? Math.max(10, (d.minutes / maxMin) * 100) : 5}%`,
                      opacity: d.minutes ? 1 : 0.2,
                    }}
                    title={`${d.label}: ${d.minutes} dk, ${d.q} soru`}
                  />
                </div>
                <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400">{d.label}</div>
              </div>
            );
          })}
        </div>
      </Card>

      <Card title="Becerilerin (son 30 gün)">
        <div className="space-y-3">
          {SKILLS.map((s) => {
            const a = acc?.[s.id] ?? { pct: null, n: 0 };
            const pct = a?.pct ?? null;
            const count = a?.n ?? 0;
            return (
              <div key={s.id}>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">
                    {s.emoji} {s.label}
                  </span>
                  <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                    {pct === null ? `veri yok (${count}/5)` : `%${pct}`}
                  </span>
                </div>
                <div className="mt-1">
                  <Bar pct={pct ?? 0} color={s.color} />
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11px] text-slate-400">Yüzde, o becerideki ilk denemede doğru cevap oranıdır. En az 5 cevap gerekir.</p>
      </Card>

      <Card title="Hafıza ve aralık tekrarı">
        <div className="grid grid-cols-2 gap-3 text-center">
          {[
            ['Öğrenilen kelime', String(mem.wordsLearned)],
            ['Kalıcı hatırlanan', String(mem.wordsRemembered)],
            ['Kelime doğruluğu', mem.vocabRate === null ? '-' : `%${mem.vocabRate}`],
            ['Gramer doğruluğu', mem.grammarRate === null ? '-' : `%${mem.grammarRate}`],
          ].map(([label, value]) => (
            <div key={label} className="rounded-2xl bg-slate-50 dark:bg-slate-900/50 py-3">
              <div className="text-lg font-black text-slate-900 dark:text-white tabular-nums">{value}</div>
              <div className="text-[11px] font-bold text-slate-400">{label}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/70">
          <div className="text-[11px] font-black uppercase tracking-wide text-slate-400 mb-2">Hafıza kutuları (Leitner)</div>
          <div className="grid grid-cols-6 gap-1.5 text-center">
            {boxes.map((b) => {
              const barPct = b.count > 0 ? Math.max(12, Math.round((b.count / totalBoxes) * 100)) : 4;
              return (
                <div key={b.box} className="flex flex-col items-center gap-1">
                  <span className="text-[10px] font-black text-slate-600 dark:text-slate-300 tabular-nums">{b.count}</span>
                  <div className="w-full h-10 bg-slate-100 dark:bg-slate-900/60 rounded-lg flex items-end overflow-hidden p-0.5">
                    <div
                      className={`w-full rounded ${
                        b.box === 0 ? 'bg-rose-400' : b.box <= 2 ? 'bg-amber-400' : 'bg-emerald-500'
                      }`}
                      style={{ height: `${barPct}%`, opacity: b.count > 0 ? 1 : 0.25 }}
                    />
                  </div>
                  <span className="text-[9px] font-bold text-slate-400 truncate max-w-full">{b.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      <Card title="Zayıf konular">
        {weak.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">Henüz yeterli veri yok. Çözdükçe en çok zorlandığın konular burada görünür.</p>
        ) : (
          <ul className="space-y-2">
            {weak.map((w) => (
              <li key={w.label} className="flex items-center justify-between text-sm">
                <span className="font-bold text-slate-800 dark:text-slate-100">{w.label}</span>
                <span className="text-xs font-black text-rose-500">{w.wrong} yanlış</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {shownLevels.length > 0 && targetsByLevel.map(({ lvl, items }) => (
        <Card key={lvl} title={`${lvl} seviye hedefleri`}>
          <div className="space-y-2.5">
            {items.map((t) => (
              <div key={t.label}>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">{t.label}</span>
                  <span className="text-slate-500 dark:text-slate-400 tabular-nums">
                    {t.done}/{t.total}
                  </span>
                </div>
                <div className="mt-1">
                  <Bar pct={(t.done / Math.max(1, t.total)) * 100} color="bg-amber-500" />
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
});
