import React from 'react';
import { ArticleType } from '../../types';
import { ARTICLE_BADGE_CLASS, ARTICLE_TEXT_COLOR, splitGermanArticle } from '../../utils/articleColors';

interface GermanNounProps {
  article?: ArticleType;
  german: string;
  variant?: 'inline' | 'badge';
  className?: string;
  nounClassName?: string;
}

export const GermanNoun: React.FC<GermanNounProps> = ({
  article,
  german,
  variant = 'inline',
  className = '',
  nounClassName = '',
}) => {
  const resolved = article ? { article, word: german } : splitGermanArticle(german);
  const art = resolved.article;
  const word = resolved.word;

  if (art === 'none') {
    return <span className={`${nounClassName} ${className}`.trim()}>{word}</span>;
  }

  return (
    <span className={`inline-flex items-baseline gap-1.5 flex-wrap ${className}`.trim()}>
      {variant === 'badge' ? (
        <span className={`text-[11px] font-black px-2 py-0.5 rounded-lg border ${ARTICLE_BADGE_CLASS[art]}`}>
          {art}
        </span>
      ) : (
        <span className={`font-black ${ARTICLE_TEXT_COLOR[art]}`}>{art}</span>
      )}
      <span className={nounClassName}>{word}</span>
    </span>
  );
};
