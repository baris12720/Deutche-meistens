import React from 'react';

interface State {
  hasError: boolean;
  errorMessage: string;
}

/** Prevents a blank screen: shows a friendly message, optional backup download, and reload button if something crashes. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false, errorMessage: '' };

  static getDerivedStateFromError(error: unknown): State {
    const msg = error instanceof Error ? `${error.name}: ${error.message}` : String(error || '');
    return { hasError: true, errorMessage: msg };
  }

  componentDidCatch(error: unknown) {
    console.error('App error:', error);
  }

  handleDownloadBackup = () => {
    try {
      const raw = window.localStorage.getItem('DEUTSCH_MEISTER_USER_STATE_V1') || '{}';
      const blob = new Blob([raw], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `deutsch_meister_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      /* ignore */
    }
  };

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center gap-4 p-6 text-center bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
        <div className="text-5xl">😕</div>
        <h1 className="text-xl font-black">Bir şeyler ters gitti</h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 max-w-sm">
          İlerlemeniz cihazda güvenle saklanıyor. Uygulamayı yeniden yükleyebilir veya güvenlik için ilerleme yedeğinizi indirebilirsiniz.
        </p>
        {this.state.errorMessage && (
          <div className="max-w-md w-full rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 text-[11px] font-mono text-rose-600 dark:text-rose-400 break-words">
            {this.state.errorMessage}
          </div>
        )}
        <div className="flex flex-wrap gap-3 justify-center">
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer"
          >
            Yeniden yükle
          </button>
          <button
            onClick={this.handleDownloadBackup}
            className="px-5 py-3 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-bold text-sm cursor-pointer"
          >
            Yedek İndir (.json)
          </button>
        </div>
      </div>
    );
  }
}
