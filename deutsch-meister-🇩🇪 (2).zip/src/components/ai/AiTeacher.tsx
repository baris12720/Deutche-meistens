import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  Circle,
  MessageCircle,
  RotateCcw,
  Send,
  Sparkles,
  Target,
  Volume2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { AiReply, AiTurn, askTeacher, loadAiConfig, saveAiConfig } from '../../utils/aiClient';
import { weakTopics } from '../../utils/analytics';
import { speakGerman } from '../../utils/audio';
import { CEFRLevel } from '../../types';
import {
  ROLEPLAY_MISSIONS,
  RoleplayMission,
  evaluateRoleplayTurnOffline,
} from '../../data/roleplayMissions';

interface Msg {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  reply?: AiReply;
}

const CHAT_KEY = 'dm_ai_chat_v1';

const TOPICS: Record<CEFRLevel, string[]> = {
  A1: ['Kendini tanıtma', 'Aile', 'Yemek ve içecek', 'Günlük rutin'],
  A2: ['Alışveriş', 'Seyahat', 'Hobiler', 'Hava ve mevsimler'],
  B1: ['İş hayatı', 'Gelecek planları', 'Sağlık', 'Medya'],
  B2: ['Çevre', 'Eğitim', 'Teknoloji', 'Toplumsal konular'],
  C1: ['Siyaset ve toplum', 'Bilim', 'Kültür ve sanat', 'Ekonomi'],
};

const GREETING: Record<string, { de: string; tr: string }> = {
  A1: { de: 'Hallo! Ich bin dein Deutschlehrer. Wie heißt du?', tr: 'Merhaba! Ben senin Almanca öğretmeninim. Adın ne?' },
  A2: { de: 'Hallo! Schön, dass du da bist. Was hast du gestern gemacht?', tr: 'Merhaba! Gelmene sevindim. Dün ne yaptın?' },
  B1: { de: 'Hallo! Worüber möchtest du heute sprechen? Erzähl mir von deinen Plänen.', tr: 'Merhaba! Bugün ne hakkında konuşmak istersin? Bana planlarını anlat.' },
  B2: { de: 'Guten Tag! Welches Thema beschäftigt dich zurzeit besonders?', tr: 'İyi günler! Şu sıralar seni özellikle hangi konu meşgul ediyor?' },
  C1: { de: 'Guten Tag! Welche aktuelle Debatte findest du besonders interessant, und warum?', tr: 'İyi günler! Güncel hangi tartışmayı özellikle ilginç buluyorsun ve neden?' },
};

export const AiTeacher: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const {
    profile,
    currentLevel,
    addAiMistake,
    recordActivity,
    addXp,
    markRoleplayMissionDone,
  } = useApp();

  const [tab, setTab] = useState<'chat' | 'missions'>('missions');
  const [cfg, setCfg] = useState(loadAiConfig());
  const [endpointInput, setEndpointInput] = useState(cfg.endpoint);
  const [tokenInput, setTokenInput] = useState(cfg.token);
  const [topic, setTopic] = useState(TOPICS[currentLevel][0]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showTr, setShowTr] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>(() => {
    try {
      const raw = localStorage.getItem(CHAT_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      /* ignore */
    }
    return [];
  });

  // Roleplay Mission state
  const [activeMission, setActiveMission] = useState<RoleplayMission>(ROLEPLAY_MISSIONS[0]);
  const [missionMsgs, setMissionMsgs] = useState<Msg[]>([]);
  const [missionCompletedGoals, setMissionCompletedGoals] = useState<string[]>([]);
  const [missionInput, setMissionInput] = useState('');
  const [missionBusy, setMissionBusy] = useState(false);
  const [missionWon, setMissionWon] = useState(false);

  const endRef = useRef<HTMLDivElement>(null);
  const missionEndRef = useRef<HTMLDivElement>(null);

  const completedMissionSet = useMemo(
    () => new Set(profile.completedRoleplayMissions || []),
    [profile.completedRoleplayMissions]
  );

  useEffect(() => {
    try {
      localStorage.setItem(CHAT_KEY, JSON.stringify(msgs.slice(-40)));
    } catch {
      /* ignore */
    }
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, busy]);

  useEffect(() => {
    missionEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [missionMsgs, missionBusy]);

  const selectMission = (m: RoleplayMission) => {
    setActiveMission(m);
    setMissionMsgs([]);
    setMissionCompletedGoals([]);
    setMissionInput('');
    setMissionWon(false);
    setError(null);
  };

  const configured = !!cfg.endpoint;
  const greeting = GREETING[currentLevel] || GREETING.A1;

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setError(null);
    setInput('');
    const userMsg: Msg = { id: `u${Date.now()}`, role: 'user', text };
    setMsgs((m) => [...m, userMsg]);
    setBusy(true);
    try {
      const history: AiTurn[] = [...msgs, userMsg].slice(-8).map((m) => ({
        role: m.role,
        text:
          m.role === 'assistant' && m.reply
            ? [m.reply.reply, m.reply.followUp].filter(Boolean).join(' ')
            : m.text,
      }));
      const reply = await askTeacher(cfg, {
        message: text,
        history: history.slice(0, -1),
        level: currentLevel,
        topic,
        weakAreas: weakTopics(profile).slice(0, 3).map((w) => w.label),
        knownErrors: (profile.aiMistakes || []).slice(0, 5).map((e) => e.type),
      });
      setMsgs((m) => [...m, { id: `a${Date.now()}`, role: 'assistant', text: reply.reply, reply }]);
      if (reply.correction) {
        addAiMistake({
          original: reply.correction.original,
          corrected: reply.correction.corrected,
          explanationTr: reply.correction.explanationTr,
          type: reply.correction.errorType,
        });
        recordActivity('writing', false, 30);
      } else {
        recordActivity('writing', true, 30);
        addXp(2);
      }
    } catch (e: any) {
      setError(e?.message || 'Bir hata oluştu.');
    } finally {
      setBusy(false);
    }
  };

  const sendMissionTurn = async (overrideText?: string) => {
    const text = (overrideText ?? missionInput).trim();
    if (!text || missionBusy) return;
    setError(null);
    if (!overrideText) setMissionInput('');

    const userMsg: Msg = { id: `mu_${Date.now()}`, role: 'user', text };
    setMissionMsgs((prev) => [...prev, userMsg]);
    setMissionBusy(true);

    // Detect completed mission sub-goals from user's German message
    const lower = text.toLowerCase();
    const newlyDone = activeMission.goals
      .filter(
        (g) =>
          !missionCompletedGoals.includes(g.id) &&
          g.keywords.some((kw) => lower.includes(kw.toLowerCase()))
      )
      .map((g) => g.id);

    const updatedGoals = Array.from(new Set([...missionCompletedGoals, ...newlyDone]));
    setMissionCompletedGoals(updatedGoals);
    const remainingGoals = activeMission.goals.filter((g) => !updatedGoals.includes(g.id));

    try {
      let reply: AiReply;
      if (configured) {
        try {
          const history: AiTurn[] = [...missionMsgs, userMsg].slice(-8).map((m) => ({
            role: m.role,
            text:
              m.role === 'assistant' && m.reply
                ? [m.reply.reply, m.reply.followUp].filter(Boolean).join(' ')
                : m.text,
          }));
          reply = await askTeacher(cfg, {
            message: text,
            history: history.slice(0, -1),
            level: activeMission.level,
            topic: `Rol yapma görevi (${activeMission.characterName}): ${activeMission.missionDescriptionTr}`,
            weakAreas: weakTopics(profile).slice(0, 2).map((w) => w.label),
            knownErrors: (profile.aiMistakes || []).slice(0, 4).map((e) => e.type),
          });
        } catch {
          const local = evaluateRoleplayTurnOffline(
            activeMission,
            text,
            newlyDone,
            remainingGoals
          );
          reply = {
            reply: local.replyDe,
            replyTr: local.replyTr,
            followUp: local.followUpDe,
            tipTr: local.tipTr,
            correction: local.correction,
          };
        }
      } else {
        const local = evaluateRoleplayTurnOffline(
          activeMission,
          text,
          newlyDone,
          remainingGoals
        );
        reply = {
          reply: local.replyDe,
          replyTr: local.replyTr,
          followUp: local.followUpDe,
          tipTr: local.tipTr,
          correction: local.correction,
        };
      }

      setMissionMsgs((prev) => [
        ...prev,
        { id: `ma_${Date.now()}`, role: 'assistant', text: reply.reply, reply },
      ]);
      speakGerman([reply.reply, reply.followUp].filter(Boolean).join(' '), profile.speechSpeed);

      if (reply.correction) {
        addAiMistake({
          original: reply.correction.original,
          corrected: reply.correction.corrected,
          explanationTr: reply.correction.explanationTr,
          type: reply.correction.errorType,
        });
        recordActivity('speaking', false, 25);
      } else {
        recordActivity('speaking', true, 25);
      }

      if (!missionWon && updatedGoals.length === activeMission.goals.length) {
        setMissionWon(true);
        markRoleplayMissionDone(activeMission.id, activeMission.xpReward);
        try {
          confetti({ particleCount: 110, spread: 75, origin: { y: 0.6 } });
        } catch {
          /* ignore */
        }
      }
    } finally {
      setMissionBusy(false);
    }
  };

  const corrections =
    tab === 'chat'
      ? msgs.filter((m) => m.reply?.correction).length
      : missionMsgs.filter((m) => m.reply?.correction).length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 h-14 shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <button onClick={onClose} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="min-w-0">
          <div className="text-sm font-black text-slate-900 dark:text-white">
            Yapay Zekâ Almanca Öğretmeni
          </div>
          <div className="text-[11px] text-slate-400">
            Seviye {tab === 'missions' ? activeMission.level : currentLevel} · {corrections} düzeltme
          </div>
        </div>
        <button
          onClick={() => setShowTr((v) => !v)}
          className={`ml-auto px-2.5 h-8 rounded-lg text-[11px] font-black cursor-pointer ${
            showTr
              ? 'bg-amber-500 text-white'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
          }`}
        >
          Türkçe
        </button>
      </div>

      {/* Mode Switcher: Senaryo Görevleri | Serbest Sohbet */}
      <div className="px-4 py-2 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shrink-0">
        <div
          className="max-w-xl mx-auto grid grid-cols-2 gap-1 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800"
          role="tablist"
        >
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'missions'}
            onClick={() => setTab('missions')}
            className={`h-9 rounded-xl text-xs font-black inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
              tab === 'missions'
                ? 'bg-white dark:bg-slate-700 text-emerald-700 dark:text-emerald-300 shadow-xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <Target className="w-3.5 h-3.5" /> Senaryo Görevleri
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'chat'}
            onClick={() => setTab('chat')}
            className={`h-9 rounded-xl text-xs font-black inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
              tab === 'chat'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" /> Serbest Sohbet
          </button>
        </div>
      </div>

      {tab === 'missions' ? (
        <>
          {/* Mission selector pills */}
          <div className="px-4 pt-2.5 pb-1.5 flex gap-2 overflow-x-auto shrink-0 bg-slate-50 dark:bg-slate-950">
            {ROLEPLAY_MISSIONS.map((m) => {
              const isSelected = activeMission.id === m.id;
              const isDone = completedMissionSet.has(m.id);
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => selectMission(m)}
                  className={`shrink-0 px-3 py-1.5 rounded-2xl text-xs font-black inline-flex items-center gap-1.5 border transition cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  <span>{m.emoji}</span>
                  <span>{m.level}: {m.titleTr}</span>
                  {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-amber-300" />}
                </button>
              );
            })}
          </div>

          {/* Active Mission Objective & Checklist Card */}
          <div className="px-4 pb-2 shrink-0">
            <div className="max-w-xl mx-auto rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3 space-y-2 shadow-2xs">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[11px] font-black uppercase tracking-wide text-emerald-600 dark:text-emerald-400">
                    {activeMission.emoji} {activeMission.characterName} · +{activeMission.xpReward} XP
                  </div>
                  <p className="text-xs font-bold text-slate-800 dark:text-slate-100 mt-0.5">
                    {activeMission.missionDescriptionTr}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => selectMission(activeMission)}
                  title="Görevi sıfırla"
                  className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer shrink-0"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                {activeMission.goals.map((goal) => {
                  const done = missionCompletedGoals.includes(goal.id);
                  return (
                    <div
                      key={goal.id}
                      className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1.5 border ${
                        done
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200'
                          : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {done ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      ) : (
                        <Circle className="w-3.5 h-3.5 shrink-0" />
                      )}
                      <span className="truncate">{goal.labelTr}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Roleplay Chat Stream */}
          <div className="flex-1 overflow-y-auto px-4 py-2 space-y-3">
            <div className="max-w-xl mx-auto space-y-3">
              {/* Opening Character Message */}
              <div className="max-w-[88%] rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                <div className="text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-400 mb-0.5">
                  {activeMission.characterName}
                </div>
                <div className="text-sm font-bold text-slate-900 dark:text-white">
                  {activeMission.openingDe}
                </div>
                {showTr && (
                  <div className="mt-1 text-xs text-slate-500">{activeMission.openingTr}</div>
                )}
                <button
                  type="button"
                  onClick={() => speakGerman(activeMission.openingDe, profile.speechSpeed)}
                  className="mt-2 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-4 h-4" /> Dinle
                </button>
              </div>

              {missionMsgs.map((m) =>
                m.role === 'user' ? (
                  <div key={m.id} className="flex justify-end">
                    <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-emerald-500 text-white p-3 text-sm font-bold">
                      {m.text}
                    </div>
                  </div>
                ) : (
                  <div key={m.id} className="max-w-[92%] space-y-2">
                    {m.reply?.correction && (
                      <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900 p-3 text-xs sm:text-sm space-y-1">
                        <div className="font-black text-amber-700 dark:text-amber-300 text-[11px] uppercase">
                          💡 Nazik Düzeltme ({m.reply.correction.errorType})
                        </div>
                        <div>
                          <span className="font-black text-rose-600">Senin cümlen:</span>{' '}
                          <span className="line-through text-slate-600 dark:text-slate-300">
                            {m.reply.correction.original}
                          </span>
                        </div>
                        <div>
                          <span className="font-black text-emerald-600">Doğrusu:</span>{' '}
                          <span className="font-bold text-slate-900 dark:text-white">
                            {m.reply.correction.corrected}
                          </span>
                        </div>
                        {m.reply.correction.explanationTr && (
                          <div className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                            {m.reply.correction.explanationTr}
                          </div>
                        )}
                      </div>
                    )}
                    <div className="rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                      <div className="text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-400 mb-0.5">
                        {activeMission.characterName}
                      </div>
                      <div className="text-sm font-bold text-slate-900 dark:text-white">
                        {m.reply?.reply}
                      </div>
                      {showTr && m.reply?.replyTr && (
                        <div className="mt-1 text-xs text-slate-500">{m.reply.replyTr}</div>
                      )}
                      {m.reply?.followUp && (
                        <div className="mt-1.5 text-sm font-bold text-emerald-700 dark:text-emerald-300">
                          {m.reply.followUp}
                        </div>
                      )}
                      {m.reply?.tipTr && (
                        <div className="mt-1.5 text-[11px] font-semibold text-amber-700 dark:text-amber-300">
                          ✨ {m.reply.tipTr}
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() =>
                          speakGerman(
                            [m.reply?.reply, m.reply?.followUp].filter(Boolean).join(' '),
                            profile.speechSpeed
                          )
                        }
                        className="mt-2 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Volume2 className="w-4 h-4" /> Dinle
                      </button>
                    </div>
                  </div>
                )
              )}

              {missionWon && (
                <div className="rounded-3xl bg-emerald-50 dark:bg-emerald-950/40 border-2 border-emerald-400 dark:border-emerald-700 p-4 text-center space-y-2 pop-in">
                  <div className="text-3xl">🎉</div>
                  <div className="text-base font-black text-emerald-800 dark:text-emerald-200">
                    Görev Başarıyla Tamamlandı! +{activeMission.xpReward} XP
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Tüm konuşma adımlarını yerine getirdin. İstersen sohbete devam edebilir veya yukarıdan yeni bir senaryo seçebilirsin.
                  </p>
                </div>
              )}

              {missionBusy && (
                <div className="text-xs font-bold text-slate-400">
                  {activeMission.characterName} yanıt yazıyor...
                </div>
              )}
              <div ref={missionEndRef} />
            </div>
          </div>

          {/* Suggested quick phrases + Input */}
          <div className="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shrink-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 space-y-2">
            <div className="max-w-xl mx-auto flex gap-1.5 overflow-x-auto pb-0.5">
              {activeMission.suggestedStartersDe.map((phrase) => (
                <button
                  key={phrase}
                  type="button"
                  onClick={() => sendMissionTurn(phrase)}
                  disabled={missionBusy}
                  className="shrink-0 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] font-bold text-slate-700 dark:text-slate-200 hover:border-emerald-400 transition cursor-pointer inline-flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3 text-emerald-500" /> {phrase}
                </button>
              ))}
            </div>
            <div className="flex gap-2 max-w-xl mx-auto">
              <input
                value={missionInput}
                onChange={(e) => setMissionInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') sendMissionTurn();
                }}
                placeholder={`${activeMission.characterName} ile Almanca konuş...`}
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                className="flex-1 h-12 px-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
              <button
                type="button"
                onClick={() => sendMissionTurn()}
                disabled={missionBusy || !missionInput.trim()}
                aria-label="Gönder"
                className="w-12 h-12 rounded-2xl bg-emerald-500 text-white inline-flex items-center justify-center disabled:opacity-40 cursor-pointer"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </>
      ) : !configured ? (
        <div className="flex-1 overflow-y-auto p-4">
          <div className="max-w-md mx-auto rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-5 space-y-3">
            <div className="text-3xl text-center">🤖</div>
            <h3 className="text-lg font-black text-center text-slate-900 dark:text-white">
              Serbest Sohbet İçin Sunucu Bağlantısı
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Serbest yapay zekâ sohbeti için API anahtarının güvende kalması adına <b>server/ai-proxy</b> sunucu adresini girebilirsin. Sunucun yoksa bile <b>Senaryo Görevleri</b> sekmesi tamamen çevrimdışı çalışır!
            </p>
            <input
              value={endpointInput}
              onChange={(e) => setEndpointInput(e.target.value)}
              placeholder="https://sunucu-adresin.run.app"
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full h-12 px-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white"
            />
            <input
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="Erişim anahtarı (varsa)"
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full h-12 px-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white"
            />
            <button
              onClick={() => {
                const c = { endpoint: endpointInput.trim(), token: tokenInput.trim() };
                saveAiConfig(c);
                setCfg(c);
              }}
              disabled={!endpointInput.trim()}
              className="w-full h-12 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none disabled:opacity-40 cursor-pointer"
            >
              Kaydet
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="px-4 pt-2 flex gap-2 overflow-x-auto shrink-0">
            {TOPICS[currentLevel].map((t) => (
              <button
                key={t}
                onClick={() => setTopic(t)}
                className={`shrink-0 px-3 h-8 rounded-full text-xs font-black cursor-pointer ${
                  topic === t
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
              <div className="text-sm font-bold text-slate-900 dark:text-white">{greeting.de}</div>
              {showTr && <div className="mt-1 text-xs text-slate-500">{greeting.tr}</div>}
            </div>
            {msgs.map((m) =>
              m.role === 'user' ? (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-emerald-500 text-white p-3 text-sm font-bold">
                    {m.text}
                  </div>
                </div>
              ) : (
                <div key={m.id} className="max-w-[92%] space-y-2">
                  {m.reply?.correction && (
                    <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900 p-3 text-sm space-y-1">
                      <div>
                        <span className="font-black text-rose-600">Yanlış:</span>{' '}
                        <span className="line-through text-slate-600 dark:text-slate-300">
                          {m.reply.correction.original}
                        </span>
                      </div>
                      <div>
                        <span className="font-black text-emerald-600">Doğru:</span>{' '}
                        <span className="font-bold text-slate-900 dark:text-white">
                          {m.reply.correction.corrected}
                        </span>
                      </div>
                      {m.reply.correction.explanationTr && (
                        <div className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                          {m.reply.correction.explanationTr}
                        </div>
                      )}
                    </div>
                  )}
                  <div className="rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                    <div className="text-sm font-bold text-slate-900 dark:text-white">{m.reply?.reply}</div>
                    {showTr && m.reply?.replyTr && (
                      <div className="mt-1 text-xs text-slate-500">{m.reply.replyTr}</div>
                    )}
                    {m.reply?.followUp && (
                      <div className="mt-2 text-sm font-bold text-emerald-700 dark:text-emerald-300">
                        {m.reply.followUp}
                      </div>
                    )}
                    {m.reply?.tipTr && (
                      <div className="mt-2 text-[11px] text-amber-700 dark:text-amber-300">
                        💡 {m.reply.tipTr}
                      </div>
                    )}
                    <button
                      onClick={() =>
                        speakGerman(
                          [m.reply?.reply, m.reply?.followUp].filter(Boolean).join(' '),
                          profile.speechSpeed
                        )
                      }
                      className="mt-2 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" /> Dinle
                    </button>
                  </div>
                </div>
              )
            )}
            {busy && <div className="text-xs font-bold text-slate-400">Öğretmen yazıyor...</div>}
            {error && (
              <div className="rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-bold p-3">
                {error}
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shrink-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
            <div className="flex gap-2 max-w-xl mx-auto">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') send();
                }}
                placeholder="Almanca yaz..."
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                className="flex-1 h-12 px-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={send}
                disabled={busy || !input.trim()}
                aria-label="Gönder"
                className="w-12 h-12 rounded-2xl bg-emerald-500 text-white inline-flex items-center justify-center disabled:opacity-40 cursor-pointer"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            <div className="max-w-xl mx-auto mt-1 flex justify-between text-[11px] text-slate-400">
              <span>Ä Ö Ü ß için telefon klavyesini kullan</span>
              <button
                onClick={() => {
                  setMsgs([]);
                  try {
                    localStorage.removeItem(CHAT_KEY);
                  } catch {
                    /* ignore */
                  }
                }}
                className="font-bold cursor-pointer"
              >
                Sohbeti temizle
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
