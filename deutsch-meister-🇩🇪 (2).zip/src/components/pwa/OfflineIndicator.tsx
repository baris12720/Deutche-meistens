import React, { useEffect, useState } from 'react';
import { WifiOff, X } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setDismissed(false);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setDismissed(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline || dismissed) return null;

  return (
    <div className="hide-on-keyboard fixed bottom-20 md:bottom-4 left-4 right-4 sm:right-auto z-40 flex items-center justify-between gap-2 rounded-xl bg-amber-600/95 px-3.5 py-2 text-xs font-semibold text-white shadow-lg backdrop-blur-xs">
      <div className="flex items-center gap-2 min-w-0">
        <WifiOff className="w-4 h-4 shrink-0" />
        <span className="truncate">Çevrimdışı Mod — Dersler ve kelimeler yerel çalışıyor.</span>
      </div>
      <button
        type="button"
        onClick={() => setDismissed(true)}
        aria-label="Bildirimi kapat"
        className="p-0.5 rounded-md hover:bg-white/20 shrink-0 cursor-pointer"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
