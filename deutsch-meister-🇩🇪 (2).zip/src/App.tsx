import React, { useEffect, useRef } from 'react';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { handleBackPress, useBackHandler } from './utils/backStack';
import { stopSpeaking } from './utils/audio';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { LearnView } from './components/learn/LearnView';
import { FlashcardsView } from './components/flashcards/FlashcardsView';
import { GrammarView } from './components/grammar/GrammarView';
import { DialoguesView } from './components/dialogues/DialoguesView';
import { PracticeArena } from './components/practice/PracticeArena';
import { ProfileView } from './components/profile/ProfileView';
import { DTZView } from './components/dtz/DTZView';
import { WordQuestView } from './components/words/WordQuestView';
import { StoriesView } from './components/stories/StoriesView';
import { TtsNotice } from './components/common/TtsNotice';
import { LessonModal } from './components/lesson/LessonModal';
import { GrammarDetailModal } from './components/grammar/GrammarDetailModal';
import { DialoguePlayerModal } from './components/dialogues/DialoguePlayerModal';
import { CompletionModal } from './components/modals/CompletionModal';
import { PlacementTestModal } from './components/placement/PlacementTestModal';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { ALL_UNITS_BY_LEVEL } from './data/levels';
import { GRAMMAR_TOPICS } from './data/grammar';
import { REAL_LIFE_DIALOGUES } from './data/dialogues';
import { Lesson, GrammarTopic, RealLifeDialogue } from './types';

const LESSON_BY_ID = new Map<string, Lesson>();
for (const lvlUnits of Object.values(ALL_UNITS_BY_LEVEL)) {
  for (const unit of lvlUnits) {
    for (const lesson of unit.lessons) {
      LESSON_BY_ID.set(lesson.id, lesson);
    }
  }
}
const GRAMMAR_BY_ID = new Map<string, GrammarTopic>(GRAMMAR_TOPICS.map((g) => [g.id, g]));
const DIALOGUE_BY_ID = new Map<string, RealLifeDialogue>(REAL_LIFE_DIALOGUES.map((d) => [d.id, d]));

function MainApp() {
  const {
    activeTab,
    activeLessonId,
    closeLesson,
    activeGrammarId,
    closeGrammar,
    activeDialogueId,
    closeDialogue,
    isPlacementTestOpen,
    closePlacementTest,
    setActiveTab,
  } = useApp();

  // Android hardware back button: close overlays first, then go to the home tab, then exit.
  const tabRef = useRef(activeTab);
  tabRef.current = activeTab;
  useBackHandler(!!activeLessonId, closeLesson);
  useBackHandler(!!activeGrammarId, closeGrammar);
  useBackHandler(!!activeDialogueId, closeDialogue);
  useBackHandler(isPlacementTestOpen, closePlacementTest);
  useEffect(() => {
    let removeBack: (() => void) | undefined;
    let removeState: (() => void) | undefined;
    try {
      if (Capacitor.isNativePlatform()) {
        const AppPlugin = registerPlugin<{
          addListener: (event: string, cb: (data?: { isActive?: boolean }) => void) => Promise<{ remove: () => void }>;
          exitApp: () => Promise<void>;
        }>('App');
        AppPlugin.addListener('backButton', () => {
          if (handleBackPress()) return;
          if (tabRef.current !== 'learn') {
            setActiveTab('learn');
          } else {
            AppPlugin.exitApp().catch(() => undefined);
          }
        })
          .then((h) => {
            removeBack = () => h.remove();
          })
          .catch(() => undefined);

        AppPlugin.addListener('appStateChange', (state) => {
          if (state && state.isActive === false) {
            stopSpeaking();
          }
        })
          .then((h) => {
            removeState = () => h.remove();
          })
          .catch(() => undefined);
      }
    } catch {
      /* not running as native app */
    }

    const onVisChange = () => {
      if (document.hidden) stopSpeaking();
    };
    document.addEventListener('visibilitychange', onVisChange);

    // Hide fixed mobile navigation/CTAs when the Android soft keyboard opens
    let baselineHeight = window.innerHeight;
    const vv = window.visualViewport;
    const updateKeyboardState = () => {
      if (!vv) return;
      if (vv.height > baselineHeight) baselineHeight = vv.height;
      const activeTag = document.activeElement?.tagName;
      const isTextFocused = activeTag === 'INPUT' || activeTag === 'TEXTAREA';
      const isKeyboardOpen = isTextFocused && vv.height < baselineHeight * 0.78;
      document.body.classList.toggle('keyboard-open', isKeyboardOpen);
    };
    const onFocusOut = () => {
      setTimeout(() => document.body.classList.remove('keyboard-open'), 120);
    };
    vv?.addEventListener('resize', updateKeyboardState);
    window.addEventListener('focusin', updateKeyboardState);
    window.addEventListener('focusout', onFocusOut);

    return () => {
      removeBack?.();
      removeState?.();
      document.removeEventListener('visibilitychange', onVisChange);
      vv?.removeEventListener('resize', updateKeyboardState);
      window.removeEventListener('focusin', updateKeyboardState);
      window.removeEventListener('focusout', onFocusOut);
      document.body.classList.remove('keyboard-open');
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const currentActiveLesson = activeLessonId ? LESSON_BY_ID.get(activeLessonId) || null : null;
  const currentActiveGrammar = activeGrammarId ? GRAMMAR_BY_ID.get(activeGrammarId) || null : null;
  const currentActiveDialogue = activeDialogueId ? DIALOGUE_BY_ID.get(activeDialogueId) || null : null;

  return (
    <div className="min-h-dvh bg-linear-to-b from-emerald-50/80 via-slate-50 to-slate-50 dark:from-slate-900 dark:via-slate-950 dark:to-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-emerald-200 dark:selection:bg-emerald-900">
      {/* Top Bar */}
      <Header />

      <div className="flex-1 flex max-w-7xl w-full mx-auto pb-20 md:pb-8">
        {/* Left Desktop Sidebar */}
        <Sidebar />

        {/* Center Content View */}
        <main className="flex-1 min-w-0 overflow-y-auto">
          <div key={activeTab} className="page-enter">
          {activeTab === 'learn' && <LearnView />}
          {activeTab === 'dtz' && <DTZView />}
          {activeTab === 'words' && <WordQuestView />}
          {activeTab === 'flashcards' && <FlashcardsView />}
          {activeTab === 'grammar' && <GrammarView />}
          {activeTab === 'dialogues' && <DialoguesView />}
          {activeTab === 'stories' && <StoriesView />}
          {activeTab === 'practice' && <PracticeArena />}
          {activeTab === 'profile' && <ProfileView />}
          </div>
        </main>
      </div>

      {/* Bottom Nav on Mobile */}
      <TtsNotice />
      <BottomNav />

      {/* Modals */}
      {currentActiveLesson && (
        <LessonModal lesson={currentActiveLesson} onClose={closeLesson} />
      )}

      {currentActiveGrammar && (
        <GrammarDetailModal topic={currentActiveGrammar} onClose={closeGrammar} />
      )}

      {currentActiveDialogue && (
        <DialoguePlayerModal dialogue={currentActiveDialogue} onClose={closeDialogue} />
      )}

      <CompletionModal />

      {isPlacementTestOpen && (
        <PlacementTestModal onClose={closePlacementTest} />
      )}

      {/* Offline Toast Indicator */}
      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
