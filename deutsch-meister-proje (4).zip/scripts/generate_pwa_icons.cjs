const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function crc32(buf) {
  let table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c >>> 0;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makePng(width, height, isMaskable = false) {
  // Generate RGBA buffer
  const stride = width * 4;
  const rawData = Buffer.alloc((stride + 1) * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (stride + 1);
    rawData[rowOffset] = 0; // Filter type: None

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const dx = (x - width / 2) / (width / 2);
      const dy = (y - height / 2) / (height / 2);
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Base background: vibrant German-green gradient (#22c55e to #15803d)
      const gradRatio = y / height;
      let r = Math.round(34 * (1 - gradRatio) + 21 * gradRatio);
      let g = Math.round(197 * (1 - gradRatio) + 128 * gradRatio);
      let b = Math.round(94 * (1 - gradRatio) + 61 * gradRatio);
      let a = 255;

      if (!isMaskable) {
        // Rounded corners for non-maskable
        const cornerRadius = 0.22;
        const cx = Math.max(0, Math.abs(dx) - (1 - cornerRadius));
        const cy = Math.max(0, Math.abs(dy) - (1 - cornerRadius));
        const cornerDist = Math.sqrt(cx * cx + cy * cy);
        if (cornerDist > cornerRadius) {
          a = 0; // Transparent outside rounded corner
        }
      }

      // Draw emblem in center (owl face + German flag banner)
      if (a > 0) {
        // Inner white badge
        if (dist < 0.65) {
          // Inside emblem circle
          r = 255;
          g = 255;
          b = 255;

          // German flag stripe in top portion of circle
          if (dy > -0.55 && dy < -0.38) {
            // Black
            r = 20; g = 20; b = 25;
          } else if (dy >= -0.38 && dy < -0.22) {
            // Red
            r = 220; g = 38; b = 38;
          } else if (dy >= -0.22 && dy < -0.06) {
            // Gold
            r = 245; g = 158; b = 11;
          }

          // Eyes
          const leftEyeDist = Math.hypot(dx + 0.2, dy - 0.12);
          const rightEyeDist = Math.hypot(dx - 0.2, dy - 0.12);
          if (leftEyeDist < 0.16 || rightEyeDist < 0.16) {
            r = 2; g = 132; b = 199; // Sky blue iris
            if (leftEyeDist < 0.08 || rightEyeDist < 0.08) {
              r = 15; g = 23; b = 42; // Pupil
            }
          }

          // Beak
          if (Math.abs(dx) < 0.08 && dy >= 0.22 && dy <= 0.36) {
            const beakWidth = 0.08 * (1 - (dy - 0.22) / 0.14);
            if (Math.abs(dx) <= beakWidth) {
              r = 245; g = 158; b = 11; // Amber beak
            }
          }
        }
      }

      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  // PNG Header
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8); // bit depth 8
  ihdrData.writeUInt8(6, 9); // RGBA
  ihdrData.writeUInt8(0, 10); // compression
  ihdrData.writeUInt8(0, 11); // filter
  ihdrData.writeUInt8(0, 12); // interlace

  const ihdrChunk = createChunk('IHDR', ihdrData);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const crc = crc32(chunk.subarray(4, 8 + len));
  chunk.writeUInt32BE(crc, 8 + len);
  return chunk;
}

const publicDir = path.join(__dirname, '..', 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), makePng(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), makePng(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), makePng(512, 512, true));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), makePng(180, 180, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), makePng(64, 64, false));

console.log('Generated PWA icon PNGs in /public successfully!');
