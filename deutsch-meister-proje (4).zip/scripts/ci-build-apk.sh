#!/usr/bin/env bash
# GitHub Actions icinde calisir: projeyi bulur, Capacitor ile Android debug APK uretir.
set -euo pipefail

ROOT="$(pwd)"
RUN="${GITHUB_RUN_NUMBER:-1}"

if [ -f package.json ]; then
  PROJECT_DIR="$ROOT"
else
  PKG="$(find _p -maxdepth 3 -name package.json -not -path '*/node_modules/*' -not -path '*/__MACOSX/*' | head -n1)"
  if [ -z "$PKG" ]; then
    echo "::error::package.json bulunamadi. Proje zip'ini depoya yukleyin."
    exit 1
  fi
  PROJECT_DIR="$ROOT/$(dirname "$PKG")"
fi
echo "Proje klasoru: $PROJECT_DIR"
cd "$PROJECT_DIR"

echo "== Android SDK lisanslari =="
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null 2>&1 || true

echo "== Bagimliliklar =="
npm install --legacy-peer-deps --no-audit --no-fund
npm install --legacy-peer-deps --no-audit --no-fund @capacitor/core@7 @capacitor/android@7
npm install --legacy-peer-deps --no-audit --no-fund --save-dev @capacitor/cli@7

echo "== Geri tusu eklentisi =="
npm install --legacy-peer-deps --no-audit --no-fund @capacitor/app@7 || echo "Uyari: @capacitor/app kurulamadi, geri tusu varsayilan davranacak."

echo "== Sesli okuma eklentisi (Android TTS) =="
TTS=0
for V in 7 6 latest; do
  if npm install --legacy-peer-deps --no-audit --no-fund "@capacitor-community/text-to-speech@$V"; then TTS=1; break; fi
done
echo "TTS eklentisi: $TTS"

if [ ! -f capacitor.config.json ] && [ ! -f capacitor.config.ts ]; then
  cat > capacitor.config.json <<'JSON'
{
  "appId": "com.deutschmeister.app",
  "appName": "Deutsch Meister",
  "webDir": "dist",
  "server": { "androidScheme": "https" }
}
JSON
fi

echo "== Web derlemesi =="
BASE_PATH=/ npm run build

echo "== Android projesi =="
if [ ! -d android ]; then npx cap add android; fi

MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q "android.permission.VIBRATE" "$MANIFEST"; then
  sed -i 's|<application|<uses-permission android:name="android.permission.VIBRATE" />\n    <application|' "$MANIFEST"
fi
if ! grep -q "TTS_SERVICE" "$MANIFEST"; then
  sed -i 's|<application|<queries><intent><action android:name="android.intent.action.TTS_SERVICE" /></intent></queries>\n    <application|' "$MANIFEST"
fi

echo "== Ikon (basarisiz olursa varsayilan kalir) =="
(
  if [ -f public/pwa-512x512.png ]; then
    mkdir -p assets
    convert public/pwa-512x512.png -resize 1024x1024 assets/icon-only.png
    cp assets/icon-only.png assets/icon-foreground.png
    convert -size 1024x1024 xc:'#22c55e' assets/icon-background.png
    npx --yes @capacitor/assets generate --android --iconBackgroundColor '#22c55e' --iconBackgroundColorDark '#22c55e'
  fi
) || echo "Ikon olusturulamadi, varsayilan ikon kullanilacak."

echo "== Sync ve surum =="
npx cap sync android
GRADLE=android/app/build.gradle
sed -i "s/versionCode [0-9]*/versionCode $RUN/" "$GRADLE"
sed -i "s/versionName \"[^\"]*\"/versionName \"1.0.$RUN\"/" "$GRADLE"

echo "== Gradle ayarlari (daha uzun zaman asimi, kucuk paket) =="
WRAP=android/gradle/wrapper/gradle-wrapper.properties
sed -i 's/-all\.zip/-bin.zip/' "$WRAP"
if grep -q '^networkTimeout=' "$WRAP"; then
  sed -i 's/^networkTimeout=.*/networkTimeout=180000/' "$WRAP"
else
  echo 'networkTimeout=180000' >> "$WRAP"
fi
cat "$WRAP"

build_apk() {
  (
    cd android
    chmod +x gradlew
    for i in 1 2 3; do
      echo "Deneme $i"
      if ./gradlew assembleDebug --no-daemon; then exit 0; fi
      echo "Basarisiz, 20 sn sonra tekrar denenecek..."
      sleep 20
    done
    exit 1
  )
}

echo "== APK derleme (3 denemeye kadar) =="
if ! build_apk; then
  if [ "$TTS" = "1" ]; then
    echo "Eklentiyle derleme basarisiz. Eklentisiz tekrar denenecek (ses WebView ile calisir)."
    npm uninstall --legacy-peer-deps @capacitor-community/text-to-speech || true
    npx cap sync android
    (cd android && ./gradlew clean --no-daemon) || true
    build_apk || { echo "::error::Gradle derlemesi basarisiz."; exit 1; }
  else
    echo "::error::Gradle derlemesi 3 denemede de basarisiz oldu."
    exit 1
  fi
fi

mkdir -p "$ROOT/out"
cp android/app/build/outputs/apk/debug/app-debug.apk "$ROOT/out/deutsch-meister-$RUN.apk"
ls -la "$ROOT/out"
echo "APK hazir."
