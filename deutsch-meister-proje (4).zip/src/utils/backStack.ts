import { useEffect, useRef } from 'react';

// Overlays (modals, quizzes) register a handler while open so the Android back button can close them first.
const stack: Array<() => void> = [];

export function handleBackPress(): boolean {
  const fn = stack[stack.length - 1];
  if (fn) {
    fn();
    return true;
  }
  return false;
}

export function useBackHandler(active: boolean, handler: () => void) {
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!active) return;
    const fn = () => ref.current();
    stack.push(fn);
    return () => {
      const i = stack.indexOf(fn);
      if (i >= 0) stack.splice(i, 1);
    };
  }, [active]);
}
