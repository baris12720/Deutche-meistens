// Web Audio API Synthesizer and Web Speech API Integration
import { Capacitor, registerPlugin } from '@capacitor/core';

// Native Android text-to-speech (plugin @capacitor-community/text-to-speech is added at APK build time).
interface NativeTtsPlugin {
  speak(options: { text: string; lang?: string; rate?: number; pitch?: number; volume?: number; category?: string; queueStrategy?: number }): Promise<void>;
  stop(): Promise<void>;
}
const NativeTTS = registerPlugin<NativeTtsPlugin>('TextToSpeech');
const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

// Short vibration feedback (works in the Android app; ignored where unsupported).
function buzz(enabled: boolean, pattern: number | number[]) {
  try {
    if (enabled && typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(pattern);
  } catch {
    /* ignore */
  }
}

function notifySpeechFailure() {
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('tts-failed'));
}

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playSuccessSound(enabled = true) {
  buzz(enabled, [15]);
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Pleasant Duolingo-like two-tone success chord (C5 -> G5)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(523.25, now); // C5
    osc1.frequency.exponentialRampToValueAtTime(783.99, now + 0.12); // G5

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(659.25, now); // E5
    osc2.frequency.exponentialRampToValueAtTime(1046.50, now + 0.12); // C6

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.4);
    osc2.stop(now + 0.4);
  } catch (err) {
    console.warn('Audio playback error:', err);
  }
}

export function playWrongSound(enabled = true) {
  buzz(enabled, [40, 60, 40]);
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Gentle soft dual-tone bump (not harsh, encourages retrying)
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(180, now + 0.18);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.3);
  } catch (err) {
    console.warn('Audio playback error:', err);
  }
}

export function playLevelUpSound(enabled = true) {
  buzz(enabled, [30, 40, 30, 40, 80]);
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const notes = [440, 554.37, 659.25, 880]; // A major fanfare
    notes.forEach((freq, index) => {
      const now = ctx.currentTime + index * 0.1;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.3);
    });
  } catch (err) {
    console.warn('Audio error:', err);
  }
}

export function playClickSound(enabled = true) {
  if (!enabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.04);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  } catch (err) {
    console.warn('Click audio error:', err);
  }
}

// Web Speech API - Text to Speech for German
let germanVoice: SpeechSynthesisVoice | null = null;
let voiceLoaded = false;

function loadVoices() {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  const voices = window.speechSynthesis.getVoices();
  germanVoice = voices.find((v) => v.lang.startsWith('de') || v.lang.includes('DE')) || null;
  voiceLoaded = true;
}

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  loadVoices();
  window.speechSynthesis.onvoiceschanged = loadVoices;
}

function speakWeb(text: string, rate: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      resolve(false);
      return;
    }
    try {
      window.speechSynthesis.cancel(); // Stop prior audio
      if (!voiceLoaded) loadVoices();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      utterance.rate = rate;
      utterance.pitch = 1.0;
      if (germanVoice) utterance.voice = germanVoice;
      utterance.onend = () => resolve(true);
      utterance.onerror = () => resolve(false);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('SpeechSynthesis error:', e);
      resolve(false);
    }
  });
}

export async function speakGerman(text: string, rate = 0.95): Promise<boolean> {
  const cleanText = text.replace(/[\/()]/g, ' ').trim();
  if (!cleanText) return false;

  if (isNativeApp()) {
    try {
      await NativeTTS.stop().catch(() => undefined);
      await NativeTTS.speak({ text: cleanText, lang: 'de-DE', rate, pitch: 1.0, volume: 1.0, category: 'playback', queueStrategy: 0 });
      return true;
    } catch (e) {
      console.warn('Native TTS error:', e);
      const ok = await speakWeb(cleanText, rate);
      if (!ok) notifySpeechFailure();
      return ok;
    }
  }

  const ok = await speakWeb(cleanText, rate);
  if (!ok) notifySpeechFailure();
  return ok;
}

// Levenshtein distance similarity calculation for speech scoring
export function calculateTextSimilarity(a: string, b: string): number {
  const normA = a.toLowerCase().replace(/[^a-zäöüß0-9]/gi, '').trim();
  const normB = b.toLowerCase().replace(/[^a-zäöüß0-9]/gi, '').trim();

  if (normA === normB) return 100;
  if (!normA.length || !normB.length) return 0;

  const matrix: number[][] = [];
  for (let i = 0; i <= normB.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= normA.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= normB.length; i++) {
    for (let j = 1; j <= normA.length; j++) {
      if (normB.charAt(i - 1) === normA.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }

  const distance = matrix[normB.length][normA.length];
  const maxLen = Math.max(normA.length, normB.length);
  const similarity = Math.max(0, Math.round(((maxLen - distance) / maxLen) * 100));
  return similarity;
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
}

export interface SpeechRecognitionResultObject {
  transcript: string;
  isMatch: boolean;
  score: number;
}

export function startSpeechRecognition(
  targetPhraseDe: string,
  onResult: (res: SpeechRecognitionResultObject) => void,
  onError: (err: string) => void
): { stop: () => void } {
  if (!isSpeechRecognitionSupported()) {
    onError('Tarayıcınız ses tanımayı desteklemiyor. Chrome veya Edge kullanabilirsiniz.');
    return { stop: () => {} };
  }

  try {
    const SpeechRecognitionClass = (window as unknown as {
      SpeechRecognition?: any;
      webkitSpeechRecognition?: any;
    }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: any }).webkitSpeechRecognition;

    const recognizer = new SpeechRecognitionClass();
    recognizer.lang = 'de-DE';
    recognizer.continuous = false;
    recognizer.interimResults = false;
    recognizer.maxAlternatives = 1;

    recognizer.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      const score = calculateTextSimilarity(transcript, targetPhraseDe);
      const isMatch = score >= 70;
      onResult({ transcript, isMatch, score });
    };

    recognizer.onerror = (event: any) => {
      onError(`Ses tanıma hatası: ${event.error || 'Ses algılanamadı'}`);
    };

    recognizer.start();

    return {
      stop: () => {
        try {
          recognizer.stop();
        } catch {
          // ignore
        }
      },
    };
  } catch (err) {
    onError('Mikrofona erişilemedi.');
    return { stop: () => {} };
  }
}
