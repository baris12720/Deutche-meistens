export type CEFRLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export type ArticleType = 'der' | 'die' | 'das' | 'none';

export interface VocabularyWord {
  id: string;
  german: string;
  turkish: string;
  article: ArticleType;
  plural?: string;
  level: CEFRLevel;
  category: string;
  exampleGerman: string;
  exampleTurkish: string;
}

export type ExerciseType =
  | 'multiple_choice'
  | 'reverse_multiple_choice'
  | 'article_select'
  | 'sentence_builder'
  | 'fill_blank'
  | 'true_false'
  | 'listening'
  | 'verb_conjugation'
  | 'speech_practice'
  | 'typing';

export interface BaseExercise {
  id: string;
  type: ExerciseType;
  instructionTr: string;
  explanationTr?: string;
  topicTag?: string;
  level?: CEFRLevel;
}

export interface MultipleChoiceExercise extends BaseExercise {
  type: 'multiple_choice' | 'reverse_multiple_choice';
  prompt: string;
  audioPrompt?: string;
  options: string[];
  correctAnswer: string;
}

export interface ArticleSelectExercise extends BaseExercise {
  type: 'article_select';
  word: string;
  turkish: string;
  correctArticle: 'der' | 'die' | 'das';
  plural?: string;
}

export interface SentenceBuilderExercise extends BaseExercise {
  type: 'sentence_builder';
  turkishPrompt: string;
  correctGermanSentence: string;
  scrambledWords: string[];
}

export interface FillBlankExercise extends BaseExercise {
  type: 'fill_blank';
  sentenceWithBlank: string; // e.g. "Ich ___ aus der Türkei."
  turkishTranslation: string;
  options: string[];
  correctAnswer: string;
}

export interface TrueFalseExercise extends BaseExercise {
  type: 'true_false';
  statementDe: string;
  statementTr: string;
  isCorrect: boolean;
}

export interface ListeningExercise extends BaseExercise {
  type: 'listening';
  germanAudioText: string;
  turkishMeaning: string;
  options: string[];
  correctAnswer: string;
}

export interface VerbConjugationExercise extends BaseExercise {
  type: 'verb_conjugation';
  verbInfinitive: string;
  pronoun: string; // e.g. "du", "er", "wir"
  turkishTranslation: string;
  options: string[];
  correctAnswer: string;
}

export interface SpeechPracticeExercise extends BaseExercise {
  type: 'speech_practice';
  targetSentenceDe: string;
  translationTr: string;
  tipTr?: string;
}

export interface TypingExercise extends BaseExercise {
  type: 'typing';
  mode: 'word' | 'sentence';
  promptTr: string; // what to write (Turkish meaning); may be empty for dictation
  hintTr?: string;
  audioText?: string; // German text to play (dictation)
  answer: string;
  accept?: string[]; // other accepted answers (word mode)
}

export type Exercise =
  | MultipleChoiceExercise
  | ArticleSelectExercise
  | SentenceBuilderExercise
  | FillBlankExercise
  | TrueFalseExercise
  | ListeningExercise
  | VerbConjugationExercise
  | SpeechPracticeExercise
  | TypingExercise;

export interface LessonSentence {
  german: string;
  turkish: string;
}

export interface LessonDialogue {
  speaker: string;
  german: string;
  turkish: string;
}

export interface Lesson {
  id: string;
  titleTr: string;
  titleDe: string;
  unitId: string;
  level: CEFRLevel;
  descriptionTr: string;
  grammarTipTr?: string;
  vocabulary: VocabularyWord[];
  exampleSentences: LessonSentence[];
  dialogue?: LessonDialogue[];
  exercises: Exercise[];
}

export interface Unit {
  id: string;
  level: CEFRLevel;
  unitNumber: number;
  titleTr: string;
  titleDe: string;
  descriptionTr: string;
  iconName: string;
  color: string;
  lessons: Lesson[];
}

export interface GrammarTopic {
  id: string;
  titleTr: string;
  titleDe: string;
  level: CEFRLevel;
  summaryTr: string;
  contentMarkdownTr: string;
  tables?: {
    caption: string;
    headers: string[];
    rows: string[][];
  }[];
  examples: {
    german: string;
    turkish: string;
    note?: string;
  }[];
  exercises: Exercise[];
}

export interface RealLifeDialogue {
  id: string;
  titleTr: string;
  titleDe: string;
  category: string;
  level: CEFRLevel;
  contextTr: string;
  lines: {
    id: string;
    speaker: string;
    german: string;
    turkish: string;
    note?: string;
  }[];
  vocabulary: {
    german: string;
    turkish: string;
  }[];
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
}

export interface UserWordCard {
  wordId: string;
  status: 'learning' | 'mastered';
  reviewsCount: number;
  lastReviewedAt: number;
  intervalDays: number;
}

export interface UserProfile {
  name: string;
  xp: number;
  streak: number;
  lastActiveDate: string;
  dailyGoalXp: number;
  todayXp: number;
  completedLessons: string[];
  unlockedBadges: string[];
  wordCards: Record<string, UserWordCard>;
  soundEnabled: boolean;
  speechSpeed: number; // 0.8 to 1.0
  activeDates: string[]; // YYYY-MM-DD
  completedWordSets?: string[]; // vocabulary quest sets finished
  passedLevelExams?: CEFRLevel[]; // level exams passed with >= 70%
  placementLevel?: CEFRLevel; // set by placement exam; levels below it are open
}

export interface DTZQuestion {
  id: string;
  section: 'hoeren' | 'lesen' | 'schreiben' | 'sprechen';
  level: CEFRLevel;
  topicTag: string;
  titleTr: string;
  contextDe?: string;
  contextTr?: string;
  audioPromptDe?: string;
  transcriptDe?: string;
  questionDe: string;
  questionTr: string;
  options?: string[];
  correctAnswer?: string;
  explanationTr: string;
  writingPointsTr?: string[];
  sampleSolutionDe?: string;
  criteriaTr?: string[];
  speakingGoalDe?: string;
  suggestedPhrasesDe?: string[];
}

export interface QuestionReviewItem {
  exercise: Exercise;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  topicTag?: string;
}

export interface TestSessionResult {
  total: number;
  correct: number;
  wrong: number;
  percentage: number;
  items: QuestionReviewItem[];
  topicBreakdown: Record<string, { total: number; correct: number }>;
}

