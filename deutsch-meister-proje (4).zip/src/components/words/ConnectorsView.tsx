import React, { useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Lock, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { speakGerman } from '../../utils/audio';
import { useBackHandler } from '../../utils/backStack';
import { LEVEL_ORDER } from '../../utils/progress';
import { CONNECTOR_GROUPS, ConnectorGroup, ConnectorItem, buildConnectorExercises } from '../../data/connectors';
import { Exercise } from '../../types';

const highlight = (it: ConnectorItem) => {
  const [before, after] = it.template.split(/\{[^}]+\}/);
  return (
    <>
      {before}
      <mark className="px-1 rounded bg-yellow-200 dark:bg-yellow-500/30 text-slate-900 dark:text-yellow-100 font-black">{it.form}</mark>
      {after}
    </>
  );
};

export const ConnectorsView: React.FC = () => {
  const { profile, addXp, markWordSetDone } = useApp();
  const [active, setActive] = useState<ConnectorGroup | null>(null);
  const [phase, setPhase] = useState<'learn' | 'quiz'>('learn');
  const [step, setStep] = useState(0); // 0 = rule card, 1..n = items
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const done = profile.completedWordSets || [];
  const doneId = (g: ConnectorGroup) => `conn_${g.id}`;

  const awardedRef = useRef<string | null>(null);
  const close = () => setActive(null);

  const notify = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 7000);
  };

  const handleFinish = (correct: number, total: number) => {
    if (!active || awardedRef.current === active.id) return;
    const ratio = correct / Math.max(1, total);
    if (ratio >= 0.5) {
      awardedRef.current = active.id;
      addXp(12 + correct * 3);
      markWordSetDone(doneId(active));
      try {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.65 } });
      } catch {
        /* ignore */
      }
      notify(`Konu tamam: ${correct}/${total}. +${12 + correct * 3} XP. Sıradaki konu açıldı.`);
    }
  };
  useBackHandler(active !== null, close);

  const open = (g: ConnectorGroup, index: number) => {
    const levelOk = LEVEL_ORDER.indexOf(g.level) >= 0;
    const prevDone = index === 0 || done.includes(doneId(CONNECTOR_GROUPS[index - 1])) || done.includes(doneId(g));
    if (!levelOk || !prevDone) {
      notify('Önce bir önceki bağlaç konusunu tamamla.');
      return;
    }
    awardedRef.current = null;
    setActive(g);
    setPhase('learn');
    setStep(0);
    setExercises(buildConnectorExercises(g));
  };

  if (active && phase === 'quiz') {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
        <ExerciseRunner
          exercises={exercises}
          allowLengthSelect={false}
          passRatio={0.5}
          completeLabel="Konuyu Tamamla"
          title={`Bağlaçlar: ${active.titleTr}`}
          onExit={close}
          onFinish={handleFinish}
          onComplete={(correct, total) => {
            if (awardedRef.current !== active.id) {
              notify(`${correct}/${total}: konuyu geçmek için %50 gerekli. Yanlışları tekrar çözüp yeniden dene.`);
            }
            close();
          }}
        />
      </div>
    );
  }

  if (active && phase === 'learn') {
    const total = active.items.length + 1;
    const item = step > 0 ? active.items[step - 1] : null;
    const last = step === total - 1;
    return (
      <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
        <div className="flex items-center gap-3 px-4 h-14 shrink-0">
          <button onClick={close} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-violet-500 rounded-full transition-all" style={{ width: `${((step + 1) / total) * 100}%` }} />
          </div>
          <span className="text-xs font-black text-slate-500 tabular-nums">
            {step + 1}/{total}
          </span>
        </div>

        <div key={step} className="page-enter flex-1 overflow-y-auto px-4 pb-4">
          <div className="max-w-md mx-auto mt-4 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6">
            {!item ? (
              <div className="space-y-4">
                <div className="text-4xl text-center">{active.emoji}</div>
                <h3 className="text-xl font-black text-center text-slate-900 dark:text-white">{active.titleTr}</h3>
                <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">{active.ruleTr}</p>
                <div className="rounded-2xl bg-violet-50 dark:bg-violet-950/40 border-2 border-violet-200 dark:border-violet-900 p-3 text-center">
                  <div className="text-[11px] font-black uppercase tracking-wide text-violet-600 dark:text-violet-300">Kalıp</div>
                  <div className="mt-1 text-sm font-black text-violet-900 dark:text-violet-100">{active.formulaDe}</div>
                </div>
                <p className="text-xs font-bold text-amber-700 dark:text-amber-300">💡 {active.tipTr}</p>
              </div>
            ) : (
              <div className="text-center">
                <div className="text-4xl font-black text-slate-900 dark:text-white">{item.word}</div>
                <div className="mt-1 text-lg text-slate-600 dark:text-slate-300">{item.meaningTr}</div>
                <button
                  onClick={() => speakGerman(item.template.replace(/[{}]/g, ''), profile.speechSpeed)}
                  className="mt-4 w-12 h-12 rounded-2xl bg-sky-500 text-white shadow-[0_4px_0_#0369a1] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center cursor-pointer"
                  aria-label="Örnek cümleyi dinle"
                >
                  <Volume2 className="w-6 h-6" />
                </button>
                <div className="mt-5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 p-4 text-left">
                  <div className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">{highlight(item)}</div>
                  <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">{item.exampleTr}</div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 pb-[max(1rem,env(safe-area-inset-bottom))] shrink-0 flex gap-3 max-w-md w-full mx-auto">
          <button
            disabled={step === 0}
            onClick={() => setStep((i) => i - 1)}
            className="h-14 w-14 rounded-2xl border-2 border-slate-200 dark:border-slate-700 text-slate-500 disabled:opacity-40 inline-flex items-center justify-center cursor-pointer"
            aria-label="Önceki"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => (last ? setPhase('quiz') : setStep((i) => i + 1))}
            className="flex-1 h-14 rounded-2xl bg-violet-500 text-white font-black text-base shadow-[0_5px_0_#6d28d9] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            {last ? 'ALIŞTIRMAYA BAŞLA' : 'DEVAM'} <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      <h2 className="text-xl font-black text-slate-900 dark:text-white">Bağlaçlar</h2>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        deshalb, deswegen, dass, obwohl... Cümleleri birbirine bağlayan kelimeleri ve kelime sırası kurallarını öğren.
      </p>
      <div className="mt-5 space-y-3">
        {CONNECTOR_GROUPS.map((g, i) => {
          const isDone = done.includes(doneId(g));
          const available = i === 0 || done.includes(doneId(CONNECTOR_GROUPS[i - 1])) || isDone;
          return (
            <button
              key={g.id}
              onClick={() => open(g, i)}
              className={`w-full text-left rounded-2xl border-2 p-4 flex items-center gap-4 transition active:translate-y-0.5 cursor-pointer ${
                isDone
                  ? 'border-amber-300 dark:border-amber-800 bg-amber-50/60 dark:bg-amber-950/20'
                  : available
                  ? 'border-violet-400 bg-white dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 opacity-70'
              }`}
            >
              <div
                className={`w-14 h-14 rounded-full shrink-0 inline-flex items-center justify-center text-white text-2xl ${
                  isDone
                    ? 'bg-amber-400 shadow-[0_5px_0_#d97706]'
                    : available
                    ? 'bg-violet-500 shadow-[0_5px_0_#6d28d9]'
                    : 'bg-slate-300 dark:bg-slate-700 shadow-[0_5px_0_#94a3b8] dark:shadow-[0_5px_0_#334155]'
                }`}
              >
                {isDone ? <Check className="w-7 h-7 stroke-4" /> : available ? g.emoji : <Lock className="w-6 h-6" />}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-[10px] font-black text-slate-600 dark:text-slate-300">{g.level}</span>
                  <span className="text-xs font-bold text-slate-400">{g.items.length} bağlaç</span>
                </div>
                <div className="mt-0.5 text-base font-black text-slate-900 dark:text-white">{g.titleTr}</div>
              </div>
            </button>
          );
        })}
      </div>
      {toast && (
        <div role="status" className="fixed left-1/2 -translate-x-1/2 bottom-28 z-40 max-w-[90vw] px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
};
