import React, { useEffect, useMemo } from 'react';
import { Flame, Volume2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { QUEST_WORDS } from '../../data/vocab/words';
import { speakGerman } from '../../utils/audio';

const WEEKDAYS = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pz'];
const RANKS = ['Anfänger', 'Entdecker', 'Lerner', 'Kenner', 'Könner', 'Profi', 'Meister', 'Legende'];
const XP_PER_LEVEL = 150;
const CHESTS = [20, 50, 100];

const dayKey = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export const DailyDashboard: React.FC = () => {
  const { profile, currentLevel } = useApp();
  const goal = Math.max(1, profile.dailyGoalXp || 30);
  const pct = Math.min(1, (profile.todayXp || 0) / goal);
  const R = 30;
  const C = 2 * Math.PI * R;
  const totalXp = profile.xp || 0;
  const playerLevel = Math.floor(totalXp / XP_PER_LEVEL) + 1;
  const levelPct = ((totalXp % XP_PER_LEVEL) / XP_PER_LEVEL) * 100;
  const rank = RANKS[Math.min(RANKS.length - 1, Math.floor((playerLevel - 1) / 3))];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar';

  const week = useMemo(() => {
    const now = new Date();
    const dow = (now.getDay() + 6) % 7; // Monday = 0
    return WEEKDAYS.map((label, i) => {
      const d = new Date(now);
      d.setDate(now.getDate() - dow + i);
      return { label, key: dayKey(d), isToday: i === dow, isFuture: i > dow };
    });
  }, []);
  const activeSet = new Set(profile.activeDates || []);

  const word = useMemo(() => {
    const pool = QUEST_WORDS.filter((w) => w.level === currentLevel);
    if (!pool.length) return null;
    const n = new Date();
    const seed = n.getFullYear() * 372 + n.getMonth() * 31 + n.getDate();
    return pool[seed % pool.length];
  }, [currentLevel]);

  useEffect(() => {
    if ((profile.todayXp || 0) >= goal) {
      const key = `dm_goal_${dayKey(new Date())}`;
      try {
        if (!localStorage.getItem(key)) {
          localStorage.setItem(key, '1');
          confetti({ particleCount: 140, spread: 80, origin: { y: 0.6 } });
        }
      } catch {
        /* storage not available */
      }
    }
  }, [profile.todayXp, goal]);

  return (
    <section className="mb-4 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4" aria-label="Günlük özet">
      <div className="flex items-center gap-4">
        <div className="relative w-[72px] h-[72px] shrink-0">
          <svg viewBox="0 0 72 72" className="w-full h-full -rotate-90" aria-hidden="true">
            <circle cx="36" cy="36" r={R} fill="none" strokeWidth="8" className="stroke-slate-200 dark:stroke-slate-700" />
            <circle
              cx="36"
              cy="36"
              r={R}
              fill="none"
              strokeWidth="8"
              strokeLinecap="round"
              className="stroke-emerald-500 transition-all duration-700"
              strokeDasharray={C}
              strokeDashoffset={C * (1 - pct)}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
            <span className="text-base font-black text-slate-900 dark:text-white tabular-nums">{Math.min(profile.todayXp || 0, goal)}</span>
            <span className="text-[10px] font-bold text-slate-400">/ {goal} XP</span>
          </div>
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-bold text-slate-500 dark:text-slate-400">{greeting}</div>
          <div className="text-base font-black text-slate-900 dark:text-white truncate">{profile.name}</div>
          <div className="mt-1 inline-flex items-center gap-1 text-sm font-black text-orange-500">
            <Flame className="w-4 h-4 fill-orange-500" /> {profile.streak} günlük seri
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {pct >= 1 ? 'Günlük hedef tamam. Harikasın!' : `Hedefe ${Math.max(0, goal - (profile.todayXp || 0))} XP kaldı`}
          </div>
        </div>
      </div>

      <div className="mt-3">
        <div className="flex items-center justify-between text-xs font-black">
          <span className="text-violet-600 dark:text-violet-400">
            Seviye {playerLevel} · {rank}
          </span>
          <span className="text-slate-400 tabular-nums">
            {totalXp % XP_PER_LEVEL}/{XP_PER_LEVEL} XP
          </span>
        </div>
        <div className="mt-1 h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
          <div className="h-full rounded-full bg-linear-to-r from-violet-500 to-fuchsia-500 transition-all duration-700" style={{ width: `${levelPct}%` }} />
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2" aria-label="Günlük sandıklar">
        {CHESTS.map((need) => {
          const open = (profile.todayXp || 0) >= need;
          return (
            <div
              key={need}
              className={`rounded-2xl border-2 py-2 text-center ${
                open
                  ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/30'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/40'
              }`}
            >
              <div className={`text-2xl ${open ? '' : 'grayscale opacity-60'}`}>{open ? '🎁' : '📦'}</div>
              <div className="text-[11px] font-black text-slate-600 dark:text-slate-300">{need} XP</div>
            </div>
          );
        })}
      </div>

      <div className="mt-3 grid grid-cols-7 gap-1.5" aria-label="Bu haftanın aktif günleri">
        {week.map((d) => {
          const done = activeSet.has(d.key) && !d.isFuture;
          return (
            <div key={d.key} className="flex flex-col items-center gap-1">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-black ${
                  done
                    ? 'bg-emerald-500 text-white'
                    : d.isToday
                    ? 'border-2 border-emerald-500 text-emerald-600 dark:text-emerald-400'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-400'
                }`}
              >
                {done ? '✓' : ''}
              </div>
              <span className={`text-[10px] font-bold ${d.isToday ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`}>{d.label}</span>
            </div>
          );
        })}
      </div>

      {word && (
        <div className="mt-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900/60 p-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[11px] font-black uppercase tracking-wide text-amber-700 dark:text-amber-400">Günün kelimesi ({currentLevel})</div>
              <div className="mt-0.5 text-lg font-black text-slate-900 dark:text-white">
                {word.article !== 'none' ? `${word.article} ` : ''}
                {word.german}
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-300">{word.turkish}</div>
              <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                {word.exampleGerman} <span className="opacity-70">({word.exampleTurkish})</span>
              </div>
            </div>
            <button
              onClick={() => speakGerman(`${word.article !== 'none' ? word.article + ' ' : ''}${word.german}. ${word.exampleGerman}`, profile.speechSpeed)}
              className="w-11 h-11 shrink-0 rounded-2xl bg-amber-500 text-white shadow-[0_4px_0_#b45309] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center cursor-pointer"
              aria-label="Kelimeyi ve cümleyi dinle"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
