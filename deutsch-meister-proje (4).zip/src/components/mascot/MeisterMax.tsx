import React from 'react';

interface MeisterMaxProps {
  mood?: 'happy' | 'encouraging' | 'thinking' | 'celebrating';
  speechBubble?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const MeisterMax: React.FC<MeisterMaxProps> = ({
  mood = 'happy',
  speechBubble,
  size = 'md',
  className = '',
}) => {
  const sizeMap = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24 sm:w-28 sm:h-28',
    lg: 'w-36 h-36 sm:w-44 sm:h-44',
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Mascot Vector */}
      <div className={`relative shrink-0 ${sizeMap[size]}`}>
        <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-md select-none">
          <defs>
            <linearGradient id="bodyG" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#4ade80" />
              <stop offset="100%" stop-color="#16a34a" />
            </linearGradient>
            <linearGradient id="bellyG" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stop-color="#f0fdf4" />
              <stop offset="100%" stop-color="#dcfce7" />
            </linearGradient>
            <linearGradient id="goldBeak" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#fbbf24" />
              <stop offset="100%" stop-color="#f59e0b" />
            </linearGradient>
          </defs>

          {/* Feet */}
          <ellipse cx="78" cy="180" rx="14" ry="7" fill="#f59e0b" />
          <ellipse cx="122" cy="180" rx="14" ry="7" fill="#f59e0b" />

          {/* Wings */}
          {mood === 'celebrating' ? (
            <>
              {/* Wings up high celebrating */}
              <path d="M 45 100 C 25 70 30 40 55 60 C 50 85 50 115 55 130 Z" fill="#22c55e" />
              <path d="M 155 100 C 175 70 170 40 145 60 C 150 85 150 115 145 130 Z" fill="#22c55e" />
            </>
          ) : (
            <>
              {/* Resting wings */}
              <path d="M 42 110 C 30 130 35 155 60 155 C 50 140 46 125 48 110 Z" fill="#15803d" />
              <path d="M 158 110 C 170 130 165 155 140 155 C 150 140 154 125 152 110 Z" fill="#15803d" />
            </>
          )}

          {/* Body */}
          <ellipse cx="100" cy="120" rx="60" ry="62" fill="url(#bodyG)" />

          {/* Tummy */}
          <ellipse cx="100" cy="132" rx="40" ry="42" fill="url(#bellyG)" />

          {/* Cheeks */}
          <circle cx="64" cy="120" r="8" fill="#f87171" opacity="0.5" />
          <circle cx="136" cy="120" r="8" fill="#f87171" opacity="0.5" />

          {/* Eyes */}
          {mood === 'thinking' ? (
            <>
              {/* Thinking squint/look up */}
              <circle cx="80" cy="104" r="16" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
              <circle cx="82" cy="98" r="8" fill="#0f172a" />
              <circle cx="85" cy="96" r="3" fill="#ffffff" />

              <circle cx="120" cy="104" r="16" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
              <circle cx="122" cy="98" r="8" fill="#0f172a" />
              <circle cx="125" cy="96" r="3" fill="#ffffff" />
            </>
          ) : (
            <>
              {/* Big happy eyes */}
              <circle cx="80" cy="104" r="18" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
              <circle cx="82" cy="104" r="10" fill="#0284c7" />
              <circle cx="84" cy="103" r="6" fill="#0f172a" />
              <circle cx="86" cy="101" r="3" fill="#ffffff" />

              <circle cx="120" cy="104" r="18" fill="#ffffff" stroke="#cbd5e1" strokeWidth="1.5" />
              <circle cx="118" cy="104" r="10" fill="#0284c7" />
              <circle cx="116" cy="103" r="6" fill="#0f172a" />
              <circle cx="118" cy="101" r="3" fill="#ffffff" />
            </>
          )}

          {/* Beak */}
          <polygon points="90,114 110,114 100,132" fill="url(#goldBeak)" />

          {/* German Meister Graduation Hat */}
          <polygon points="100,32 165,54 100,74 35,54" fill="#1e293b" />
          {/* German flag strip on hat border */}
          <polygon points="100,32 165,54 158,57 100,36" fill="#fbbf24" />
          <polygon points="100,36 158,57 151,60 100,40" fill="#ef4444" />
          <path d="M 68,63 Q 100,78 132,63 L 132,74 Q 100,89 68,74 Z" fill="#0f172a" />
          {/* Golden Tassel */}
          <circle cx="100" cy="53" r="4.5" fill="#f59e0b" />
          <path d="M 100,53 C 125,56 142,66 147,82" stroke="#f59e0b" strokeWidth="2.5" fill="none" />
          <polygon points="144,82 150,82 152,94 142,94" fill="#f59e0b" />
        </svg>
      </div>

      {/* Optional Speech Bubble */}
      {speechBubble && (
        <div className="relative bg-white dark:bg-slate-800 border-2 border-emerald-500/30 rounded-2xl p-3 shadow-md max-w-sm">
          <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-3 h-3 bg-white dark:bg-slate-800 border-l-2 border-b-2 border-emerald-500/30 rotate-45" />
          <p className="text-xs sm:text-sm font-medium text-slate-800 dark:text-slate-100 leading-snug">
            {speechBubble}
          </p>
        </div>
      )}
    </div>
  );
};
