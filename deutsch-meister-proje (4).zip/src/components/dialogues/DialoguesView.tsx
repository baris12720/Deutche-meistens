import React, { useState } from 'react';
import { MessageSquare, Volume2, ChevronRight, Filter } from 'lucide-react';
import { REAL_LIFE_DIALOGUES } from '../../data/dialogues';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';

export const DialoguesView: React.FC = () => {
  const { openDialogue, currentLevel } = useApp();
  const [filterLevel, setFilterLevel] = useState<CEFRLevel | 'ALL'>(currentLevel);

  const filtered = REAL_LIFE_DIALOGUES.filter(
    (d) => filterLevel === 'ALL' || d.level === filterLevel
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-teal-600 to-emerald-700 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Günlük Almanca
          </span>
          <h2 className="text-2xl font-black mt-1">Gerçek Hayat Diyalogları</h2>
          <p className="text-xs sm:text-sm text-teal-100 mt-0.5">
            Restoran, doktor, alışveriş, iş görüşmesi ve tren garında geçen pratik konuşmalar.
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-2xl text-center shrink-0">
          <span className="text-xl font-black block">{REAL_LIFE_DIALOGUES.length} Diyalog</span>
          <span className="text-[10px] uppercase font-bold text-teal-200">Sesli Oynatıcı</span>
        </div>
      </div>

      {/* Level Filters */}
      <div className="bg-white dark:bg-slate-800 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        {(['ALL', 'A1', 'A2', 'B1', 'B2'] as const).map((lvl) => (
          <button
            key={lvl}
            onClick={() => setFilterLevel(lvl)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              filterLevel === lvl
                ? 'bg-teal-600 text-white'
                : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            {lvl === 'ALL' ? 'Tüm Diyaloglar' : lvl}
          </button>
        ))}
      </div>

      {/* Dialogues List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((dialogue) => (
          <div
            key={dialogue.id}
            onClick={() => openDialogue(dialogue.id)}
            className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-400 dark:hover:border-teal-600 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                  {dialogue.level} • {dialogue.category}
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {dialogue.lines.length} Replik
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                {dialogue.titleTr}
              </h3>
              <p className="text-xs text-slate-400 font-medium mt-0.5">{dialogue.titleDe}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2">
                {dialogue.contextTr}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-bold text-teal-600 dark:text-teal-400">
              <span className="flex items-center gap-1.5">
                <Volume2 className="w-4 h-4" /> Diyaloğu Dinle & Oyna
              </span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
