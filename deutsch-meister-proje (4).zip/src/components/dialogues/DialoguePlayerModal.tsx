import React, { useState } from 'react';
import { X, Volume2, Play, Pause, Eye, EyeOff, Sparkles } from 'lucide-react';
import { RealLifeDialogue } from '../../types';
import { useApp } from '../../context/AppContext';
import { speakGerman } from '../../utils/audio';

interface DialoguePlayerModalProps {
  dialogue: RealLifeDialogue;
  onClose: () => void;
}

export const DialoguePlayerModal: React.FC<DialoguePlayerModalProps> = ({
  dialogue,
  onClose,
}) => {
  const { profile, addXp } = useApp();
  const [showTranslations, setShowTranslations] = useState(true);
  const [activeLineId, setActiveLineId] = useState<string | null>(null);
  const [isPlayingAll, setIsPlayingAll] = useState(false);

  const handlePlayLine = async (lineId: string, germanText: string) => {
    setActiveLineId(lineId);
    await speakGerman(germanText, profile.speechSpeed);
    setActiveLineId(null);
  };

  const handlePlayAll = async () => {
    if (isPlayingAll) {
      setIsPlayingAll(false);
      window.speechSynthesis?.cancel();
      setActiveLineId(null);
      return;
    }

    setIsPlayingAll(true);
    for (const line of dialogue.lines) {
      setActiveLineId(line.id);
      await speakGerman(line.german, profile.speechSpeed);
      // Brief pause between speakers
      await new Promise((r) => setTimeout(r, 600));
    }
    setActiveLineId(null);
    setIsPlayingAll(false);
    addXp(15);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4">
      <div className="w-full max-w-2xl h-[92vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white dark:bg-slate-900">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-extrabold text-[10px]">
                {dialogue.level}
              </span>
              <span className="text-xs font-semibold text-slate-400">
                {dialogue.category}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white mt-0.5">
              {dialogue.titleTr}
            </h3>
            <p className="text-xs text-slate-500">{dialogue.titleDe}</p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar */}
        <div className="px-5 py-2.5 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={handlePlayAll}
            className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer ${
              isPlayingAll
                ? 'bg-rose-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
            }`}
          >
            {isPlayingAll ? (
              <>
                <Pause className="w-3.5 h-3.5" /> Durdur
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-white" /> Tüm Diyaloğu Oynat
              </>
            )}
          </button>

          <button
            onClick={() => setShowTranslations(!showTranslations)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition flex items-center gap-1.5 cursor-pointer"
          >
            {showTranslations ? (
              <>
                <EyeOff className="w-3.5 h-3.5" /> Çevirileri Gizle
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" /> Çevirileri Göster
              </>
            )}
          </button>
        </div>

        {/* Dialogue Lines Chat Area */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
          <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 font-medium">
            💡 <strong>Senaryo:</strong> {dialogue.contextTr}
          </div>

          <div className="space-y-3">
            {dialogue.lines.map((line) => {
              const isActive = activeLineId === line.id;
              return (
                <div
                  key={line.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isActive
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-400 shadow-sm'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <span className="text-[10px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-md inline-block mb-1">
                        {line.speaker}
                      </span>
                      <p className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                        {line.german}
                      </p>
                      {showTranslations && (
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                          {line.turkish}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => handlePlayLine(line.id, line.german)}
                      className="p-2 rounded-xl text-emerald-600 bg-emerald-50 hover:bg-emerald-100 dark:bg-slate-700 dark:text-emerald-400 transition cursor-pointer shrink-0"
                      title="Seslendir"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Key Vocabulary Table */}
          {dialogue.vocabulary.length > 0 && (
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                Diyalogdaki Anahtar Kelimeler
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {dialogue.vocabulary.map((v, i) => (
                  <div
                    key={i}
                    onClick={() => speakGerman(v.german, profile.speechSpeed)}
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs flex items-center justify-between cursor-pointer hover:border-emerald-300"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {v.german}
                      </span>
                      <span className="text-slate-400 text-[11px]">{v.turkish}</span>
                    </div>
                    <Volume2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
