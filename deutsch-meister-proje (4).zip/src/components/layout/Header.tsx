import React from 'react';
import { Flame, Zap, Heart, Volume2, VolumeX, ChevronDown } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { CEFRLevel } from '../../types';

export const Header: React.FC = () => {
  const { profile, currentLevel, setCurrentLevel, toggleSound, setActiveTab } = useApp();

  const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand */}
        <div
          onClick={() => setActiveTab('learn')}
          className="flex items-center gap-2.5 cursor-pointer select-none shrink-0"
        >
          <img src={`${import.meta.env.BASE_URL}icon.svg`} alt="Deutsch Meister Logo" className="w-9 h-9 rounded-xl shadow-xs" />
          <div className="hidden sm:block">
            <span className="text-base font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
              Deutsch Meister <span className="text-sm">🇩🇪</span>
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block -mt-1">
              %100 Ücretsiz Almanca
            </span>
          </div>
        </div>

        {/* Center / Level Dropdown Selector */}
        <div className="relative group">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer text-xs font-black text-slate-800 dark:text-slate-100">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Seviye: {currentLevel}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </div>

          {/* Dropdown Menu */}
          <div className="absolute left-0 sm:left-auto sm:right-0 mt-1 w-48 bg-white dark:bg-slate-800 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 p-1.5 hidden group-hover:block animate-in fade-in zoom-in-95 duration-100 z-50">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 py-1 block">
              Seviyeni Seç:
            </span>
            {levels.map((lvl) => (
              <button
                key={lvl}
                onClick={() => setCurrentLevel(lvl)}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-between cursor-pointer ${
                  currentLevel === lvl
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                <span>{lvl} Seviyesi</span>
                {currentLevel === lvl && <span className="text-emerald-600">✓</span>}
              </button>
            ))}
          </div>
        </div>

        {/* Top Gamification Badges */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Unlimited Lives ∞ (Infinite practice, zero penalty!) */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 font-black text-xs cursor-help"
            title="Deutsch Meister'da can sınırı yok! İstediğin kadar hata yapabilir, dilediğince pratik yapabilirsin."
          >
            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
            <span className="text-sm font-extrabold leading-none">∞</span>
          </div>

          {/* Daily Streak Flame */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300 font-extrabold text-xs"
            title={`${profile.streak} günlük kesintisiz çalışma serisi!`}
          >
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>{profile.streak}</span>
          </div>

          {/* Total XP */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-yellow-50 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-900 text-yellow-800 dark:text-yellow-300 font-extrabold text-xs"
            title="Toplam Deneyim Puanı (XP)"
          >
            <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
            <span>{profile.xp}</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title={profile.soundEnabled ? 'Sesi Kapat' : 'Sesi Aç'}
          >
            {profile.soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
};
