import React from 'react';
import {
  BookOpen,
  Layers,
  GraduationCap,
  MessageSquare,
  Dumbbell,
  User,
  Heart,
  ShieldCheck,
  Award,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, profile } = useApp();

  const navItems = [
    { id: 'learn', label: 'Öğrenim Haritası', icon: BookOpen },
    { id: 'dtz', label: 'Goethe & DTZ 🇩🇪', icon: Award },
    { id: 'words', label: 'Kelime Oyunu 🎮', icon: Layers },
    { id: 'flashcards', label: 'Kelime Kartları', icon: Layers },
    { id: 'grammar', label: 'Dil Bilgisi', icon: GraduationCap },
    { id: 'dialogues', label: 'Günlük Diyaloglar', icon: MessageSquare },
    { id: 'practice', label: 'Alıştırma & Test', icon: Dumbbell },
    { id: 'profile', label: 'Profilim & Başarılar', icon: User },
  ] as const;

  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shrink-0 min-h-[calc(100vh-4rem)] justify-between">
      {/* Navigation items */}
      <div className="space-y-1.5">
        <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-3 py-1 block">
          Ana Menü
        </span>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-2xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                isActive
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-2 border-emerald-500/40 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white border-2 border-transparent'
              }`}
            >
              <Icon
                className={`w-5 h-5 ${
                  isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'
                }`}
              />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Free & Zero Paywall Promise Banner */}
      <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
        <div className="flex items-center gap-2 text-xs font-black text-emerald-700 dark:text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>Sonsuz Ücretsizlik</span>
        </div>
        <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
          Deutsch Meister'da premium abonelik, can limiti veya ödeme duvarı asla bulunmaz.
        </p>
        <div className="flex items-center gap-1.5 text-[11px] font-bold text-rose-500">
          <Heart className="w-3.5 h-3.5 fill-rose-500" />
          <span>Sınırsız Can & Alıştırma</span>
        </div>
      </div>
    </aside>
  );
};
