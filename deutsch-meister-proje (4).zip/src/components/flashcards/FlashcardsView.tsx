import React, { useState } from 'react';
import {
  Volume2,
  RotateCw,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  Sparkles,
  Layers,
} from 'lucide-react';
import { ALL_VOCABULARY_WORDS } from '../../data/flashcards';
import { useApp } from '../../context/AppContext';
import { speakGerman } from '../../utils/audio';
import { CEFRLevel, VocabularyWord } from '../../types';

export const FlashcardsView: React.FC = () => {
  const { profile, updateWordStatus, currentLevel, setCurrentLevel } = useApp();
  const [filterLevel, setFilterLevel] = useState<CEFRLevel | 'ALL'>(currentLevel);
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'LEARNING' | 'MASTERED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});

  // Filter words
  const filteredWords = ALL_VOCABULARY_WORDS.filter((word) => {
    if (filterLevel !== 'ALL' && word.level !== filterLevel) return false;

    const userWord = profile.wordCards[word.id];
    const status = userWord ? userWord.status : 'learning';

    if (filterStatus === 'LEARNING' && status !== 'learning') return false;
    if (filterStatus === 'MASTERED' && status !== 'mastered') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchDe = word.german.toLowerCase().includes(q);
      const matchTr = word.turkish.toLowerCase().includes(q);
      if (!matchDe && !matchTr) return false;
    }

    return true;
  });

  const toggleFlip = (id: string) => {
    setFlippedCards((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAudio = (e: React.MouseEvent, text: string) => {
    e.stopPropagation();
    speakGerman(text, profile.speechSpeed);
  };

  const handleMarkStatus = (
    e: React.MouseEvent,
    wordId: string,
    status: 'learning' | 'mastered'
  ) => {
    e.stopPropagation();
    updateWordStatus(wordId, status);
  };

  // Stats
  const totalMastered = Object.values(profile.wordCards).filter(
    (w) => w.status === 'mastered'
  ).length;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Top Header Card */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-blue-600 to-indigo-700 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Aralıklı Tekrar (Spaced Repetition)
          </span>
          <h2 className="text-2xl font-black mt-1">Kelime Ezberleme Kartları</h2>
          <p className="text-xs sm:text-sm text-blue-100 mt-0.5">
            Kartların üzerine dokunarak Türkçe anlamını ve çoğul halini görün.
          </p>
        </div>

        {/* Counter */}
        <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs p-3 rounded-2xl shrink-0">
          <div className="text-center px-3 border-r border-white/20">
            <span className="text-2xl font-black block">{totalMastered}</span>
            <span className="text-[10px] uppercase font-bold text-blue-200">Öğrenilen</span>
          </div>
          <div className="text-center px-3">
            <span className="text-2xl font-black block">{ALL_VOCABULARY_WORDS.length}</span>
            <span className="text-[10px] uppercase font-bold text-blue-200">Toplam Kart</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs space-y-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Almanca veya Türkçe kelime ara..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        {/* Level Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-1 overflow-x-auto py-1">
            <span className="text-xs font-bold text-slate-400 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Seviye:
            </span>
            {(['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setFilterLevel(lvl)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  filterLevel === lvl
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {lvl === 'ALL' ? 'Tümü' : lvl}
              </button>
            ))}
          </div>

          {/* Status Tabs */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setFilterStatus('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'ALL'
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Tümü
            </button>
            <button
              onClick={() => setFilterStatus('LEARNING')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'LEARNING'
                  ? 'bg-amber-500 text-white'
                  : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Tekrar Edilecek
            </button>
            <button
              onClick={() => setFilterStatus('MASTERED')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                filterStatus === 'MASTERED'
                  ? 'bg-emerald-600 text-white'
                  : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              Öğrenildi
            </button>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      {filteredWords.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700">
          <p className="text-sm font-semibold text-slate-500">
            Arama kriterlerinize uygun kelime kartı bulunamadı.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filteredWords.map((word) => {
            const isFlipped = !!flippedCards[word.id];
            const userCard = profile.wordCards[word.id];
            const isMastered = userCard?.status === 'mastered';

            const articleColor =
              word.article === 'der'
                ? 'bg-blue-100 text-blue-700 border-blue-200'
                : word.article === 'die'
                ? 'bg-rose-100 text-rose-700 border-rose-200'
                : word.article === 'das'
                ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                : 'bg-slate-100 text-slate-600 border-slate-200';

            return (
              <div
                key={word.id}
                onClick={() => toggleFlip(word.id)}
                className={`relative min-h-[220px] rounded-3xl p-5 border-2 transition-all cursor-pointer shadow-xs hover:shadow-md flex flex-col justify-between ${
                  isFlipped
                    ? 'bg-slate-50 dark:bg-slate-800/90 border-emerald-400 dark:border-emerald-700'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                }`}
              >
                {/* Top Row: Level & Flip indicator */}
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                    {word.level} • {word.category}
                  </span>

                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <RotateCw className="w-3 h-3" /> Çevir
                  </span>
                </div>

                {/* Card Center: Front vs Back */}
                {!isFlipped ? (
                  /* FRONT: German + Article + Audio */
                  <div className="my-auto text-center py-2">
                    <div className="flex items-center justify-center gap-2 mb-2">
                      {word.article !== 'none' && (
                        <span
                          className={`text-xs font-black px-2 py-0.5 rounded-lg border ${articleColor}`}
                        >
                          {word.article}
                        </span>
                      )}
                      <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                        {word.german}
                      </h3>
                    </div>

                    <button
                      onClick={(e) => handleAudio(e, word.german)}
                      className="p-2 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 hover:bg-emerald-100 transition inline-flex items-center justify-center"
                      title="Telaffuzu Dinle"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <span className="block text-[11px] text-slate-400 mt-2">
                      Anlamı görmek için tıkla
                    </span>
                  </div>
                ) : (
                  /* BACK: Turkish Meaning + Plural + Example */
                  <div className="my-auto text-center py-2 space-y-1">
                    <h4 className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                      {word.turkish}
                    </h4>
                    {word.plural && (
                      <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                        Çoğul: <span className="text-slate-700 dark:text-slate-200">{word.plural}</span>
                      </p>
                    )}
                    {word.exampleGerman && (
                      <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-left text-[11px]">
                        <p className="text-slate-800 dark:text-slate-200 font-medium">
                          "{word.exampleGerman}"
                        </p>
                        <p className="text-slate-400 italic">
                          {word.exampleTurkish}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Card Bottom: Mastery Actions */}
                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-700/60">
                  <button
                    onClick={(e) => handleMarkStatus(e, word.id, 'learning')}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center justify-center gap-1 ${
                      !isMastered
                        ? 'bg-amber-50 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-300'
                        : 'border-slate-200 text-slate-500 hover:bg-slate-100 dark:border-slate-700'
                    }`}
                  >
                    <Clock className="w-3 h-3" /> Tekrar Et
                  </button>
                  <button
                    onClick={(e) => handleMarkStatus(e, word.id, 'mastered')}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-[11px] font-bold border transition cursor-pointer flex items-center justify-center gap-1 ${
                      isMastered
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'border-slate-200 text-slate-500 hover:bg-emerald-50 hover:text-emerald-700 dark:border-slate-700'
                    }`}
                  >
                    <CheckCircle2 className="w-3 h-3" /> Öğrendim
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
