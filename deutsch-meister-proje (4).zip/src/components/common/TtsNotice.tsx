import React, { useEffect, useState } from 'react';

/** Shows a short note when the phone cannot play German speech. */
export const TtsNotice: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const onFail = () => {
      setVisible(true);
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => setVisible(false), 7000);
    };
    window.addEventListener('tts-failed', onFail);
    return () => {
      window.removeEventListener('tts-failed', onFail);
      if (timer) clearTimeout(timer);
    };
  }, []);

  if (!visible) return null;
  return (
    <div
      role="alert"
      onClick={() => setVisible(false)}
      className="fixed left-3 right-3 bottom-24 z-[60] rounded-2xl bg-slate-900 text-white text-sm font-bold p-4 shadow-2xl"
    >
      Ses çalınamadı. Telefon Ayarları &gt; Genel yönetim &gt; Metin okuma bölümünden Google Metin Okuma motorunu seçip
      Almanca ses verisini indirin.
    </div>
  );
};
