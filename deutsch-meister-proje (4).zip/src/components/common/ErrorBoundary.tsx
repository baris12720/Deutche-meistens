import React from 'react';

interface State {
  hasError: boolean;
}

/** Prevents a blank screen: shows a friendly message and a reload button if something crashes. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.error('App error:', error);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-6 text-center bg-slate-50 text-slate-900">
        <div className="text-5xl">😕</div>
        <h1 className="text-xl font-black">Bir şeyler ters gitti</h1>
        <p className="text-sm text-slate-600 max-w-sm">İlerlemeniz cihazda saklanıyor. Uygulamayı yeniden yüklemeyi deneyin.</p>
        <button
          onClick={() => window.location.reload()}
          className="px-6 py-3 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none"
        >
          Yeniden yükle
        </button>
      </div>
    );
  }
}
