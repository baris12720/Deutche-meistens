import React, { useState } from 'react';
import { X, Volume2, BookOpen, Dumbbell, Sparkles, CheckCircle2 } from 'lucide-react';
import { Lesson } from '../../types';
import { useApp } from '../../context/AppContext';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { speakGerman } from '../../utils/audio';
import { getLevelQuestionPool } from '../../data/questionBank';

interface LessonModalProps {
  lesson: Lesson;
  onClose: () => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({ lesson, onClose }) => {
  const { profile, completeLessonSession } = useApp();
  const [activeSubTab, setActiveSubTab] = useState<'study' | 'quiz'>('study');

  const isAlreadyCompleted = profile.completedLessons.includes(lesson.id);

  // Combine lesson exercises with full level question bank
  const levelPool = getLevelQuestionPool(lesson.level);
  const existingIds = new Set(lesson.exercises.map((e) => e.id));
  const fullExercisePool = [
    ...lesson.exercises,
    ...levelPool.filter((e) => !existingIds.has(e.id)),
  ];

  const handleStudyAudio = (text: string) => {
    speakGerman(text, profile.speechSpeed);
  };

  const handleQuizComplete = (correctCount: number, total: number) => {
    // 15 XP for lesson completion + 5 XP per correct question
    const earnedXp = 15 + correctCount * 5;
    completeLessonSession(lesson.id, earnedXp, correctCount, total);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4">
      <div className="w-full max-w-3xl h-[92vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Bar */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center font-black text-sm">
              {lesson.level}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white leading-tight">
                  {lesson.titleTr}
                </h3>
                {isAlreadyCompleted && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Tamamlandı
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">{lesson.titleDe}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-tab navigation */}
        <div className="flex border-b border-slate-100 dark:border-slate-800 px-5 pt-2 bg-slate-50/50 dark:bg-slate-900/50 shrink-0">
          <button
            onClick={() => setActiveSubTab('study')}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-bold border-b-2 transition cursor-pointer ${
              activeSubTab === 'study'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Konu Anlatımı & Kelimeler</span>
          </button>
          <button
            onClick={() => setActiveSubTab('quiz')}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-bold border-b-2 transition cursor-pointer ${
              activeSubTab === 'quiz'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Dumbbell className="w-4 h-4" />
            <span>Alıştırmalar & Test ({fullExercisePool.length} Soru)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto">
          {activeSubTab === 'study' ? (
            <div className="p-5 sm:p-7 space-y-6">
              {/* Description & Grammar Tip */}
              <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900">
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block">
                  Ders Özeti
                </span>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-200 mt-1">
                  {lesson.descriptionTr}
                </p>
                {lesson.grammarTipTr && (
                  <div className="mt-3 pt-3 border-t border-emerald-200/60 dark:border-emerald-800/60">
                    <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block mb-0.5">
                      💡 Dil Bilgisi İpucu:
                    </span>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {lesson.grammarTipTr}
                    </p>
                  </div>
                )}
              </div>

              {/* Vocabulary Section */}
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                  <span>📚</span> Bu Derste Öğreneceğiniz Kelimeler
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {lesson.vocabulary.map((vocab) => {
                    const articleColor =
                      vocab.article === 'der'
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                        : vocab.article === 'die'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        : vocab.article === 'das'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400';

                    return (
                      <div
                        key={vocab.id}
                        className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-300 dark:hover:border-emerald-700 transition shadow-2xs flex flex-col justify-between"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {vocab.article !== 'none' && (
                                <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md ${articleColor}`}>
                                  {vocab.article}
                                </span>
                              )}
                              <span className="font-bold text-slate-900 dark:text-white text-base">
                                {vocab.german}
                              </span>
                            </div>
                            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5 block">
                              {vocab.turkish} {vocab.plural ? `• Çoğul: ${vocab.plural}` : ''}
                            </span>
                          </div>
                          <button
                            onClick={() => handleStudyAudio(vocab.german)}
                            className="p-2 rounded-xl text-emerald-600 bg-emerald-50 hover:bg-emerald-100 dark:bg-slate-700 dark:text-emerald-400 transition cursor-pointer shrink-0"
                            title="Kelimeyi Dinle"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>

                        {vocab.exampleGerman && (
                          <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-700/60 text-xs">
                            <p className="text-slate-700 dark:text-slate-300 font-medium">
                              "{vocab.exampleGerman}"
                            </p>
                            <p className="text-slate-400 italic mt-0.5">
                              {vocab.exampleTurkish}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Example Sentences */}
              {lesson.exampleSentences.length > 0 && (
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                    <span>💬</span> Örnek Cümleler
                  </h4>
                  <div className="space-y-2">
                    {lesson.exampleSentences.map((sent, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 flex items-center justify-between gap-3"
                      >
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                            {sent.german}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            {sent.turkish}
                          </p>
                        </div>
                        <button
                          onClick={() => handleStudyAudio(sent.german)}
                          className="p-2 text-slate-400 hover:text-emerald-600 transition cursor-pointer"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Dialogue (if available) */}
              {lesson.dialogue && lesson.dialogue.length > 0 && (
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3 flex items-center gap-2">
                    <span>👥</span> Günlük Hayattan Diyalog
                  </h4>
                  <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-3">
                    {lesson.dialogue.map((line, idx) => (
                      <div key={idx} className="flex items-start gap-2.5">
                        <span className="text-xs font-black text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-1 rounded-md shrink-0">
                          {line.speaker}
                        </span>
                        <div className="flex-1">
                          <p className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white">
                            {line.german}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">
                            {line.turkish}
                          </p>
                        </div>
                        <button
                          onClick={() => handleStudyAudio(line.german)}
                          className="p-1 text-slate-400 hover:text-emerald-600 transition"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button to launch quiz */}
              <div className="pt-4 text-center">
                <button
                  onClick={() => setActiveSubTab('quiz')}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm shadow-[0_4px_0_#15803d] active:shadow-none active:translate-y-1 transition flex items-center justify-center gap-2 mx-auto cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Ders Testine ve Alıştırmalara Başla</span>
                </button>
              </div>
            </div>
          ) : (
            <ExerciseRunner
              exercises={fullExercisePool}
              title={`${lesson.titleTr} - Seviye ${lesson.level}`}
              onComplete={handleQuizComplete}
              onExit={() => setActiveSubTab('study')}
            />
          )}
        </div>
      </div>
    </div>
  );
};
