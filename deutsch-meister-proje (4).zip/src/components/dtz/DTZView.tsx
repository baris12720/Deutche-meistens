import React, { useState } from 'react';
import {
  Award,
  Headphones,
  BookOpen,
  PenTool,
  Mic,
  MicOff,
  Volume2,
  CheckCircle2,
  XCircle,
  Sparkles,
  Play,
  RotateCcw,
  Eye,
  EyeOff,
  ChevronRight,
  HelpCircle,
  FileText,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { getExamPool } from '../../data/questionBank/examPool';
import { CEFRLevel, DTZQuestion } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  speakGerman,
  playSuccessSound,
  playWrongSound,
  startSpeechRecognition,
} from '../../utils/audio';
import { shuffleArray } from '../../data/questionBank';

export const DTZView: React.FC = () => {
  const { profile, addXp } = useApp();
  const [examLevel, setExamLevel] = useState<CEFRLevel>('A1');
  const EXAM_LEVELS: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
  const POOL = getExamPool(examLevel);

  const [activeTab, setActiveTab] = useState<
    'overview' | 'hoeren' | 'lesen' | 'schreiben' | 'sprechen' | 'exam'
  >('overview');

  // Exam simulator state
  const [examMode, setExamMode] = useState<20 | 50>(20);
  const [examQuestions, setExamQuestions] = useState<DTZQuestion[]>([]);
  const [examIndex, setExamIndex] = useState(0);
  const [examAnswers, setExamAnswers] = useState<
    Record<string, { userAnswer: string; isCorrect: boolean }>
  >({});
  const [examFinished, setExamFinished] = useState(false);
  const [examChecked, setExamChecked] = useState(false);
  const [selectedExamOption, setSelectedExamOption] = useState<string | null>(null);

  // Hören tab state
  const [activeHoerenId, setActiveHoerenId] = useState<string>('');
  const [revealedTranscripts, setRevealedTranscripts] = useState<Record<string, boolean>>({});
  const [hoerenAnswers, setHoerenAnswers] = useState<Record<string, string>>({});
  const [hoerenChecked, setHoerenChecked] = useState<Record<string, boolean>>({});

  // Lesen tab state
  const [activeLesenIndex, setActiveLesenIndex] = useState(0);
  const [lesenAnswers, setLesenAnswers] = useState<Record<string, string>>({});
  const [lesenChecked, setLesenChecked] = useState<Record<string, boolean>>({});

  // Schreiben tab state
  const [activeSchreibenIndex, setActiveSchreibenIndex] = useState(0);
  const [userTexts, setUserTexts] = useState<Record<string, string>>({});
  const [showSampleSolutions, setShowSampleSolutions] = useState<Record<string, boolean>>({});

  // Sprechen tab state
  const [activeSprechenIndex, setActiveSprechenIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [spokenTranscript, setSpokenTranscript] = useState('');
  const [speechStopper, setSpeechStopper] = useState<{ stop: () => void } | null>(null);

  const hoerenList = POOL.filter((q) => q.section === 'hoeren');
  const lesenList = POOL.filter((q) => q.section === 'lesen');
  const schreibenList = POOL.filter((q) => q.section === 'schreiben');
  const sprechenList = POOL.filter((q) => q.section === 'sprechen');

  const startExam = (length: 20 | 50) => {
    setExamMode(length);
    const shuffled = shuffleArray([...POOL]);
    setExamQuestions(shuffled.slice(0, length));
    setExamIndex(0);
    setExamAnswers({});
    setExamFinished(false);
    setExamChecked(false);
    setSelectedExamOption(null);
    setActiveTab('exam');
  };

  const handleExamNext = () => {
    if (!selectedExamOption && examQuestions[examIndex]?.options) return;

    const currentQ = examQuestions[examIndex];
    if (currentQ.correctAnswer) {
      const isRight = selectedExamOption === currentQ.correctAnswer;
      setExamAnswers((prev) => ({
        ...prev,
        [currentQ.id]: { userAnswer: selectedExamOption || '', isCorrect: isRight },
      }));
    }

    if (examIndex + 1 < examQuestions.length) {
      setExamIndex((prev) => prev + 1);
      setSelectedExamOption(null);
      setExamChecked(false);
    } else {
      setExamFinished(true);
      addXp(examMode === 20 ? 40 : 100);
    }
  };

  const handleToggleMic = () => {
    if (isRecording) {
      speechStopper?.stop();
      setIsRecording(false);
      return;
    }
    setSpokenTranscript('');
    setIsRecording(true);
    const stopper = startSpeechRecognition(
      'Guten Tag, mein Name ist',
      (res) => {
        setSpokenTranscript(res.transcript);
        setIsRecording(false);
        playSuccessSound(profile.soundEnabled);
      },
      () => {
        setIsRecording(false);
      }
    );
    setSpeechStopper(stopper);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 select-none">
      {/* DTZ Top Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-red-700 via-rose-700 to-amber-700 text-white shadow-xl relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center sm:text-left z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-bold uppercase tracking-wider">
            <span>🇩🇪 Goethe & DTZ Sınav Merkezi</span>
            <span>•</span>
            <span>{examLevel} Seviyesi</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
            Deutsch-Test für Zuwanderer (DTZ)
          </h2>
          <p className="text-rose-100 text-xs sm:text-sm max-w-xl leading-relaxed">
            Almanya vatandaşlığı ve süresiz oturum izni (Niederlassungserlaubnis) için gerekli olan resmi DTZ sınavına 4 beceride kapsamlı hazırlık.
          </p>
        </div>

        <div className="z-10 shrink-0 text-center sm:text-right">
          <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs border border-white/20">
            <span className="block text-2xl font-black">{POOL.length} Görev / Soru</span>
            <span className="block text-[11px] text-rose-100 font-semibold">Tüm Beceriler Hazır</span>
          </div>
        </div>
      </div>

      {/* Level selector */}
      <div className="flex gap-2 overflow-x-auto" role="tablist" aria-label="Sınav seviyesi">
        {EXAM_LEVELS.map((lvl) => {
          const count = getExamPool(lvl).length;
          const active = lvl === examLevel;
          return (
            <button
              key={lvl}
              role="tab"
              aria-selected={active}
              disabled={count === 0}
              onClick={() => {
                setExamLevel(lvl);
                setActiveTab('overview');
                setActiveLesenIndex(0);
                setActiveSchreibenIndex(0);
                setActiveSprechenIndex(0);
                setExamFinished(false);
              }}
              className={`flex-1 min-w-[84px] py-2 px-3 rounded-xl font-black text-sm transition ${
                active
                  ? 'bg-rose-600 text-white shadow-[0_3px_0_#9f1239]'
                  : count === 0
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-2 border-slate-200 dark:border-slate-700 cursor-pointer'
              }`}
            >
              {lvl}
              <span className="block text-[10px] font-bold opacity-80">{count === 0 ? 'Yakında' : `${count} görev`}</span>
            </button>
          );
        })}
      </div>

      {/* Sub Navigation Tabs */}
      <div className="flex bg-white dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs gap-1 overflow-x-auto">
        {[
          { key: 'overview', label: 'Genel Bakış & Sınav', icon: ShieldCheck },
          { key: 'hoeren', label: `🎧 Hören (${hoerenList.length})`, icon: Headphones },
          { key: 'lesen', label: `📖 Lesen (${lesenList.length})`, icon: BookOpen },
          { key: 'schreiben', label: `✍️ Schreiben (${schreibenList.length})`, icon: PenTool },
          { key: 'sprechen', label: `🗣️ Sprechen (${sprechenList.length})`, icon: Mic },
        ].map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => {
                setActiveTab(tab.key as any);
                setExamFinished(false);
              }}
              className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 ${
                isActive
                  ? 'bg-rose-600 text-white shadow-[0_3px_0_#9f1239]'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. OVERVIEW & EXAM SIMULATOR */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Mock Launch Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-rose-200 dark:border-rose-900/60 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[11px] font-bold uppercase mb-2">
                  <Clock className="w-3.5 h-3.5" /> Hızlı Pratik (~10 dk)
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  20 Soruluk Kısa Deneme Sınavı
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Hören, Lesen ve Sprechen havuzundan karışık 20 soruyla hızlı bir deneme yapın.
                </p>
              </div>
              <button
                onClick={() => startExam(20)}
                className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-sm shadow-[0_3px_0_#9f1239] active:translate-y-0.5 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>20 Soruluk Denemeyi Başlat</span>
              </button>
            </div>

            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-emerald-500/40 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[11px] font-bold uppercase mb-2">
                  <Award className="w-3.5 h-3.5" /> Tam Simülasyon (~25 dk)
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  50 Soruluk Kapsamlı DTZ Sınavı
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Soru havuzundaki tüm bölümleri kapsayan 50 soruluk eksiksiz DTZ simülasyonu.
                </p>
              </div>
              <button
                onClick={() => startExam(50)}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm shadow-[0_3px_0_#15803d] active:translate-y-0.5 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>50 Soruluk Tam Sınavı Başlat</span>
              </button>
            </div>
          </div>

          {/* Exam Structure Accordion */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
            <h4 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-rose-600" />
              <span>DTZ Sınav Sistemi Nasıl Puanlanır?</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              <div className="p-3.5 bg-slate-50 dark:bg-slate-700/50 rounded-2xl space-y-1">
                <span className="font-black text-slate-900 dark:text-white block">
                  1. Yazılı Sınav (Schriftliche Prüfung - 100 dk)
                </span>
                <p>• <strong>Hören (25 dk):</strong> Anonslar, telefon mesajları ve diyaloglar.</p>
                <p>• <strong>Lesen (45 dk):</strong> İlanlar, resmi mektuplar ve duyurular.</p>
                <p>• <strong>Schreiben (30 dk):</strong> Kısa bir resmi veya yarı resmi mektup/e-posta.</p>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-700/50 rounded-2xl space-y-1">
                <span className="font-black text-slate-900 dark:text-white block">
                  2. Sözlü Sınav (Mündliche Prüfung - 16 dk)
                </span>
                <p>• <strong>Teil 1:</strong> Kendini tanıtma ve heceleme (Buchstabieren).</p>
                <p>• <strong>Teil 2:</strong> Resim tasviri veya kişisel deneyim anlatımı.</p>
                <p>• <strong>Teil 3:</strong> Sınav partneriyle ortak bir etkinlik planlama.</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200">
              💡 <strong>B1 Sertifikası Alma Şartı:</strong> Sözlü sınavdan (Sprechen) kesinlikle B1 seviyesinde puan almak ve yazılı kısımlardan en az birinde (Hören/Lesen veya Schreiben) B1 barajını geçmek şarttır.
            </div>
          </div>
        </div>
      )}

      {/* EXAM RUNNER SCREEN */}
      {activeTab === 'exam' && (
        <div className="space-y-6">
          {!examFinished ? (
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-md space-y-6">
              {/* Exam progress bar */}
              <div className="flex items-center justify-between gap-4">
                <button
                  onClick={() => setActiveTab('overview')}
                  className="text-xs font-bold text-slate-400 hover:text-slate-600"
                >
                  ✕ Sınavdan Çık
                </button>
                <div className="flex-1 h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-rose-600 rounded-full transition-all"
                    style={{
                      width: `${Math.round(((examIndex + 1) / examQuestions.length) * 100)}%`,
                    }}
                  />
                </div>
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  {examIndex + 1} / {examQuestions.length}
                </span>
              </div>

              {/* Current Question Body */}
              {examQuestions[examIndex] && (() => {
                const q = examQuestions[examIndex];
                return (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-rose-600 bg-rose-50 dark:bg-rose-950/60 px-2.5 py-1 rounded-full uppercase">
                        {q.topicTag} • {q.level}
                      </span>
                      <span className="text-xs font-bold text-slate-400">{q.titleTr}</span>
                    </div>

                    {/* Context / Audio Prompt if hoeren */}
                    {q.contextDe && (
                      <div className="p-4 bg-slate-50 dark:bg-slate-700/40 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line">
                        {q.contextDe}
                      </div>
                    )}

                    {q.audioPromptDe && (
                      <div className="p-4 bg-rose-50/60 dark:bg-rose-950/30 rounded-2xl border border-rose-200 dark:border-rose-900/40 flex items-center justify-between">
                        <div>
                          <span className="text-xs font-bold text-rose-700 dark:text-rose-400 block">
                            🎧 Sesli Anons
                          </span>
                          <span className="text-xs text-slate-500">
                            Anonsu dinlemek için butona dokunun
                          </span>
                        </div>
                        <button
                          onClick={() => speakGerman(q.audioPromptDe!, profile.speechSpeed)}
                          className="p-3 rounded-xl bg-rose-600 text-white hover:bg-rose-700 shadow-md transition cursor-pointer"
                        >
                          <Volume2 className="w-5 h-5" />
                        </button>
                      </div>
                    )}

                    {/* Question text */}
                    <div>
                      <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                        {q.questionDe}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{q.questionTr}</p>
                    </div>

                    {/* Options */}
                    {q.options && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        {q.options.map((opt, idx) => {
                          const isSelected = selectedExamOption === opt;
                          return (
                            <button
                              key={idx}
                              onClick={() => setSelectedExamOption(opt)}
                              className={`p-4 rounded-2xl border-2 text-left text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-rose-600 bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-100'
                                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-slate-300'
                              }`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Next Action */}
                    <div className="pt-4 flex justify-end">
                      <button
                        disabled={!selectedExamOption && !!q.options}
                        onClick={handleExamNext}
                        className={`px-8 py-3 rounded-xl font-black text-sm text-white shadow-md transition flex items-center gap-2 cursor-pointer ${
                          selectedExamOption || !q.options
                            ? 'bg-rose-600 hover:bg-rose-700 active:translate-y-0.5'
                            : 'bg-slate-300 dark:bg-slate-700 cursor-not-allowed'
                        }`}
                      >
                        <span>{examIndex + 1 < examQuestions.length ? 'Sonraki Soru' : 'Sınavı Bitir'}</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })()}
            </div>
          ) : (
            /* Exam Result Screen */
            <div className="p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl space-y-6 text-center">
              <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center">
                <Award className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                  DTZ Deneme Sınavı Tamamlandı!
                </h3>
                {(() => {
                  const correctAnswers = Object.values(examAnswers).filter((a) => a.isCorrect).length;
                  const total = examQuestions.filter((q) => q.correctAnswer).length;
                  const percent = Math.round((correctAnswers / Math.max(1, total)) * 100);
                  const isB1 = percent >= 75;

                  return (
                    <div className="space-y-4 pt-3">
                      <div className="text-4xl font-black text-rose-600">
                        %{percent} Doğruluk
                      </div>
                      <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                        {isB1
                          ? '🎉 Tebrikler! DTZ B1 Barajını geçtiniz.'
                          : percent >= 50
                          ? '👍 Sonucunuz A2 seviyesinde. Biraz daha pratikle B1 hedefine ulaşabilirsiniz.'
                          : 'Tekrar çalışarak denemeyi yeniden çözmenizi öneririz.'}
                      </p>

                      <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto pt-2">
                        <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-2xl">
                          <span className="block text-xl font-black text-emerald-600">
                            {correctAnswers}
                          </span>
                          <span className="block text-[11px] text-slate-400 font-bold">Doğru</span>
                        </div>
                        <div className="p-3 bg-slate-50 dark:bg-slate-700/50 rounded-2xl">
                          <span className="block text-xl font-black text-rose-600">
                            {total - correctAnswers}
                          </span>
                          <span className="block text-[11px] text-slate-400 font-bold">Yanlış</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={() => startExam(examMode)}
                  className="px-6 py-3 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-sm hover:bg-slate-200 transition"
                >
                  Sınavı Tekrar Başlat
                </button>
                <button
                  onClick={() => setActiveTab('overview')}
                  className="px-6 py-3 rounded-xl bg-rose-600 text-white font-bold text-sm hover:bg-rose-700 transition"
                >
                  DTZ Menüsüne Dön
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. HÖREN SECTION */}
      {activeTab === 'hoeren' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 flex items-center justify-between">
            <span className="text-xs font-bold text-rose-800 dark:text-rose-200">
              🎧 Toplam <strong>{hoerenList.length} Dinleme Görevi</strong> (Tren, doktor, alışveriş, acil anonslar)
            </span>
          </div>

          <div className="space-y-4">
            {hoerenList.map((item, idx) => {
              const userChoice = hoerenAnswers[item.id];
              const isChecked = hoerenChecked[item.id];
              const isRight = userChoice === item.correctAnswer;
              const isRevealed = revealedTranscripts[item.id];

              return (
                <div
                  key={item.id}
                  className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-rose-600 bg-rose-50 dark:bg-rose-950/60 px-2.5 py-1 rounded-full uppercase">
                      {item.topicTag} • {item.level}
                    </span>
                    <span className="text-xs text-slate-400 font-bold">Görev #{idx + 1}</span>
                  </div>

                  <p className="text-xs text-slate-500 italic">{item.contextTr}</p>

                  {/* Audio trigger card */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => speakGerman(item.audioPromptDe!, profile.speechSpeed)}
                        className="w-12 h-12 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-md hover:bg-rose-700 active:scale-95 transition cursor-pointer"
                        title="Anonsu Dinle"
                      >
                        <Volume2 className="w-6 h-6" />
                      </button>
                      <div>
                        <span className="text-xs font-bold text-slate-900 dark:text-white block">
                          Sesli Anonsu Dinle
                        </span>
                        <span className="text-[11px] text-slate-400">
                          Doğal hızda Alman aksanı
                        </span>
                      </div>
                    </div>

                    {userChoice && (
                    <button
                      onClick={() =>
                        setRevealedTranscripts((prev) => ({
                          ...prev,
                          [item.id]: !prev[item.id],
                        }))
                      }
                      className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                    >
                      {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{isRevealed ? 'Metni Gizle' : 'Transkripti Aç'}</span>
                    </button>
                    )}
                  </div>

                  {/* Revealed Transcript */}
                  {userChoice && isRevealed && item.transcriptDe && (
                    <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 animate-in fade-in">
                      <span className="font-bold block mb-0.5">📜 Anons Metni (Transkript):</span>
                      "{item.transcriptDe}"
                    </div>
                  )}

                  {/* Question and Options */}
                  <div className="space-y-2">
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                      {item.questionDe}
                    </h4>
                    <p className="text-xs text-slate-500">{item.questionTr}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      {item.options?.map((opt, oIdx) => {
                        const isSelected = userChoice === opt;
                        return (
                          <button
                            key={oIdx}
                            disabled={isChecked}
                            onClick={() =>
                              setHoerenAnswers((prev) => ({ ...prev, [item.id]: opt }))
                            }
                            className={`p-3 rounded-xl border-2 text-left text-xs font-semibold transition-all cursor-pointer ${
                              isSelected
                                ? 'border-rose-600 bg-rose-50 text-rose-900 dark:bg-rose-950 dark:text-rose-100'
                                : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Evaluation bar */}
                  {!isChecked ? (
                    <button
                      disabled={!userChoice}
                      onClick={() => {
                        setHoerenChecked((prev) => ({ ...prev, [item.id]: true }));
                        if (isRight) playSuccessSound(profile.soundEnabled);
                        else playWrongSound(profile.soundEnabled);
                      }}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${
                        userChoice
                          ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      Cevabı Kontrol Et
                    </button>
                  ) : (
                    <div
                      className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                        isRight
                          ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200 border border-emerald-200'
                          : 'bg-rose-50 text-rose-800 dark:bg-rose-950 dark:text-rose-200 border border-rose-200'
                      }`}
                    >
                      {isRight ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span className="font-bold">
                          {isRight ? 'Doğru!' : `Yanlış! Doğru cevap: ${item.correctAnswer}`}
                        </span>
                        <p className="mt-0.5">{item.explanationTr}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. LESEN SECTION */}
      {activeTab === 'lesen' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/60 flex items-center justify-between">
            <span className="text-xs font-bold text-blue-800 dark:text-blue-200">
              📖 Toplam <strong>{lesenList.length} Okuma Parçası</strong> (Ev kiralama, iş ilanları, okul mektupları)
            </span>
          </div>

          <div className="space-y-4">
            {lesenList.map((item, idx) => {
              const userChoice = lesenAnswers[item.id];
              const isChecked = lesenChecked[item.id];
              const isRight = userChoice === item.correctAnswer;

              return (
                <div
                  key={item.id}
                  className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-600 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded-full uppercase">
                      {item.topicTag} • {item.level}
                    </span>
                    <span className="text-xs text-slate-400 font-bold">Metin #{idx + 1}</span>
                  </div>

                  {/* Reading Box */}
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border-2 border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-100 whitespace-pre-line font-medium leading-relaxed font-sans">
                    {item.contextDe}
                  </div>

                  {/* Question and Options */}
                  <div className="space-y-2">
                    <h4 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                      {item.questionDe}
                    </h4>
                    <p className="text-xs text-slate-500">{item.questionTr}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      {item.options?.map((opt, oIdx) => {
                        const isSelected = userChoice === opt;
                        return (
                          <button
                            key={oIdx}
                            disabled={isChecked}
                            onClick={() =>
                              setLesenAnswers((prev) => ({ ...prev, [item.id]: opt }))
                            }
                            className={`p-3 rounded-xl border-2 text-left text-xs font-semibold transition-all cursor-pointer ${
                              isSelected
                                ? 'border-blue-600 bg-blue-50 text-blue-900 dark:bg-blue-950 dark:text-blue-100'
                                : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Evaluation bar */}
                  {!isChecked ? (
                    <button
                      disabled={!userChoice}
                      onClick={() => {
                        setLesenChecked((prev) => ({ ...prev, [item.id]: true }));
                        if (isRight) playSuccessSound(profile.soundEnabled);
                        else playWrongSound(profile.soundEnabled);
                      }}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${
                        userChoice
                          ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      Cevabı Kontrol Et
                    </button>
                  ) : (
                    <div
                      className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                        isRight
                          ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200 border border-emerald-200'
                          : 'bg-rose-50 text-rose-800 dark:bg-rose-950 dark:text-rose-200 border border-rose-200'
                      }`}
                    >
                      {isRight ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span className="font-bold">
                          {isRight ? 'Doğru!' : `Yanlış! Doğru cevap: ${item.correctAnswer}`}
                        </span>
                        <p className="mt-0.5">{item.explanationTr}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. SCHREIBEN SECTION */}
      {activeTab === 'schreiben' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/60 flex items-center justify-between">
            <span className="text-xs font-bold text-amber-900 dark:text-amber-200">
              ✍️ Toplam <strong>{schreibenList.length} Yazma Görevi</strong> (Mazeret, şikayet, teyit mektupları)
            </span>
          </div>

          <div className="space-y-6">
            {schreibenList.map((item, idx) => {
              const currentText = userTexts[item.id] || '';
              const wordCount = currentText.trim().split(/\s+/).filter(Boolean).length;
              const isSampleOpen = showSampleSolutions[item.id];

              return (
                <div
                  key={item.id}
                  className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-600 bg-amber-50 dark:bg-amber-950/60 px-2.5 py-1 rounded-full uppercase">
                      {item.topicTag} • {item.level}
                    </span>
                    <span className="text-xs text-slate-400 font-bold">Görev #{idx + 1}</span>
                  </div>

                  <div>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                      {item.titleTr}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{item.contextTr}</p>
                  </div>

                  {/* Leitpunkte (Değinilmesi Gereken Noktalar) */}
                  {item.writingPointsTr && (
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-700/40 border border-slate-200 dark:border-slate-700 space-y-2">
                      <span className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                        📌 Mektubunuzda Değinmeniz Gereken Noktalar (Leitpunkte):
                      </span>
                      <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
                        {item.writingPointsTr.map((pt, pIdx) => (
                          <li key={pIdx} className="flex items-start gap-2">
                            <span className="text-amber-500 font-bold">•</span>
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Interactive Textarea */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                      <span>Mektubunuzu Almanca Yazın:</span>
                      <span
                        className={
                          wordCount >= 30
                            ? 'text-emerald-600 dark:text-emerald-400 font-black'
                            : 'text-amber-600'
                        }
                      >
                        {wordCount} Kelime (Hedef: 35-50 kelime)
                      </span>
                    </div>

                    <textarea
                      rows={5}
                      value={currentText}
                      onChange={(e) =>
                        setUserTexts((prev) => ({ ...prev, [item.id]: e.target.value }))
                      }
                      placeholder="Sehr geehrte Damen und Herren / Liebe/r..."
                      className="w-full p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs sm:text-sm font-sans focus:outline-hidden focus:border-amber-500 transition resize-y"
                    />
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      onClick={() =>
                        setShowSampleSolutions((prev) => ({
                          ...prev,
                          [item.id]: !prev[item.id],
                        }))
                      }
                      className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <span>{isSampleOpen ? 'Örnek Çözümü Gizle' : 'Örnek Çözümü (Musterlösung) Göster'}</span>
                    </button>
                  </div>

                  {/* Sample Solution Display */}
                  {isSampleOpen && item.sampleSolutionDe && (
                    <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 space-y-3 animate-in fade-in">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-emerald-800 dark:text-emerald-200 uppercase tracking-wider">
                          🌟 Örnek B1 Seviye Mektup (Musterbrief):
                        </span>
                        <button
                          onClick={() => speakGerman(item.sampleSolutionDe!, profile.speechSpeed)}
                          className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800 hover:bg-emerald-200 transition"
                          title="Örnek Mektubu Dinle"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-800 rounded-xl text-xs sm:text-sm text-slate-800 dark:text-slate-100 whitespace-pre-line leading-relaxed font-sans border border-emerald-200 dark:border-emerald-900">
                        {item.sampleSolutionDe}
                      </div>

                      {/* Criteria */}
                      {item.criteriaTr && (
                        <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-900 text-[11px] text-emerald-900 dark:text-emerald-300 space-y-1">
                          <span className="font-bold block">Puanlama Kriterleri:</span>
                          {item.criteriaTr.map((c, cIdx) => (
                            <p key={cIdx}>✓ {c}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. SPRECHEN SECTION */}
      {activeTab === 'sprechen' && (
        <div className="space-y-6">
          <div className="p-4 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/60 flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
              🗣️ Toplam <strong>{sprechenList.length} Sözlü Sınav Görevi</strong> (Teil 1, Teil 2, Teil 3)
            </span>
          </div>

          <div className="space-y-6">
            {sprechenList.map((item, idx) => {
              return (
                <div
                  key={item.id}
                  className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-full uppercase">
                      {item.topicTag} • {item.level}
                    </span>
                    <span className="text-xs text-slate-400 font-bold">Bölüm #{idx + 1}</span>
                  </div>

                  <div>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
                      {item.titleTr}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">{item.contextTr}</p>
                  </div>

                  {/* Exam prompt */}
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                    "{item.questionDe}"
                  </div>

                  {/* Suggested phrases */}
                  {item.suggestedPhrasesDe && (
                    <div className="space-y-2">
                      <span className="text-xs font-black text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                        💬 Kullanabileceğiniz Kalıplar ve Örnek Cümleler:
                      </span>
                      <div className="grid grid-cols-1 gap-2">
                        {item.suggestedPhrasesDe.map((ph, pIdx) => (
                          <div
                            key={pIdx}
                            className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 flex items-center justify-between gap-3 text-xs"
                          >
                            <span className="font-semibold text-slate-800 dark:text-slate-100">
                              "{ph}"
                            </span>
                            <button
                              onClick={() => speakGerman(ph, profile.speechSpeed)}
                              className="p-1 text-emerald-600 hover:text-emerald-700 shrink-0 cursor-pointer"
                              title="Dinle"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Interactive Microphone Test */}
                  <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-center sm:text-left">
                      <span className="text-xs font-bold text-slate-900 dark:text-white block">
                        Konuşarak Pratik Yapın
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        Mikrofona dokunun ve yukarıdaki cümleleri yüksek sesle okuyun
                      </span>
                    </div>

                    <button
                      onClick={handleToggleMic}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 cursor-pointer transition ${
                        isRecording
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                      }`}
                    >
                      {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      <span>{isRecording ? 'Dinleniyor... Konuşun' : 'Mikrofonu Aç ve Konuş'}</span>
                    </button>
                  </div>

                  {spokenTranscript && (
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-xs text-emerald-900 dark:text-emerald-200 border border-emerald-200">
                      <strong>Algılanan Telaffuz:</strong> "{spokenTranscript}"
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
