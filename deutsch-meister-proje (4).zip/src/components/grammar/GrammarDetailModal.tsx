import React, { useState } from 'react';
import { X, Volume2, BookOpen, CheckCircle2, Dumbbell } from 'lucide-react';
import { GrammarTopic } from '../../types';
import { useApp } from '../../context/AppContext';
import { speakGerman } from '../../utils/audio';
import { ExerciseRunner } from '../exercise/ExerciseRunner';

interface GrammarDetailModalProps {
  topic: GrammarTopic;
  onClose: () => void;
}

export const GrammarDetailModal: React.FC<GrammarDetailModalProps> = ({
  topic,
  onClose,
}) => {
  const { profile, addXp } = useApp();
  const [activeTab, setActiveTab] = useState<'reading' | 'quiz'>('reading');

  const handleAudio = (text: string) => {
    speakGerman(text, profile.speechSpeed);
  };

  const handleQuizDone = (correct: number, total: number) => {
    addXp(10 + correct * 5);
    setActiveTab('reading');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4">
      <div className="w-full max-w-3xl h-[92vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 font-extrabold text-xs">
              {topic.level}
            </span>
            <div>
              <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-tight">
                {topic.titleTr}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">{topic.titleDe}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-100 dark:border-slate-800 px-6 pt-2 bg-slate-50/50 dark:bg-slate-900/50 shrink-0">
          <button
            onClick={() => setActiveTab('reading')}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-bold border-b-2 transition cursor-pointer ${
              activeTab === 'reading'
                ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Konu Anlatımı</span>
          </button>
          {topic.exercises.length > 0 && (
            <button
              onClick={() => setActiveTab('quiz')}
              className={`flex items-center gap-2 pb-3 px-3 text-sm font-bold border-b-2 transition cursor-pointer ${
                activeTab === 'quiz'
                  ? 'border-purple-600 text-purple-600 dark:text-purple-400'
                : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <Dumbbell className="w-4 h-4" />
              <span>Mini Test ({topic.exercises.length})</span>
            </button>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {activeTab === 'reading' ? (
            <div className="p-6 sm:p-8 space-y-6">
              {/* Summary */}
              <div className="p-4 rounded-2xl bg-purple-50/60 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900 text-sm font-medium text-slate-700 dark:text-slate-300">
                {topic.summaryTr}
              </div>

              {/* Main Markdown Body */}
              <div className="prose prose-slate dark:prose-invert max-w-none text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                {topic.contentMarkdownTr}
              </div>

              {/* Tables */}
              {topic.tables &&
                topic.tables.map((table, tIdx) => (
                  <div key={tIdx} className="overflow-x-auto my-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                    {table.caption && (
                      <div className="p-3 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                        {table.caption}
                      </div>
                    )}
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-100 dark:bg-slate-800/60">
                          {table.headers.map((h, hIdx) => (
                            <th key={hIdx} className="p-2.5 font-bold text-slate-700 dark:text-slate-200 border-b border-slate-200 dark:border-slate-700">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {table.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="p-2.5 text-slate-600 dark:text-slate-300">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ))}

              {/* Examples with Audio */}
              {topic.examples.length > 0 && (
                <div className="space-y-3 pt-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Örnek Cümleler & Sesli Dinleme
                  </h4>
                  <div className="space-y-2">
                    {topic.examples.map((ex, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 shadow-2xs"
                      >
                        <div>
                          <p className="text-sm font-bold text-slate-900 dark:text-white">
                            {ex.german}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            {ex.turkish}
                          </p>
                          {ex.note && (
                            <span className="text-[11px] text-purple-600 dark:text-purple-400 font-medium">
                              💡 {ex.note}
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => handleAudio(ex.german)}
                          className="p-2 rounded-xl text-purple-600 bg-purple-50 dark:bg-purple-950 hover:bg-purple-100 transition cursor-pointer"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button */}
              {topic.exercises.length > 0 && (
                <div className="pt-4 text-center">
                  <button
                    onClick={() => setActiveTab('quiz')}
                    className="px-6 py-3 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-sm shadow-[0_4px_0_#6b21a8] active:shadow-none active:translate-y-1 transition cursor-pointer"
                  >
                    Konu Testine Başla
                  </button>
                </div>
              )}
            </div>
          ) : (
            <ExerciseRunner
              exercises={topic.exercises}
              onComplete={handleQuizDone}
              onExit={() => setActiveTab('reading')}
            />
          )}
        </div>
      </div>
    </div>
  );
};
