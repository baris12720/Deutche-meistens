import React, { useState, useEffect } from 'react';
import {
  Timer,
  Mic,
  MicOff,
  RotateCcw,
  Volume2,
  CheckCircle2,
  XCircle,
  Zap,
  Play,
  Award,
  Target,
} from 'lucide-react';
import { ALL_VOCABULARY_WORDS } from '../../data/flashcards';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { getLevelQuestionPool } from '../../data/questionBank';
import {
  speakGerman,
  playSuccessSound,
  playWrongSound,
  startSpeechRecognition,
  isSpeechRecognitionSupported,
} from '../../utils/audio';

export const PracticeArena: React.FC = () => {
  const { profile, addXp, openPlacementTest } = useApp();
  const [activeMode, setActiveMode] = useState<'menu' | 'timed' | 'speech' | 'level_test'>('menu');
  const [testLevel, setTestLevel] = useState<CEFRLevel>('A1');

  // Timed Challenge State
  const [timeLeft, setTimeLeft] = useState(60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timedScore, setTimedScore] = useState(0);
  const [timedQuestions, setTimedQuestions] = useState<any[]>([]);
  const [timedIndex, setTimedIndex] = useState(0);
  const [timedCompleted, setTimedCompleted] = useState(false);

  // Speech Practice State
  const [speechSentenceIndex, setSpeechSentenceIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [spokenText, setSpokenText] = useState('');
  const [speechScore, setSpeechScore] = useState<number | null>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [speechStopper, setSpeechStopper] = useState<{ stop: () => void } | null>(null);

  const SPEECH_PROMPTS = [
    { de: 'Guten Morgen, wie geht es dir?', tr: 'Günaydın, nasılsın?' },
    { de: 'Ich möchte einen Kaffee, bitte.', tr: 'Bir kahve rica ediyorum lütfen.' },
    { de: 'Wo ist der nächste Bahnhof?', tr: 'En yakın tren garı nerede?' },
    { de: 'Ich lerne jeden Tag fleißig Deutsch.', tr: 'Her gün çalışkan bir şekilde Almanca öğreniyorum.' },
    { de: 'Entschuldigung, wie viel kostet das?', tr: 'Affedersiniz, bu ne kadar tutuyor?' },
    { de: 'Ich komme aus der Türkei.', tr: 'Türkiye\'den geliyorum.' },
    { de: 'Das Wetter ist heute wunderbar.', tr: 'Hava bugün harika.' },
  ];

  // Start Timed Challenge
  const startTimedSprint = () => {
    // Generate 15 rapid multiple choice items from vocabulary
    const shuffled = [...ALL_VOCABULARY_WORDS].sort(() => 0.5 - Math.random());
    const items = shuffled.slice(0, 15).map((w) => {
      const wrongOpts = shuffled
        .filter((o) => o.id !== w.id)
        .slice(0, 3)
        .map((o) => o.turkish);
      const options = [w.turkish, ...wrongOpts].sort(() => 0.5 - Math.random());
      return {
        word: w.german,
        article: w.article,
        correct: w.turkish,
        options,
      };
    });

    setTimedQuestions(items);
    setTimedIndex(0);
    setTimedScore(0);
    setTimeLeft(60);
    setTimedCompleted(false);
    setIsTimerRunning(true);
    setActiveMode('timed');
  };

  // Timer countdown hook
  useEffect(() => {
    if (!isTimerRunning) return;
    if (timeLeft <= 0) {
      setIsTimerRunning(false);
      setTimedCompleted(true);
      addXp(timedScore * 10);
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isTimerRunning, timeLeft, timedScore]);

  const handleTimedAnswer = (selected: string) => {
    const current = timedQuestions[timedIndex];
    if (selected === current.correct) {
      setTimedScore((s) => s + 1);
      playSuccessSound(profile.soundEnabled);
    } else {
      playWrongSound(profile.soundEnabled);
    }

    if (timedIndex + 1 < timedQuestions.length) {
      setTimedIndex((i) => i + 1);
    } else {
      setIsTimerRunning(false);
      setTimedCompleted(true);
      addXp((timedScore + 1) * 10);
    }
  };

  // Speech Practice Handlers
  const currentSpeechPrompt = SPEECH_PROMPTS[speechSentenceIndex];

  const handleToggleSpeech = () => {
    if (isRecording) {
      speechStopper?.stop();
      setIsRecording(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      setSpeechError(
        'Tarayıcınız ses tanımayı desteklemiyor. Google Chrome veya Edge masaüstü tarayıcısında deneyebilirsiniz.'
      );
      return;
    }

    setSpeechError(null);
    setSpokenText('');
    setSpeechScore(null);
    setIsRecording(true);

    const stopper = startSpeechRecognition(
      currentSpeechPrompt.de,
      (res) => {
        setIsRecording(false);
        setSpokenText(res.transcript);
        setSpeechScore(res.score);
        if (res.isMatch) {
          playSuccessSound(profile.soundEnabled);
          addXp(10);
        } else {
          playWrongSound(profile.soundEnabled);
        }
      },
      (err) => {
        setIsRecording(false);
        setSpeechError(err);
      }
    );

    setSpeechStopper(stopper);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Menu / Selection Mode */}
      {activeMode === 'menu' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-linear-to-r from-amber-500 to-orange-600 text-white shadow-lg">
            <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
              Özel Antrenman Alanı
            </span>
            <h2 className="text-2xl font-black mt-1">Alıştırma & Pratik Arenası</h2>
            <p className="text-xs sm:text-sm text-amber-100 mt-0.5">
              Hızlı reflekslerini test et veya mikrofon ile Almanca konuşma pratiği yap.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Mode 0: Placement Test */}
            <div
              onClick={openPlacementTest}
              className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-purple-200 dark:border-purple-800 hover:border-purple-500 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-purple-100 dark:bg-purple-950 text-purple-600 flex items-center justify-center mb-4">
                  <Target className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Seviye Tespit Sınavı
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  15 soru ile A1-C1 arası düzeyinizi belirleyin ve en uygun ders önerisini alın.
                </p>
              </div>

              <div className="mt-6 flex items-center gap-2 text-xs font-bold text-purple-600 dark:text-purple-400">
                <Play className="w-4 h-4 fill-purple-500" />
                <span>Sınava Başla</span>
              </div>
            </div>

            {/* Mode 1: Timed Test */}
            <div
              onClick={startTimedSprint}
              className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-amber-400 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 flex items-center justify-center mb-4">
                  <Timer className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Zamana Karşı Test (60 Saniye)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  60 saniye içinde maksimum sayıda Almanca kelimeyi doğru bil! Her doğru cevap için ekstra XP kazan.
                </p>
              </div>

              <div className="mt-6 flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400">
                <Play className="w-4 h-4 fill-amber-500" />
                <span>Testi Başlat</span>
              </div>
            </div>

            {/* Mode 2: Speech & Microphone Practice */}
            <div
              onClick={() => setActiveMode('speech')}
              className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-400 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center mb-4">
                  <Mic className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Konuşma ve Telaffuz Pratiği
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                  Mikrofonunu kullanarak örnek Almanca cümleleri seslendir. Ses tanıma motoruyla eşleşme oranını gör.
                </p>
              </div>

              <div className="mt-6 flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <Play className="w-4 h-4 fill-emerald-500" />
                <span>Pratiğe Başla</span>
              </div>
            </div>

            {/* Mode 4: Level Soru Havuzu Testi */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-blue-400 hover:shadow-lg transition-all flex flex-col justify-between sm:col-span-2 lg:col-span-3">
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center">
                      <Target className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white">
                        Kapsamlı Seviye Soru Havuzu Sınavı
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Her seviyede 50+ soru havuzu. 10, 20, 50 soru veya havuzun tamamını seçin!
                      </p>
                    </div>
                  </div>

                  {/* Level picker */}
                  <div className="flex gap-1 bg-slate-100 dark:bg-slate-700 p-1 rounded-xl">
                    {(['A1', 'A2', 'B1', 'B2', 'C1'] as CEFRLevel[]).map((lvl) => (
                      <button
                        key={lvl}
                        onClick={() => setTestLevel(lvl)}
                        className={`px-3 py-1.5 rounded-lg font-bold text-xs transition cursor-pointer ${
                          testLevel === lvl
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-3 bg-blue-50/60 dark:bg-blue-950/20 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-800 dark:text-blue-300 flex items-center justify-between">
                  <span>
                    Seçilen Seviye: <strong>{testLevel}</strong> • Soru Havuzundaki Soru Sayısı: <strong>{getLevelQuestionPool(testLevel).length} Soru</strong>
                  </span>
                  <span className="hidden sm:inline">Sorular karıştırılır • Yanlışlar tekrar çözülebilir</span>
                </div>
              </div>

              <div className="mt-4 flex justify-end">
                <button
                  onClick={() => setActiveMode('level_test')}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-[0_3px_0_#1d4ed8] active:translate-y-0.5 active:shadow-none transition cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>{testLevel} Sınavını Başlat</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Level Test Runner Screen */}
      {activeMode === 'level_test' && (
        <div className="h-[80vh] bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden flex flex-col">
          <ExerciseRunner
            exercises={getLevelQuestionPool(testLevel)}
            title={`${testLevel} Kapsamlı Seviye Sınavı`}
            onComplete={(correct) => {
              addXp(correct * 5);
              setActiveMode('menu');
            }}
            onExit={() => setActiveMode('menu')}
          />
        </div>
      )}

      {/* Timed Challenge Screen */}
      {activeMode === 'timed' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl p-6 sm:p-8">
          {!timedCompleted ? (
            <>
              {/* Top timer bar */}
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-700">
                <button
                  onClick={() => {
                    setIsTimerRunning(false);
                    setActiveMode('menu');
                  }}
                  className="text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  ✕ Vazgeç
                </button>

                <div className="flex items-center gap-2 bg-amber-50 dark:bg-amber-950 px-3 py-1 rounded-full text-amber-700 dark:text-amber-300 font-black text-sm">
                  <Timer className="w-4 h-4" />
                  <span>{timeLeft}s</span>
                </div>

                <div className="text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                  <span>Skor: {timedScore}</span>
                </div>
              </div>

              {/* Current Question */}
              {timedQuestions[timedIndex] && (
                <div className="space-y-6 text-center">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Soru {timedIndex + 1} / {timedQuestions.length}
                  </span>

                  <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                    <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                      {timedQuestions[timedIndex].word}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {timedQuestions[timedIndex].options.map((opt: string, i: number) => (
                      <button
                        key={i}
                        onClick={() => handleTimedAnswer(opt)}
                        className="p-4 rounded-xl border-2 border-slate-200 dark:border-slate-700 hover:border-amber-400 bg-white dark:bg-slate-800 font-bold text-sm text-slate-800 dark:text-slate-100 shadow-[0_3px_0_#e2e8f0] active:translate-y-0.5 active:shadow-none transition cursor-pointer"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Timed Completed Summary */
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto text-2xl font-black">
                🏆
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                Süre Doldu!
              </h3>
              <p className="text-sm text-slate-500">
                Tebrikler! 60 saniyede toplam <strong>{timedScore}</strong> doğru cevap verdin.
              </p>
              <div className="p-3 bg-amber-50 dark:bg-amber-950/60 rounded-xl inline-block text-amber-800 dark:text-amber-200 font-black text-base">
                +{timedScore * 10} XP Kazandın!
              </div>
              <div className="pt-4 flex justify-center gap-3">
                <button
                  onClick={startTimedSprint}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-xs cursor-pointer"
                >
                  Tekrar Dene
                </button>
                <button
                  onClick={() => setActiveMode('menu')}
                  className="px-6 py-2.5 rounded-xl border border-slate-200 font-bold text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 cursor-pointer"
                >
                  Menüye Dön
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Speech Practice Screen */}
      {activeMode === 'speech' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <button
              onClick={() => setActiveMode('menu')}
              className="text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              ← Menüye Dön
            </button>
            <span className="text-xs font-bold text-slate-500">
              Cümle {speechSentenceIndex + 1} / {SPEECH_PROMPTS.length}
            </span>
          </div>

          <div className="p-6 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900 text-center space-y-2">
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider block">
              Hedef Cümle:
            </span>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              "{currentSpeechPrompt.de}"
            </h3>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {currentSpeechPrompt.tr}
            </p>

            <button
              onClick={() => speakGerman(currentSpeechPrompt.de, profile.speechSpeed)}
              className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-emerald-200 text-emerald-700 text-xs font-bold hover:bg-emerald-50 transition cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5" /> Doğru Telaffuzu Dinle
            </button>
          </div>

          {/* Microphone interaction */}
          <div className="text-center space-y-3">
            <button
              onClick={handleToggleSpeech}
              className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center transition-all cursor-pointer ${
                isRecording
                  ? 'bg-rose-500 text-white animate-pulse shadow-xl shadow-rose-200 scale-105'
                  : 'bg-emerald-500 text-white hover:bg-emerald-600 shadow-lg shadow-emerald-200 active:scale-95'
              }`}
            >
              {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
            </button>
            <span className="text-xs font-semibold text-slate-500 block">
              {isRecording ? 'Dinleniyor... Lütfen Almanca konuşun.' : 'Mikrofona dokunun ve cümleyi okuyun'}
            </span>
          </div>

          {spokenText && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center space-y-1 text-xs">
              <span className="text-slate-400 block">Algılanan Metin:</span>
              <p className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                "{spokenText}"
              </p>
              {speechScore !== null && (
                <div className="pt-2">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                      speechScore >= 70
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    Eşleşme Oranı: %{speechScore} {speechScore >= 70 ? '✓ Başarılı!' : '— Tekrar dene'}
                  </span>
                </div>
              )}
            </div>
          )}

          {speechError && (
            <p className="text-xs text-rose-500 text-center">{speechError}</p>
          )}

          {/* Transparent Notice as required by user prompt */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-[11px] text-slate-400 leading-normal">
            ℹ️ <strong>Şeffaf Bilgilendirme:</strong> Bu telaffuz analizi, cihazınızın yerel Web Speech API ses tanıma motorunu kullanarak konuşmanızı metne dönüştürür ve hedef cümle ile kelime benzerliğini ölçer. Fonetik boğaz/dil akustiği analizi yerine metinsel kelime eşleşmesi kontrol edilmektedir.
          </div>

          {/* Navigation to next sentence */}
          <div className="pt-2 flex justify-between">
            <button
              disabled={speechSentenceIndex === 0}
              onClick={() => {
                setSpeechSentenceIndex((i) => i - 1);
                setSpokenText('');
                setSpeechScore(null);
              }}
              className="px-4 py-2 text-xs font-bold rounded-xl border border-slate-200 disabled:opacity-40 cursor-pointer"
            >
              Önceki Cümle
            </button>
            <button
              disabled={speechSentenceIndex + 1 >= SPEECH_PROMPTS.length}
              onClick={() => {
                setSpeechSentenceIndex((i) => i + 1);
                setSpokenText('');
                setSpeechScore(null);
              }}
              className="px-4 py-2 text-xs font-bold rounded-xl bg-emerald-600 text-white disabled:opacity-40 cursor-pointer"
            >
              Sonraki Cümle
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
