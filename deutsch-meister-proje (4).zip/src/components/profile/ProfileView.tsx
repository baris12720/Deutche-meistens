import React, { useState } from 'react';
import {
  Flame,
  Zap,
  BookOpen,
  Award,
  Download,
  Upload,
  RotateCcw,
  Volume2,
  VolumeX,
  Gauge,
  CheckCircle2,
  Heart,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ALL_BADGES } from '../../data/badges';
import { MeisterMax } from '../mascot/MeisterMax';
import { CEFR_LEVEL_DETAILS, ALL_UNITS_BY_LEVEL } from '../../data/levels';
import { CEFRLevel } from '../../types';

export const ProfileView: React.FC = () => {
  const {
    profile,
    toggleSound,
    setSpeechSpeed,
    setDailyGoalXp,
    exportData,
    importData,
    resetProgress,
  } = useApp();

  const [importJsonText, setImportJsonText] = useState('');
  const [showImportBox, setShowImportBox] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const totalMasteredWords = Object.values(profile.wordCards).filter(
    (w) => w.status === 'mastered'
  ).length;

  const handleExport = () => {
    const json = exportData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deutsch_meister_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    setStatusMessage('İlerlemeniz başarıyla JSON dosyası olarak indirildi!');
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleImport = () => {
    if (!importJsonText.trim()) return;
    const ok = importData(importJsonText);
    if (ok) {
      setStatusMessage('Yedek başarıyla yüklendi!');
      setShowImportBox(false);
      setImportJsonText('');
    } else {
      setStatusMessage('Geçersiz yedek dosyası formatı. Lütfen kontrol edin.');
    }
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleReset = () => {
    if (window.confirm('Tüm ilerlemenizi, XP puanlarınızı ve kayıtlı kelimelerinizi sıfırlamak istediğinize emin misiniz?')) {
      resetProgress();
      setStatusMessage('İlerlemeniz sıfırlandı.');
      setTimeout(() => setStatusMessage(null), 3000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Profile Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs flex flex-col sm:flex-row items-center gap-6">
        <MeisterMax mood="happy" size="lg" />

        <div className="text-center sm:text-left flex-1 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>%100 Ücretsiz • Sonsuz Can • Ödeme Duvarı Yok</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {profile.name}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Kayıt gerektirmeden tüm dersler tarayıcınızda ve çevrimdışı güvende saklanır.
          </p>

          {/* Daily Goal bar */}
          <div className="pt-2 max-w-sm">
            <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
              <span>Bugünkü Hedef</span>
              <span>{profile.todayXp} / {profile.dailyGoalXp} XP</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (profile.todayXp / profile.dailyGoalXp) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-2xl text-xs font-bold text-center animate-in fade-in">
          {statusMessage}
        </div>
      )}

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Streak */}
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center">
          <Flame className="w-6 h-6 text-amber-500 mx-auto mb-1 fill-amber-400" />
          <span className="text-2xl font-black text-amber-900 dark:text-amber-200 block">
            {profile.streak} Gün
          </span>
          <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300">
            Günlük Seri
          </span>
        </div>

        {/* Total XP */}
        <div className="p-4 rounded-2xl bg-yellow-50 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-800 text-center">
          <Zap className="w-6 h-6 text-yellow-500 mx-auto mb-1 fill-yellow-400" />
          <span className="text-2xl font-black text-yellow-900 dark:text-yellow-200 block">
            {profile.xp} XP
          </span>
          <span className="text-[11px] font-bold text-yellow-700 dark:text-yellow-300">
            Toplam Deneyim
          </span>
        </div>

        {/* Completed Lessons */}
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center">
          <BookOpen className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
          <span className="text-2xl font-black text-emerald-900 dark:text-emerald-200 block">
            {profile.completedLessons.length}
          </span>
          <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
            Tamamlanan Ders
          </span>
        </div>

        {/* Mastered Words */}
        <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center">
          <CheckCircle2 className="w-6 h-6 text-blue-600 mx-auto mb-1" />
          <span className="text-2xl font-black text-blue-900 dark:text-blue-200 block">
            {totalMasteredWords}
          </span>
          <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300">
            Öğrenilen Kelime
          </span>
        </div>
      </div>

      {/* Level Breakdown Progress */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <span>📊</span> Seviye Bazında İlerleme
        </h3>

        <div className="space-y-3">
          {(['A1', 'A2', 'B1', 'B2', 'C1'] as CEFRLevel[]).map((lvl) => {
            const units = ALL_UNITS_BY_LEVEL[lvl] || [];
            const total = units.reduce((acc, u) => acc + u.lessons.length, 0);
            const done = units.reduce(
              (acc, u) => acc + u.lessons.filter((l) => profile.completedLessons.includes(l.id)).length,
              0
            );
            const pct = Math.round((done / Math.max(1, total)) * 100);

            return (
              <div key={lvl} className="space-y-1">
                <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
                  <span className="font-extrabold">{lvl} Seviyesi</span>
                  <span>%{pct} ({done}/{total} Ders)</span>
                </div>
                <div className="h-2.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Badges Shelf */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>🏆</span> Başarı Rozetleri ({profile.unlockedBadges.length}/{ALL_BADGES.length})
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {ALL_BADGES.map((b) => {
            const isUnlocked = profile.unlockedBadges.includes(b.id);
            return (
              <div
                key={b.id}
                className={`p-3.5 rounded-2xl border text-center transition ${
                  isUnlocked
                    ? 'bg-purple-50/70 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800'
                    : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800 opacity-40 grayscale'
                }`}
              >
                <span className="text-3xl block mb-1">{b.icon}</span>
                <span className="text-xs font-black text-slate-900 dark:text-white block">
                  {b.title}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-snug">
                  {b.description}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Preferences & Settings */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          ⚙️ Uygulama & Ses Ayarları
        </h3>

        <div className="space-y-4">
          {/* Sound Toggle */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Ses Efektleri
              </span>
              <span className="text-xs text-slate-400">
                Doğru ve yanlış cevap chimes sesleri
              </span>
            </div>
            <button
              onClick={toggleSound}
              className={`p-2.5 rounded-xl border transition cursor-pointer ${
                profile.soundEnabled
                  ? 'bg-emerald-50 text-emerald-600 border-emerald-300'
                  : 'bg-slate-100 text-slate-400 border-slate-200'
              }`}
            >
              {profile.soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>

          {/* Speech Speed */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Almanca Ses Hızı
              </span>
              <span className="text-xs text-slate-400">
                Kelime ve cümle telaffuz hızı
              </span>
            </div>
            <div className="flex gap-2">
              {[
                { label: 'Yavaş (0.75x)', val: 0.75 },
                { label: 'Normal (0.95x)', val: 0.95 },
              ].map((s) => (
                <button
                  key={s.val}
                  onClick={() => setSpeechSpeed(s.val)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    profile.speechSpeed === s.val
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Daily Goal Selector */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Günlük Hedef
              </span>
              <span className="text-xs text-slate-400">
                Her gün kazanmak istediğin minimum XP
              </span>
            </div>
            <div className="flex gap-2">
              {[20, 30, 50, 100].map((goal) => (
                <button
                  key={goal}
                  onClick={() => setDailyGoalXp(goal)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    profile.dailyGoalXp === goal
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {goal} XP
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Data Backup & Restore */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            💾 Veri Güvenliği ve Yedekleme (Çevrimdışı / Yerel)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            İlerlemeniz cihazınızın yerel hafızasında saklanır. Telefonunuzu değiştirirseniz ilerlemenizi JSON olarak yedekleyip diğer cihaza kolayca aktarabilirsiniz.
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold shadow-xs hover:opacity-90 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>İlerlememi Yedekle (JSON İndir)</span>
          </button>

          <button
            onClick={() => setShowImportBox(!showImportBox)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Yedeği Yükle</span>
          </button>

          <button
            onClick={handleReset}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition cursor-pointer ml-auto"
          >
            <RotateCcw className="w-4 h-4" />
            <span>İlerlemeyi Sıfırla</span>
          </button>
        </div>

        {showImportBox && (
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              Daha önce indirdiğiniz JSON yedek metnini buraya yapıştırın:
            </span>
            <textarea
              rows={4}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder='{"xp": 150, "streak": 3, ...}'
              className="w-full p-2.5 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowImportBox(false)}
                className="px-3 py-1.5 text-xs text-slate-500 font-bold"
              >
                İptal
              </button>
              <button
                onClick={handleImport}
                className="px-4 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
              >
                Yedeği Uygula
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
