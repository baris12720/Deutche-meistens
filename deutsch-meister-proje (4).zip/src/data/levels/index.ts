import { CEFRLevel, Unit } from '../../types';
import { A1_UNITS } from './a1';
import { A2_UNITS } from './a2';
import { B1_UNITS } from './b1';
import { B2_UNITS } from './b2';
import { C1_UNITS } from './c1';

export const ALL_UNITS_BY_LEVEL: Record<CEFRLevel, Unit[]> = {
  A1: A1_UNITS,
  A2: A2_UNITS,
  B1: B1_UNITS,
  B2: B2_UNITS,
  C1: C1_UNITS,
};

export const CEFR_LEVEL_DETAILS: Record<
  CEFRLevel,
  {
    nameTr: string;
    descriptionTr: string;
    badgeColor: string;
    borderColor: string;
    tagBg: string;
    totalLessons: number;
  }
> = {
  A1: {
    nameTr: 'A1 - Başlangıç Seviyesi',
    descriptionTr: 'Sıfırdan Almancaya ilk adım. Selamlaşma, kendini tanıtma, sayılar, aile ve temel ihtiyaçlar.',
    badgeColor: 'bg-emerald-600 text-white',
    borderColor: 'border-emerald-500',
    tagBg: 'bg-emerald-50 text-emerald-800',
    totalLessons: A1_UNITS.reduce((acc, u) => acc + u.lessons.length, 0),
  },
  A2: {
    nameTr: 'A2 - Temel Almanca',
    descriptionTr: 'Günlük hayatı rahatça idare etme. Geçmiş zaman (Perfekt), yol tarifi, doktor, tren ve alışveriş.',
    badgeColor: 'bg-sky-600 text-white',
    borderColor: 'border-sky-500',
    tagBg: 'bg-sky-50 text-sky-800',
    totalLessons: A2_UNITS.reduce((acc, u) => acc + u.lessons.length, 0),
  },
  B1: {
    nameTr: 'B1 - Orta Seviye (Bağımsız Kullanıcı)',
    descriptionTr: 'Almanya\'da bağımsız yaşama seviyesi. Yan cümleler, iş mülakatı, ev kiralama ve resmi işler.',
    badgeColor: 'bg-indigo-600 text-white',
    borderColor: 'border-indigo-500',
    tagBg: 'bg-indigo-50 text-indigo-800',
    totalLessons: B1_UNITS.reduce((acc, u) => acc + u.lessons.length, 0),
  },
  B2: {
    nameTr: 'B2 - İleri Orta Seviye (Mesleki Almanca)',
    descriptionTr: 'Akıcı tartışma ve iş dünyası. Pasif yapı, N-Deklination, sabit fiil edatları ve resmi yazışmalar.',
    badgeColor: 'bg-amber-600 text-white',
    borderColor: 'border-amber-500',
    tagBg: 'bg-amber-50 text-amber-800',
    totalLessons: B2_UNITS.reduce((acc, u) => acc + u.lessons.length, 0),
  },
  C1: {
    nameTr: 'C1 - İleri Almanca (Akademik & Profesyonel)',
    descriptionTr: 'Üniversite ve yüksek bürokrasi düzeyi. Nominal stil, Konjunktiv I, retorik ve edebi metin tahlili.',
    badgeColor: 'bg-rose-600 text-white',
    borderColor: 'border-rose-500',
    tagBg: 'bg-rose-50 text-rose-800',
    totalLessons: C1_UNITS.reduce((acc, u) => acc + u.lessons.length, 0),
  },
};
