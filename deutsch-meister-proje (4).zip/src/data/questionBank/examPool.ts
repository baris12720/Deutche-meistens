import { CEFRLevel, DTZQuestion } from '../../types';
import { DTZ_QUESTIONS } from './dtzQuestions';
import { GOETHE_QUESTIONS } from './goetheQuestions';

export const ALL_EXAM_QUESTIONS: DTZQuestion[] = [...GOETHE_QUESTIONS, ...DTZ_QUESTIONS];

export const getExamPool = (level: CEFRLevel): DTZQuestion[] =>
  ALL_EXAM_QUESTIONS.filter((q) => q.level === level);
