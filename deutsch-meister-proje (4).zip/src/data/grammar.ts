import { GrammarTopic } from '../types';

export const GRAMMAR_TOPICS: GrammarTopic[] = [
  {
    id: 'g_alphabet',
    titleTr: 'Almanca Alfabe ve Telaffuz Kuralları',
    titleDe: 'Das Alphabet und Ausspracheregeln',
    level: 'A1',
    summaryTr: 'Almancadaki özel harfler (Ä, Ö, Ü, ß) ve harf ikililerinin (ch, sp, st, ei, ie, eu) okunuş mantığı.',
    contentMarkdownTr: `
Almanca alfabesinde Türkçeden farklı olarak 26 standart Latin harfinin yanı sıra **üç Umlaut (Ä, Ö, Ü)** ve **bir özel sert harf (ß - Eszett / Scharfes S)** bulunur.

### 1. Özel Harfler
- **Ä / ä**: Türkçedeki açık "e" gibi okunur (Mädchen -> Medhın).
- **Ö / ö**: Türkçedeki "ö" gibidir (schön -> şön).
- **Ü / ü**: Türkçedeki "ü" gibidir (über -> üba).
- **ß (Eszett)**: Çift "ss" anlamına gelir ve sert "s" sesi verir (Straße -> Ştrase). Küçük harftir, kelime başında asla bulunmaz.

### 2. Önemli Harf Kombinasyonları
- **ei**: "ay" şeklinde okunur -> *mein* (mayn), *zwei* (tsvay), *arbeiten* (arbaytın).
- **ie**: Uzun bir "i:" sesi verir -> *sie* (zi:), *Knie* (kni:), *Liebe* (li:be).
- **eu / äu**: "oy" şeklinde okunur -> *Euro* (oyro), *heute* (hoyte), *Häuser* (hoyza).
- **ch**: 
  - a, o, u harflerinden sonra boğazdan gelen hırıltılı "h" -> *Buch*, *Nacht*, *doch*.
  - e, i, ä, ö, ü veya sessizlerden sonra yumuşak damağa yakın hışırtılı ses -> *ich*, *Milch*, *Recht*.
- **sp / st**: Kelime başında "şp" ve "şt" olarak okunur -> *Sport* (Şport), *Stadt* (Ştat).
- **sch**: Türkçedeki "ş" sesidir -> *Schule* (Şule), *schreiben* (şraybın).
- **w**: Türkçedeki "v" sesidir -> *Wasser* (Vassa), *wir* (via).
- **v**: Genellikle sert "f" okunur -> *Vater* (Fata), *vier* (fia). (Yabancı kökenlilerde "v" okunur: *Vase*).
- **z**: "ts" sesi verir -> *Zimmer* (Tsimma), *Zug* (Tsuk).
- **-er son eki**: Kelime sonundaki "-er" hafif yutularak yumuşak bir "a" gibi duyulur -> *Vater* (Fata), *Mutter* (Muta).
    `,
    tables: [
      {
        caption: 'Almanca Ses İkilikleri ve Türkçe Okunuşları',
        headers: ['Harf Grubu', 'Okunuş', 'Almanca Örnek', 'Türkçe Anlamı'],
        rows: [
          ['ei', 'ay', 'mein / nein', 'benim / hayır'],
          ['ie', 'i (uzun)', 'sie / Liebe', 'o/onlar / aşk'],
          ['eu', 'oy', 'Euro / heute', 'Euro / bugün'],
          ['sch', 'ş', 'Schule / Tisch', 'okul / masa'],
          ['sp (başta)', 'şp', 'Sport / spielen', 'spor / oynamak'],
          ['st (başta)', 'şt', 'Stadt / Straße', 'şehir / sokak'],
          ['v (Almanca)', 'f', 'Vater / vier', 'baba / dört'],
          ['z', 'ts', 'Zeit / zwei', 'zaman / iki'],
        ],
      },
    ],
    examples: [
      { german: 'Ich liebe deutsche Musik.', turkish: 'Alman müziğini seviyorum.', note: 'ie = uzun i' },
      { german: 'Mein Name ist Stefan.', turkish: 'Benim adım Stefan.', note: 'ei = ay, st = şt' },
      { german: 'Heute habe ich viel Zeit.', turkish: 'Bugün çok vaktim var.', note: 'eu = oy, z = ts' },
    ],
    exercises: [
      {
        id: 'g_ex_alpha_1',
        type: 'multiple_choice',
        instructionTr: '"Kommen Sie heute?" cümlesindeki "heute" kelimesi nasıl telaffuz edilir?',
        prompt: 'heute',
        audioPrompt: 'heute',
        options: ['hoyte', 'hayte', 'hi:te', 'hovte'],
        correctAnswer: 'hoyte',
        explanationTr: '"eu" ikilisi "oy" şeklinde telaffuz edilir.',
      },
      {
        id: 'g_ex_alpha_2',
        type: 'multiple_choice',
        instructionTr: 'Almancada "ei" harf grubu nasıl okunur?',
        prompt: 'ei harf grubu',
        options: ['ay', 'ey', 'i', 'oy'],
        correctAnswer: 'ay',
        explanationTr: '"ei" daima "ay" okunur (mein, zwei, kein).',
      },
    ],
  },
  {
    id: 'g_articles',
    titleTr: 'Artikel Sistemi (der, die, das)',
    titleDe: 'Das Genus und die Artikel',
    level: 'A1',
    summaryTr: 'Almanca isimlerin cinsiyetleri: Eril (der), Dişil (die) ve Nötr (das). Artikelleri tahmin etmenin pratik ipuçları.',
    contentMarkdownTr: `
Almancada **her ismin büyük harfle yazılması** ve **bir cinsiyete (artikele)** sahip olması temel kuraldır.

Üç çeşit artikel vardır:
1. **der (Eril / Maskulin - Mavi)**
2. **die (Dişil / Feminin - Kırmızı)**
3. **das (Nötr / Neutrum - Yeşil)**
4. **Çoğul (Plural) artikeli her zaman "die"dır!**

### Artikelleri Tahmin Etmenin Altın İpuçları:

#### 1. DER (Eril) Olanlar:
- Erkek şahıslar ve meslekler: *der Mann, der Vater, der Arzt, der Kellner*
- Günler, aylar ve mevsimler: *der Montag, der Mai, der Sommer, der Winter*
- Yönler ve rüzgarlar: *der Norden, der Süden, der Regen*
- Otomobil markaları ve alkollü içecekler (bira hariç): *der BMW, der Wein*
- Şu eklerle biten isimler:
  - **-er**: *der Computer, der Fahrer*
  - **-ling**: *der Frühling, der Schmetterling*
  - **-or**: *der Motor, der Doktor*
  - **-ismus**: *der Optimismus, der Realismus*

#### 2. DIE (Dişil) Olanlar:
- Kadın şahıslar ve meslekler: *die Frau, die Mutter, die Ärztin*
- Meyve ve ağaç isimlerinin çoğu: *die Banane, die Orange*
- Sayı isimleri: *die Eins, die Million*
- **Şu eklerle biten isimler %99 DİE alır**:
  - **-ung**: *die Wohnung, die Zeitung, die Übung, die Hoffnung*
  - **-heit**: *die Freiheit, die Gesundheit*
  - **-keit**: *die Möglichkeit, die Freundlichkeit*
  - **-schaft**: *die Freundschaft, die Mannschaft*
  - **-tät**: *die Universität, die Realität*
  - **-ion**: *die Information, die Lektion*
  - **-ie**: *die Energie, die Familie*
  - **-e ile biten iki heceli kelimelerin çoğu**: *die Lampe, die Sonne, die Tasche*

#### 3. DAS (Nötr) Olanlar:
- Küçültme ekleri alanlar:
  - **-chen**: *das Mädchen, das Brötchen*
  - **-lein**: *das Fräulein*
- İsimleşmiş mastar fiiller: *das Essen (yemek), das Leben (yaşam), das Lernen (öğrenme)*
- Metaller ve kimyasal elementler: *das Gold, das Silber, das Eisen*
- Renk isimleri: *das Blau, das Grün*
- Şu eklerle bitenler:
  - **-ment**: *das Dokument, das Instrument*
  - **-um**: *das Zentrum, das Museum*
  - **-o**: *das Auto, das Kino, das Foto*
    `,
    tables: [
      {
        caption: 'Almanca Artikeller ve İpucu Ekleri',
        headers: ['Artikel', 'Cinsiyet', 'Tipik Son Ekler', 'Örnek Kelimeler'],
        rows: [
          ['der', 'Eril (Maskulin)', '-er, -ling, -or, -ismus', 'der Lehrer, der Frühling, der Motor'],
          ['die', 'Dişil (Feminin)', '-ung, -heit, -keit, -schaft, -tät, -ion', 'die Wohnung, die Freiheit, die Information'],
          ['das', 'Nötr (Neutrum)', '-chen, -lein, -ment, -um, mastarlar', 'das Mädchen, das Dokument, das Zentrum'],
          ['die (çoğul)', 'Çoğul (Plural)', 'Tüm çoğul isimlerin artikeli die olur', 'die Bücher, die Autos, die Häuser'],
        ],
      },
    ],
    examples: [
      { german: 'Der Tisch ist sehr groß.', turkish: 'Masa çok büyük.', note: 'der Tisch' },
      { german: 'Die Wohnung hat drei Zimmer.', turkish: 'Dairenin üç odası var.', note: '-ung ile bittiği için die' },
      { german: 'Das Mädchen lernt schnell.', turkish: 'Kız çocuğu hızlı öğreniyor.', note: '-chen ile bittiği için das' },
    ],
    exercises: [
      {
        id: 'g_ex_art_1',
        type: 'article_select',
        instructionTr: '"Zeitung" (Gazete) kelimesinin artikeli nedir?',
        word: 'Zeitung',
        turkish: 'Gazete',
        correctArticle: 'die',
        explanationTr: '-ung ile biten isimler daima "die" alır (die Zeitung).',
      },
      {
        id: 'g_ex_art_2',
        type: 'article_select',
        instructionTr: '"Auto" (Araba) kelimesinin artikeli nedir?',
        word: 'Auto',
        turkish: 'Araba',
        correctArticle: 'das',
        explanationTr: '-o ile biten yabancı kökenli kelimelerin çoğu "das" alır (das Auto, das Kino).',
      },
      {
        id: 'g_ex_art_3',
        type: 'article_select',
        instructionTr: '"Lehrer" (Öğretmen - Erkek) kelimesinin artikeli nedir?',
        word: 'Lehrer',
        turkish: 'Öğretmen (Erkek)',
        correctArticle: 'der',
        explanationTr: 'Erkek meslekleri ve -er eki "der" alır.',
      },
    ],
  },
  {
    id: 'g_pronouns',
    titleTr: 'Kişi Zamirleri (Personalpronomen)',
    titleDe: 'Die Personalpronomen',
    level: 'A1',
    summaryTr: 'ich, du, er, sie, es, wir, ihr, sie ve resmi hitap "Sie".',
    contentMarkdownTr: `
Almancada kişi zamirleri Türkçedeki ben, sen, o, biz, siz, onlar zamirlerine karşılık gelir:

- **ich**: ben
- **du**: sen (arkadaşça, tekil)
- **er**: o (eril isimlerin yerine geçer - der Mann -> er)
- **sie**: o (dişil isimlerin yerine geçer - die Frau -> sie)
- **es**: o (nötr isimlerin yerine geçer - das Kind -> es)
- **wir**: biz
- **ihr**: siz (birden fazla arkadaşa hitap ederken)
- **sie**: onlar
- **Sie (büyük harfle)**: Siz (resmi, nezaket zamiri, tekil ve çoğul için geçerli)
    `,
    tables: [
      {
        caption: 'Almanca Kişi Zamirleri Tablosu',
        headers: ['Almanca Zamir', 'Türkçe Anlamı', 'Kullanım Örneği'],
        rows: [
          ['ich', 'ben', 'Ich bin Öğrenci.'],
          ['du', 'sen', 'Woher kommst du?'],
          ['er', 'o (erkek/der)', 'Er heißt Can.'],
          ['sie', 'o (kadın/die)', 'Sie ist nett.'],
          ['es', 'o (nötr/das)', 'Es regnet.'],
          ['wir', 'biz', 'Wir lernen Deutsch.'],
          ['ihr', 'siz (arkadaşlar)', 'Kommt ihr mit?'],
          ['sie', 'onlar', 'Sie wohnen in Izmir.'],
          ['Sie', 'Siz (resmi)', 'Wie heißen Sie?'],
        ],
      },
    ],
    examples: [
      { german: 'Wo ist der Tisch? - Er ist im Wohnzimmer.', turkish: 'Masa nerede? - O oturma odasında.', note: 'der Tisch eril olduğu için "er" ile karşılanır' },
      { german: 'Wo ist die Tasche? - Sie ist hier.', turkish: 'Çanta nerede? - O burada.', note: 'die Tasche dişil olduğu için "sie"' },
    ],
    exercises: [
      {
        id: 'g_ex_pron_1',
        type: 'multiple_choice',
        instructionTr: 'Resmi bir ortamda bir doktora "Siz nasılsınız?" derken hangi zamir kullanılır?',
        prompt: 'Resmi "Siz"',
        options: ['Sie', 'ihr', 'du', 'er'],
        correctAnswer: 'Sie',
        explanationTr: 'Resmi nezaket hitabında her zaman büyük harfle "Sie" kullanılır.',
      },
    ],
  },
  {
    id: 'g_sein_haben',
    titleTr: 'Sein ve Haben Fiilleri',
    titleDe: 'Die Verben sein und haben',
    level: 'A1',
    summaryTr: 'Almancanın en temel iki yardımcı fiilinin çekimleri ve kullanım yerleri.',
    contentMarkdownTr: `
**sein (olmak)** ve **haben (sahip olmak / var)** fiilleri hem kendi başlarına ana fiil hem de geçmiş zamanda yardımcı fiildir. Düzensiz oldukları için ezberlenmelidir.

### sein (olmak) Çekimi:
- ich **bin** (ben ...-yim)
- du **bist** (sen ...-sin)
- er/sie/es **ist** (o ...-dir)
- wir **sind** (biz ...-yiz)
- ihr **seid** (siz ...-siniz)
- sie/Sie **sind** (onlar/Siz ...-siniz)

### haben (sahip olmak) Çekimi:
- ich **habe** (sahibim / bende var)
- du **hast** (sahipsin / sende var)
- er/sie/es **hat** (sahip / onda var)
- wir **haben** (sahibiz / bizde var)
- ihr **habt** (sahipsiniz / sizde var)
- sie/Sie **haben** (sahipler / onlarda/Sizde var)
    `,
    tables: [
      {
        caption: 'sein ve haben Çekim Karşılaştırması',
        headers: ['Zamir', 'sein (olmak)', 'haben (sahip olmak)'],
        rows: [
          ['ich', 'bin', 'habe'],
          ['du', 'bist', 'hast'],
          ['er / sie / es', 'ist', 'hat'],
          ['wir', 'sind', 'haben'],
          ['ihr', 'seid', 'habt'],
          ['sie / Sie', 'sind', 'haben'],
        ],
      },
    ],
    examples: [
      { german: 'Ich bin müde.', turkish: 'Yorgunum.' },
      { german: 'Wir haben ein neues Auto.', turkish: 'Yeni bir arabamız var.' },
      { german: 'Seid ihr bereit?', turkish: 'Hazır mısınız?' },
    ],
    exercises: [
      {
        id: 'g_ex_sh_1',
        type: 'fill_blank',
        instructionTr: 'Boşluğu uygun "sein" çekimiyle doldurun: "ihr ___ glücklich."',
        sentenceWithBlank: 'Ihr ___ glücklich.',
        turkishTranslation: 'Siz mutlusunuz.',
        options: ['seid', 'sind', 'bist', 'ist'],
        correctAnswer: 'seid',
      },
      {
        id: 'g_ex_sh_2',
        type: 'fill_blank',
        instructionTr: 'Boşluğu uygun "haben" çekimiyle doldurun: "Du ___ Zeit."',
        sentenceWithBlank: 'Du ___ viel Zeit.',
        turkishTranslation: 'Senin çok vaktin var.',
        options: ['hast', 'habe', 'hat', 'haben'],
        correctAnswer: 'hast',
      },
    ],
  },
  {
    id: 'g_regular_irregular_verbs',
    titleTr: 'Düzenli ve Düzensiz Fiiller (Präsens)',
    titleDe: 'Regelmäßige und unregelmäßige Verben',
    level: 'A1',
    summaryTr: 'Fiil köküne gelen şahıs ekleri (-e, -st, -t, -en, -t, -en) ve düzensiz fiillerde kök ses değişimi.',
    contentMarkdownTr: `
Almancada düzenli fiiller çekimlenirken mastar eki (-en) atılır ve kalan fiil köküne şu ekler gelir:

### Düzenli Çekim Kuralı (Örnek: lernen)
- ich: **-e** -> lern-**e**
- du: **-st** -> lern-**st**
- er/sie/es: **-t** -> lern-**t**
- wir: **-en** -> lern-**en**
- ihr: **-t** -> lern-**t**
- sie/Sie: **-en** -> lern-**en**

### Düzensiz Fiillerde Kök Ses Değişimi:
Düzensiz fiillerde sadece **du** ve **er/sie/es** şahıslarında kök sesli harfi değişir:
1. **e -> i**: geben (du gibst, er gibt), helfen (du hilfst, er hilft)
2. **e -> ie**: sehen (du siehst, er sieht), lesen (du liest, er liest)
3. **a -> ä**: fahren (du fährst, er fährt), schlafen (du schläfst, er schläft)
    `,
    tables: [
      {
        caption: 'Fiil Çekim Şablonu',
        headers: ['Zamir', 'Ek', 'lernen (düzenli)', 'fahren (düzensiz)'],
        rows: [
          ['ich', '-e', 'ich lerne', 'ich fahre'],
          ['du', '-st', 'du lernst', 'du fährst (a->ä)'],
          ['er/sie/es', '-t', 'er lernt', 'er fährt (a->ä)'],
          ['wir', '-en', 'wir lernen', 'wir fahren'],
          ['ihr', '-t', 'ihr lernt', 'ihr fahrt'],
          ['sie/Sie', '-en', 'sie lernen', 'sie fahren'],
        ],
      },
    ],
    examples: [
      { german: 'Er fährt jeden Tag mit dem Bus.', turkish: 'O her gün otobüsle gider.' },
      { german: 'Liest du gerne Bücher?', turkish: 'Severek kitap okur musun?' },
    ],
    exercises: [
      {
        id: 'g_ex_reg_1',
        type: 'verb_conjugation',
        instructionTr: '"sehen" fiilinin "du" zamirine göre çekimi nedir?',
        verbInfinitive: 'sehen',
        pronoun: 'du',
        turkishTranslation: 'sen görüyorsun',
        options: ['siehst', 'sehst', 'seht', 'sieht'],
        correctAnswer: 'siehst',
        explanationTr: 'sehen düzensizdir ve e -> ie olur: du siehst.',
      },
    ],
  },
  {
    id: 'g_modal_verbs',
    titleTr: 'Modal Fiiller (Tarz Fiilleri)',
    titleDe: 'Die Modalverben',
    level: 'A2',
    summaryTr: 'können, müssen, dürfen, wollen, sollen, möchten, mögen fiilleri ve cümledeki yerleri.',
    contentMarkdownTr: `
Modal fiiller bir eyleme yetenek, zorunluluk, izin, istek veya tavsiye katar.

### Cümle Yapısı Kuralı:
Modal fiil cümlenin **2. sırasında özneye göre çekimlenir**. Asıl fiil ise **mastar halde cümlenin en sonuna gider**:
*Örnek:* Ich **kann** sehr gut Deutsch **sprechen**.

### Modal Fiillerin Anlamları:
1. **können**: -ebilmek (yetenek veya olasılık) -> *Ich kann schwimmen.*
2. **müssen**: zorunda olmak (kesin kural/ihtiyaç) -> *Ich muss lernen.*
3. **dürfen**: izni olmak (yasaklar için 'nicht dürfen') -> *Hier darf man nicht parken.*
4. **wollen**: kesin istemek / niyet etmek -> *Ich will Arzt werden.*
5. **möchten**: nazikçe rica etmek / arzu etmek -> *Ich möchte einen Kaffee.*
6. **sollen**: -meli/-malı (tavsiye veya başkasının görevi) -> *Der Arzt sagt, ich soll schlafen.*
7. **mögen**: hoşlanmak / sevmek -> *Ich mag Schokolade.*
    `,
    tables: [
      {
        caption: 'Modal Fiillerin Präsens Çekimleri',
        headers: ['Zamir', 'können', 'müssen', 'dürfen', 'wollen', 'möchten'],
        rows: [
          ['ich', 'kann', 'muss', 'darf', 'will', 'möchte'],
          ['du', 'kannst', 'musst', 'darfst', 'willst', 'möchtest'],
          ['er/sie/es', 'kann', 'muss', 'darf', 'will', 'möchte'],
          ['wir', 'können', 'müssen', 'dürfen', 'wollen', 'möchten'],
          ['ihr', 'könnt', 'müsst', 'dürft', 'wollt', 'möchtet'],
          ['sie/Sie', 'können', 'müssen', 'dürfen', 'wollen', 'möchten'],
        ],
      },
    ],
    examples: [
      { german: 'Darf ich das Fenster öffnen?', turkish: 'Pencereyi açabilir miyim? (İzin)' },
      { german: 'Wir müssen heute arbeiten.', turkish: 'Bugün çalışmak zorundayız.' },
    ],
    exercises: [
      {
        id: 'g_ex_mod_1',
        type: 'sentence_builder',
        instructionTr: '"Yarın gelemem" cümlesini kurun.',
        turkishPrompt: 'Yarın gelemem.',
        correctGermanSentence: 'Ich kann morgen nicht kommen.',
        scrambledWords: ['kommen.', 'kann', 'morgen', 'Ich', 'nicht'],
      },
    ],
  },
  {
    id: 'g_akkusativ_dativ',
    titleTr: 'Akkusativ (-i hali) ve Dativ (-e hali)',
    titleDe: 'Akkusativ und Dativ',
    level: 'A2',
    summaryTr: 'İsmin halleri, soru kalıpları (Wen? / Wem?) ve artikellerin dönüşüm tablosu.',
    contentMarkdownTr: `
Almancada ismin halleri (Kasus) cümlenin mantığını belirler.

### 1. Akkusativ (-i Hali / Belirtme Hali):
- **Soru:** Wen? (Kimi?), Was? (Neyi?)
- Sadece **der** artikeli **den** olur!
- die -> **die** (değişmez)
- das -> **das** (değişmez)
- die (çoğul) -> **die** (değişmez)
- ein -> **einen**, mein -> **meinen**

### 2. Dativ (-e Hali / Yönelme & Bulunma Hali):
- **Soru:** Wem? (Kime?), Wo? (Nerede?)
- der -> **dem** (ein -> einem, mein -> meinem)
- das -> **dem** (ein -> einem, mein -> meinem)
- die -> **der** (ein -> einer, mein -> meiner)
- Çoğul die -> **den + isme -n eklenir** (den Kindern, den Tischen)
    `,
    tables: [
      {
        caption: 'Bütün Artikellerin Hal Değişim Özeti',
        headers: ['Hal', 'Eril (der)', 'Dişil (die)', 'Nötr (das)', 'Çoğul (die)'],
        rows: [
          ['Nominativ (Yalın)', 'der / ein', 'die / eine', 'das / ein', 'die / -'],
          ['Akkusativ (-i hali)', 'den / einen', 'die / eine', 'das / ein', 'die / -'],
          ['Dativ (-e hali)', 'dem / einem', 'der / einer', 'dem / einem', 'den / -n'],
          ['Genitiv (-in hali)', 'des (+s) / eines', 'der / einer', 'des (+s) / eines', 'der / -'],
        ],
      },
    ],
    examples: [
      { german: 'Ich sehe den Mann.', turkish: 'Adamı görüyorum.', note: 'der Mann -> den Mann (Akkusativ)' },
      { german: 'Ich helfe dem Mann.', turkish: 'Adama yardım ediyorum.', note: 'helfen Dativ ister -> dem Mann' },
      { german: 'Ich gebe der Frau ein Buch.', turkish: 'Kadına bir kitap veriyorum.', note: 'der Frau (Dativ), ein Buch (Akkusativ)' },
    ],
    exercises: [
      {
        id: 'g_ex_kas_1',
        type: 'fill_blank',
        instructionTr: 'Boşluğu doldurun: "Ich kaufe ___ Apfel (der Apfel - Akkusativ)."',
        sentenceWithBlank: 'Ich kaufe ___ Apfel.',
        turkishTranslation: 'Elmayı satın alıyorum.',
        options: ['den', 'der', 'dem', 'das'],
        correctAnswer: 'den',
      },
      {
        id: 'g_ex_kas_2',
        type: 'fill_blank',
        instructionTr: 'Boşluğu doldurun: "Ich danke ___ Lehrerin (die Lehrerin - Dativ)."',
        sentenceWithBlank: 'Ich danke ___ Lehrerin.',
        turkishTranslation: 'Öğretmene teşekkür ediyorum.',
        options: ['der', 'die', 'dem', 'den'],
        correctAnswer: 'der',
        explanationTr: 'danken fiili Dativ ister. Dişil isimlerde Dativ artikel "der" olur.',
      },
    ],
  },
  {
    id: 'g_trennbare_verben',
    titleTr: 'Ayrılabilen Fiiller (Trennbare Verben)',
    titleDe: 'Trennbare Verben im Satz',
    level: 'A2',
    summaryTr: 'aufstehen, einkaufen, mitkommen, anrufen fiillerinin ön eklerinin cümlenin sonuna gitmesi.',
    contentMarkdownTr: `
Almancada birçok fiil bir ön ek (Präfix) alarak yeni bir anlam kazanır. Ayrılabilen ön ekler çekimli cümlede **fiilden kopar ve cümlenin en sonuna gider**.

### En Çok Kullanılan Ayrılabilen Ön Ekler:
- **ab-**: abfahren (hareket etmek) -> *Der Zug fährt um 9 Uhr ab.*
- **an-**: anrufen (telefon etmek), ankommen (varmak) -> *Ich rufe dich an.*
- **auf-**: aufstehen (kalkmak), aufmachen (açmak) -> *Wann stehst du auf?*
- **aus-**: aussteigen (inmek), ausmachen (kapatmak) -> *Er steigt hier aus.*
- **ein-**: einkaufen (alışveriş yapmak) -> *Wir kaufen im Supermarkt ein.*
- **mit-**: mitkommen (birlikte gelmek) -> *Kommst du mit?*
- **vor-**: vorstellen (tanıtmak) -> *Ich stelle mich vor.*
    `,
    tables: [
      {
        caption: 'Ayrılabilen ve Ayrılamayan Ön Ekler',
        headers: ['Tür', 'Ön Ekler', 'Örnek Fiil', 'Cümle İçi Hali'],
        rows: [
          ['Ayrılabilen (Vurgulu)', 'ab-, an-, auf-, aus-, ein-, mit-, vor-, zu-', 'aufstehen', 'Ich stehe um 7 Uhr auf.'],
          ['Ayrılamayan (Vurgusuz)', 'be-, emp-, ent-, er-, ge-, miss-, ver-, zer-', 'verstehen', 'Ich verstehe alles.'],
        ],
      },
    ],
    examples: [
      { german: 'Ich lade dich zur Party ein.', turkish: 'Seni partiye davet ediyorum (einladen).' },
      { german: 'Er macht das Licht aus.', turkish: 'Işığı kapatıyor (ausmachen).' },
    ],
    exercises: [
      {
        id: 'g_ex_trennb_1',
        type: 'sentence_builder',
        instructionTr: '"Akşam alışveriş yapıyorum" cümlesini kurun.',
        turkishPrompt: 'Akşam alışveriş yapıyorum.',
        correctGermanSentence: 'Ich kaufe am Abend ein.',
        scrambledWords: ['ein.', 'kaufe', 'am', 'Ich', 'Abend'],
      },
    ],
  },
  {
    id: 'g_word_order',
    titleTr: 'Cümle Dizilişi ve Hauptsatz (Sözcük Sırası)',
    titleDe: 'Der Satzbau im Hauptsatz',
    level: 'A2',
    summaryTr: 'Almancanın en temel kuralı: Çekimli fiil düz cümlede daima 2. pozisyondadır!',
    contentMarkdownTr: `
Almanca cümle kurmanın altın kuralı: **ÇEKİMLİ FİİL DAİMA 2. SIRADADIR**.

Başa zaman zarfı, yer zarfı veya nesne gelse bile fiil 2. pozisyonu asla terk etmez:

- **1. Özne başta:**
  - *Ich* (1) **gehe** (2) *heute ins Kino* (3).
- **2. Zaman zarfı başta (Devrik Cümle / Inversion):**
  - *Heute* (1) **gehe** (2) *ich ins Kino* (3).
- **3. Yer başta:**
  - *In Berlin* (1) **wohnen** (2) *viele Menschen* (3).

### Soru Cümlelerinde Fiilin Yeri:
- **W-Fragen (W-soruları: Wo, Wann, Wie, Warum...):** Soru kelimesi 1. sırada, **fiil yine 2. sırada**: *Woher kommst du?*
- **Ja/Nein-Fragen (Evet/Hayır soruları):** Fiil **1. sıraya** geçer: ***Kommst** du aus der Türkei?*
    `,
    tables: [
      {
        caption: 'Hauptsatz Cümle Düzeni Şeması',
        headers: ['Pozisyon 1', 'Pozisyon 2 (FİİL)', 'Pozisyon 3 (Özne/Zarf)', 'Cümle Sonu'],
        rows: [
          ['Ich', 'lerne', 'heute Deutsch', 'zu Hause.'],
          ['Heute', 'lerne', 'ich Deutsch', 'zu Hause.'],
          ['Deutsch', 'lerne', 'ich heute', 'zu Hause.'],
        ],
      },
    ],
    examples: [
      { german: 'Am Montag fahre ich nach Hamburg.', turkish: 'Pazartesi günü Hamburg\'a gidiyorum.', note: 'Am Montag (1) + fahre (2) + ich (3)' },
    ],
    exercises: [
      {
        id: 'g_ex_order_1',
        type: 'sentence_builder',
        instructionTr: '"Bugün Berlin\'e gidiyoruz" cümlesini kurun.',
        turkishPrompt: 'Bugün Berlin\'e gidiyoruz.',
        correctGermanSentence: 'Heute fahren wir nach Berlin.',
        scrambledWords: ['nach', 'Heute', 'fahren', 'Berlin.', 'wir'],
      },
    ],
  },
  {
    id: 'g_passiv',
    titleTr: 'Pasif Yapı (Das Passiv)',
    titleDe: 'Das Passiv im Deutschen',
    level: 'B2',
    summaryTr: 'werden + Partizip II ile eyleme odaklanan edilgen cümleler kurma.',
    contentMarkdownTr: `
Pasif yapıda eylemi kimin yaptığı değil, eylemin kendisi önemlidir.

### Vorgangspassiv (Süreç Pasifi):
**werden (çekimli) + ... + Partizip II**
- Präsens: *Das Auto **wird** repariert.* (Araba tamir ediliyor.)
- Präteritum: *Das Auto **wurde** repariert.* (Araba tamir edildi.)
- Perfekt: *Das Auto **ist** repariert **worden**.* (Araba tamir edildi.)
- Modal fiille: *Das Auto **muss** repariert **werden**.* (Araba tamir edilmeli.)

Eğer eylemi yapan kişi belirtilmek istenirse:
- Şahıslar ve kurumlar için: **von + Dativ** (*vom Mechaniker / von der Firma*)
- Araç ve vasıtalar için: **durch + Akkusativ** (*durch ein Programm*)
    `,
    tables: [
      {
        caption: 'Pasif Zaman Formülleri',
        headers: ['Zaman Kipi', 'Yapı Formülü', 'Örnek Cümle'],
        rows: [
          ['Präsens', 'wird + Partizip II', 'Der Brief wird geschrieben.'],
          ['Präteritum', 'wurde + Partizip II', 'Der Brief wurde geschrieben.'],
          ['Perfekt', 'ist + Partizip II + worden', 'Der Brief ist geschrieben worden.'],
          ['Modalverb', 'muss + Partizip II + werden', 'Der Brief muss geschrieben werden.'],
        ],
      },
    ],
    examples: [
      { german: 'Hier wird Deutsch gesprochen.', turkish: 'Burada Almanca konuşulur.' },
      { german: 'Die Stadt wurde im Krieg zerstört.', turkish: 'Şehir savaşta yıkıldı.' },
    ],
    exercises: [
      {
        id: 'g_ex_pass_1',
        type: 'fill_blank',
        instructionTr: 'Boşluğu doldurun: "Das Buch ___ von vielen Menschen gelesen."',
        sentenceWithBlank: 'Das Buch ___ von vielen Menschen gelesen.',
        turkishTranslation: 'Kitap birçok insan tarafından okunuyor.',
        options: ['wird', 'ist', 'hat', 'macht'],
        correctAnswer: 'wird',
      },
    ],
  },
];
