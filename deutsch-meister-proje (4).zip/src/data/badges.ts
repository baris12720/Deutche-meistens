import { Badge } from '../types';

export const ALL_BADGES: Badge[] = [
  {
    id: 'first_lesson',
    title: 'İlk Adım',
    description: 'İlk Almanca dersini başarıyla tamamladın!',
    icon: '🚀',
  },
  {
    id: 'streak_3',
    title: 'Ateşli Başlangıç',
    description: '3 gün üst üste Almanca çalıştın!',
    icon: '🔥',
  },
  {
    id: 'streak_7',
    title: 'Haftalık Seri Şampiyonu',
    description: '7 günlük kesintisiz çalışma serisine ulaştın!',
    icon: '⚡',
  },
  {
    id: 'xp_100',
    title: 'XP Avcısı',
    description: 'Toplamda 100 Deneyim Puanına (XP) eriştin.',
    icon: '🏆',
  },
  {
    id: 'xp_500',
    title: 'Çalışkan Öğrenci',
    description: '500 XP toplayarak Almancada dev bir adım attın!',
    icon: '🌟',
  },
  {
    id: 'words_25',
    title: 'Kelime Kumbarası',
    description: '25 yeni Almanca kelime öğrendin veya tekrar ettin.',
    icon: '📚',
  },
  {
    id: 'grammar_master',
    title: 'Dil Bilgisi Kaşifi',
    description: 'Almanca dil bilgisi kütüphanesinden konular çalıştın.',
    icon: '🧠',
  },
  {
    id: 'article_champion',
    title: 'Artikel Ustası',
    description: 'der, die, das artikellerini başarıyla ayırt ettin.',
    icon: '🎯',
  },
  {
    id: 'dialogue_explorer',
    title: 'Almanya Yolcusu',
    description: 'Günlük hayatta geçen pratik diyalogları tamamladın.',
    icon: '🥨',
  },
  {
    id: 'speech_pioneer',
    title: 'Konuşma Öncüsü',
    description: 'Mikrofon ile Almanca telaffuz pratiği yaptın.',
    icon: '🎙️',
  },
];
