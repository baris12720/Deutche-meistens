import { CEFRLevel } from '../types';

export interface PlacementQuestion {
  id: string;
  level: CEFRLevel;
  instructionTr: string;
  promptDe: string;
  audioText?: string;
  turkishHint?: string;
  options: string[];
  correctAnswer: string;
  explanationTr: string;
  category: string;
}

export const PLACEMENT_QUESTIONS: PlacementQuestion[] = [
  // --- A1 LEVEL ---
  {
    id: 'pq_a1_1',
    level: 'A1',
    category: 'Fiil Çekimi',
    instructionTr: 'Cümleyi uygun fiil çekimi ile tamamlayınız:',
    promptDe: 'Hallo! Ich ___ Mehmet und komme aus Istanbul.',
    options: ['heiße', 'heißt', 'heißen', 'bist'],
    correctAnswer: 'heiße',
    explanationTr: '"ich" (ben) zamirinde heißen fiili "heiße" olarak çekimlenir.',
  },
  {
    id: 'pq_a1_2',
    level: 'A1',
    category: 'Artikel Bilgisi',
    instructionTr: 'Aşağıdaki cümlenin doğru artikeli hangisidir?',
    promptDe: 'Hier ist ___ Tisch (Masa) und das Buch.',
    turkishHint: 'Masa (eril isimdir)',
    options: ['der', 'die', 'das', 'den'],
    correctAnswer: 'der',
    explanationTr: 'Tisch kelimesi eril cinsiyettedir ve Nominativ yalın halde "der" artikelini alır.',
  },
  {
    id: 'pq_a1_3',
    level: 'A1',
    category: 'Kelime ve Nezaket',
    instructionTr: '"Guten Abend, wie geht es Ihnen?" sorusuna en uygun cevap hangisidir?',
    promptDe: 'Wie geht es Ihnen?',
    audioText: 'Wie geht es Ihnen?',
    options: [
      'Danke, gut! Und Ihnen?',
      'Ich heiße Anna.',
      'Ich komme aus Deutschland.',
      'Es ist drei Uhr.',
    ],
    correctAnswer: 'Danke, gut! Und Ihnen?',
    explanationTr: '"Wie geht es Ihnen?" resmi olarak "Nasılsınız?" demektir. Cevap "Danke, gut! Und Ihnen?" (Teşekkürler, iyiyim, ya siz?) olur.',
  },

  // --- A2 LEVEL ---
  {
    id: 'pq_a2_1',
    level: 'A2',
    category: 'Geçmiş Zaman (Perfekt)',
    instructionTr: 'Perfekt zamanında doğru yardımcı fiili seçiniz:',
    promptDe: 'Gestern ___ ich mit dem Zug nach München gefahren.',
    options: ['bin', 'habe', 'ist', 'hat'],
    correctAnswer: 'bin',
    explanationTr: '"fahren" yer değiştirme/hareket fiili olduğu için Perfekt\'te "sein" yardımcı fiilini alır (ich bin gefahren).',
  },
  {
    id: 'pq_a2_2',
    level: 'A2',
    category: 'Dativ Edatları',
    instructionTr: 'Boşluğa gelebilecek uygun artikeli seçiniz:',
    promptDe: 'Ich fahre jeden Morgen mit ___ Bus zur Arbeit.',
    options: ['dem', 'den', 'der', 'das'],
    correctAnswer: 'dem',
    explanationTr: '"mit" edatı daima Dativ (-e hali) gerektirir. "der Bus" eril olduğu için "dem Bus" haline dönüşür.',
  },
  {
    id: 'pq_a2_3',
    level: 'A2',
    category: 'Modal Fiiller',
    instructionTr: 'Cümleyi doğru modal fiil yapısıyla tamamlayınız:',
    promptDe: 'Hier ist eine Bibliothek. Man ___ hier leise sein.',
    options: ['muss', 'kannst', 'wollt', 'darfst'],
    correctAnswer: 'muss',
    explanationTr: '"Man" öznesi 3. tekil şahıstır (er/sie/es gibi). Kütüphanede sessiz olma zorunluluğu "muss" ile ifade edilir.',
  },

  // --- B1 LEVEL ---
  {
    id: 'pq_b1_1',
    level: 'B1',
    category: 'Yan Cümleler (Nebensätze)',
    instructionTr: '"weil" (çünkü) bağlacı ile doğru cümle yapısını seçiniz:',
    promptDe: 'Er lernt jeden Tag Deutsch, weil er in Deutschland ___ .',
    options: [
      'studieren möchte',
      'möchte studieren',
      'studiert möchte',
      'möchte studiert',
    ],
    correctAnswer: 'studieren möchte',
    explanationTr: '"weil" bağlacında çekimli fiil (möchte) cümlenin en sonuna gider.',
  },
  {
    id: 'pq_b1_2',
    level: 'B1',
    category: 'Sıfat Çekimleri',
    instructionTr: 'Doğru sıfat takısını bulunuz:',
    promptDe: 'Ich habe gestern ein interessant___ Buch gelesen.',
    options: ['es', 'e', 'en', 'em'],
    correctAnswer: 'es',
    explanationTr: 'das Buch nötrdür. Belirsiz artikelden ("ein") sonra Akkusativ tekil nötr sıfat "-es" takısı alır (ein interessantes Buch).',
  },
  {
    id: 'pq_b1_3',
    level: 'B1',
    category: 'Konjunktiv II',
    instructionTr: 'Nezaket / dilek ifadesini tamamlayınız:',
    promptDe: 'Wenn ich mehr Freizeit ___, würde ich eine Weltreise machen.',
    options: ['hätte', 'habe', 'hatte', 'wäre'],
    correctAnswer: 'hätte',
    explanationTr: 'Geçmişte veya şimdiki zamanda gerçekleşmemiş varsayım için haben fiilinin Konjunktiv II hali "hätte" kullanılır.',
  },

  // --- B2 LEVEL ---
  {
    id: 'pq_b2_1',
    level: 'B2',
    category: 'Pasif Çatı (Passiv)',
    instructionTr: 'Cümlenin doğru edilgen (Passiv) halini seçiniz:',
    promptDe: 'Das neue Bürogebäude ___ bis zum Jahresende fertiggestellt.',
    options: ['wird', 'hat', 'ist', 'macht'],
    correctAnswer: 'wird',
    explanationTr: 'Vorgangspassiv (Süreç pasifi) şimdiki/gelecek zamanda "werden + Partizip II" ile kurulur: wird fertiggestellt.',
  },
  {
    id: 'pq_b2_2',
    level: 'B2',
    category: 'N-Deklination',
    instructionTr: 'Zayıf eril isim çekimini bulunuz:',
    promptDe: 'Der Chef sprach gestern ausführlich mit dem neu___ Kolleg___ .',
    options: [
      'en / en',
      'em / e',
      'en / e',
      'em / en',
    ],
    correctAnswer: 'en / en',
    explanationTr: '"der Kollege" zayıf isimdir (N-Deklination). Dativ halinde hem sıfat hem isim "-en" alır: mit dem neuen Kollegen.',
  },
  {
    id: 'pq_b2_3',
    level: 'B2',
    category: 'Sabit Fiil Edatları',
    instructionTr: 'Doğru edatı seçiniz:',
    promptDe: 'Der Erfolg dieses Projekts hängt weitgehend ___ Engagement des Teams ab.',
    options: ['vom', 'auf das', 'für das', 'an dem'],
    correctAnswer: 'vom',
    explanationTr: '"abhängen von + Dativ" kalıbıdır. von + dem = vom Engagement.',
  },

  // --- C1 LEVEL ---
  {
    id: 'pq_c1_1',
    level: 'C1',
    category: 'Nominalstil',
    instructionTr: '"Weil die Kosten drastisch gestiegen sind" ifadesinin Nominalstil karşılığı nedir?',
    promptDe: 'Weil die Kosten drastisch gestiegen sind...',
    options: [
      'Aufgrund des drastischen Kostenanstiegs...',
      'Obwohl die Kosten hoch waren...',
      'Trotz des Anstiegs der Kosten...',
      'Um die Kosten drastisch zu erhöhen...',
    ],
    correctAnswer: 'Aufgrund des drastischen Kostenanstiegs...',
    explanationTr: 'C1 düzeyinde neden bildiren "weil" cümlesi, "aufgrund + Genitiv" kalıbı ve isimleştirme (der Kostenanstieg) ile ifade edilir.',
  },
  {
    id: 'pq_c1_2',
    level: 'C1',
    category: 'Konjunktiv I (Dolaylı Anlatım)',
    instructionTr: 'Haber dilinde dolaylı anlatım için doğru Konjunktiv I çekimini seçiniz:',
    promptDe: 'Der Regierungssprecher teilte mit, die Verhandlungen ___ auf gutem Wege.',
    options: ['seien', 'waren', 'sind', 'wären'],
    correctAnswer: 'seien',
    explanationTr: 'Konjunktiv I çoğul 3. şahıs (die Verhandlungen) için "sein" fiili "seien" şeklindedir.',
  },
  {
    id: 'pq_c1_3',
    level: 'C1',
    category: 'Pasif Alternatifleri',
    instructionTr: '"Das Problem kann gelöst werden" cümlesinin eşdeğer alternatifini bulunuz:',
    promptDe: 'Das Problem kann gelöst werden.',
    options: [
      'Das Problem lässt sich lösen.',
      'Das Problem hat sich gelöst.',
      'Man muss das Problem lösen wollen.',
      'Das Problem ist ohne Lösung.',
    ],
    correctAnswer: 'Das Problem lässt sich lösen.',
    explanationTr: '"sich lassen + Infinitiv", "können + Passiv" yapısının C1 seviyesinde en yaygın kullanılan alternatifidir.',
  },
];
