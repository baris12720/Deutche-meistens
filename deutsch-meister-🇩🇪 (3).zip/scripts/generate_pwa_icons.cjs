const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function crc32(buf) {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function createChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const crc = crc32(chunk.subarray(4, 8 + len));
  chunk.writeUInt32BE(crc, 8 + len);
  return chunk;
}

function pointInPolygon(px, py, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const xi = pts[i][0], yi = pts[i][1];
    const xj = pts[j][0], yj = pts[j][1];
    const intersect =
      yi > py !== yj > py &&
      px < ((xj - xi) * (py - yi)) / (yj - yi + 1e-12) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function distToSegment(px, py, x1, y1, x2, y2) {
  const vx = x2 - x1;
  const vy = y2 - y1;
  const wx = px - x1;
  const wy = py - y1;
  const c1 = vx * wx + vy * wy;
  if (c1 <= 0) return Math.hypot(px - x1, py - y1);
  const c2 = vx * vx + vy * vy;
  if (c2 <= c1) return Math.hypot(px - x2, py - y2);
  const b = c1 / c2;
  return Math.hypot(px - (x1 + b * vx), py - (y1 + b * vy));
}

function sdRoundedBox(px, py, cx, cy, halfW, halfH, r) {
  const qx = Math.abs(px - cx) - halfW + r;
  const qy = Math.abs(py - cy) - halfH + r;
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
}

// Evaluate icon design in normalized 512x512 coordinate space
function sampleDeutschMeister(nx, ny, fullBleed, maskableScale) {
  // Background squircle / full bleed
  let bgAlpha = 1;
  if (!fullBleed) {
    const sdBg = sdRoundedBox(nx, ny, 256, 256, 240, 240, 116);
    if (sdBg > 1) return [0, 0, 0, 0];
    if (sdBg > -1) bgAlpha = Math.max(0, Math.min(1, 0.5 - sdBg * 0.5));
  }

  // Base anthracite gradient (#1e293b -> #111827 -> #090d16)
  const t = Math.max(0, Math.min(1, (nx * 0.35 + ny * 0.65) / 512));
  let r = 30 * (1 - t) + 9 * t;
  let g = 41 * (1 - t) + 13 * t;
  let b = 59 * (1 - t) + 22 * t;

  // Radial slate glow behind owl
  const glowDist = Math.hypot(nx - 256, ny - 236);
  if (glowDist < 196) {
    const k = 0.45 * (1 - glowDist / 196);
    r = r * (1 - k) + 38 * k;
    g = g * (1 - k) + 52 * k;
    b = b * (1 - k) + 76 * k;
  }

  // Transform coordinates for maskable safe-zone scaling
  const x = (nx - 256) / maskableScale + 256;
  const y = (ny - 256) / maskableScale + 256;

  // German Tricolor Crest Ribbon at top of icon
  if (fullBleed) {
    // Clean centered crest band inside safe zone for maskable / iOS full-bleed
    if (y >= 46 && y < 78 && x >= 88 && x <= 424) {
      r = 9; g = 9; b = 11; // Deep black
    } else if (y >= 78 && y < 96 && x >= 88 && x <= 424) {
      r = 220; g = 38; b = 38; // Vibrant German red
    } else if (y >= 96 && y < 108 && x >= 88 && x <= 424) {
      r = 250; g = 204; b = 21; // Gold
    }
  } else {
    if (ny >= 16 && ny < 52) {
      r = 9; g = 9; b = 11;
    } else if (ny >= 52 && ny < 72) {
      r = 220; g = 38; b = 38;
    } else if (ny >= 72 && ny < 86) {
      r = 250; g = 204; b = 21;
    }
  }

  // Owl Body & "M" Ear Tufts Silhouette
  const inOwlEllipse =
    ((x - 256) / 130) ** 2 + ((y - 246) / 104) ** 2 <= 1;
  const leftTuft = pointInPolygon(x, y, [
    [138, 130],
    [198, 162],
    [210, 210],
    [128, 224],
  ]);
  const rightTuft = pointInPolygon(x, y, [
    [374, 130],
    [314, 162],
    [302, 210],
    [384, 224],
  ]);

  if (inOwlEllipse || leftTuft || rightTuft) {
    r = 248; g = 250; b = 252; // Crisp ivory white

    // Subtle crimson brow accent
    const leftBrow = pointInPolygon(x, y, [
      [148, 148],
      [204, 178],
      [204, 194],
      [158, 180],
    ]);
    const rightBrow = pointInPolygon(x, y, [
      [364, 148],
      [308, 178],
      [308, 194],
      [354, 180],
    ]);
    if (leftBrow || rightBrow) {
      r = 220; g = 38; b = 38;
    }
  }

  // Expressive Eyes
  const dLeftEye = Math.hypot(x - 204, y - 242);
  const dRightEye = Math.hypot(x - 308, y - 242);
  if (dLeftEye <= 48 || dRightEye <= 48) {
    r = 15; g = 23; b = 42; // Dark eye mask
    if (dLeftEye <= 36 || dRightEye <= 36) {
      r = 255; g = 255; b = 255; // Eye ring
    }
    const dLeftPupil = Math.hypot(x - 210, y - 242);
    const dRightPupil = Math.hypot(x - 302, y - 242);
    if (dLeftPupil <= 20 || dRightPupil <= 20) {
      r = 15; g = 23; b = 42; // Deep pupil
    }
    if (Math.hypot(x - 218, y - 232) <= 8 || Math.hypot(x - 310, y - 232) <= 8) {
      r = 255; g = 255; b = 255; // Specular white highlight
    }
    if (Math.hypot(x - 198, y - 252) <= 4 || Math.hypot(x - 290, y - 252) <= 4) {
      r = 250; g = 204; b = 21; // Warm gold glint
    }
  }

  // Golden Beak (Diamond)
  const inBeak = pointInPolygon(x, y, [
    [256, 256],
    [278, 284],
    [256, 314],
    [234, 284],
  ]);
  if (inBeak) {
    if (x > 256 && y < 290) {
      r = 245; g = 158; b = 11;
    } else {
      r = 250; g = 204; b = 21;
    }
  }

  // Open Book Pages at Base
  const inLeftPage = pointInPolygon(x, y, [
    [96, 342],
    [176, 326],
    [256, 360],
    [256, 432],
    [180, 402],
    [110, 422],
  ]);
  const inRightPage = pointInPolygon(x, y, [
    [416, 342],
    [336, 326],
    [256, 360],
    [256, 432],
    [332, 402],
    [402, 422],
  ]);

  if (inLeftPage) {
    r = 255; g = 255; b = 255;
    if (
      distToSegment(x, y, 134, 366, 230, 374) < 3.5 ||
      distToSegment(x, y, 138, 390, 230, 398) < 3.5
    ) {
      r = 148; g = 163; b = 184;
    }
  } else if (inRightPage) {
    r = 235; g = 242; b = 249;
    if (
      distToSegment(x, y, 378, 366, 282, 374) < 3.5 ||
      distToSegment(x, y, 374, 390, 282, 398) < 3.5
    ) {
      r = 148; g = 163; b = 184;
    }
  }

  // Center Spine Bookmark Ribbon (Gold top + Crimson tail)
  const inRibbon =
    x >= 242 &&
    x <= 270 &&
    y >= 360 &&
    (y <= 446 || (y <= 462 && Math.abs(x - 256) >= y - 446));
  if (inRibbon) {
    if (y < 384) {
      r = 250; g = 204; b = 21; // Gold bookmark clasp
    } else {
      r = 220; g = 38; b = 38; // Crimson bookmark tail
    }
  }

  // Subtle rim border for non-maskable rounded icon
  if (!fullBleed) {
    const rimDist = Math.abs(sdRoundedBox(nx, ny, 256, 256, 236, 236, 112));
    if (rimDist < 2.2) {
      r = r * 0.55 + 71 * 0.45;
      g = g * 0.55 + 85 * 0.45;
      b = b * 0.55 + 105 * 0.45;
    }
  }

  return [
    Math.max(0, Math.min(255, Math.round(r))),
    Math.max(0, Math.min(255, Math.round(g))),
    Math.max(0, Math.min(255, Math.round(b))),
    Math.round(bgAlpha * 255),
  ];
}

function makePng(width, height, { fullBleed = false, maskableScale = 1 } = {}) {
  const stride = width * 4;
  const rawData = Buffer.alloc((stride + 1) * height);
  const sub = 3; // 3x3 supersampling for crisp anti-aliased edges

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (stride + 1);
    rawData[rowOffset] = 0;

    for (let x = 0; x < width; x++) {
      let sr = 0, sg = 0, sb = 0, sa = 0;
      for (let sy = 0; sy < sub; sy++) {
        for (let sx = 0; sx < sub; sx++) {
          const nx = ((x + (sx + 0.5) / sub) / width) * 512;
          const ny = ((y + (sy + 0.5) / sub) / height) * 512;
          const [pr, pg, pb, pa] = sampleDeutschMeister(nx, ny, fullBleed, maskableScale);
          sr += pr * pa;
          sg += pg * pa;
          sb += pb * pa;
          sa += pa;
        }
      }
      const total = sub * sub;
      const alphaAvg = sa / total;
      const pixelOffset = rowOffset + 1 + x * 4;
      if (alphaAvg > 0.5) {
        rawData[pixelOffset] = Math.round(sr / sa);
        rawData[pixelOffset + 1] = Math.round(sg / sa);
        rawData[pixelOffset + 2] = Math.round(sb / sa);
        rawData[pixelOffset + 3] = Math.round(alphaAvg);
      } else {
        rawData[pixelOffset] = 0;
        rawData[pixelOffset + 1] = 0;
        rawData[pixelOffset + 2] = 0;
        rawData[pixelOffset + 3] = 0;
      }
    }
  }

  const compressed = zlib.deflateSync(rawData, { level: 9 });
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8);
  ihdrData.writeUInt8(6, 9);
  ihdrData.writeUInt8(0, 10);
  ihdrData.writeUInt8(0, 11);
  ihdrData.writeUInt8(0, 12);

  return Buffer.concat([
    signature,
    createChunk('IHDR', ihdrData),
    createChunk('IDAT', compressed),
    createChunk('IEND', Buffer.alloc(0)),
  ]);
}

// Wrap 32x32 + 64x64 PNGs inside a standard multi-resolution Windows/Browser ICO container
function makeIco(entries) {
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0); // Reserved
  header.writeUInt16LE(1, 2); // Icon type = 1
  header.writeUInt16LE(entries.length, 4);

  const dirBuffers = [];
  let dataOffset = 6 + entries.length * 16;

  for (const entry of entries) {
    const dir = Buffer.alloc(16);
    dir.writeUInt8(entry.size >= 256 ? 0 : entry.size, 0);
    dir.writeUInt8(entry.size >= 256 ? 0 : entry.size, 1);
    dir.writeUInt8(0, 2); // Color palette
    dir.writeUInt8(0, 3); // Reserved
    dir.writeUInt16LE(1, 4); // Color planes
    dir.writeUInt16LE(32, 6); // Bits per pixel
    dir.writeUInt32LE(entry.png.length, 8);
    dir.writeUInt32LE(dataOffset, 12);
    dirBuffers.push(dir);
    dataOffset += entry.png.length;
  }

  return Buffer.concat([header, ...dirBuffers, ...entries.map((e) => e.png)]);
}

const publicDir = path.join(__dirname, '..', 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(
  path.join(publicDir, 'pwa-192x192.png'),
  makePng(192, 192, { fullBleed: false, maskableScale: 1 })
);
fs.writeFileSync(
  path.join(publicDir, 'pwa-512x512.png'),
  makePng(512, 512, { fullBleed: false, maskableScale: 1 })
);
fs.writeFileSync(
  path.join(publicDir, 'pwa-maskable-512x512.png'),
  makePng(512, 512, { fullBleed: true, maskableScale: 0.76 })
);
fs.writeFileSync(
  path.join(publicDir, 'apple-touch-icon.png'),
  makePng(180, 180, { fullBleed: true, maskableScale: 0.88 })
);

const icoPng32 = makePng(32, 32, { fullBleed: false, maskableScale: 1 });
const icoPng64 = makePng(64, 64, { fullBleed: false, maskableScale: 1 });
fs.writeFileSync(
  path.join(publicDir, 'favicon.ico'),
  makeIco([
    { size: 32, png: icoPng32 },
    { size: 64, png: icoPng64 },
  ])
);

console.log('Generated Deutsch Meister brand PWA icons & favicon.ico successfully!');
