import { CEFRLevel } from '../types';

// The AI teacher talks to YOUR OWN server (see server/ai-proxy). The API key never lives in the app.
export interface AiConfig {
  endpoint: string;
  token: string;
}

const CFG_KEY = 'dm_ai_config_v1';

export function loadAiConfig(): AiConfig {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { endpoint: String(p.endpoint || ''), token: String(p.token || '') };
    }
  } catch {
    /* ignore */
  }
  return { endpoint: '', token: '' };
}

export function saveAiConfig(cfg: AiConfig) {
  try {
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
  } catch {
    /* ignore */
  }
}

export interface AiTurn {
  role: 'user' | 'assistant';
  text: string;
}

export interface AiCorrection {
  original: string;
  corrected: string;
  explanationTr: string;
  errorType: string;
}

export interface AiReply {
  reply: string; // German answer of the teacher
  replyTr?: string; // Turkish translation of the answer
  correction: AiCorrection | null;
  followUp?: string; // next question in German
  tipTr?: string;
}

export interface AiRequest {
  message: string;
  history: AiTurn[];
  level: CEFRLevel;
  topic: string;
  weakAreas: string[];
  knownErrors: string[];
}

const norm = (t: string) => t.toLowerCase().replace(/[.,!?;:"']/g, '').replace(/\s+/g, ' ').trim();
const cache = new Map<string, AiReply>();
let lastCall = 0;

export async function askTeacher(cfg: AiConfig, req: AiRequest): Promise<AiReply> {
  if (!cfg.endpoint) throw new Error('Sunucu adresi ayarlanmamış.');
  const message = req.message.trim();
  if (message.length < 2) throw new Error('Lütfen bir cümle yaz.');

  // avoid useless API calls: same question in the same context is answered from memory
  const key = JSON.stringify([message, req.history.slice(-4), req.level, req.topic]);
  const hit = cache.get(key);
  if (hit) return hit;

  const wait = 1500 - (Date.now() - lastCall);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCall = Date.now();

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  let res: Response;
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cfg.token) headers.Authorization = `Bearer ${cfg.token}`;
    res = await fetch(`${cfg.endpoint.replace(/\/+$/, '')}/teach`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ ...req, message, history: req.history.slice(-8) }),
      signal: ctrl.signal,
    });
  } catch {
    throw new Error('Sunucuya ulaşılamadı. İnternet bağlantını ve sunucu adresini kontrol et.');
  } finally {
    clearTimeout(timer);
  }
  if (res.status === 401 || res.status === 403) throw new Error('Erişim reddedildi. Erişim anahtarını kontrol et.');
  if (res.status === 429) throw new Error('Çok fazla istek gönderildi. Biraz bekleyip tekrar dene.');
  if (!res.ok) throw new Error(`Sunucu hatası (${res.status}). Biraz sonra tekrar dene.`);

  let data: any;
  try {
    data = await res.json();
  } catch {
    throw new Error('Sunucudan geçersiz cevap geldi.');
  }
  if (!data || typeof data.reply !== 'string') throw new Error('Sunucudan beklenmeyen biçimde cevap geldi.');

  let correction: AiCorrection | null = null;
  const c = data.correction;
  if (c && typeof c.original === 'string' && typeof c.corrected === 'string' && norm(c.original) !== norm(c.corrected)) {
    correction = {
      original: c.original,
      corrected: c.corrected,
      explanationTr: String(c.explanationTr || ''),
      errorType: String(c.errorType || 'genel'),
    };
  }
  const out: AiReply = {
    reply: data.reply,
    replyTr: typeof data.replyTr === 'string' ? data.replyTr : undefined,
    correction,
    followUp: typeof data.followUp === 'string' ? data.followUp : undefined,
    tipTr: typeof data.tipTr === 'string' ? data.tipTr : undefined,
  };
  cache.set(key, out);
  return out;
}

export interface WritingRubricScores {
  taskCompletion: number; // 0-100: Görev Tamamlama (Leitpunkte)
  grammar: number; // 0-100: Dilbilgisi
  vocabulary: number; // 0-100: Kelime Zenginliği
  formatTone: number; // 0-100: Hitap / Kapanış Formatı
  overall: number; // 0-100
}

export interface WritingSentenceFix {
  original: string;
  corrected: string;
  explanationTr: string;
  errorType: string;
}

export interface WritingNaturalAlternative {
  basicDe: string;
  betterDe: string;
  explanationTr: string;
}

export interface WritingEvaluation {
  source: 'ai' | 'offline';
  scores: WritingRubricScores;
  summaryTr: string;
  coveredLeitpunkte: boolean[];
  sentenceFixes: WritingSentenceFix[];
  naturalAlternatives: WritingNaturalAlternative[];
  vocabularySuggestions: { article: 'der' | 'die' | 'das' | 'none'; german: string; turkish: string; exampleDe: string }[];
}

export interface WritingPromptRef {
  id: string;
  level: CEFRLevel;
  titleTr: string;
  recipientType: 'formal' | 'informal';
  minWords: number;
  leitpunkteTr: string[];
  expectedConceptGroups: { labelTr: string; keywords: string[] }[];
}

export function evaluateWritingOffline(prompt: WritingPromptRef, rawText: string): WritingEvaluation {
  const text = rawText.trim();
  const lower = text.toLowerCase();
  const words = text.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  // 1. Leitpunkte coverage
  const coveredLeitpunkte = prompt.expectedConceptGroups.map((grp) =>
    grp.keywords.some((kw) => lower.includes(kw.toLowerCase()))
  );
  const coveredRatio =
    coveredLeitpunkte.length > 0
      ? coveredLeitpunkte.filter(Boolean).length / coveredLeitpunkte.length
      : wordCount >= prompt.minWords ? 1 : 0.5;
  const lengthRatio = Math.min(1, wordCount / Math.max(15, prompt.minWords));
  const taskCompletion = Math.min(100, Math.round(coveredRatio * 70 + lengthRatio * 30));

  // 2. Format & Tone check (Salutation & Closing)
  const hasFormalSalutation = /(sehr geehrte|sehr geehrter|guten tag)/i.test(text);
  const hasInformalSalutation = /(liebe|lieber|hallo|guten tag)/i.test(text);
  const hasFormalClosing = /(mit freundlichen grüßen|vielen dank im voraus|hochachtungsvoll)/i.test(text);
  const hasInformalClosing = /(viele grüße|liebe grüße|bis bald|dein|deine)/i.test(text);

  let formatScore = 35;
  if (prompt.recipientType === 'formal') {
    if (hasFormalSalutation) formatScore += 35;
    else if (hasInformalSalutation) formatScore += 12;
    if (hasFormalClosing) formatScore += 30;
    else if (hasInformalClosing) formatScore += 10;
  } else {
    if (hasInformalSalutation) formatScore += 35;
    else if (hasFormalSalutation) formatScore += 18;
    if (hasInformalClosing) formatScore += 30;
    else if (hasFormalClosing) formatScore += 18;
  }
  const formatTone = Math.min(100, formatScore);

  // 3. Grammar & Sentence Diagnostics
  const sentenceFixes: WritingSentenceFix[] = [];
  const sentences = text
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 4);

  const checkSentence = (sent: string) => {
    // Check wrong "ich habe ... gegangen / gefahren / gekommen / geblieben"
    const auxMatch = sent.match(/\b(ich|du|er|sie|es|wir|ihr)\s+(habe|hast|hat|haben|habt)\b([^.!?]*)\b(gegangen|gefahren|gekommen|geblieben|gewesen)\b/i);
    if (auxMatch) {
      const seinMap: Record<string, string> = { habe: 'bin', hast: 'bist', hat: 'ist', haben: 'sind', habt: 'seid' };
      const replacementAux = seinMap[auxMatch[2].toLowerCase()] || 'bin';
      sentenceFixes.push({
        original: sent,
        corrected: sent.replace(new RegExp(`\\b${auxMatch[2]}\\b`, 'i'), replacementAux),
        explanationTr: `Hareket ve yer/durum değişikliği bildiren "${auxMatch[4]}" fiili Perfekt zamanda "haben" değil, "sein" (${replacementAux}) yardımcı fiiliyle kurulur.`,
        errorType: 'perfekt',
      });
    }

    // Check lowercase "ich" after comma/line start OR common lowercase nouns
    if (/\bich\b/.test(sent) && /^\s*ich\b/.test(sent)) {
      sentenceFixes.push({
        original: sent,
        corrected: sent.replace(/^\s*ich\b/, 'Ich'),
        explanationTr: 'Cümle başındaki ilk harf Almancada daima büyük yazılır.',
        errorType: 'yazim',
      });
    }

    // Check common noun capitalization mistakes
    const lowercaseNouns: Record<string, string> = {
      termin: 'Termin',
      heizung: 'Heizung',
      wohnung: 'Wohnung',
      arbeit: 'Arbeit',
      kurs: 'Kurs',
      deutschkurs: 'Deutschkurs',
      arzt: 'Arzt',
      handwerker: 'Handwerker',
      zeit: 'Zeit',
      hilfe: 'Hilfe',
      tag: 'Tag',
      grüße: 'Grüße',
      freundlichen: 'freundlichen',
      problem: 'Problem',
      antwort: 'Antwort',
    };
    let fixedCaps = sent;
    let foundCapError: string | null = null;
    for (const [low, cap] of Object.entries(lowercaseNouns)) {
      if (low === 'freundlichen') continue;
      const rx = new RegExp(`\\b${low}\\b`);
      if (rx.test(fixedCaps) && !new RegExp(`\\b${cap}\\b`).test(fixedCaps)) {
        fixedCaps = fixedCaps.replace(rx, cap);
        foundCapError = cap;
      }
    }
    if (foundCapError && fixedCaps !== sent) {
      sentenceFixes.push({
        original: sent,
        corrected: fixedCaps,
        explanationTr: `Almancada tüm isimlerin baş harfi büyüktür ("${foundCapError}").`,
        errorType: 'yazim',
      });
    }

    // Check wrong prepositions: "warten für" -> "warten auf", "danken über" -> "danken für", "interessieren über" -> "interessieren für"
    if (/\bwarte(?:n|st|t|te)?\s+für\b/i.test(sent)) {
      sentenceFixes.push({
        original: sent,
        corrected: sent.replace(/\b(warte(?:n|st|t|te)?)\s+für\b/gi, '$1 auf'),
        explanationTr: '"beklemek" anlamındaki "warten" fiili her zaman "auf + Akkusativ" edatı alır ("warten auf").',
        errorType: 'edat',
      });
    }
    if (/\b(?:vielen\s+dank|danke)\s+über\b/i.test(sent)) {
      sentenceFixes.push({
        original: sent,
        corrected: sent.replace(/\b(vielen\s+dank|danke)\s+über\b/gi, '$1 für'),
        explanationTr: 'Teşekkür ederken "über" değil, "für + Akkusativ" kullanılır (Danke für...).',
        errorType: 'edat',
      });
    }

    // Check weil/obwohl/dass verb position simple heuristic: "weil ich bin krank"
    const weilBad = sent.match(/\b(weil|obwohl|dass)\s+(ich|du|er|sie|es|wir|ihr|Sie)\s+(bin|bist|ist|sind|habe|hat|kann|muss|will)\s+([^,.!?]+)/i);
    if (weilBad) {
      sentenceFixes.push({
        original: sent,
        corrected: sent.replace(
          weilBad[0],
          `${weilBad[1]} ${weilBad[2]} ${weilBad[4].trim()} ${weilBad[3]}`
        ),
        explanationTr: `"${weilBad[1]}" yan cümle bağlacıdır ve çekimli fiili ("${weilBad[3]}") cümlenin en sonuna gönderir.`,
        errorType: 'kelime-sirasi',
      });
    }

    // Check tone mismatch in formal letters
    if (prompt.recipientType === 'formal' && /\b(hallo|lieber|liebe|viele grüße)\b/i.test(sent)) {
      sentenceFixes.push({
        original: sent,
        corrected: sent
          .replace(/hallo/i, 'Sehr geehrte Damen und Herren')
          .replace(/viele grüße/i, 'Mit freundlichen Grüßen'),
        explanationTr: 'Resmî DTZ/Goethe mektuplarında "Hallo / Viele Grüße" yerine "Sehr geehrte..." ve "Mit freundlichen Grüßen" kullanılmalıdır.',
        errorType: 'kelime-secimi',
      });
    }
  };

  sentences.forEach(checkSentence);

  // Check missing ending punctuation on long text
  if (text.length > 20 && !/[.!?]$/.test(text) && !hasFormalClosing && !hasInformalClosing) {
    sentenceFixes.push({
      original: sentences[sentences.length - 1] || text.slice(-30),
      corrected: `${sentences[sentences.length - 1] || text.slice(-30)}.`,
      explanationTr: 'Son cümlenin sonuna nokta veya uygun noktalama işareti koymayı unutma.',
      errorType: 'yazim',
    });
  }

  const penalty = Math.min(45, sentenceFixes.length * 11);
  const grammar = Math.max(30, Math.min(98, Math.round(78 + lengthRatio * 18 - penalty)));

  // 4. Vocabulary richness (unique tokens & CEFR connectors)
  const uniqueTokens = new Set(words.map((w) => w.toLowerCase().replace(/[^a-zäöüß]/gi, '')).filter(Boolean));
  const connectorHits = ['deshalb', 'deswegen', 'obwohl', 'weil', 'außerdem', 'zudem', 'jedoch', 'damit', 'sodass', 'leider', 'könnten'].filter(
    (c) => lower.includes(c)
  ).length;
  const lexicalDiversity = wordCount > 0 ? uniqueTokens.size / wordCount : 0;
  const vocabulary = Math.min(
    98,
    Math.max(35, Math.round(lengthRatio * 48 + lexicalDiversity * 32 + Math.min(20, connectorHits * 7)))
  );

  const overall = Math.round(taskCompletion * 0.35 + grammar * 0.3 + vocabulary * 0.2 + formatTone * 0.15);

  const naturalAlternatives: WritingNaturalAlternative[] = [];
  if (!lower.includes('könnten sie') && prompt.recipientType === 'formal') {
    naturalAlternatives.push({
      basicDe: 'Bitte schicken / geben Sie mir...',
      betterDe: 'Könnten Sie mir bitte ... zukommen lassen? / Wäre es möglich, dass...?',
      explanationTr: 'Konjunktiv II ("Könnten Sie...", "Wäre es möglich...") B1/B2 resmî yazılarda puanı doğrudan artırır.',
    });
  }
  if (!lower.includes('deshalb') && !lower.includes('daher')) {
    naturalAlternatives.push({
      basicDe: 'Ich bin krank. Ich komme nicht.',
      betterDe: 'Ich bin leider erkrankt, weshalb / deshalb ich heute nicht teilnehmen kann.',
      explanationTr: '"deshalb" veya "deswegen" gibi sebep-sonuç bağlaçları cümle akıcılığını (Kohärenz) güçlendirir.',
    });
  }
  if (prompt.level === 'B2' || prompt.level === 'C1') {
    naturalAlternatives.push({
      basicDe: 'Ich denke, das ist gut.',
      betterDe: 'Meines Erachtens trägt dieser Ansatz maßgeblich zu einer nachhaltigen Lösung bei.',
      explanationTr: 'B2/C1 düzeyinde "Ich denke" yerine "Meines Erachtens" ve isim-fiil kalıpları tercih edilir.',
    });
  } else {
    naturalAlternatives.push({
      basicDe: 'Vielen Dank.',
      betterDe: 'Vielen Dank im Voraus für Ihre Mühe und Ihr Verständnis.',
      explanationTr: 'Mektubu bitirirken "Vielen Dank im Voraus" (Şimdiden çok teşekkürler) kalıbı çok doğal durur.',
    });
  }

  const vocabularySuggestions: WritingEvaluation['vocabularySuggestions'] = [
    {
      article: 'das',
      german: 'Verständnis',
      turkish: 'anlayış',
      exampleDe: 'Vielen Dank für Ihr Verständnis.',
    },
    {
      article: 'die',
      german: 'Rückmeldung',
      turkish: 'geri bildirim / dönüş',
      exampleDe: 'Ich bitte um eine kurze Rückmeldung.',
    },
    {
      article: 'der',
      german: 'Termin',
      turkish: 'randevu',
      exampleDe: 'Wir müssen den Termin leider verschieben.',
    },
  ];

  const missingCount = coveredLeitpunkte.filter((x) => !x).length;
  const summaryTr =
    overall >= 80
      ? `Harika bir ${prompt.level} metni! Tüm temel noktalara değindin, formatın düzenli.`
      : missingCount > 0
      ? `İyi başlangıç! Görevdeki ${missingCount} Leitpunkt maddesini daha açık yazarsan puanın hızla yükselir.`
      : `Güzel deneme! Aşağıdaki dilbilgisi ve üslup önerilerini uygulayarak tam sınav puanına ulaşabilirsin.`;

  return {
    source: 'offline',
    scores: { taskCompletion, grammar, vocabulary, formatTone, overall },
    summaryTr,
    coveredLeitpunkte,
    sentenceFixes,
    naturalAlternatives,
    vocabularySuggestions,
  };
}

export async function evaluateWritingWithAi(
  cfg: AiConfig,
  prompt: WritingPromptRef,
  userText: string
): Promise<WritingEvaluation> {
  const clean = userText.trim();
  if (clean.length < 10) {
    throw new Error('Değerlendirme için en az birkaç cümle (10+ karakter) Almanca metin yaz.');
  }

  // Always compute baseline diagnostics first
  const localEval = evaluateWritingOffline(prompt, clean);

  // If no AI endpoint configured, return local offline diagnostic immediately
  if (!cfg.endpoint) {
    return localEval;
  }

  // Try configured AI proxy server (keeps API key on user's server)
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  let res: Response;
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cfg.token) headers.Authorization = `Bearer ${cfg.token}`;

    const rubricPrompt = [
      `[SCHREIBEN_DEGERLENDIRME | Seviye: ${prompt.level} | Görev: ${prompt.titleTr}]`,
      `Leitpunkte: ${prompt.leitpunkteTr.join(' | ')}`,
      `Öğrenci metni:\n"""\n${clean}\n"""`,
      `Lütfen metni DTZ/Goethe kriterlerine göre Türkçe açıkla ve düzelt.`,
    ].join('\n');

    res = await fetch(`${cfg.endpoint.replace(/\/+$/, '')}/teach`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        message: rubricPrompt.slice(0, 500),
        history: [],
        level: prompt.level,
        topic: `DTZ Schreiben: ${prompt.titleTr}`,
        weakAreas: [],
        knownErrors: [],
      }),
      signal: ctrl.signal,
    });
  } catch {
    throw new Error('AI sunucusuna ulaşılamadı. Bağlantını veya sunucu ayarını kontrol et.');
  } finally {
    clearTimeout(timer);
  }

  if (res.status === 401 || res.status === 403) {
    throw new Error('AI sunucusu erişimi reddetti. Erişim anahtarını kontrol et.');
  }
  if (!res.ok) {
    throw new Error(`AI sunucu hatası (${res.status}).`);
  }

  try {
    const data = await res.json();
    const fixes = [...localEval.sentenceFixes];
    if (
      data?.correction &&
      typeof data.correction.original === 'string' &&
      typeof data.correction.corrected === 'string' &&
      norm(data.correction.original) !== norm(data.correction.corrected)
    ) {
      fixes.unshift({
        original: data.correction.original,
        corrected: data.correction.corrected,
        explanationTr: String(data.correction.explanationTr || data.tipTr || ''),
        errorType: String(data.correction.errorType || 'gramer'),
      });
    }
    const aiNote = [data?.replyTr, data?.tipTr].filter((x) => typeof x === 'string' && x.trim()).join(' ');
    return {
      ...localEval,
      source: 'ai',
      summaryTr: aiNote || localEval.summaryTr,
      sentenceFixes: fixes,
    };
  } catch {
    throw new Error('AI sunucusundan beklenmeyen yanıt alındı.');
  }
}
