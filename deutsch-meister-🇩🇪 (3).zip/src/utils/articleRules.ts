import { ArticleType } from '../types';

export interface ArticleRuleHint {
  article: 'der' | 'die' | 'das';
  ruleTitleTr: string;
  ruleDetailTr: string;
  confidence: 'kesin' | 'genel';
}

interface SuffixRule {
  suffixes: string[];
  article: 'der' | 'die' | 'das';
  confidence: 'kesin' | 'genel';
  ruleTitleTr: string;
  ruleDetailTr: string;
}

const SUFFIX_RULES: SuffixRule[] = [
  {
    suffixes: ['ung', 'heit', 'keit', 'schaft', 'tät', 'ion', 'ik', 'ur', 'enz', 'anz'],
    article: 'die',
    confidence: 'kesin',
    ruleTitleTr: '-ung / -heit / -keit / -schaft / -tät / -ion kuralı',
    ruleDetailTr: 'Bu eklerle biten Almanca isimler neredeyse her zaman dişil (die) artikel alır.',
  },
  {
    suffixes: ['ei'],
    article: 'die',
    confidence: 'genel',
    ruleTitleTr: '-ei eki (yer / meslek adı)',
    ruleDetailTr: '-ei ile biten kelimeler (ör. die Bäckerei, die Polizei) genellikle "die" artikel alır.',
  },
  {
    suffixes: ['chen', 'lein', 'ment', 'um', 'tum', 'ma', 'nis'],
    article: 'das',
    confidence: 'kesin',
    ruleTitleTr: '-chen / -lein / -ment / -um / -tum kuralı',
    ruleDetailTr: 'Küçültme (-chen, -lein) ve -ment/-um ekli kelimeler nötr (das) artikel alır.',
  },
  {
    suffixes: ['ling', 'ismus', 'or', 'ig', 'ich', 'ner', 'ler'],
    article: 'der',
    confidence: 'genel',
    ruleTitleTr: '-ling / -ismus / -or / -ner / -ler kuralı',
    ruleDetailTr: 'Bu son ekleri alan kelimeler ve erkek/meslek bildiren -er/-or isimler genellikle "der" alır.',
  },
];

const DAYS_MONTHS_SEASONS = new Set([
  'montag', 'dienstag', 'mittwoch', 'donnerstag', 'freitag', 'samstag', 'sonntag',
  'januar', 'februar', 'märz', 'april', 'mai', 'juni', 'juli', 'august', 'september', 'oktober', 'november', 'dezember',
  'frühling', 'sommer', 'herbst', 'winter',
]);

/**
 * Returns a pedagogical German article hint based on noun morphology/semantics.
 * When `actualArticle` is provided, skips any heuristic that would contradict the true article.
 */
export function getArticleRuleHint(
  rawGermanWord: string,
  actualArticle?: ArticleType
): ArticleRuleHint | null {
  if (actualArticle === 'none') return null;

  const clean = String(rawGermanWord || '')
    .replace(/^(der|die|das)\s+/i, '')
    .split(/[\s/(,]/)[0]
    .trim()
    .toLowerCase();

  if (!clean || clean.length < 3) return null;

  if (DAYS_MONTHS_SEASONS.has(clean)) {
    if (actualArticle && actualArticle !== 'der') return null;
    return {
      article: 'der',
      confidence: 'kesin',
      ruleTitleTr: 'Günler, aylar ve mevsimler → der',
      ruleDetailTr: 'Almancada bütün haftanın günleri, aylar ve mevsim adları istisnasız "der" artikel alır.',
    };
  }

  for (const rule of SUFFIX_RULES) {
    const matched = rule.suffixes.find((sfx) => clean.endsWith(sfx) && clean.length > sfx.length + 1);
    if (matched) {
      if (actualArticle && actualArticle !== rule.article) continue;
      return {
        article: rule.article,
        confidence: rule.confidence,
        ruleTitleTr: `-${matched} son eki → ${rule.article}`,
        ruleDetailTr: rule.ruleDetailTr,
      };
    }
  }

  // Common Ge-... collective/abstract nouns -> das
  if (clean.startsWith('ge') && clean.length >= 6 && (!actualArticle || actualArticle === 'das')) {
    if (actualArticle === 'das') {
      return {
        article: 'das',
        confidence: 'genel',
        ruleTitleTr: 'Ge- ön eki → genellikle das',
        ruleDetailTr: '"Ge-" ile başlayan pek çok isim (ör. das Gespräch, das Gesetz, das Gebäude) "das" artikel alır.',
      };
    }
  }

  // Ends with -e (two-syllable feminine tendency)
  if (clean.endsWith('e') && clean.length >= 4 && actualArticle === 'die') {
    return {
      article: 'die',
      confidence: 'genel',
      ruleTitleTr: '-e ile biten isimler → çoğunlukla die',
      ruleDetailTr: 'Almancada sonu "-e" ile biten isimlerin büyük çoğunluğu (ör. die Lampe, die Straße) "die" artikel alır.',
    };
  }

  return null;
}
