import { STORIES, Story } from '../data/stories';
import { QUEST_WORDS, QuestWord } from '../data/vocab/words';
import { CONNECTOR_GROUPS } from '../data/connectors';
import { weakTopics } from './analytics';
import { CEFRLevel, UserProfile } from '../types';

export type ExamSectionTarget = 'hoeren' | 'lesen' | 'schreiben' | 'sprechen';

export interface LearningBridgeRecommendation {
  story: Story;
  examLevel: CEFRLevel;
  examSection: ExamSectionTarget;
  examLabelTr: string;
  reasonTr: string;
}

const STORY_KEYWORDS: { storyId: string; keywords: string[] }[] = [
  { storyId: 'story_a1_bakery', keywords: ['fırın', 'kahvaltı', 'ekmek', 'yemek', 'içecek', 'kafe', 'restoran', 'sipariş'] },
  { storyId: 'story_a1_supermarket', keywords: ['market', 'alışveriş', 'kasa', 'sayı', 'fiyat', 'para', 'meyve', 'sebze'] },
  { storyId: 'story_a1_lost_key', keywords: ['ev', 'eşya', 'aile', 'günlük', 'rutin', 'saat', 'oda', 'artikel'] },
  { storyId: 'story_a1_station', keywords: ['tren', 'seyahat', 'yol', 'ulasım', 'ulaşım', 'bilet', 'şehir', 'yön', 'yer'] },
  { storyId: 'story_a2_apartment', keywords: ['ev', 'kira', 'daire', 'mobilya', 'taşın', 'konut', 'oda'] },
  { storyId: 'story_a2_wrong_platform', keywords: ['tren', 'seyahat', 'peron', 'gecikme', 'yolculuk', 'bilet', 'perfekt'] },
  { storyId: 'story_a2_restaurant_bill', keywords: ['restoran', 'hesap', 'menü', 'yemek', 'garson', 'sipariş', 'modal'] },
  { storyId: 'story_a2_neighbor_package', keywords: ['komşu', 'paket', 'teslim', 'posta', 'kargo', 'tanış', 'dativ'] },
  { storyId: 'story_b1_wg_casting', keywords: ['ortak', 'ev', 'kurallar', 'bağlaç', 'obwohl', 'dass', 'temizlik'] },
  { storyId: 'story_b1_doctor', keywords: ['doktor', 'sağlık', 'hastane', 'reçete', 'randevu', 'vücut', 'hastalık'] },
  { storyId: 'story_b1_customer_return', keywords: ['iade', 'şikayet', 'müşteri', 'alışveriş', 'ürün', 'garanti', 'hizmet'] },
  { storyId: 'story_b2_interview', keywords: ['iş', 'kariyer', 'maaş', 'görüşme', 'mülakat', 'ofis', 'meslek'] },
  { storyId: 'story_b2_car_rental', keywords: ['araba', 'sigorta', 'kaza', 'kiralama', 'seyahat', 'ehliyet'] },
  { storyId: 'story_b2_university_seminar', keywords: ['üniversite', 'eğitim', 'seminer', 'tartışma', 'akademik', 'passiv'] },
  { storyId: 'story_c1_digital', keywords: ['yapay zeka', 'teknoloji', 'dijital', 'gelecek', 'iş dünyası'] },
  { storyId: 'story_c1_urban_planning', keywords: ['çevre', 'şehir', 'iklim', 'sürdürülebilir', 'planlama'] },
  { storyId: 'story_c1_contract_negotiation', keywords: ['hukuk', 'sözleşme', 'müzakere', 'resmi', 'konjunktiv'] },
];

const EXAM_LABELS: Record<ExamSectionTarget, string> = {
  hoeren: 'Hören (Dinleme) Pratiği',
  lesen: 'Lesen (Okuma) Pratiği',
  schreiben: 'Schreiben (Yazma Atölyesi)',
  sprechen: 'Sprechen (Konuşma) Pratiği',
};

export function getRecommendedNextSteps(input: {
  level?: CEFRLevel;
  titleTr?: string;
  descriptionTr?: string;
  id?: string;
  isGrammar?: boolean;
}): LearningBridgeRecommendation {
  const level: CEFRLevel = input.level || 'A1';
  const haystack = `${input.id || ''} ${input.titleTr || ''} ${input.descriptionTr || ''}`.toLowerCase();

  const levelStories = STORIES.filter((s) => s.level === level);
  const candidates = levelStories.length > 0 ? levelStories : STORIES;

  let matchedStory = candidates[0];
  let bestScore = -1;
  for (const story of STORIES) {
    const rule = STORY_KEYWORDS.find((k) => k.storyId === story.id);
    if (!rule) continue;
    let score = story.level === level ? 3 : 0;
    for (const kw of rule.keywords) {
      if (haystack.includes(kw)) score += 4;
    }
    if (score > bestScore) {
      bestScore = score;
      matchedStory = story;
    }
  }

  let examSection: ExamSectionTarget = 'lesen';
  if (input.isGrammar || haystack.includes('mektup') || haystack.includes('yaz') || haystack.includes('şikayet') || haystack.includes('randevu') || haystack.includes('bağlaç')) {
    examSection = 'schreiben';
  } else if (haystack.includes('dinle') || haystack.includes('anons') || haystack.includes('tren') || haystack.includes('saat')) {
    examSection = 'hoeren';
  } else if (haystack.includes('diyalog') || haystack.includes('tanış') || haystack.includes('görüşme') || haystack.includes('doktor')) {
    examSection = 'sprechen';
  }

  const reasonTr = input.isGrammar
    ? `"${input.titleTr || 'Bu gramer'}" yapısını şimdi gerçek bir Almanca hikayede görerek ve yazarak kalıcı hale getir.`
    : `"${input.titleTr || 'Bu ders'}" konusunda öğrendiğin kelimeleri hemen bir diyalog hikayesinde ve sınav bölümünde pekiştir.`;

  return {
    story: matchedStory,
    examLevel: level,
    examSection,
    examLabelTr: `${level} · ${EXAM_LABELS[examSection]}`,
    reasonTr,
  };
}

export interface PersonalizedWeakWord {
  id: string;
  article: string;
  german: string;
  turkish: string;
  wrongCount: number;
}

export interface PersonalizedMiniQuestion {
  id: string;
  refId?: string;
  promptTr: string;
  promptDe: string;
  options: string[];
  correctAnswer: string;
  explanationTr: string;
}

export interface PersonalizedMiniSet {
  hasRealMistakes: boolean;
  focusLabelTr: string;
  weakWords: PersonalizedWeakWord[];
  grammarTipTitleTr: string;
  grammarTipBodyTr: string;
  questions: PersonalizedMiniQuestion[];
}

const QUEST_BY_ID = new Map<string, QuestWord>(QUEST_WORDS.map((w) => [w.id, w]));

const FALLBACK_QUESTIONS: PersonalizedMiniQuestion[] = [
  {
    id: 'mini_fb_1',
    promptTr: '"Randevuyu ertelemek istiyorum" cümlesindeki eksik edatı seç:',
    promptDe: 'Ich warte schon lange ___ deine Antwort.',
    options: ['auf', 'mit', 'von'],
    correctAnswer: 'auf',
    explanationTr: '"warten auf + Akkusativ" kalıbı her zaman "auf" edatı ile kullanılır.',
  },
  {
    id: 'mini_fb_2',
    promptTr: 'Hangi kelimenin artikeli "die" değildir?',
    promptDe: 'Artikel seçimi:',
    options: ['Mädchen', 'Wohnung', 'Gesundheit'],
    correctAnswer: 'Mädchen',
    explanationTr: '-ung ve -heit ekleri her zaman "die" alır; ancak -chen küçültme eki HER ZAMAN "das" alır (das Mädchen).',
  },
  {
    id: 'mini_fb_3',
    promptTr: '"Çünkü hastayım" yan cümlesinde doğru fiil sırasını seç:',
    promptDe: 'Ich bleibe heute zu Hause, weil ich krank ___.',
    options: ['bin', 'ist', 'sein'],
    correctAnswer: 'bin',
    explanationTr: '"weil" bağlacından sonra çekimli fiil cümlenin en sonuna gider (weil ich krank bin).',
  },
];

export function buildPersonalizedMiniSet(profile: UserProfile | null | undefined): PersonalizedMiniSet {
  const srs = profile?.srs && typeof profile.srs === 'object' ? profile.srs : {};
  const aiMistakes = Array.isArray(profile?.aiMistakes) ? profile.aiMistakes : [];
  const topics = weakTopics(profile);

  const weakWords: PersonalizedWeakWord[] = [];
  Object.entries(srs).forEach(([id, entry]) => {
    if (!entry || typeof entry !== 'object' || (entry.wrong || 0) <= 0) return;
    if (id.startsWith('vq_')) {
      const w = QUEST_BY_ID.get(id);
      if (w) {
        weakWords.push({
          id: w.id,
          article: w.article,
          german: w.german,
          turkish: w.turkish,
          wrongCount: entry.wrong || 1,
        });
      }
    }
  });

  // Also include custom words with wrong answers in SRS
  (profile?.customWords || []).forEach((cw) => {
    const e = srs[cw.id];
    if (e && (e.wrong || 0) > 0 && !weakWords.some((x) => x.id === cw.id)) {
      weakWords.push({
        id: cw.id,
        article: cw.article,
        german: cw.german,
        turkish: cw.turkish,
        wrongCount: e.wrong || 1,
      });
    }
  });

  weakWords.sort((a, b) => b.wrongCount - a.wrongCount);
  const topWords = weakWords.slice(0, 4);

  const questions: PersonalizedMiniQuestion[] = [];

  // 1. Build questions from user's top wrong vocabulary words
  for (const ww of topWords) {
    if (questions.length >= 2) break;
    const wrongArticleChoices = ['der', 'die', 'das'].filter((a) => a !== ww.article);
    if (ww.article === 'der' || ww.article === 'die' || ww.article === 'das') {
      questions.push({
        id: `mini_art_${ww.id}`,
        refId: ww.id,
        promptTr: `Daha önce karıştırdığın "${ww.turkish}" kelimesinin artikeli nedir?`,
        promptDe: `___ ${ww.german}`,
        options: [ww.article, ...wrongArticleChoices].sort(),
        correctAnswer: ww.article,
        explanationTr: `Doğru artikel "${ww.article} ${ww.german}" (${ww.turkish}).`,
      });
    } else {
      const distractors = QUEST_WORDS.filter(
        (q) => q.id !== ww.id && q.turkish.toLowerCase() !== ww.turkish.toLowerCase()
      )
        .slice(0, 2)
        .map((q) => q.turkish);
      if (distractors.length === 2) {
        questions.push({
          id: `mini_tr_${ww.id}`,
          refId: ww.id,
          promptTr: `"${ww.german}" kelimesinin Türkçe anlamı nedir?`,
          promptDe: ww.german,
          options: [ww.turkish, ...distractors].sort((a, b) => a.localeCompare(b)),
          correctAnswer: ww.turkish,
          explanationTr: `"${ww.german}" kelimesi "${ww.turkish}" anlamına gelir.`,
        });
      }
    }
  }

  // 2. Build a question from AI / Writing mistakes if present
  for (const m of aiMistakes.slice(0, 3)) {
    if (questions.length >= 3) break;
    if (m.original && m.corrected && m.original !== m.corrected) {
      questions.push({
        id: `mini_ai_${m.id}`,
        promptTr: 'Hata Defterindeki bu ifadenin doğru yazılışını seç:',
        promptDe: `Yanlış kayıt: "${m.original}"`,
        options: [m.corrected, m.original].sort((a, b) => a.localeCompare(b)),
        correctAnswer: m.corrected,
        explanationTr: m.explanationTr || `Doğru kullanım: "${m.corrected}"`,
      });
    }
  }

  // 3. Build connector question if user missed any connector
  const wrongConnEntry = Object.entries(srs).find(
    ([id, entry]) => id.startsWith('conn:') && (entry?.wrong || 0) > 0
  );
  if (questions.length < 3 && wrongConnEntry) {
    const [, groupId, idxStr] = wrongConnEntry[0].split(':');
    const grp = CONNECTOR_GROUPS.find((g) => g.id === groupId);
    const item = grp?.items?.[Number(idxStr)];
    if (grp && item) {
      const sentence = item.template.replace(/\{[^}]+\}/g, '___');
      const otherWords = grp.items.filter((x) => x.word !== item.word).slice(0, 2).map((x) => x.word);
      if (otherWords.length === 2) {
        questions.push({
          id: `mini_conn_${wrongConnEntry[0]}`,
          refId: wrongConnEntry[0],
          promptTr: `Bağlaç tekrarı (${item.meaningTr}):`,
          promptDe: sentence,
          options: [item.word, ...otherWords].sort(),
          correctAnswer: item.word,
          explanationTr: `${item.word}: ${item.exampleTr}`,
        });
      }
    }
  }

  // Fill up to 3 questions smoothly
  for (const fb of FALLBACK_QUESTIONS) {
    if (questions.length >= 3) break;
    if (!questions.some((q) => q.id === fb.id)) {
      questions.push(fb);
    }
  }

  const topWeak = topics[0];
  let grammarTipTitleTr = 'Kişisel Tekrar Önerisi: Artikel & Fiil Yeri';
  let grammarTipBodyTr =
    'İsimleri her zaman artikeliyle (der/die/das) öğren; yan cümlelerde (weil, dass, obwohl) çekimli fiili sona gönder.';

  if (topWeak?.label?.includes('artikel') || topWords.some((w) => w.article !== 'none')) {
    grammarTipTitleTr = 'Odak Kuralı: Artikel İpuçları (-ung, -heit, -chen)';
    grammarTipBodyTr =
      '-ung, -heit, -keit, -schaft, -tät ekleri her zaman "die"; -chen, -lein, -ment ekleri her zaman "das" alır.';
  } else if (topWeak?.label?.toLowerCase().includes('bağlaç')) {
    grammarTipTitleTr = `Odak Kuralı: ${topWeak.label}`;
    grammarTipBodyTr =
      'denn / aber / und fiil yerini değiştirmez (Pozisyon 0); weil / dass / obwohl ise çekimli fiili cümle sonuna gönderir.';
  } else if (topWeak) {
    grammarTipTitleTr = `Odak Alanın: ${topWeak.label}`;
    grammarTipBodyTr =
      'Hata Defterindeki ve zayıf SRS kutularındaki öğeler bu mini sette otomatik önceliklendirildi.';
  }

  const hasRealMistakes = topWords.length > 0 || aiMistakes.length > 0 || topics.length > 0;
  const focusLabelTr = topWeak?.label
    ? topWeak.label
    : topWords.length > 0
    ? `${topWords.length} Zayıf Kelime`
    : 'Günlük Karma Pekiştirme';

  return {
    hasRealMistakes,
    focusLabelTr,
    weakWords: topWords,
    grammarTipTitleTr,
    grammarTipBodyTr,
    questions: questions.slice(0, 3),
  };
}
