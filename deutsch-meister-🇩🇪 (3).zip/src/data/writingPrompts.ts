import { CEFRLevel } from '../types';

export interface WritingPromptTask {
  id: string;
  level: CEFRLevel;
  examBadgeTr: string;
  titleTr: string;
  titleDe: string;
  scenarioTr: string;
  recipientType: 'formal' | 'informal';
  minWords: number;
  recommendedWords: string;
  leitpunkteTr: string[];
  usefulPhrasesDe: string[];
  sampleSolutionDe: string;
  /** Keywords (stem fragments in lowercase DE) expected across Leitpunkte for rubric checking */
  expectedConceptGroups: {
    labelTr: string;
    keywords: string[];
  }[];
}

export const WRITING_PROMPTS: WritingPromptTask[] = [
  {
    id: 'wr_a1_birthday',
    level: 'A1',
    examBadgeTr: 'Goethe A1 · Schreiben Teil 2',
    titleTr: 'Arkadaşına Doğum Günü Daveti',
    titleDe: 'Einladung zum Geburtstag',
    scenarioTr: 'Cumartesi günü doğum gününü kutluyorsun. Yakın arkadaşın Lukas\'a kısa ve samimi bir davet mesajı yaz.',
    recipientType: 'informal',
    minWords: 20,
    recommendedWords: '25–40 kelime',
    leitpunkteTr: [
      'Neden yazıyorsun? (Doğum günü daveti)',
      'Parti ne zaman ve saat kaçta başlıyor?',
      'Ne getirmesini veya ne zaman cevap vermesini istiyorsun?',
    ],
    usefulPhrasesDe: [
      'Lieber Lukas,',
      'Ich lade dich herzlich ein.',
      'Am Samstag um 18 Uhr',
      'Bitte sag mir Bescheid.',
      'Viele Grüße',
    ],
    sampleSolutionDe:
      'Lieber Lukas,\n\nam Samstag habe ich Geburtstag und mache eine kleine Party zu Hause. Ich lade dich herzlich ein! Wir fangen um 18 Uhr an. Du brauchst nichts mitzubringen, nur gute Laune. Kannst du kommen? Bitte sag mir bis Freitag Bescheid.\n\nViele Grüße\nDeniz',
    expectedConceptGroups: [
      { labelTr: 'Davet / Doğum günü', keywords: ['geburtstag', 'party', 'einlad', 'feiern'] },
      { labelTr: 'Gün ve saat bilgisi', keywords: ['samstag', 'uhr', 'um', 'wann'] },
      { labelTr: 'Cevap / Getirme ricası', keywords: ['bescheid', 'mitbring', 'kommst', 'kommen', 'antwort'] },
    ],
  },
  {
    id: 'wr_a1_course_info',
    level: 'A1',
    examBadgeTr: 'Goethe A1 · Resmî E-posta',
    titleTr: 'Dil Okulundan Kurs Bilgisi İsteme',
    titleDe: 'Informationen zum Deutschkurs',
    scenarioTr: 'Berlin\'de bir dil okuluna yazılmak istiyorsun. Okul sekreterliğine kısa bir bilgi e-postası yaz.',
    recipientType: 'formal',
    minWords: 20,
    recommendedWords: '25–40 kelime',
    leitpunkteTr: [
      'Hangi seviyede Almanca kursu arıyorsun?',
      'Kurs günleri ve saatlerini sor.',
      'Fiyat hakkında bilgi iste.',
    ],
    usefulPhrasesDe: [
      'Sehr geehrte Damen und Herren,',
      'ich möchte einen Deutschkurs besuchen.',
      'Wann findet der Kurs statt?',
      'Wie viel kostet der Kurs?',
      'Mit freundlichen Grüßen',
    ],
    sampleSolutionDe:
      'Sehr geehrte Damen und Herren,\n\nich möchte gern einen Deutschkurs (A1) in Ihrer Schule besuchen. Wann beginnt der nächste Kurs und wie sind die Unterrichtszeiten? Außerdem möchte ich fragen, wie viel der Kurs pro Monat kostet. Vielen Dank für Ihre Antwort.\n\nMit freundlichen Grüßen\nMert Yılmaz',
    expectedConceptGroups: [
      { labelTr: 'Kurs seviyesi / isteği', keywords: ['kurs', 'deutschkurs', 'a1', 'besuchen', 'lernen'] },
      { labelTr: 'Tarih ve saat sorusu', keywords: ['wann', 'zeit', 'uhr', 'beginn', 'statt'] },
      { labelTr: 'Ücret sorusu', keywords: ['kostet', 'preis', 'euro', 'kosten'] },
    ],
  },
  {
    id: 'wr_a2_weekend_trip',
    level: 'A2',
    examBadgeTr: 'Goethe A2 · E-posta',
    titleTr: 'Arkadaşına Hafta Sonu Planı',
    titleDe: 'Ausflug am Wochenende',
    scenarioTr: 'Arkadaşın Anna geçen hafta sonu seni aradı ama ulaşamadı. Ona hafta sonu nereye gittiğini anlat ve yeni bir buluşma öner.',
    recipientType: 'informal',
    minWords: 30,
    recommendedWords: '35–55 kelime',
    leitpunkteTr: [
      'Neden telefonunu açamadın? (özür dile)',
      'Hafta sonu ne yaptın / nereye gittin?',
      'Bu hafta için ortak bir buluşma günü ve yeri öner.',
    ],
    usefulPhrasesDe: [
      'Es tut mir leid, dass...',
      'Letztes Wochenende bin ich ... gefahren.',
      'Hast du am Freitag Zeit?',
      'Wollen wir uns treffen?',
    ],
    sampleSolutionDe:
      'Liebe Anna,\n\nes tut mir leid, dass ich am Sonntag nicht ans Telefon gegangen bin. Mein Handy war leider leer. Letztes Wochenende bin ich mit meiner Familie nach Hamburg gefahren und wir haben den Hafen besichtigt. Hast du am Donnerstag nach der Arbeit Zeit? Wir könnten zusammen einen Kaffee im Zentrum trinken.\n\nLiebe Grüße\nSelin',
    expectedConceptGroups: [
      { labelTr: 'Özür / neden ulaşamama', keywords: ['leid', 'handy', 'telefon', 'akku', 'konnte'] },
      { labelTr: 'Geçmiş hafta sonu aktivitesi', keywords: ['wochenende', 'gefahren', 'war', 'gemacht', 'besucht'] },
      { labelTr: 'Yeni buluşma önerisi', keywords: ['treffen', 'zeit', 'kaffee', 'donnerstag', 'freitag', 'samstag'] },
    ],
  },
  {
    id: 'wr_a2_doctor_appointment',
    level: 'A2',
    examBadgeTr: 'Goethe A2 · Yarı Resmî',
    titleTr: 'Doktor Randevusunu Erteleme',
    titleDe: 'Arzttermin verschieben',
    scenarioTr: 'Yarın Dr. Weber ile diş randevun var ancak iş toplantın çıktığı için gidemeyeceksin. Muayenehaneye mail yaz.',
    recipientType: 'formal',
    minWords: 30,
    recommendedWords: '35–55 kelime',
    leitpunkteTr: [
      'Mevcut randevu tarih ve saatini belirt.',
      'Neden gelemeyeceğini kısaca açıkla.',
      'Yeni bir randevu günü/saati rica et.',
    ],
    usefulPhrasesDe: [
      'Sehr geehrter Herr Dr. Weber,',
      'ich habe morgen um ... einen Termin.',
      'Leider kann ich nicht kommen, weil...',
      'Könnten wir den Termin verschieben?',
    ],
    sampleSolutionDe:
      'Sehr geehrtes Praxisteam,\n\nich habe morgen um 10:30 Uhr einen Termin bei Herrn Dr. Weber. Leider kann ich diesen Termin nicht wahrnehmen, weil ich plötzlich einen wichtigen Arbeitstermin bekommen habe. Entschuldigen Sie bitte die Umstände. Könnten wir den Termin auf nächste Woche Dienstag nach 15 Uhr verschieben? Vielen Dank!\n\nMit freundlichen Grüßen\nEmre Kaya',
    expectedConceptGroups: [
      { labelTr: 'Mevcut randevu bilgisi', keywords: ['termin', 'uhr', 'morgen'] },
      { labelTr: 'Gelememe nedeni', keywords: ['leider', 'arbeit', 'weil', 'kann nicht', 'krank'] },
      { labelTr: 'Erteleme / yeni randevu talebi', keywords: ['verschieben', 'neuen termin', 'nächste', 'möglich'] },
    ],
  },
  {
    id: 'wr_b1_dtz_heating',
    level: 'B1',
    examBadgeTr: 'DTZ B1 · Resmî Şikayet Mektubu',
    titleTr: 'Ev Sahibine Kalorifer Arızası Bildirimi',
    titleDe: 'Beschwerde wegen defekter Heizung',
    scenarioTr: 'Kış ortasında dairendeki kalorifer iki gündür hiç ısıtmıyor. Ev sahibin Herr Becker\'i aradın ama açmadı. Resmî ve nazik ama net bir mektup/e-posta yaz.',
    recipientType: 'formal',
    minWords: 45,
    recommendedWords: '55–85 kelime',
    leitpunkteTr: [
      'Sorunu tam olarak tanımla (kalorifer ne zamandır çalışmıyor).',
      'Bu durumun günlük hayatını nasıl etkilediğini belirt.',
      'Tamir için bir teknisyen (Handwerker) gönderilmesini ve ne zaman evde olduğunu yaz.',
      'Hızlı geri dönüş beklediğini ekle.',
    ],
    usefulPhrasesDe: [
      'Sehr geehrter Herr Becker,',
      'ich wende mich an Sie, weil...',
      'Seit zwei Tagen funktioniert die Heizung nicht.',
      'Ich bitte Sie, schnell einen Handwerker zu schicken.',
      'Ich bin ab 16 Uhr zu Hause erreichbar.',
    ],
    sampleSolutionDe:
      'Sehr geehrter Herr Becker,\n\nleider konnte ich Sie telefonisch nicht erreichen, deshalb schreibe ich Ihnen diese E-Mail. Seit zwei Tagen funktioniert die Heizung in meiner Wohnung überhaupt nicht mehr, obwohl es draußen sehr kalt ist. In allen Räumen hat es nur noch 14 Grad, sodass ich mich kaum aufhalten kann.\n\nIch bitte Sie herzlich, so schnell wie möglich einen Handwerker zu schicken. Morgen bin ich den ganzen Tag ab 15 Uhr zu Hause erreichbar. Bitte geben Sie mir kurz Bescheid, wann die Reparatur stattfinden kann.\n\nMit freundlichen Grüßen\nCan Demir',
    expectedConceptGroups: [
      { labelTr: 'Arıza tanımı & süresi', keywords: ['heizung', 'funktioniert', 'kalt', 'seit', 'kaputt'] },
      { labelTr: 'Etki / aciliyet', keywords: ['grad', 'wohnung', 'kalt', 'obwohl', 'kinder', 'krank'] },
      { labelTr: 'Tamirci / evde olma saati', keywords: ['handwerker', 'techniker', 'reparatur', 'uhr', 'hause'] },
      { labelTr: 'Geri dönüş ricası', keywords: ['bescheid', 'rückmeldung', 'antwort', 'bitte'] },
    ],
  },
  {
    id: 'wr_b1_dtz_course_absence',
    level: 'B1',
    examBadgeTr: 'DTZ B1 · Mazeret Bildirimi',
    titleTr: 'Entegrasyon Kursunda Mazeret ve Ders Notları',
    titleDe: 'Entschuldigung für den Integrationskurs',
    scenarioTr: 'Çocuğun hastalandığı veya iş görüşmen olduğu için 3 gün entegrasyon kursuna katılamayacaksın. Öğretmenin Frau Klein\'a yaz.',
    recipientType: 'formal',
    minWords: 45,
    recommendedWords: '50–80 kelime',
    leitpunkteTr: [
      'Hangi tarihler arasında derse gelemeyeceğini yaz.',
      'Mazeretini (nedenini) açıkla.',
      'Kaçırdığın ders notlarını / ödevleri nasıl alabileceğini sor.',
      'Ne zaman tekrar derste olacağını belirt.',
    ],
    usefulPhrasesDe: [
      'Sehr geehrte Frau Klein,',
      'ich möchte mich für ... entschuldigen.',
      'Aus diesem Grund kann ich nicht am Unterricht teilnehmen.',
      'Könnten Sie mir bitte die Arbeitsblätter schicken?',
    ],
    sampleSolutionDe:
      'Sehr geehrte Frau Klein,\n\nich schreibe Ihnen, weil ich von Mittwoch bis Freitag leider nicht am Integrationskurs teilnehmen kann. Mein Sohn hat hohes Fieber und muss zu Hause bleiben, sodass ich mich um ihn kümmern muss. Eine ärztliche Bescheinigung reiche ich selbstverständlich nach.\n\nKönnten Sie mir bitte die Hausaufgaben und die wichtigsten Arbeitsblätter per E-Mail schicken, damit ich nichts verpasse? Am Montag bin ich wieder pünktlich im Kurs.\n\nVielen Dank für Ihr Verständnis!\nMit freundlichen Grüßen\nAyşe Şahin',
    expectedConceptGroups: [
      { labelTr: 'Devamsızlık tarih/süresi', keywords: ['tage', 'mittwoch', 'montag', 'woche', 'bis', 'unterricht'] },
      { labelTr: 'Mazeret sebebi', keywords: ['krank', 'fieber', 'arzt', 'kind', 'termin', 'weil'] },
      { labelTr: 'Ödev / ders materyali ricası', keywords: ['hausaufgaben', 'arbeitsblätter', 'material', 'schicken', 'notizen'] },
    ],
  },
  {
    id: 'wr_b1_dtz_municipality',
    level: 'B1',
    examBadgeTr: 'DTZ B1 · Belediye / Komşuluk Dilekçesi',
    titleTr: 'İnternet Siparişi Hasarlı Ürün İadesi',
    titleDe: 'Reklamation einer defekten Bestellung',
    scenarioTr: 'İnternetten sipariş ettiğin kahve makinesi bozuk ve çizik geldi. Müşteri hizmetlerine iade ve değişim talebi yaz.',
    recipientType: 'formal',
    minWords: 45,
    recommendedWords: '55–85 kelime',
    leitpunkteTr: [
      'Sipariş numarası / tarihini ve ne aldığını belirt.',
      'Üründeki hasarı veya hatayı açıkla.',
      'Ne talep ediyorsun? (Para iadesi veya yeni ürün gönderimi)',
      'Cevap için süre ve iletişim bilgisi ver.',
    ],
    usefulPhrasesDe: [
      'Ich habe am ... bei Ihnen bestellt.',
      'Leider wurde der Artikel beschädigt geliefert.',
      'Ich möchte mich über die Qualität beschweren.',
      'Deshalb bitte ich um einen Umtausch / eine Rückerstattung.',
    ],
    sampleSolutionDe:
      'Sehr geehrte Damen und Herren,\n\nam 10. Oktober habe ich bei Ihnen eine Kaffeemaschine (Bestellnummer 48291) bestellt. Leider kam das Paket gestern beschädigt an: Das Gerät hat mehrere Kratzer und schaltet sich überhaupt nicht ein.\n\nDa ich ein einwandfreies Produkt erwartet habe, möchte ich die Maschine zurückschicken. Ich bitte Sie deshalb entweder um den schnellen Versand eines neuen Geräts oder um die vollständige Rückerstattung des Kaufpreises innerhalb von 14 Tagen.\n\nMit freundlichen Grüßen\nKerem Aydın',
    expectedConceptGroups: [
      { labelTr: 'Sipariş bilgisi', keywords: ['bestellt', 'bestellung', 'bestellnummer', 'paket'] },
      { labelTr: 'Hasar / kusur açıklaması', keywords: ['kaputt', 'beschädigt', 'funktioniert', 'kratzer', 'defekt'] },
      { labelTr: 'İade / değişim talebi', keywords: ['zurück', 'umtausch', 'geld', 'erstattung', 'neues'] },
    ],
  },
  {
    id: 'wr_b2_homeoffice',
    level: 'B2',
    examBadgeTr: 'Goethe B2 · Yöneticiden Talepte Bulunma',
    titleTr: 'Yöneticiden Kısmi Home-Office İzni İsteme',
    titleDe: 'Antrag auf mobiles Arbeiten (Homeoffice)',
    scenarioTr: 'Şirketinizde haftada 2 gün evden çalışma (Homeoffice) sistemine geçmek için müdürünüz Frau Hartmann\'a ikna edici ve profesyonel bir e-posta yazın.',
    recipientType: 'formal',
    minWords: 70,
    recommendedWords: '80–120 kelime',
    leitpunkteTr: [
      'Talebin amacını net ve profesyonel şekilde sun.',
      'Evden çalışmanın verimlilik ve odaklanma avantajlarını gerekçelendir.',
      'Ekip iletişiminin aksamayacağına dair somut çözüm öner.',
      'Önce 2 aylık deneme süreci öner.',
    ],
    usefulPhrasesDe: [
      'Ich wende mich mit einem Anliegen an Sie.',
      'Einerseits ..., andererseits...',
      'Dadurch ließe sich die Produktivität deutlich steigern.',
      'Um die Zusammenarbeit im Team zu gewährleisten, ...',
    ],
    sampleSolutionDe:
      'Sehr geehrte Frau Hartmann,\n\nich wende mich heute mit einem Anliegen bezüglich meiner Arbeitsorganisation an Sie. Aufgrund des langen Arbeitswegs verliere ich täglich fast zwei Stunden im Pendelverkehr. Daher möchte ich fragen, ob es möglich wäre, zweimal pro Woche im Homeoffice zu arbeiten.\n\nFür konzeptionelle Aufgaben benötige ich oft ruhige Arbeitsphasen, in denen ich zu Hause besonders konzentriert und effizient arbeiten kann. Um den reibungslosen Austausch im Team weiterhin zu gewährleisten, wäre ich während der Kernarbeitszeiten telefonisch sowie per Videokonferenz jederzeit erreichbar und an drei festen Tagen im Büro.\n\nAls Kompromiss schlage ich eine zweimonatige Testphase vor, nach der wir die Ergebnisse gemeinsam auswerten können. Über ein kurzes persönliches Gespräch würde ich mich sehr freuen.\n\nMit freundlichen Grüßen\nDilara Özkan',
    expectedConceptGroups: [
      { labelTr: 'Home-office talebi', keywords: ['homeoffice', 'mobil', 'zu hause', 'arbeiten'] },
      { labelTr: 'Verimlilik / gerekçe', keywords: ['konzentriert', 'produktivität', 'zeit', 'arbeitsweg', 'effizient'] },
      { labelTr: 'Ekip iletişimi & deneme süresi', keywords: ['team', 'erreichbar', 'testphase', 'gespräch', 'absprache'] },
    ],
  },
  {
    id: 'wr_b2_forum_plastic',
    level: 'B2',
    examBadgeTr: 'Goethe B2 · Forum Tartışma Yazısı',
    titleTr: 'Şehir Merkezlerinde Araç Yasağı Tartışması',
    titleDe: 'Autofreie Innenstädte – Pro und Contra',
    scenarioTr: 'Bir çevrimiçi forumda büyük şehirlerin merkezlerinde özel araçların yasaklanması tartışılıyor. Kendi görüşünü artıları ve eksileriyle yaz.',
    recipientType: 'informal',
    minWords: 75,
    recommendedWords: '85–130 kelime',
    leitpunkteTr: [
      'Konuya güncel bir giriş yap ve kendi fikrini belirt.',
      'Araçsız şehir merkezinin 2 avantajını açıkla.',
      'Olası bir dezavantaj veya endişeye değin (ör. esnaf, yaşlılar).',
      'Somut bir çözüm/alternatif önerisiyle bitir.',
    ],
    usefulPhrasesDe: [
      'Meiner Meinung nach ist dieses Thema äußerst aktuell.',
      'Einerseits bietet es den Vorteil, dass...',
      'Auf der anderen Seite darf man nicht vergessen, dass...',
      'Abschließend lässt sich sagen, dass...',
    ],
    sampleSolutionDe:
      'Hallo zusammen,\n\ndas Thema autofreie Innenstädte wird derzeit zu Recht intensiv diskutiert. Meiner Ansicht nach wäre ein schrittweiser Verzicht auf Privat-Pkw im Zentrum ein wichtiger Gewinn für die Lebensqualität.\n\nEin wesentlicher Vorteil liegt in der deutlichen Reduzierung von Lärm und Abgasen, wodurch Fußgänger und Radfahrer mehr Raum gewinnen. Zudem würden Cafés und kleine Geschäfte von einer angenehmeren Atmosphäre profitieren. Auf der anderen Seite darf man nicht außer Acht lassen, dass Lieferanten sowie ältere oder mobilitätseingeschränkte Menschen weiterhin auf eine gute Erreichbarkeit angewiesen sind.\n\nDeshalb halte ich ein intelligentes Konzept aus ausgebautem Nahverkehr, Ausnahmegenehmigungen für Anwohner und günstigen Park-and-Ride-Plätzen für die sinnvollste Lösung.',
    expectedConceptGroups: [
      { labelTr: 'Görüş bildirimi', keywords: ['meiner meinung', 'ansicht', 'denke', 'finde', 'überzeugt'] },
      { labelTr: 'Avantajlar (hava, gürültü, yaşam)', keywords: ['luft', 'abgase', 'lärm', 'umwelt', 'fußgänger', 'vorteil'] },
      { labelTr: 'Dezavantaj & alternatif', keywords: ['nahverkehr', 'bus', 'bahn', 'ältere', 'nachteil', 'ausnahme', 'lösung'] },
    ],
  },
  {
    id: 'wr_c1_ai_education',
    level: 'C1',
    examBadgeTr: 'Goethe C1 · Akademik Görüş Metni',
    titleTr: 'Yükseköğretimde Yapay Zeka Kullanımı',
    titleDe: 'Künstliche Intelligenz an Hochschulen',
    scenarioTr: 'Üniversitelerde yapay zeka araçlarının sınav ve ödevlerde kullanımı yasaklanmalı mı yoksa müfredata entegre mi edilmeli? C1 düzeyinde yapılandırılmış bir değerlendirme metni yaz.',
    recipientType: 'formal',
    minWords: 100,
    recommendedWords: '120–170 kelime',
    leitpunkteTr: [
      'Tartışmanın arka planını soyut ve tarafsız bir dille özetle.',
      'Tam yasaklama fikrinin neden gerçekçi olmadığını analiz et.',
      'Akademik dürüstlüğü koruyarak AI entegrasyonunun nasıl sağlanacağını tartış.',
      'Kapsayıcı bir sonuç cümlesiyle pozisyonunu netleştir.',
    ],
    usefulPhrasesDe: [
      'Angesichts der rasanten Entwicklung...',
      'Es greift jedoch zu kurz, diese Technologie pauschal zu verbieten.',
      'Entscheidend ist vielmehr, inwiefern...',
      'Zusammenfassend lässt sich festhalten, dass...',
    ],
    sampleSolutionDe:
      'Angesichts der rasanten Verbreitung generativer KI-Systeme stehen Hochschulen vor der Frage, wie sie Leistungsnachweise künftig gestalten sollen. Während einige Stimmen ein striktes Verbot fordern, um Plagiate zu verhindern, plädieren andere für eine bewusste Integration.\n\nEin pauschales Verbot greift meines Erachtens zu kurz, da sich weder die Nutzung zuverlässig kontrollieren lässt noch die künftige Berufswelt ohne KI-Kompetenzen auskommt. Vielmehr sollten Universitäten Prüfungsformate überdenken: Mündliche Kolloquien, Prozessdokumentationen sowie kritische Quellenanalysen fördern eigenständiges Denken deutlich wirksamer als klassische Hausarbeiten.\n\nEntscheidend ist folglich nicht die Ablehnung moderner Werkzeuge, sondern die Vermittlung von Medienkritik und Transparenz. Zusammenfassend lässt sich festhalten, dass eine reflektierte Integration den Bildungsauftrag nachhaltiger stärkt als jede Verbotskultur.',
    expectedConceptGroups: [
      { labelTr: 'Tartışma bağlamı', keywords: ['hochschul', 'universit', 'ki', 'künstlich', 'studier'] },
      { labelTr: 'Yasak eleştirisi', keywords: ['verbot', 'verbieten', 'kontroll', 'realistisch', 'pauschal'] },
      { labelTr: 'Çözüm & sentez', keywords: ['prüfung', 'kompetenz', 'transparenz', 'integration', 'zusammenfassend'] },
    ],
  },
];
