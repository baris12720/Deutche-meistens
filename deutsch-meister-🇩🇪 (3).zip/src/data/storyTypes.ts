import { ArticleType, CEFRLevel } from '../types';

export interface StoryWordEntry {
  base: string;
  turkish: string;
  article: ArticleType;
  plural?: string;
  category?: string;
  exampleDe?: string;
  exampleTr?: string;
}

export interface StoryCharacter {
  id: string;
  name: string;
  roleTr: string;
  avatarEmoji: string;
  side: 'left' | 'right';
  bubbleTone: 'indigo' | 'emerald' | 'amber' | 'rose' | 'sky' | 'violet';
}

export interface StoryLineStep {
  kind: 'line';
  id: string;
  speaker: string;
  isNarrator?: boolean;
  characterId?: string;
  german: string;
  turkish: string;
}

export interface StoryComprehensionChallenge {
  kind: 'challenge';
  challengeType: 'comprehension';
  id: string;
  titleTr: string;
  questionTr: string;
  options: string[];
  correctAnswer: string;
  hintTr: string;
  explanationTr: string;
}

export interface StoryFillBlankChallenge {
  kind: 'challenge';
  challengeType: 'fill_blank';
  id: string;
  titleTr: string;
  speaker?: string;
  promptDe: string;
  promptTr: string;
  options: string[];
  correctAnswer: string;
  hintTr: string;
  explanationTr: string;
}

export interface StoryWordOrderChallenge {
  kind: 'challenge';
  challengeType: 'word_order';
  id: string;
  titleTr: string;
  speaker?: string;
  promptTr: string;
  correctWords: string[];
  scrambledWords: string[];
  hintTr: string;
  explanationTr: string;
}

export interface StoryVocabMatchChallenge {
  kind: 'challenge';
  challengeType: 'vocab_match';
  id: string;
  titleTr: string;
  promptTr: string;
  pairs: { id: string; de: string; tr: string }[];
  hintTr: string;
  explanationTr: string;
}

export type StoryChallengeStep =
  | StoryComprehensionChallenge
  | StoryFillBlankChallenge
  | StoryWordOrderChallenge
  | StoryVocabMatchChallenge;

export type StoryStep = StoryLineStep | StoryChallengeStep;

export interface Story {
  id: string;
  level: CEFRLevel;
  titleTr: string;
  titleDe: string;
  scenarioTag: string;
  emoji: string;
  durationMin: number;
  summaryTr: string;
  xpReward: number;
  characters: StoryCharacter[];
  steps: StoryStep[];
  vocabularyMap: Record<string, StoryWordEntry>;
}
