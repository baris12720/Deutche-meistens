export * from './storyTypes';
import { STORIES_A1_A2 } from './storiesA1A2';
import { STORIES_B1_C1 } from './storiesB1C1';
import { Story } from './storyTypes';

export const STORIES: Story[] = [...STORIES_A1_A2, ...STORIES_B1_C1];
