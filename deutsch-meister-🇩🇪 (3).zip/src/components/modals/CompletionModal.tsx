import React, { useMemo } from 'react';
import { Zap, CheckCircle2, ArrowRight, BookOpen, GraduationCap, Sparkles } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MeisterMax } from '../mascot/MeisterMax';
import { ALL_BADGES } from '../../data/badges';
import { ALL_UNITS_BY_LEVEL } from '../../data/levels';
import { getRecommendedNextSteps } from '../../utils/learningBridge';
import { Lesson } from '../../types';

const LESSON_LOOKUP = new Map<string, Lesson>();
for (const units of Object.values(ALL_UNITS_BY_LEVEL)) {
  for (const unit of units) {
    for (const lesson of unit.lessons) {
      LESSON_LOOKUP.set(lesson.id, lesson);
    }
  }
}

export const CompletionModal: React.FC = () => {
  const { completionData, closeCompletionModal, goTo, currentLevel } = useApp();

  const bridge = useMemo(() => {
    if (!completionData) return null;
    const lesson = LESSON_LOOKUP.get(completionData.lessonTitle);
    return getRecommendedNextSteps({
      id: lesson?.id || completionData.lessonTitle,
      level: lesson?.level || currentLevel,
      titleTr: lesson?.titleTr || completionData.lessonTitle,
      descriptionTr: lesson?.descriptionTr || '',
    });
  }, [completionData, currentLevel]);

  if (!completionData) return null;

  const accuracy = Math.round(
    (completionData.correctCount / Math.max(1, completionData.totalQuestions)) * 100
  );

  const unlockedBadgeObjects = ALL_BADGES.filter((b) =>
    completionData.newBadges.includes(b.id)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-800 text-center flex flex-col items-center my-auto">
        {/* Celebrating Mascot */}
        <MeisterMax
          mood="celebrating"
          size="lg"
          speechBubble="Wunderbar! Harika bir performans gösterdin!"
          className="mb-3"
        />

        <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
          Ders Tamamlandı! 🎉
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Almanca hedefine bir adım daha yaklaştın.
        </p>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 w-full my-5">
          <div className="p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
            <div className="flex items-center justify-center gap-1.5 text-amber-600 mb-1">
              <Zap className="w-5 h-5 fill-amber-500" />
              <span className="text-2xl font-black">+{completionData.earnedXp}</span>
            </div>
            <span className="text-xs font-bold text-amber-800 dark:text-amber-300">
              Kazanılan XP
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800">
            <div className="flex items-center justify-center gap-1.5 text-emerald-600 mb-1">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-2xl font-black">%{accuracy}</span>
            </div>
            <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
              Başarı Oranı
            </span>
          </div>
        </div>

        {/* Unlocked Badges */}
        {unlockedBadgeObjects.length > 0 && (
          <div className="w-full mb-4 p-3.5 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 animate-bounce">
            <span className="text-xs font-bold text-purple-700 dark:text-purple-300 uppercase tracking-wider block mb-2">
              🏆 Yeni Rozet Kazandın!
            </span>
            <div className="flex items-center justify-center gap-2">
              {unlockedBadgeObjects.map((b) => (
                <div key={b.id} className="flex items-center gap-2">
                  <span className="text-2xl">{b.icon}</span>
                  <div className="text-left">
                    <p className="text-xs font-extrabold text-purple-900 dark:text-purple-100">{b.title}</p>
                    <p className="text-[10px] text-purple-600 dark:text-purple-300">{b.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Holistic Learning Bridge: Story + Exam Practice */}
        {bridge && (
          <div className="w-full mb-5 p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/70 text-left space-y-2.5">
            <div className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
              <Sparkles className="w-3.5 h-3.5" /> Sıradaki Bağlam Köprüsü
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
              {bridge.reasonTr}
            </p>
            <div className="grid grid-cols-1 gap-2">
              <button
                type="button"
                onClick={() => {
                  closeCompletionModal();
                  goTo('stories', bridge.story.id);
                }}
                className="w-full p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-700 hover:border-indigo-400 flex items-center justify-between gap-2 text-left transition cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-xl shrink-0">{bridge.story.emoji}</span>
                  <div className="min-w-0">
                    <span className="text-[10px] font-black uppercase text-indigo-600 dark:text-indigo-400 block">
                      Önerilen Hikaye · {bridge.story.level}
                    </span>
                    <span className="text-xs font-black text-slate-900 dark:text-white truncate block">
                      {bridge.story.titleTr}
                    </span>
                  </div>
                </div>
                <BookOpen className="w-4 h-4 text-indigo-500 shrink-0" />
              </button>

              <button
                type="button"
                onClick={() => {
                  closeCompletionModal();
                  goTo('dtz', `${bridge.examLevel}:${bridge.examSection}`);
                }}
                className="w-full p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-rose-200 dark:border-rose-800 hover:border-rose-400 flex items-center justify-between gap-2 text-left transition cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-xl shrink-0">🎯</span>
                  <div className="min-w-0">
                    <span className="text-[10px] font-black uppercase text-rose-600 dark:text-rose-400 block">
                      İlgili Sınav Pratiği
                    </span>
                    <span className="text-xs font-black text-slate-900 dark:text-white truncate block">
                      {bridge.examLabelTr}
                    </span>
                  </div>
                </div>
                <GraduationCap className="w-4 h-4 text-rose-500 shrink-0" />
              </button>
            </div>
          </div>
        )}

        {/* Continue Button */}
        <button
          onClick={closeCompletionModal}
          className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-[0_4px_0_#15803d] active:shadow-none active:translate-y-1 transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Öğrenmeye Devam Et</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
