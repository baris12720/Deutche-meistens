import React, { memo, useMemo, useState } from 'react';
import { Brain, Check, CheckCircle2, ChevronDown, ChevronUp, Sparkles, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Skill } from '../../types';
import { SKILLS, skillAccuracy, todayActivity } from '../../utils/analytics';
import { getDueItems } from '../../utils/srs';
import { buildPersonalizedMiniSet } from '../../utils/learningBridge';
import { ARTICLE_TEXT_COLOR } from '../../utils/articleColors';
import { playSuccessSound, playWrongSound, speakGerman } from '../../utils/audio';

const MINUTE_CHOICES = [10, 15, 20, 30];

interface Step {
  id: string;
  label: string;
  emoji: string;
  skill?: Skill;
}

const STEPS: Step[] = [
  { id: 'review', label: 'Tekrar', emoji: '🔁' },
  { id: 'words', label: 'Yeni kelime', emoji: '📚', skill: 'vocab' },
  { id: 'grammar', label: 'Gramer', emoji: '🧩', skill: 'grammar' },
  { id: 'listening', label: 'Dinleme', emoji: '🎧', skill: 'listening' },
  { id: 'speaking', label: 'Konuşma', emoji: '🎤', skill: 'speaking' },
];

/** Personal daily plan: split of the chosen study time, with extra minutes for the weakest skill + personalized MistakeNotebook mini review set. */
export const DailyPlan: React.FC<{ onStartReview: () => void }> = memo(({ onStartReview }) => {
  const { profile, setDailyMinutes, goTo, recordAnswer, recordActivity, addXp } = useApp();
  const total = profile.dailyMinutes || 15;
  const today = useMemo(() => todayActivity(profile), [profile]);
  const due = useMemo(() => getDueItems(profile).length, [profile]);
  const acc = useMemo(() => skillAccuracy(profile, 30), [profile]);
  const miniSet = useMemo(() => buildPersonalizedMiniSet(profile), [profile]);

  const [miniOpen, setMiniOpen] = useState(false);
  const [miniAnswers, setMiniAnswers] = useState<Record<string, string>>({});
  const [miniRewarded, setMiniRewarded] = useState(false);

  const { weakest, weakestStep, weakestPct } = useMemo(() => {
    const candidates = (['vocab', 'grammar', 'listening', 'speaking'] as Skill[]).filter(
      (s) => typeof acc?.[s]?.pct === 'number'
    );
    const w = candidates.sort((a, b) => (acc[a]?.pct ?? 100) - (acc[b]?.pct ?? 100))[0];
    return {
      weakest: w,
      weakestStep: w ? STEPS.find((s) => s.skill === w) : undefined,
      weakestPct: w ? acc?.[w]?.pct ?? null : null,
    };
  }, [acc]);

  const base = total / 5;
  const bonus = weakestStep ? Math.max(1, Math.round(total * 0.1)) : 0;
  const minutesFor = (s: Step) => {
    let m = base;
    if (weakestStep && s.id === weakestStep.id) m += bonus;
    else if (weakestStep && s.id === 'review') m -= bonus;
    return Math.max(1, Math.round(m));
  };

  const isDone = (s: Step): boolean => {
    if (s.id === 'review') return due === 0 || (today.rev || 0) >= 1;
    const sk = s.skill ? today.skills?.[s.skill] : undefined;
    const done = (sk?.r || 0) + (sk?.w || 0);
    return done >= Math.max(4, minutesFor(s) * 2);
  };
  const doneCount = STEPS.filter(isDone).length;

  const start = (s: Step) => {
    if (s.id === 'review') return onStartReview();
    if (s.id === 'words') return goTo('words', 'sets');
    if (s.id === 'grammar') return goTo('grammar', 'lab');
    if (s.id === 'listening') return goTo('words', 'listening');
    return goTo('words', 'speaking');
  };

  const handleMiniPick = (qId: string, option: string, correctAnswer: string, refId?: string) => {
    if (miniAnswers[qId]) return;
    const isOk = option === correctAnswer;
    const next = { ...miniAnswers, [qId]: option };
    setMiniAnswers(next);
    if (refId) recordAnswer(refId, isOk);
    recordActivity('grammar', isOk, 12);
    if (isOk) playSuccessSound(profile.soundEnabled);
    else playWrongSound(profile.soundEnabled);

    if (!miniRewarded && Object.keys(next).length === miniSet.questions.length) {
      setMiniRewarded(true);
      addXp(12);
    }
  };

  const miniCorrectCount = miniSet.questions.filter(
    (q) => miniAnswers[q.id] === q.correctAnswer
  ).length;
  const miniAnsweredCount = Object.keys(miniAnswers).length;

  return (
    <div className="mt-4 space-y-3">
      <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-200 dark:border-emerald-900/60 p-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <div className="text-[11px] font-black uppercase tracking-wide text-emerald-700 dark:text-emerald-300">Bugünkü planın</div>
            <div className="text-sm font-black text-slate-900 dark:text-white">
              {doneCount}/5 tamam · {total} dakika
            </div>
          </div>
          <div className="flex gap-1" aria-label="Günlük çalışma süresi">
            {MINUTE_CHOICES.map((m) => (
              <button
                key={m}
                onClick={() => setDailyMinutes(m)}
                className={`px-2.5 h-8 rounded-lg text-[11px] font-black cursor-pointer transition ${
                  total === m
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {m} dk
              </button>
            ))}
          </div>
        </div>
        {weakestStep && weakestPct !== null && (
          <p className="mt-1.5 text-[11px] text-slate-600 dark:text-slate-300">
            Odak: {SKILLS.find((x) => x.id === weakest)?.label} (%{weakestPct}). Bu adıma fazladan süre ayrıldı.
          </p>
        )}
        <ul className="mt-2.5 space-y-1.5">
          {STEPS.map((s) => {
            const done = isDone(s);
            return (
              <li key={s.id} className="flex items-center gap-3">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0 ${
                    done ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {done ? <Check className="w-4 h-4" /> : s.emoji}
                </div>
                <div className="flex-1 min-w-0 text-sm font-bold text-slate-800 dark:text-slate-100">
                  {s.label}
                  <span className="ml-2 text-xs font-bold text-slate-400">
                    {s.id === 'review' && due === 0 ? 'bugün tekrar yok' : `${minutesFor(s)} dk`}
                  </span>
                </div>
                {!done && (
                  <button
                    onClick={() => start(s)}
                    className="px-3 h-8 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-black cursor-pointer transition"
                  >
                    Başla
                  </button>
                )}
              </li>
            );
          })}
        </ul>
      </div>

      {/* Personalized Weak-Spot Mini Review Set */}
      <div className="rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/30 border-2 border-indigo-200 dark:border-indigo-900/60 p-3.5 space-y-2.5">
        <button
          type="button"
          onClick={() => setMiniOpen((v) => !v)}
          className="w-full flex items-center justify-between gap-2 text-left cursor-pointer"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Brain className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-black uppercase tracking-wide text-indigo-700 dark:text-indigo-300">
                {miniSet.hasRealMistakes ? 'Hata Defterine Özel Mini Tekrar' : 'Akıllı Pekiştirme Seti'}
              </div>
              <div className="text-xs sm:text-sm font-black text-slate-900 dark:text-white truncate">
                {miniSet.focusLabelTr} · 3 Hızlı Soru (+12 XP)
              </div>
            </div>
          </div>
          <span className="p-1.5 rounded-lg bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-300 shrink-0">
            {miniOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </span>
        </button>

        {miniOpen && (
          <div className="pt-2 border-t border-indigo-200/70 dark:border-indigo-800/60 space-y-3 pop-in">
            {/* Weak words chips */}
            {miniSet.weakWords.length > 0 && (
              <div className="space-y-1">
                <div className="text-[11px] font-black text-slate-600 dark:text-slate-300">
                  Zayıf Kelimeler:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {miniSet.weakWords.map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() =>
                        void speakGerman(
                          w.article !== 'none' ? `${w.article} ${w.german}` : w.german,
                          profile.speechSpeed
                        )
                      }
                      className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-700 text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      {w.article !== 'none' && (
                        <span className={`font-black ${ARTICLE_TEXT_COLOR[w.article as 'der' | 'die' | 'das'] || ''}`}>
                          {w.article}
                        </span>
                      )}
                      <span className="text-slate-900 dark:text-white">{w.german}</span>
                      <span className="text-slate-400">({w.turkish})</span>
                      <Volume2 className="w-3 h-3 text-indigo-500" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Related grammar rule */}
            <div className="p-2.5 rounded-xl bg-white/90 dark:bg-slate-900/60 border border-indigo-200/80 dark:border-indigo-800 text-xs">
              <div className="font-black text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> {miniSet.grammarTipTitleTr}
              </div>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5 leading-snug">
                {miniSet.grammarTipBodyTr}
              </p>
            </div>

            {/* 3 Interactive Reinforcement Questions */}
            <div className="space-y-2.5">
              {miniSet.questions.map((q, idx) => {
                const picked = miniAnswers[q.id];
                return (
                  <div
                    key={q.id}
                    className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-2 text-xs"
                  >
                    <div className="font-bold text-slate-500 dark:text-slate-400">
                      Soru {idx + 1}/3: {q.promptTr}
                    </div>
                    <div className="text-sm font-black text-slate-900 dark:text-white">
                      {q.promptDe}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {q.options.map((opt) => {
                        const isPicked = picked === opt;
                        const isCorrect = opt === q.correctAnswer;
                        return (
                          <button
                            key={opt}
                            type="button"
                            disabled={!!picked}
                            onClick={() => handleMiniPick(q.id, opt, q.correctAnswer, q.refId)}
                            className={`px-3 py-1.5 rounded-xl border-2 text-xs font-black transition cursor-pointer ${
                              picked && isCorrect
                                ? 'bg-emerald-500 text-white border-emerald-600'
                                : picked && isPicked && !isCorrect
                                ? 'bg-rose-100 dark:bg-rose-950 border-rose-500 text-rose-700 dark:text-rose-200'
                                : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-indigo-400'
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>
                    {picked && (
                      <div
                        className={`p-2 rounded-xl text-[11px] font-bold ${
                          picked === q.correctAnswer
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                            : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
                        }`}
                      >
                        {q.explanationTr}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {miniAnsweredCount === miniSet.questions.length && (
              <div className="p-3 rounded-xl bg-emerald-600 text-white text-xs font-black flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Mini tekrar tamamlandı ({miniCorrectCount}/3 doğru) · +12 XP!
                </span>
                <button
                  type="button"
                  onClick={() => setMiniAnswers({})}
                  className="px-2.5 py-1 rounded-lg bg-white/20 hover:bg-white/30 cursor-pointer"
                >
                  Tekrar Çöz
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
});
