import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, Play, Square, Turtle, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CEFRLevel, Exercise, RealLifeDialogue } from '../../types';
import { REAL_LIFE_DIALOGUES } from '../../data/dialogues';
import { buildDialogueListeningExercises } from '../../data/dialogueExercises';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { speakGerman, speakGermanSlow, stopSpeaking } from '../../utils/audio';
import { useBackHandler } from '../../utils/backStack';
import { LEVEL_ORDER } from '../../utils/progress';

const SPEEDS = [
  { rate: 0.6, label: '0.6x Çok Yavaş' },
  { rate: 0.75, label: '0.75x Yavaş' },
  { rate: 1.0, label: '1.0x Normal' },
];

export const ListeningLab: React.FC = () => {
  const { currentLevel, addXp } = useApp();
  const [level, setLevel] = useState<CEFRLevel>(currentLevel);
  const [open, setOpen] = useState<RealLifeDialogue | null>(null);
  const [quiz, setQuiz] = useState<Exercise[] | null>(null);
  const [rate, setRate] = useState(0.75);
  const [showTr, setShowTr] = useState(false);
  const [hideText, setHideText] = useState(false);
  const [playing, setPlaying] = useState<number | null>(null);
  const stopRef = useRef(false);
  const awarded = useRef(false);

  const stop = () => {
    stopRef.current = true;
    setPlaying(null);
    void stopSpeaking();
  };
  const close = () => {
    stop();
    setOpen(null);
    setQuiz(null);
  };
  useBackHandler(open !== null, () => (quiz ? setQuiz(null) : close()));
  useEffect(() => () => stop(), []); // eslint-disable-line react-hooks/exhaustive-deps

  const playAll = async () => {
    if (!open) return;
    stopRef.current = false;
    for (let i = 0; i < open.lines.length; i++) {
      if (stopRef.current) break;
      setPlaying(i);
      await speakGerman(open.lines[i].german, rate);
      await new Promise((r) => setTimeout(r, 450));
    }
    setPlaying(null);
  };

  const list = REAL_LIFE_DIALOGUES.filter((d) => d.level === level);

  if (open && quiz) {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
        <ExerciseRunner
          exercises={quiz}
          allowLengthSelect={false}
          title={`Dinleme: ${open.titleTr}`}
          completeLabel="Bitir"
          onExit={() => setQuiz(null)}
          onFinish={(correct) => {
            if (awarded.current) return;
            awarded.current = true;
            addXp(6 + correct * 2);
          }}
          onComplete={() => setQuiz(null)}
        />
      </div>
    );
  }

  if (open) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
        <div className="flex items-center gap-3 px-4 h-14 shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <button onClick={close} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="min-w-0">
            <div className="text-sm font-black text-slate-900 dark:text-white truncate">{open.titleTr}</div>
            <div className="text-[11px] text-slate-400 truncate">{open.titleDe}</div>
          </div>
        </div>

        <div className="px-4 pt-3 space-y-2 shrink-0">
          <div className="flex items-center gap-2 flex-wrap">
            {SPEEDS.map((s) => (
              <button
                key={s.rate}
                onClick={() => setRate(s.rate)}
                className={`px-3 h-9 rounded-xl text-xs font-black cursor-pointer ${rate === s.rate ? 'bg-indigo-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
              >
                {s.label}
              </button>
            ))}
            <button
              onClick={() => setShowTr((v) => !v)}
              className={`px-3 h-9 rounded-xl text-xs font-black cursor-pointer ${showTr ? 'bg-amber-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
            >
              Türkçe çeviri
            </button>
            <button
              onClick={() => setHideText((v) => !v)}
              className={`px-3 h-9 rounded-xl text-xs font-black cursor-pointer ${hideText ? 'bg-slate-700 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
            >
              Metni gizle
            </button>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">{open.contextTr}</p>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2.5">
          {open.lines.map((l, i) => (
            <div key={l.id} className={`rounded-2xl p-3 border-2 ${playing === i ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-950/30' : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'}`}>
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-black text-slate-400">{l.speaker}</div>
                  <div className={`text-base font-bold text-slate-900 dark:text-white leading-snug ${hideText ? 'blur-md select-none' : ''}`}>{l.german}</div>
                  {showTr && <div className="mt-1 text-sm text-slate-500 dark:text-slate-400">{l.turkish}</div>}
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => speakGerman(l.german, rate)}
                    className="w-9 h-9 rounded-full bg-sky-500 text-white inline-flex items-center justify-center cursor-pointer"
                    aria-label="Bu cümleyi dinle"
                    title="Seçili hızda dinle"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => speakGermanSlow(l.german)}
                    className="h-9 px-2.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 inline-flex items-center gap-1 text-[11px] font-black cursor-pointer"
                    aria-label="0.75x yavaş dinle"
                    title="0.75x yavaş dinle"
                  >
                    <Turtle className="w-3.5 h-3.5" /> 0.75x
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 pb-[max(1rem,env(safe-area-inset-bottom))] shrink-0 grid grid-cols-2 gap-3 max-w-xl w-full mx-auto">
          <button
            onClick={() => (playing === null ? playAll() : stop())}
            className="h-14 rounded-2xl bg-indigo-500 text-white font-black shadow-[0_5px_0_#4338ca] active:translate-y-1 active:shadow-none inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            {playing === null ? (
              <>
                <Play className="w-5 h-5" /> Hepsini dinle
              </>
            ) : (
              <>
                <Square className="w-5 h-5" /> Durdur
              </>
            )}
          </button>
          <button
            onClick={() => {
              stop();
              awarded.current = false;
              setQuiz(buildDialogueListeningExercises(open));
            }}
            className="h-14 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer"
          >
            Alıştırma yap
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      <h2 className="text-xl font-black text-slate-900 dark:text-white">Dinleme laboratuvarı</h2>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
        Günlük diyaloglar. Hızı seç, önce metni gizleyip sadece dinle, sonra çeviriyle kontrol et ve alıştırma yap.
      </p>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Dinleme seviyesi">
        {LEVEL_ORDER.map((lvl) => (
          <button
            key={lvl}
            role="tab"
            aria-selected={lvl === level}
            onClick={() => setLevel(lvl)}
            className={`flex-1 min-w-[56px] h-10 rounded-2xl text-sm font-black cursor-pointer ${lvl === level ? 'bg-indigo-500 text-white shadow-[0_4px_0_#4338ca]' : 'bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
          >
            {lvl}
          </button>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {list.length === 0 && <p className="text-sm text-slate-500">Bu seviyede henüz diyalog yok. Diğer seviyeleri dene.</p>}
        {list.map((d) => (
          <button
            key={d.id}
            onClick={() => setOpen(d)}
            className="w-full text-left rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4 active:translate-y-0.5 transition cursor-pointer"
          >
            <div className="text-[11px] font-black text-indigo-500">{d.category}</div>
            <div className="mt-0.5 text-base font-black text-slate-900 dark:text-white">{d.titleTr}</div>
            <div className="text-xs text-slate-500 dark:text-slate-400">{d.lines.length} cümle · {d.titleDe}</div>
          </button>
        ))}
      </div>
    </div>
  );
};
