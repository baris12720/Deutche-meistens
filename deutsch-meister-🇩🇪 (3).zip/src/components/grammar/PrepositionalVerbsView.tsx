import React, { memo, useMemo, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Dumbbell,
  PlusCircle,
  Search,
  Sparkles,
  Turtle,
  Volume2,
  XCircle,
} from 'lucide-react';
import { PREPOSITIONAL_VERBS, PrepositionalVerb } from '../../data/prepositionalVerbs';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import {
  playSuccessSound,
  playWrongSound,
  speakGerman,
  speakGermanSlow,
} from '../../utils/audio';

const CASE_BADGE: Record<'Akkusativ' | 'Dativ', string> = {
  Akkusativ: 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700',
  Dativ: 'bg-sky-100 dark:bg-sky-950/70 text-sky-800 dark:text-sky-300 border-sky-300 dark:border-sky-700',
};

export const PrepositionalVerbsView: React.FC = memo(() => {
  const { profile, addCustomWord, recordAnswer, recordActivity, addXp } = useApp();
  const [subMode, setSubMode] = useState<'list' | 'drill'>('list');
  const [levelFilter, setLevelFilter] = useState<CEFRLevel | 'ALL'>('ALL');
  const [caseFilter, setCaseFilter] = useState<'ALL' | 'Akkusativ' | 'Dativ'>('ALL');
  const [search, setSearch] = useState('');
  const [savedMap, setSavedMap] = useState<Record<string, boolean>>({});

  // Drill mode state
  const [drillIdx, setDrillIdx] = useState(0);
  const [pickedPrep, setPickedPrep] = useState<string | null>(null);
  const [pickedCase, setPickedCase] = useState<'Akkusativ' | 'Dativ' | null>(null);
  const [checked, setChecked] = useState(false);
  const [drillScore, setDrillScore] = useState(0);
  const [drillTotal, setDrillTotal] = useState(0);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return PREPOSITIONAL_VERBS.filter((v) => {
      if (levelFilter !== 'ALL' && v.level !== levelFilter) return false;
      if (caseFilter !== 'ALL' && v.caseType !== caseFilter) return false;
      if (q) {
        return (
          v.verb.toLowerCase().includes(q) ||
          v.preposition.toLowerCase().includes(q) ||
          v.meaningTr.toLowerCase().includes(q) ||
          v.exampleDe.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [levelFilter, caseFilter, search]);

  const activeDrillList = useMemo(
    () => (filtered.length > 0 ? filtered : PREPOSITIONAL_VERBS),
    [filtered]
  );
  const currentDrill: PrepositionalVerb =
    activeDrillList[drillIdx % activeDrillList.length];

  const drillOptions = useMemo(() => {
    const set = new Set([
      currentDrill.preposition,
      ...currentDrill.distractorPreps,
    ]);
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [currentDrill]);

  const handleSaveToSrs = (v: PrepositionalVerb) => {
    if (savedMap[v.id]) return;
    const created = addCustomWord({
      german: `${v.verb} ${v.preposition} (+ ${v.caseType})`,
      turkish: v.meaningTr,
      article: 'none',
      level: v.level,
      category: 'Edatlı Fiiller',
      exampleGerman: v.exampleDe,
      exampleTurkish: v.exampleTr,
      sourceTag: 'Edatlı Fiiller (Verben + Präp.)',
    });
    recordAnswer(created.id, false);
    setSavedMap((prev) => ({ ...prev, [v.id]: true }));
  };

  const handleCheckDrill = () => {
    if (!pickedPrep || !pickedCase || checked) return;
    const ok =
      pickedPrep === currentDrill.preposition &&
      pickedCase === currentDrill.caseType;
    setChecked(true);
    setDrillTotal((t) => t + 1);
    recordAnswer(`gram:praep:${currentDrill.id}`, ok);
    recordActivity('grammar', ok, 12);
    if (ok) {
      setDrillScore((s) => s + 1);
      addXp(5);
      playSuccessSound(profile.soundEnabled);
    } else {
      playWrongSound(profile.soundEnabled);
    }
  };

  const handleNextDrill = () => {
    setPickedPrep(null);
    setPickedCase(null);
    setChecked(false);
    setDrillIdx((i) => i + 1);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-24 space-y-5">
      {/* Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-sky-700 via-indigo-700 to-purple-700 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-black bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Verben mit Präpositionen · A2–C1
          </span>
          <h2 className="text-2xl font-black mt-1.5">Edatlı Fiiller & Kasus Merkezi</h2>
          <p className="text-xs sm:text-sm text-sky-100 mt-0.5 max-w-xl">
            warten auf + Akk, träumen von + Dat... Hangi fiilin hangi edatı ve hangi hali (Akkusativ/Dativ) aldığını sesli örnekler ve hızlı quizle öğren!
          </p>
        </div>
        <div className="bg-white/15 backdrop-blur-xs px-4 py-2.5 rounded-2xl text-center shrink-0">
          <span className="text-xl font-black block">{PREPOSITIONAL_VERBS.length} Kalıp</span>
          <span className="text-[10px] uppercase font-bold text-sky-100">Akkusativ & Dativ</span>
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-slate-200/70 dark:bg-slate-800 max-w-md mx-auto">
        <button
          type="button"
          onClick={() => setSubMode('list')}
          className={`h-10 rounded-xl text-xs sm:text-sm font-black inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
            subMode === 'list'
              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <BookOpen className="w-4 h-4" /> Referans Listesi
        </button>
        <button
          type="button"
          onClick={() => setSubMode('drill')}
          className={`h-10 rounded-xl text-xs sm:text-sm font-black inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
            subMode === 'drill'
              ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-xs'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Dumbbell className="w-4 h-4" /> Edat + Kasus Quiz
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Fiil, edat veya Türkçe anlam ara (ör: warten, auf, beklemek)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 overflow-x-auto">
            {(['ALL', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
              <button
                key={lvl}
                type="button"
                onClick={() => setLevelFilter(lvl)}
                className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer ${
                  levelFilter === lvl
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {lvl === 'ALL' ? 'Tümü' : lvl}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {(['ALL', 'Akkusativ', 'Dativ'] as const).map((cs) => (
              <button
                key={cs}
                type="button"
                onClick={() => setCaseFilter(cs)}
                className={`px-2.5 py-1 rounded-lg text-xs font-black transition cursor-pointer ${
                  caseFilter === cs
                    ? cs === 'Dativ'
                      ? 'bg-sky-600 text-white'
                      : cs === 'Akkusativ'
                      ? 'bg-amber-500 text-white'
                      : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cs === 'ALL' ? 'Tüm Haller' : cs}
              </button>
            ))}
          </div>
        </div>
      </div>

      {subMode === 'list' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((v) => (
            <div
              key={v.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-2xs flex flex-col justify-between gap-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-black px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
                    {v.level}
                  </span>
                  <span
                    className={`text-[11px] font-black px-2.5 py-0.5 rounded-full border ${CASE_BADGE[v.caseType]}`}
                  >
                    + {v.caseType}
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    {v.verb}{' '}
                    <span className="text-indigo-600 dark:text-indigo-400 underline decoration-2 underline-offset-4">
                      {v.preposition}
                    </span>
                  </h3>
                  <p className="text-xs sm:text-sm font-bold text-emerald-700 dark:text-emerald-400 mt-0.5">
                    {v.meaningTr}
                  </p>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100">
                      "{v.exampleDe}"
                    </p>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => void speakGerman(v.exampleDe, profile.speechSpeed)}
                        className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 cursor-pointer"
                        title="Normal Dinle"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => void speakGermanSlow(v.exampleDe)}
                        className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-600 dark:text-amber-300 cursor-pointer"
                        title="0.75x Yavaş Dinle"
                      >
                        <Turtle className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 italic">{v.exampleTr}</p>
                </div>

                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  💡 {v.tipTr}
                </p>
              </div>

              <button
                type="button"
                disabled={!!savedMap[v.id]}
                onClick={() => handleSaveToSrs(v)}
                className={`w-full py-2 px-3 rounded-xl text-xs font-black inline-flex items-center justify-center gap-1.5 transition cursor-pointer ${
                  savedMap[v.id]
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-100 dark:bg-slate-700 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-200'
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>{savedMap[v.id] ? 'Defterim & SRS\'e Eklendi' : 'Defterime & Tekrara Ekle'}</span>
              </button>
            </div>
          ))}
        </div>
      ) : (
        /* Interactive Drill Mode */
        <div className="max-w-xl mx-auto p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-sm space-y-5">
          <div className="flex items-center justify-between text-xs font-black">
            <span className="px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
              {currentDrill.level} · Soru {(drillIdx % activeDrillList.length) + 1}/{activeDrillList.length}
            </span>
            <span className="text-emerald-600 dark:text-emerald-400">
              Skor: {drillScore}/{drillTotal}
            </span>
          </div>

          <div className="space-y-1.5">
            <div className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Fiil: <strong className="text-slate-900 dark:text-white">{currentDrill.verb}</strong> ({currentDrill.meaningTr})
            </div>
            <p className="text-lg sm:text-xl font-black text-slate-900 dark:text-white leading-snug">
              {currentDrill.blankSentenceDe.replace(
                '___',
                checked ? currentDrill.preposition : '_____'
              )}
            </p>
          </div>

          {/* Step 1: Pick Preposition */}
          <div className="space-y-2">
            <div className="text-xs font-black uppercase tracking-wider text-slate-600 dark:text-slate-300">
              1. Doğru Edatı Seç:
            </div>
            <div className="grid grid-cols-3 gap-2">
              {drillOptions.map((opt) => {
                const isPicked = pickedPrep === opt;
                const isRight = opt === currentDrill.preposition;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={checked}
                    onClick={() => setPickedPrep(opt)}
                    className={`min-h-11 rounded-2xl border-2 text-sm font-black transition cursor-pointer ${
                      checked && isRight
                        ? 'bg-emerald-500 text-white border-emerald-600'
                        : checked && isPicked && !isRight
                        ? 'bg-rose-100 dark:bg-rose-950 border-rose-500 text-rose-700 dark:text-rose-200'
                        : isPicked
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Pick Case */}
          <div className="space-y-2">
            <div className="text-xs font-black uppercase tracking-wider text-slate-600 dark:text-slate-300">
              2. Bu kalıp hangi hali (Kasus) alır?
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {(['Akkusativ', 'Dativ'] as const).map((cs) => {
                const isPicked = pickedCase === cs;
                const isRight = cs === currentDrill.caseType;
                return (
                  <button
                    key={cs}
                    type="button"
                    disabled={checked}
                    onClick={() => setPickedCase(cs)}
                    className={`min-h-11 rounded-2xl border-2 text-sm font-black transition cursor-pointer ${
                      checked && isRight
                        ? 'bg-emerald-500 text-white border-emerald-600'
                        : checked && isPicked && !isRight
                        ? 'bg-rose-100 dark:bg-rose-950 border-rose-500 text-rose-700 dark:text-rose-200'
                        : isPicked
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100'
                    }`}
                  >
                    + {cs}
                  </button>
                );
              })}
            </div>
          </div>

          {!checked ? (
            <button
              type="button"
              disabled={!pickedPrep || !pickedCase}
              onClick={handleCheckDrill}
              className="w-full min-h-12 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-black text-sm shadow-[0_4px_0_#047857] active:translate-y-0.5 active:shadow-none transition cursor-pointer"
            >
              Kontrol Et
            </button>
          ) : (
            <div className="space-y-3">
              <div
                className={`p-4 rounded-2xl border text-xs space-y-1.5 ${
                  pickedPrep === currentDrill.preposition && pickedCase === currentDrill.caseType
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
                    : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-700 text-rose-900 dark:text-rose-200'
                }`}
              >
                <div className="font-black flex items-center gap-1.5">
                  {pickedPrep === currentDrill.preposition && pickedCase === currentDrill.caseType ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Harika! Doğru: {currentDrill.verb} {currentDrill.preposition} + {currentDrill.caseType}</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-rose-600" />
                      <span>Doğrusu: {currentDrill.verb} {currentDrill.preposition} + {currentDrill.caseType}</span>
                    </>
                  )}
                </div>
                <p>{currentDrill.tipTr}</p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => void speakGerman(currentDrill.exampleDe, profile.speechSpeed)}
                    className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-300 font-black inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" /> Örneği Dinle
                  </button>
                  <button
                    type="button"
                    onClick={() => void speakGermanSlow(currentDrill.exampleDe)}
                    className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-300 font-black inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Turtle className="w-3.5 h-3.5" /> 0.75x
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={handleNextDrill}
                className="w-full min-h-12 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm inline-flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" /> Sonraki Kalıp
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
});
