import React, { memo, useEffect, useMemo, useState } from 'react';
import {
  Flame,
  Zap,
  BookOpen,
  Award,
  Download,
  Upload,
  RotateCcw,
  Volume2,
  VolumeX,
  Gauge,
  CheckCircle2,
  Heart,
  ShieldCheck,
  Snowflake,
  Copy,
  AlertCircle,
} from 'lucide-react';
import { ProgressPanel } from './ProgressPanel';
import { useApp } from '../../context/AppContext';
import { ALL_BADGES } from '../../data/badges';
import { MeisterMax } from '../mascot/MeisterMax';
import { CEFR_LEVEL_DETAILS, ALL_UNITS_BY_LEVEL } from '../../data/levels';
import { CEFRLevel } from '../../types';

const PROFILE_LEVELS: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

const ProfileMainView: React.FC = memo(() => {
  const {
    profile,
    toggleSound,
    setSpeechSpeed,
    setDailyGoalXp,
    updateProfileName,
    setThemePreference,
    exportData,
    importBackupWithReport,
    resetProgress,
    buyStreakFreeze,
  } = useApp();

  const [importJsonText, setImportJsonText] = useState('');
  const [showImportBox, setShowImportBox] = useState(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [backupFeedback, setBackupFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [nameDraft, setNameDraft] = useState(profile.name);

  useEffect(() => setNameDraft(profile.name), [profile.name]);

  const totalMasteredWords = useMemo(
    () => Object.values(profile.wordCards).filter((w) => w.status === 'mastered').length,
    [profile.wordCards]
  );

  const levelProgress = useMemo(() => {
    const completedSet = new Set(profile.completedLessons);
    return PROFILE_LEVELS.map((lvl) => {
      const units = ALL_UNITS_BY_LEVEL[lvl] || [];
      let total = 0;
      let done = 0;
      for (const u of units) {
        total += u.lessons.length;
        for (const l of u.lessons) {
          if (completedSet.has(l.id)) done += 1;
        }
      }
      return {
        lvl,
        total,
        done,
        pct: Math.round((done / Math.max(1, total)) * 100),
      };
    });
  }, [profile.completedLessons]);

  const unlockedBadgeSet = useMemo(
    () => new Set(profile.unlockedBadges),
    [profile.unlockedBadges]
  );

  const handleExport = () => {
    const json = exportData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `deutsch_meister_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    setBackupFeedback({ ok: true, text: 'İlerlemeniz başarıyla JSON dosyası olarak indirildi!' });
    window.setTimeout(() => setBackupFeedback(null), 5000);
  };

  const handleCopyBackup = async () => {
    const json = exportData();
    let copied = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(json);
        copied = true;
      }
    } catch {
      copied = false;
    }
    if (!copied) {
      try {
        const ta = document.createElement('textarea');
        ta.value = json;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        copied = document.execCommand('copy');
        document.body.removeChild(ta);
      } catch {
        copied = false;
      }
    }
    setBackupFeedback(
      copied
        ? { ok: true, text: 'Yedek JSON verisi panoya kopyalandı! Başka bir cihaza yapıştırabilirsin.' }
        : { ok: false, text: 'Panoya kopyalanamadı. Lütfen "JSON İndir" butonunu kullan.' }
    );
    window.setTimeout(() => setBackupFeedback(null), 5000);
  };

  const applyBackupText = (rawText: string) => {
    const result = importBackupWithReport(rawText);
    if (result.ok) {
      setBackupFeedback({
        ok: true,
        text: result.summaryTr || 'Yedek başarıyla geri yüklendi!',
      });
      setShowImportBox(false);
      setImportJsonText('');
    } else {
      setBackupFeedback({
        ok: false,
        text: result.errorTr || 'Geçersiz yedek dosyası formatı. Lütfen kontrol edin.',
      });
    }
    window.setTimeout(() => setBackupFeedback(null), 6500);
  };

  const handleImport = () => {
    if (!importJsonText.trim()) {
      setBackupFeedback({ ok: false, text: 'Lütfen yapıştırılacak JSON yedek metnini girin.' });
      return;
    }
    applyBackupText(importJsonText);
  };

  const handleImportFile = async (file?: File) => {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.json') && file.type !== 'application/json') {
      setBackupFeedback({ ok: false, text: 'Lütfen .json uzantılı bir yedek dosyası seç.' });
      return;
    }
    try {
      const text = await file.text();
      applyBackupText(text);
    } catch {
      setBackupFeedback({ ok: false, text: 'Dosya okunamadı. Lütfen tekrar dene.' });
    }
  };

  const handleConfirmReset = () => {
    resetProgress();
    setConfirmResetOpen(false);
    setStatusMessage('İlerlemeniz sıfırlandı.');
    setTimeout(() => setStatusMessage(null), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Profile Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs flex flex-col sm:flex-row items-center gap-6">
        <MeisterMax mood="happy" size="lg" />

        <div className="text-center sm:text-left flex-1 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>%100 Ücretsiz • Sonsuz Can • Ödeme Duvarı Yok</span>
          </div>

          <label className="block max-w-sm">
            <span className="sr-only">Profil adı</span>
            <input
              value={nameDraft}
              maxLength={30}
              onChange={(event) => setNameDraft(event.target.value)}
              onBlur={() => updateProfileName(nameDraft)}
              onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }}
              aria-label="Profil adın"
              className="w-full bg-transparent text-center sm:text-left text-2xl sm:text-3xl font-black text-slate-900 dark:text-white border-b border-transparent hover:border-slate-300 focus:border-emerald-500 focus:outline-none"
            />
            <span className="text-[10px] text-slate-400">Adını değiştirmek için dokun.</span>
          </label>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Kayıt gerektirmeden tüm dersler tarayıcınızda ve çevrimdışı güvende saklanır.
          </p>

          {/* Daily Goal bar */}
          <div className="pt-2 max-w-sm">
            <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
              <span>Bugünkü Hedef</span>
              <span>{profile.todayXp} / {profile.dailyGoalXp} XP</span>
            </div>
            <div className="h-3 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, (profile.todayXp / profile.dailyGoalXp) * 100)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-xs font-bold text-center animate-in fade-in">
          {statusMessage}
        </div>
      )}

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {/* Streak */}
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center">
          <Flame className="w-6 h-6 text-amber-500 mx-auto mb-1 fill-amber-400" />
          <span className="text-2xl font-black text-amber-900 dark:text-amber-200 block">
            {profile.streak} Gün
          </span>
          <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300">
            Günlük Seri
          </span>
        </div>

        {/* Total XP */}
        <div className="p-4 rounded-2xl bg-yellow-50 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-800 text-center">
          <Zap className="w-6 h-6 text-yellow-500 mx-auto mb-1 fill-yellow-400" />
          <span className="text-2xl font-black text-yellow-900 dark:text-yellow-200 block">
            {profile.xp} XP
          </span>
          <span className="text-[11px] font-bold text-yellow-700 dark:text-yellow-300">
            Toplam Deneyim
          </span>
        </div>

        {/* Completed Lessons */}
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-center">
          <BookOpen className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
          <span className="text-2xl font-black text-emerald-900 dark:text-emerald-200 block">
            {profile.completedLessons.length}
          </span>
          <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300">
            Tamamlanan Ders
          </span>
        </div>

        {/* Mastered Words */}
        <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-center">
          <CheckCircle2 className="w-6 h-6 text-blue-600 mx-auto mb-1" />
          <span className="text-2xl font-black text-blue-900 dark:text-blue-200 block">
            {totalMasteredWords}
          </span>
          <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300">
            Öğrenilen Kelime
          </span>
        </div>
      </div>

      {/* Streak Freeze Market Card */}
      <div className="p-5 rounded-3xl bg-linear-to-r from-sky-50 to-indigo-50 dark:from-sky-950/40 dark:to-indigo-950/40 border border-sky-200 dark:border-sky-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-sky-500 text-white flex items-center justify-center shrink-0">
            <Snowflake className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-white">
              Seri Dondurma (Streak Freeze): {profile.streakFreezes || 0} / 5 Aktif
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              1 gün çalışmayı kaçırsan bile serini otomatik korur. Kazanılan XP'lerinle alabilirsin.
            </p>
          </div>
        </div>
        <button
          type="button"
          disabled={(profile.xp || 0) < 100 || (profile.streakFreezes || 0) >= 5}
          onClick={() => {
            const ok = buyStreakFreeze(100);
            if (ok) {
              setStatusMessage('❄️ 1 adet Seri Dondurma satın alındı!');
              window.setTimeout(() => setStatusMessage(null), 3000);
            }
          }}
          className="px-4 py-2.5 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-black shadow-xs disabled:opacity-45 transition cursor-pointer shrink-0"
        >
          {(profile.streakFreezes || 0) >= 5 ? 'Kalkan Dolu (5/5)' : '100 XP ile Dondurma Al'}
        </button>
      </div>

      {/* Level Breakdown Progress */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <span>📊</span> Seviye Bazında İlerleme
        </h3>

        <div className="space-y-3">
          {levelProgress.map(({ lvl, total, done, pct }) => (
            <div key={lvl} className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300">
                <span className="font-extrabold">{lvl} Seviyesi</span>
                <span>%{pct} ({done}/{total} Ders)</span>
              </div>
              <div className="h-2.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Badges Shelf */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>🏆</span> Başarı Rozetleri ({profile.unlockedBadges.length}/{ALL_BADGES.length})
          </h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {ALL_BADGES.map((b) => {
            const isUnlocked = unlockedBadgeSet.has(b.id);
            return (
              <div
                key={b.id}
                className={`p-3.5 rounded-2xl border text-center transition ${
                  isUnlocked
                    ? 'bg-purple-50/70 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800'
                    : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-800 opacity-40 grayscale'
                }`}
              >
                <span className="text-3xl block mb-1">{b.icon}</span>
                <span className="text-xs font-black text-slate-900 dark:text-white block">
                  {b.title}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-snug">
                  {b.description}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Preferences & Settings */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          ⚙️ Uygulama & Ses Ayarları
        </h3>

        <div className="space-y-4">
          {/* Theme preference */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">Görünüm</span>
              <span className="text-xs text-slate-400">Açık, koyu veya cihaz ayarına göre</span>
            </div>
            <select
              value={profile.themePreference || 'system'}
              onChange={(event) => setThemePreference(event.target.value as 'system' | 'light' | 'dark')}
              aria-label="Uygulama görünümü"
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-bold text-slate-700 dark:text-slate-200"
            >
              <option value="system">Cihaz ayarı</option>
              <option value="light">Açık tema</option>
              <option value="dark">Koyu tema</option>
            </select>
          </div>

          {/* Sound Toggle */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Ses Efektleri
              </span>
              <span className="text-xs text-slate-400">
                Doğru ve yanlış cevap chimes sesleri
              </span>
            </div>
            <button
              onClick={toggleSound}
              className={`p-2.5 rounded-xl border transition cursor-pointer ${
                profile.soundEnabled
                  ? 'bg-emerald-50 text-emerald-600 border-emerald-300'
                  : 'bg-slate-100 text-slate-400 border-slate-200'
              }`}
            >
              {profile.soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>

          {/* Speech Speed */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Almanca Ses Hızı
              </span>
              <span className="text-xs text-slate-400">
                Kelime ve cümle telaffuz hızı
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { label: 'Yavaş (0.75x)', val: 0.75 },
                { label: 'Normal (0.95x)', val: 0.95 },
                { label: 'Hızlı (1.1x)', val: 1.1 },
              ].map((s) => (
                <button
                  key={s.val}
                  onClick={() => setSpeechSpeed(s.val)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    profile.speechSpeed === s.val
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Daily Goal Selector */}
          <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-700">
            <div>
              <span className="text-sm font-bold text-slate-800 dark:text-slate-100 block">
                Günlük Hedef
              </span>
              <span className="text-xs text-slate-400">
                Her gün kazanmak istediğin minimum XP
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {[20, 30, 50, 100].map((goal) => (
                <button
                  key={goal}
                  onClick={() => setDailyGoalXp(goal)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    profile.dailyGoalXp === goal
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {goal} XP
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Data Backup & Restore */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            💾 Veri Güvenliği ve Yedekleme (Çevrimdışı / Yerel)
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            İlerlemeniz cihazınızın yerel hafızasında saklanır. Telefonunuzu değiştirirseniz ilerlemenizi JSON olarak indirip veya panoya kopyalayıp diğer cihaza aktarabilirsiniz.
          </p>
        </div>

        {/* Backup Snapshot Summary */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
          {[
            { label: 'XP', val: profile.xp || 0 },
            { label: 'Seri', val: `${profile.streak || 0}g` },
            { label: 'Ders', val: profile.completedLessons.length },
            { label: 'Hikaye', val: profile.completedStories?.length || 0 },
            { label: 'Özel Kelime', val: profile.customWords?.length || 0 },
            { label: 'Hata Defteri', val: profile.aiMistakes?.length || 0 },
          ].map((stat) => (
            <div
              key={stat.label}
              className="px-2 py-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700"
            >
              <div className="text-sm font-black text-slate-900 dark:text-white tabular-nums">
                {stat.val}
              </div>
              <div className="text-[10px] font-bold text-slate-400">{stat.label}</div>
            </div>
          ))}
        </div>

        {backupFeedback && (
          <div
            className={`p-3 rounded-2xl border text-xs font-bold flex items-center gap-2 ${
              backupFeedback.ok
                ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 dark:border-rose-800 text-rose-800 dark:text-rose-200'
            }`}
          >
            {backupFeedback.ok ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{backupFeedback.text}</span>
          </div>
        )}

        <div className="flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold shadow-xs hover:opacity-90 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>JSON İndir</span>
          </button>

          <button
            type="button"
            onClick={() => { void handleCopyBackup(); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-xs font-bold text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 transition cursor-pointer"
          >
            <Copy className="w-4 h-4" />
            <span>Panoya Kopyala</span>
          </button>

          <button
            type="button"
            onClick={() => setShowImportBox(!showImportBox)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Yedeği Yükle</span>
          </button>

          <button
            type="button"
            onClick={() => setConfirmResetOpen((v) => !v)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition cursor-pointer ml-auto"
          >
            <RotateCcw className="w-4 h-4" />
            <span>İlerlemeyi Sıfırla</span>
          </button>
        </div>

        {confirmResetOpen && (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 space-y-3">
            <p className="text-xs font-bold text-rose-900 dark:text-rose-200">
              Tüm ilerlemenizi, XP puanlarınızı, rozetlerinizi ve kayıtlı kelimelerinizi sıfırlamak istediğinize emin misiniz? (Önce JSON yedeği indirmeniz önerilir.)
            </p>
            <div className="flex flex-wrap justify-end gap-2">
              <button
                onClick={() => setConfirmResetOpen(false)}
                className="px-4 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                Vazgeç
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black cursor-pointer"
              >
                Evet, Sıfırla
              </button>
            </div>
          </div>
        )}

        {showImportBox && (
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              JSON yedek dosyanı seçebilir veya yedek metnini aşağıya yapıştırabilirsin:
            </span>
            <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
              <Upload className="w-4 h-4" /> Dosyadan yedek seç
              <input
                type="file"
                accept=".json,application/json"
                className="sr-only"
                onChange={(event) => { void handleImportFile(event.target.files?.[0]); event.currentTarget.value = ''; }}
              />
            </label>
            <textarea
              rows={4}
              value={importJsonText}
              onChange={(e) => setImportJsonText(e.target.value)}
              placeholder='{"xp": 150, "streak": 3, ...}'
              className="w-full p-2.5 text-xs font-mono rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowImportBox(false)}
                className="px-3 py-1.5 text-xs text-slate-500 font-bold"
              >
                İptal
              </button>
              <button
                onClick={handleImport}
                className="px-4 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-xl hover:bg-emerald-700"
              >
                Yedeği Uygula
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});

export const ProfileView: React.FC = memo(() => {
  const [mode, setMode] = useState<'profile' | 'progress'>('progress');
  return (
    <div>
      <div className="max-w-xl mx-auto px-4 pt-4">
        <div className="grid grid-cols-2 gap-1 p-1 rounded-2xl bg-slate-200/70 dark:bg-slate-800" role="tablist" aria-label="Profil bölümü">
          {([['progress', 'Gelişim'], ['profile', 'Profil ve ayarlar']] as const).map(([id, label]) => (
            <button
              key={id}
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
              className={`h-10 rounded-xl text-sm font-black transition cursor-pointer ${
                mode === id ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {mode === 'progress' ? <ProgressPanel /> : <ProfileMainView />}
    </div>
  );
});
