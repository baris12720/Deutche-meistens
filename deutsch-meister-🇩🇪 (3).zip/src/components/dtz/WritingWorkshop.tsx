import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  BookPlus,
  CheckCircle2,
  Eye,
  EyeOff,
  PenTool,
  RotateCcw,
  Sparkles,
  Turtle,
  Volume2,
} from 'lucide-react';
import { WRITING_PROMPTS, WritingPromptTask } from '../../data/writingPrompts';
import { useApp } from '../../context/AppContext';
import {
  evaluateWritingWithAi,
  loadAiConfig,
  WritingEvaluation,
} from '../../utils/aiClient';
import { playSuccessSound, speakGerman, speakGermanSlow } from '../../utils/audio';
import { ARTICLE_BADGE_CLASS } from '../../utils/articleColors';
import { CEFRLevel } from '../../types';

interface WritingWorkshopProps {
  initialLevel?: CEFRLevel;
  compact?: boolean;
}

const LEVELS: (CEFRLevel | 'ALL')[] = ['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'];

export const WritingWorkshop: React.FC<WritingWorkshopProps> = ({
  initialLevel,
  compact = false,
}) => {
  const {
    profile,
    currentLevel,
    addAiMistake,
    addCustomWord,
    recordAnswer,
    recordActivity,
    markWritingTaskDone,
  } = useApp();

  const [levelFilter, setLevelFilter] = useState<CEFRLevel | 'ALL'>(
    initialLevel || currentLevel || 'B1'
  );
  const filteredPrompts = useMemo(
    () =>
      WRITING_PROMPTS.filter(
        (p) => levelFilter === 'ALL' || p.level === levelFilter
      ),
    [levelFilter]
  );

  const [selectedId, setSelectedId] = useState<string>(
    () => filteredPrompts[0]?.id || WRITING_PROMPTS[0].id
  );
  const activePrompt: WritingPromptTask = useMemo(
    () =>
      filteredPrompts.find((p) => p.id === selectedId) ||
      filteredPrompts[0] ||
      WRITING_PROMPTS[0],
    [filteredPrompts, selectedId]
  );

  useEffect(() => {
    if (initialLevel) setLevelFilter(initialLevel);
  }, [initialLevel]);

  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [evaluation, setEvaluation] = useState<WritingEvaluation | null>(null);
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showSample, setShowSample] = useState(false);
  const [savedFixIndices, setSavedFixIndices] = useState<Record<number, boolean>>({});
  const [savedVocabIndices, setSavedVocabIndices] = useState<Record<number, boolean>>({});

  const currentText = drafts[activePrompt.id] || '';
  const wordCount = useMemo(
    () => currentText.trim().split(/\s+/).filter(Boolean).length,
    [currentText]
  );

  const completedSet = useMemo(
    () => new Set(profile.completedWritingTasks || []),
    [profile.completedWritingTasks]
  );

  const selectPrompt = (p: WritingPromptTask) => {
    setSelectedId(p.id);
    setEvaluation(null);
    setErrorMsg(null);
    setShowSample(false);
    setSavedFixIndices({});
    setSavedVocabIndices({});
  };

  const insertPhrase = (phrase: string) => {
    setDrafts((prev) => {
      const existing = prev[activePrompt.id] || '';
      const sep = existing && !/[\s\n]$/.test(existing) ? ' ' : '';
      return { ...prev, [activePrompt.id]: `${existing}${sep}${phrase}` };
    });
  };

  const handleEvaluate = async () => {
    if (busy) return;
    setErrorMsg(null);
    setBusy(true);
    setSavedFixIndices({});
    setSavedVocabIndices({});
    try {
      const cfg = loadAiConfig();
      const result = await evaluateWritingWithAi(cfg, activePrompt, currentText);
      setEvaluation(result);
      const passed = result.scores.overall >= 60;
      recordActivity('writing', passed, 60);
      if (passed) {
        markWritingTaskDone(activePrompt.id, 25);
        playSuccessSound(profile.soundEnabled);
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Değerlendirme yapılamadı.');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveFixToNotebook = (
    idx: number,
    fix: WritingEvaluation['sentenceFixes'][number]
  ) => {
    if (savedFixIndices[idx]) return;
    addAiMistake({
      original: fix.original,
      corrected: fix.corrected,
      explanationTr: fix.explanationTr,
      type: fix.errorType || 'yazim',
    });
    setSavedFixIndices((prev) => ({ ...prev, [idx]: true }));
  };

  const handleSaveVocabToSrs = (
    idx: number,
    vocab: WritingEvaluation['vocabularySuggestions'][number]
  ) => {
    if (savedVocabIndices[idx]) return;
    const created = addCustomWord({
      german: vocab.german,
      turkish: vocab.turkish,
      article: vocab.article,
      level: activePrompt.level,
      category: 'Yazma Atölyesi',
      exampleGerman: vocab.exampleDe,
      exampleTurkish: '',
      sourceTag: `Yazma: ${activePrompt.titleTr}`,
    });
    recordAnswer(created.id, false);
    setSavedVocabIndices((prev) => ({ ...prev, [idx]: true }));
  };

  const scoreBars = evaluation
    ? [
        { label: 'Görev Tamamlama (Leitpunkte)', score: evaluation.scores.taskCompletion, color: 'bg-emerald-500' },
        { label: 'Dilbilgisi (Grammatik)', score: evaluation.scores.grammar, color: 'bg-sky-500' },
        { label: 'Kelime Zenginliği (Wortschatz)', score: evaluation.scores.vocabulary, color: 'bg-indigo-500' },
        { label: 'Hitap & Kapanış Formatı', score: evaluation.scores.formatTone, color: 'bg-amber-500' },
      ]
    : [];

  return (
    <div className={compact ? 'space-y-4' : 'space-y-5'}>
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-linear-to-r from-amber-600 via-orange-600 to-rose-600 text-white shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full">
            <PenTool className="w-3.5 h-3.5" /> AI Yazma Atölyesi · DTZ & Goethe Schreiben
          </span>
          <h3 className="text-xl sm:text-2xl font-black mt-1.5">
            Resmî & Günlük Yazı Değerlendiricisi
          </h3>
          <p className="text-xs text-amber-50 mt-0.5 max-w-xl">
            Leitpunkte maddelerine göre mektup veya e-posta yaz; 4 kriterde 0–100 puan, cümle düzeltmeleri ve doğal B1/B2/C1 önerileri al.
          </p>
        </div>
        <div className="px-4 py-2.5 rounded-2xl bg-white/15 backdrop-blur-xs text-center shrink-0">
          <div className="text-xl font-black">
            {completedSet.size}/{WRITING_PROMPTS.length}
          </div>
          <div className="text-[10px] font-bold uppercase text-amber-100">Tamamlanan Görev</div>
        </div>
      </div>

      {/* Level Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {LEVELS.map((lvl) => (
          <button
            key={lvl}
            type="button"
            onClick={() => setLevelFilter(lvl)}
            className={`px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer shrink-0 ${
              levelFilter === lvl
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            {lvl === 'ALL' ? 'Tüm Seviyeler' : lvl}
          </button>
        ))}
      </div>

      {/* Task Selector Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {filteredPrompts.map((p) => {
          const isSelected = p.id === activePrompt.id;
          const isDone = completedSet.has(p.id);
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => selectPrompt(p)}
              className={`shrink-0 text-left px-3.5 py-2.5 rounded-2xl border-2 transition cursor-pointer max-w-[240px] ${
                isSelected
                  ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-100 shadow-xs'
                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-2 text-[10px] font-black uppercase">
                <span className="text-amber-600 dark:text-amber-400">{p.level}</span>
                {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
              </div>
              <div className="text-xs font-black truncate mt-0.5">{p.titleTr}</div>
            </button>
          );
        })}
      </div>

      {/* Active Writing Task Workspace */}
      <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-[11px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300">
            {activePrompt.examBadgeTr}
          </span>
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
            {activePrompt.recipientType === 'formal' ? '🏛️ Resmî (Sie)' : '👋 Samimi (du)'} · Hedef: {activePrompt.recommendedWords}
          </span>
        </div>

        <div>
          <h4 className="text-lg font-black text-slate-900 dark:text-white">
            {activePrompt.titleTr}
          </h4>
          <p className="text-xs font-semibold text-slate-400">{activePrompt.titleDe}</p>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
            {activePrompt.scenarioTr}
          </p>
        </div>

        {/* Leitpunkte Checklist */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-2">
          <div className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
            📌 Değinilmesi Gereken Noktalar (Leitpunkte)
          </div>
          <ul className="space-y-1.5">
            {activePrompt.leitpunkteTr.map((pt, idx) => {
              const covered = evaluation?.coveredLeitpunkte?.[idx];
              return (
                <li
                  key={idx}
                  className={`text-xs flex items-start gap-2 ${
                    covered === true
                      ? 'text-emerald-700 dark:text-emerald-300 font-bold'
                      : covered === false
                      ? 'text-rose-600 dark:text-rose-400 font-bold'
                      : 'text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span className="mt-0.5 shrink-0">
                    {covered === true ? '✅' : covered === false ? '⚠️' : '•'}
                  </span>
                  <span>{pt}</span>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Clickable Useful Phrases with Audio */}
        <div className="space-y-1.5">
          <div className="text-[11px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
            💬 Tıkla ve Metne Ekle / Dinle:
          </div>
          <div className="flex flex-wrap gap-1.5">
            {activePrompt.usefulPhrasesDe.map((ph, idx) => (
              <div
                key={idx}
                className="inline-flex items-center rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => insertPhrase(ph)}
                  className="px-2.5 py-1.5 text-xs font-bold text-indigo-800 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 cursor-pointer"
                  title="Editöre ekle"
                >
                  + {ph}
                </button>
                <button
                  type="button"
                  onClick={() => void speakGerman(ph, profile.speechSpeed)}
                  aria-label="Kalıbı dinle"
                  className="px-2 py-1.5 text-indigo-600 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border-l border-indigo-200 dark:border-indigo-800 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Editor */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-slate-600 dark:text-slate-300">Almanca Metnin:</span>
            <span
              className={
                wordCount >= activePrompt.minWords
                  ? 'text-emerald-600 dark:text-emerald-400 font-black'
                  : 'text-amber-600 dark:text-amber-400'
              }
            >
              {wordCount} kelime (min. {activePrompt.minWords})
            </span>
          </div>
          <textarea
            rows={6}
            value={currentText}
            onChange={(e) =>
              setDrafts((prev) => ({ ...prev, [activePrompt.id]: e.target.value }))
            }
            placeholder={
              activePrompt.recipientType === 'formal'
                ? 'Sehr geehrte Damen und Herren,\n\nich schreibe Ihnen, weil...\n\nMit freundlichen Grüßen\n...'
                : 'Liebe/r ...,\n\nich möchte dir schreiben, weil...\n\nViele Grüße\n...'
            }
            className="w-full p-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900 text-slate-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:border-amber-500 transition resize-y"
          />
        </div>

        {errorMsg && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs font-bold text-rose-700 dark:text-rose-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Action Bar */}
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={handleEvaluate}
            className="min-h-11 px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-black text-xs sm:text-sm inline-flex items-center gap-2 shadow-[0_3px_0_#047857] active:translate-y-0.5 active:shadow-none transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>{busy ? 'Değerlendiriliyor...' : 'Metni Değerlendir & Puanla'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowSample((v) => !v)}
            className="min-h-11 px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black text-xs inline-flex items-center gap-1.5 cursor-pointer"
          >
            {showSample ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span>{showSample ? 'Örnek Mektubu Gizle' : 'Musterlösung (Örnek Çözüm)'}</span>
          </button>

          {currentText.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setDrafts((prev) => ({ ...prev, [activePrompt.id]: '' }));
                setEvaluation(null);
                setErrorMsg(null);
              }}
              className="min-h-11 px-3 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-700 dark:text-slate-300 text-xs font-bold inline-flex items-center gap-1 cursor-pointer ml-auto"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Temizle
            </button>
          )}
        </div>

        {/* Sample Solution */}
        {showSample && (
          <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800 space-y-2.5 pop-in">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-black text-emerald-800 dark:text-emerald-200 uppercase">
                🌟 Örnek {activePrompt.level} Çözümü (Musterbrief)
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => void speakGerman(activePrompt.sampleSolutionDe, profile.speechSpeed)}
                  className="px-2.5 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-black inline-flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" /> Dinle
                </button>
                <button
                  type="button"
                  onClick={() => void speakGermanSlow(activePrompt.sampleSolutionDe)}
                  className="px-2.5 py-1.5 rounded-xl bg-amber-500 text-white text-[11px] font-black inline-flex items-center gap-1 cursor-pointer"
                  title="0.75x yavaş ve net telaffuzla dinle"
                >
                  <Turtle className="w-3.5 h-3.5" /> 0.75x
                </button>
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900 text-xs sm:text-sm text-slate-800 dark:text-slate-100 whitespace-pre-line leading-relaxed">
              {activePrompt.sampleSolutionDe}
            </div>
          </div>
        )}

        {/* Evaluation Output */}
        {evaluation && (
          <div className="pt-4 border-t-2 border-slate-100 dark:border-slate-700 space-y-4 pop-in">
            {/* Overall Score & 4-Criteria Bars */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <span className="text-[11px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    {evaluation.source === 'ai' ? '✨ AI Değerlendirme Raporu' : '📊 Akıllı Sınav Analizi'}
                  </span>
                  <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 mt-0.5">
                    {evaluation.summaryTr}
                  </p>
                </div>
                <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex flex-col items-center justify-center shrink-0 shadow-sm">
                  <span className="text-xl font-black leading-none">{evaluation.scores.overall}</span>
                  <span className="text-[10px] font-bold opacity-85">/ 100</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {scoreBars.map((bar) => (
                  <div key={bar.label} className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      <span>{bar.label}</span>
                      <span className="font-black text-slate-900 dark:text-white">{bar.score}/100</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${bar.color} transition-all duration-500`}
                        style={{ width: `${bar.score}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sentence-by-Sentence Corrections */}
            <div className="space-y-2.5">
              <h5 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                🔍 Cümle Bazlı Hata & Gramer Kontrolü ({evaluation.sentenceFixes.length})
              </h5>
              {evaluation.sentenceFixes.length === 0 ? (
                <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-200">
                  ✅ Belirgin bir gramer veya yazım hatası tespit edilmedi! Harika gidiyorsun.
                </div>
              ) : (
                evaluation.sentenceFixes.map((fix, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-amber-200/70 dark:bg-amber-900 text-amber-900 dark:text-amber-200 text-[10px] font-black uppercase">
                        {fix.errorType}
                      </span>
                      <button
                        type="button"
                        disabled={!!savedFixIndices[idx]}
                        onClick={() => handleSaveFixToNotebook(idx, fix)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-black inline-flex items-center gap-1 cursor-pointer ${
                          savedFixIndices[idx]
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                            : 'bg-indigo-600 text-white hover:bg-indigo-700'
                        }`}
                      >
                        <BookPlus className="w-3.5 h-3.5" />
                        <span>{savedFixIndices[idx] ? 'Hata Defterine Eklendi' : 'Hata Defterine Ekle'}</span>
                      </button>
                    </div>
                    <div>
                      <span className="font-black text-rose-600">Yazdığın: </span>
                      <span className="line-through decoration-rose-500 text-slate-600 dark:text-slate-300">
                        {fix.original}
                      </span>
                    </div>
                    <div>
                      <span className="font-black text-emerald-600">Doğrusu: </span>
                      <span className="font-bold text-slate-900 dark:text-white">{fix.corrected}</span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-200 leading-relaxed">
                      <strong>Neden yanlış?</strong> {fix.explanationTr}
                    </p>
                  </div>
                ))
              )}
            </div>

            {/* Natural Level-Up Alternatives */}
            <div className="space-y-2">
              <h5 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                🚀 Seviyeni Yükseltecek Doğal Almanca Alternatifler
              </h5>
              <div className="grid grid-cols-1 gap-2.5">
                {evaluation.naturalAlternatives.map((alt, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/80 text-xs space-y-1.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="text-slate-500 dark:text-slate-400">
                          Basit ifade: <span className="italic">{alt.basicDe}</span>
                        </div>
                        <div className="font-black text-indigo-900 dark:text-indigo-200">
                          Daha doğal: "{alt.betterDe}"
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => void speakGerman(alt.betterDe, profile.speechSpeed)}
                          className="p-1.5 rounded-lg bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-300 cursor-pointer"
                          title="Dinle"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => void speakGermanSlow(alt.betterDe)}
                          className="p-1.5 rounded-lg bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-300 cursor-pointer"
                          title="0.75x Yavaş Dinle"
                        >
                          <Turtle className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">{alt.explanationTr}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* One-Click SRS Vocabulary Suggestions */}
            <div className="space-y-2">
              <h5 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-200">
                📚 Bu Konudan Tekrara Ekleyebileceğin Anahtar Kelimeler
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {evaluation.vocabularySuggestions.map((v, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-xs flex flex-col justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {v.article !== 'none' && (
                          <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md border ${ARTICLE_BADGE_CLASS[v.article]}`}>
                            {v.article}
                          </span>
                        )}
                        <span className="font-black text-slate-900 dark:text-white">{v.german}</span>
                      </div>
                      <div className="text-emerald-700 dark:text-emerald-400 font-bold mt-0.5">
                        {v.turkish}
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={!!savedVocabIndices[idx]}
                      onClick={() => handleSaveVocabToSrs(idx, v)}
                      className={`w-full py-1.5 px-2.5 rounded-xl text-[11px] font-black cursor-pointer ${
                        savedVocabIndices[idx]
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                          : 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                      }`}
                    >
                      {savedVocabIndices[idx] ? '✓ SRS\'e Eklendi' : '+ Hata Defteri & SRS'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
