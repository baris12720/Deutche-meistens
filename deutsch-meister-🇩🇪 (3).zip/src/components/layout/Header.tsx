import React, { memo, useState } from 'react';
import { Flame, Zap, Heart, Volume2, VolumeX, Sun, Moon, Monitor, Snowflake } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { StreakFreezeModal } from '../modals/StreakFreezeModal';
import { CEFRLevel, ThemePreference } from '../../types';

export const Header: React.FC = memo(() => {
  const { profile, currentLevel, setCurrentLevel, toggleSound, setActiveTab, setThemePreference } = useApp();
  const [freezeOpen, setFreezeOpen] = useState(false);

  const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
  const currentTheme: ThemePreference = profile.themePreference || 'system';
  const nextTheme: ThemePreference =
    currentTheme === 'system' ? 'light' : currentTheme === 'light' ? 'dark' : 'system';
  const themeLabel =
    currentTheme === 'light'
      ? 'Tema: Açık (Değiştir)'
      : currentTheme === 'dark'
      ? 'Tema: Koyu (Değiştir)'
      : 'Tema: Sistem (Değiştir)';

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand */}
        <button
          type="button"
          onClick={() => setActiveTab('learn')}
          aria-label="Deutsch Meister ana sayfa"
          className="flex items-center gap-2.5 cursor-pointer select-none shrink-0 text-left"
        >
          <img src={`${import.meta.env.BASE_URL}icon.svg`} alt="Deutsch Meister Logo" className="w-10 h-10 rounded-xl shadow-sm ring-1 ring-slate-200 dark:ring-slate-700" />
          <div className="hidden sm:block">
            <span className="text-base font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
              Deutsch Meister
              <span className="inline-flex h-3 w-4 overflow-hidden rounded-[2px] border border-slate-300 dark:border-slate-700 flex-col" aria-hidden="true">
                <span className="h-1 bg-zinc-900" />
                <span className="h-1 bg-red-600" />
                <span className="h-1 bg-amber-400" />
              </span>
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block -mt-1">
              %100 Ücretsiz Almanca
            </span>
          </div>
        </button>

        {/* Accessible level selector: works with touch, keyboard and screen readers. */}
        <label className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-black text-slate-800 dark:text-slate-100">
          <span className="hidden sm:inline">Seviye</span>
          <select
            value={currentLevel}
            onChange={(event) => setCurrentLevel(event.target.value as CEFRLevel)}
            aria-label="Öğrenme seviyesini seç"
            className="max-w-[4.5rem] bg-transparent font-black focus:outline-none cursor-pointer"
          >
            {levels.map((level) => <option key={level} value={level}>{level}</option>)}
          </select>
        </label>

        {/* Top Gamification Badges */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Unlimited Lives ∞ */}
          <div
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 font-black text-xs cursor-help"
            title="Deutsch Meister'da can sınırı yok! İstediğin kadar pratik yapabilirsin."
          >
            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
            <span className="text-sm font-extrabold leading-none">∞</span>
          </div>

          {/* Daily Streak Flame + Streak Freeze button */}
          <button
            type="button"
            onClick={() => setFreezeOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300 font-extrabold text-xs cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-950/70 transition"
            title={`${profile.streak} günlük seri · ${profile.streakFreezes || 0} Seri Dondurma (Yönetmek için dokun)`}
          >
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>{profile.streak}</span>
            {(profile.streakFreezes || 0) > 0 && (
              <span className="inline-flex items-center gap-0.5 ml-0.5 pl-1 border-l border-amber-300 dark:border-amber-700 text-sky-600 dark:text-sky-400">
                <Snowflake className="w-3 h-3" />
                <span>{profile.streakFreezes}</span>
              </span>
            )}
          </button>

          {/* Total XP */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-yellow-50 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-900 text-yellow-800 dark:text-yellow-300 font-extrabold text-xs"
            title="Toplam Deneyim Puanı (XP)"
          >
            <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
            <span>{profile.xp}</span>
          </div>

          {/* Quick Theme Toggle */}
          <button
            type="button"
            onClick={() => setThemePreference(nextTheme)}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title={themeLabel}
            aria-label={themeLabel}
          >
            {currentTheme === 'light' ? (
              <Sun className="w-4 h-4 text-amber-500" />
            ) : currentTheme === 'dark' ? (
              <Moon className="w-4 h-4 text-indigo-400" />
            ) : (
              <Monitor className="w-4 h-4" />
            )}
          </button>

          {/* Sound Toggle */}
          <button
            type="button"
            onClick={toggleSound}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title={profile.soundEnabled ? 'Sesi Kapat' : 'Sesi Aç'}
            aria-label={profile.soundEnabled ? 'Sesi Kapat' : 'Sesi Aç'}
          >
            {profile.soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>
      {freezeOpen && <StreakFreezeModal onClose={() => setFreezeOpen(false)} />}
    </header>
  );
});
