import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronLeft,
  Clock,
  HelpCircle,
  Languages,
  PlusCircle,
  RotateCcw,
  Sparkles,
  Trophy,
  Turtle,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import {
  STORIES,
  Story,
  StoryChallengeStep,
  StoryCharacter,
  StoryWordEntry,
} from '../../data/stories';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import {
  playClickSound,
  playSuccessSound,
  playWrongSound,
  speakGerman,
  speakGermanSlow,
  stopSpeaking,
} from '../../utils/audio';
import { ARTICLE_BADGE_CLASS, ARTICLE_TEXT_COLOR } from '../../utils/articleColors';
import { getArticleRuleHint } from '../../utils/articleRules';
import { useBackHandler } from '../../utils/backStack';

interface SelectedWordState {
  token: string;
  entry: StoryWordEntry;
  lineGerman: string;
  lineTurkish: string;
}

const LEVELS: (CEFRLevel | 'ALL')[] = ['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'];
const AUTO_AUDIO_STORAGE_KEY = 'dm_story_auto_audio';

const normalizeTokenKey = (raw: string): string =>
  raw
    .replace(/^[^A-Za-zÄÖÜäöüß]+|[^A-Za-zÄÖÜäöüß]+$/g, '')
    .toLowerCase();

const TONE_CLASSES: Record<
  StoryCharacter['bubbleTone'],
  { avatarBg: string; nameColor: string; bubbleBorder: string }
> = {
  indigo: {
    avatarBg: 'bg-indigo-100 dark:bg-indigo-950/80 border-indigo-300 dark:border-indigo-700',
    nameColor: 'text-indigo-700 dark:text-indigo-300',
    bubbleBorder: 'border-indigo-200 dark:border-indigo-800/80',
  },
  emerald: {
    avatarBg: 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-300 dark:border-emerald-700',
    nameColor: 'text-emerald-700 dark:text-emerald-300',
    bubbleBorder: 'border-emerald-200 dark:border-emerald-800/80',
  },
  amber: {
    avatarBg: 'bg-amber-100 dark:bg-amber-950/80 border-amber-300 dark:border-amber-700',
    nameColor: 'text-amber-700 dark:text-amber-300',
    bubbleBorder: 'border-amber-200 dark:border-amber-800/80',
  },
  rose: {
    avatarBg: 'bg-rose-100 dark:bg-rose-950/80 border-rose-300 dark:border-rose-700',
    nameColor: 'text-rose-700 dark:text-rose-300',
    bubbleBorder: 'border-rose-200 dark:border-rose-800/80',
  },
  sky: {
    avatarBg: 'bg-sky-100 dark:bg-sky-950/80 border-sky-300 dark:border-sky-700',
    nameColor: 'text-sky-700 dark:text-sky-300',
    bubbleBorder: 'border-sky-200 dark:border-sky-800/80',
  },
  violet: {
    avatarBg: 'bg-violet-100 dark:bg-violet-950/80 border-violet-300 dark:border-violet-700',
    nameColor: 'text-violet-700 dark:text-violet-300',
    bubbleBorder: 'border-violet-200 dark:border-violet-800/80',
  },
};

const CHALLENGE_BADGE: Record<StoryChallengeStep['challengeType'], string> = {
  comprehension: 'Ara Soru • Anlama',
  fill_blank: 'Ara Görev • Boşluk Doldur',
  word_order: 'Ara Görev • Cümleyi Diz',
  vocab_match: 'Ara Görev • Kelime Eşleştir',
};

interface InlineChallengeCardProps {
  challenge: StoryChallengeStep;
  solved: boolean;
  soundEnabled: boolean;
  onSolved: (challengeId: string) => void;
}

const InlineChallengeCard: React.FC<InlineChallengeCardProps> = memo(
  ({ challenge, solved, soundEnabled, onSolved }) => {
    const [pickedOption, setPickedOption] = useState<string | null>(null);
    const [showHint, setShowHint] = useState(false);

    // Word order state: stores indices into challenge.scrambledWords
    const [selectedIndices, setSelectedIndices] = useState<number[]>([]);

    // Vocab match state
    const [pickedDeId, setPickedDeId] = useState<string | null>(null);
    const [matchedPairIds, setMatchedPairIds] = useState<string[]>([]);
    const [wrongFlashPair, setWrongFlashPair] = useState<{ deId: string; trId: string } | null>(null);

    const shuffledRightPairs = useMemo(() => {
      if (challenge.challengeType !== 'vocab_match') return [];
      // Deterministic permutation based on challenge id so SSR & re-renders remain stable
      return [...challenge.pairs].sort((a, b) =>
        `${challenge.id}_${a.tr}`.localeCompare(`${challenge.id}_${b.tr}`)
      );
    }, [challenge]);

    const handleChoicePick = (option: string, correctAnswer: string) => {
      if (solved) return;
      setPickedOption(option);
      if (option === correctAnswer) {
        setShowHint(false);
        playSuccessSound(soundEnabled);
        onSolved(challenge.id);
      } else {
        setShowHint(true);
        playWrongSound(soundEnabled);
      }
    };

    const handleWordBankTap = (idx: number) => {
      if (solved || challenge.challengeType !== 'word_order') return;
      playClickSound(soundEnabled);
      setShowHint(false);
      setSelectedIndices((prev) =>
        prev.includes(idx) ? prev.filter((item) => item !== idx) : [...prev, idx]
      );
    };

    const handleCheckWordOrder = () => {
      if (solved || challenge.challengeType !== 'word_order') return;
      const assembled = selectedIndices.map((idx) => challenge.scrambledWords[idx]);
      const isRight =
        assembled.length === challenge.correctWords.length &&
        assembled.every((word, idx) => word === challenge.correctWords[idx]);
      if (isRight) {
        setShowHint(false);
        playSuccessSound(soundEnabled);
        onSolved(challenge.id);
      } else {
        setShowHint(true);
        playWrongSound(soundEnabled);
      }
    };

    const handleMatchRightTap = (trId: string) => {
      if (solved || challenge.challengeType !== 'vocab_match' || !pickedDeId) return;
      if (matchedPairIds.includes(trId)) return;

      if (pickedDeId === trId) {
        const nextMatched = [...matchedPairIds, trId];
        setMatchedPairIds(nextMatched);
        setPickedDeId(null);
        setShowHint(false);
        playSuccessSound(soundEnabled);
        if (nextMatched.length === challenge.pairs.length) {
          onSolved(challenge.id);
        }
      } else {
        playWrongSound(soundEnabled);
        setShowHint(true);
        setWrongFlashPair({ deId: pickedDeId, trId });
        setPickedDeId(null);
        window.setTimeout(() => setWrongFlashPair(null), 550);
      }
    };

    return (
      <motion.div
        initial={{ opacity: 0, y: 14, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.24 }}
        className={`rounded-3xl border-2 p-4 sm:p-5 shadow-sm transition-colors ${
          solved
            ? 'bg-emerald-50/90 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-600'
            : 'bg-amber-50/80 dark:bg-slate-800 border-amber-300 dark:border-amber-600/80'
        }`}
      >
        <div className="flex items-center justify-between gap-2 mb-3">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[11px] font-black uppercase tracking-wide ${
              solved
                ? 'bg-emerald-500 text-white'
                : 'bg-amber-500 text-white'
            }`}
          >
            {solved ? <CheckCircle2 className="w-3.5 h-3.5" /> : <HelpCircle className="w-3.5 h-3.5" />}
            {CHALLENGE_BADGE[challenge.challengeType]}
          </span>
          <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
            {challenge.titleTr}
          </span>
        </div>

        {/* 1. Comprehension Challenge */}
        {challenge.challengeType === 'comprehension' && (
          <div className="space-y-3">
            <p className="text-sm sm:text-base font-black text-slate-900 dark:text-white">
              {challenge.questionTr}
            </p>
            <div className="grid grid-cols-1 gap-2">
              {challenge.options.map((opt) => {
                const isCorrectOpt = opt === challenge.correctAnswer;
                const isPicked = pickedOption === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={solved}
                    onClick={() => handleChoicePick(opt, challenge.correctAnswer)}
                    className={`min-h-11 text-left px-3.5 py-2.5 rounded-2xl border-2 text-xs sm:text-sm font-bold transition cursor-pointer ${
                      solved && isCorrectOpt
                        ? 'bg-emerald-500 text-white border-emerald-600'
                        : isPicked && !isCorrectOpt
                        ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-400 text-rose-700 dark:text-rose-200'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-indigo-400'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. Fill in the Blank Challenge */}
        {challenge.challengeType === 'fill_blank' && (
          <div className="space-y-3">
            {challenge.speaker && (
              <span className="text-[11px] font-black uppercase tracking-wide text-indigo-600 dark:text-indigo-400 block">
                {challenge.speaker}
              </span>
            )}
            <p className="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-relaxed">
              {challenge.promptDe.split('___').map((part, idx, arr) => (
                <React.Fragment key={idx}>
                  <span>{part}</span>
                  {idx < arr.length - 1 && (
                    <span
                      className={`inline-flex items-center justify-center min-w-20 px-2.5 py-0.5 mx-1 rounded-xl border-2 text-sm font-black align-baseline ${
                        solved
                          ? 'bg-emerald-500 text-white border-emerald-600'
                          : 'bg-white dark:bg-slate-900 border-dashed border-amber-500 text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {solved ? challenge.correctAnswer : '_____'}
                    </span>
                  )}
                </React.Fragment>
              ))}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 italic">
              {challenge.promptTr}
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {challenge.options.map((opt) => {
                const isCorrectOpt = opt === challenge.correctAnswer;
                const isPicked = pickedOption === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={solved}
                    onClick={() => handleChoicePick(opt, challenge.correctAnswer)}
                    className={`min-h-11 px-3 py-2.5 rounded-2xl border-2 text-sm font-black transition cursor-pointer ${
                      solved && isCorrectOpt
                        ? 'bg-emerald-500 text-white border-emerald-600'
                        : isPicked && !isCorrectOpt
                        ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-400 text-rose-700 dark:text-rose-200'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-indigo-400'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. Word Order Challenge */}
        {challenge.challengeType === 'word_order' && (
          <div className="space-y-3">
            <p className="text-sm font-black text-slate-900 dark:text-white">
              {challenge.promptTr}
            </p>

            {/* Answer Tray */}
            <div className="min-h-14 p-3 rounded-2xl bg-white dark:bg-slate-900 border-2 border-dashed border-slate-300 dark:border-slate-600 flex flex-wrap gap-2 items-center">
              {solved ? (
                challenge.correctWords.map((word, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500 text-white text-sm font-black shadow-2xs"
                  >
                    {word}
                  </span>
                ))
              ) : selectedIndices.length === 0 ? (
                <span className="text-xs font-semibold text-slate-400">
                  Aşağıdaki kelimelere sırayla dokun...
                </span>
              ) : (
                selectedIndices.map((wordIdx) => (
                  <button
                    key={wordIdx}
                    type="button"
                    onClick={() => handleWordBankTap(wordIdx)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-sm font-black shadow-2xs cursor-pointer hover:bg-indigo-700 transition"
                  >
                    {challenge.scrambledWords[wordIdx]}
                  </button>
                ))
              )}
            </div>

            {/* Word Bank */}
            {!solved && (
              <>
                <div className="flex flex-wrap gap-2">
                  {challenge.scrambledWords.map((word, idx) => {
                    const isUsed = selectedIndices.includes(idx);
                    return (
                      <button
                        key={idx}
                        type="button"
                        disabled={isUsed}
                        onClick={() => handleWordBankTap(idx)}
                        className={`min-h-10 px-3 py-1.5 rounded-xl border-2 text-sm font-black transition cursor-pointer ${
                          isUsed
                            ? 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-transparent select-none'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-indigo-400 shadow-2xs'
                        }`}
                      >
                        {word}
                      </button>
                    );
                  })}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedIndices([]);
                      setShowHint(false);
                    }}
                    disabled={selectedIndices.length === 0}
                    className="min-h-11 px-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-black inline-flex items-center gap-1 disabled:opacity-40 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Sıfırla
                  </button>
                  <button
                    type="button"
                    disabled={selectedIndices.length !== challenge.correctWords.length}
                    onClick={handleCheckWordOrder}
                    className="flex-1 min-h-11 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-black disabled:opacity-40 transition cursor-pointer"
                  >
                    Cümleyi Kontrol Et
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* 4. Vocab Match Challenge */}
        {challenge.challengeType === 'vocab_match' && (
          <div className="space-y-3">
            <p className="text-sm font-black text-slate-900 dark:text-white">
              {challenge.promptTr}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              {/* Left Column: German */}
              <div className="space-y-2">
                {challenge.pairs.map((pair) => {
                  const isMatched = solved || matchedPairIds.includes(pair.id);
                  const isPicked = pickedDeId === pair.id;
                  const isWrong = wrongFlashPair?.deId === pair.id;
                  return (
                    <button
                      key={pair.id}
                      type="button"
                      disabled={isMatched}
                      onClick={() => {
                        playClickSound(soundEnabled);
                        setPickedDeId(isPicked ? null : pair.id);
                      }}
                      className={`w-full min-h-11 px-3 py-2 rounded-xl border-2 text-xs sm:text-sm font-black transition cursor-pointer ${
                        isMatched
                          ? 'bg-emerald-100 dark:bg-emerald-950/70 border-emerald-400 text-emerald-700 dark:text-emerald-300'
                          : isWrong
                          ? 'bg-rose-100 dark:bg-rose-950 border-rose-500 text-rose-700'
                          : isPicked
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-indigo-400'
                      }`}
                    >
                      {pair.de}
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Turkish */}
              <div className="space-y-2">
                {shuffledRightPairs.map((pair) => {
                  const isMatched = solved || matchedPairIds.includes(pair.id);
                  const isWrong = wrongFlashPair?.trId === pair.id;
                  return (
                    <button
                      key={pair.id}
                      type="button"
                      disabled={isMatched || !pickedDeId}
                      onClick={() => handleMatchRightTap(pair.id)}
                      className={`w-full min-h-11 px-3 py-2 rounded-xl border-2 text-xs sm:text-sm font-bold transition cursor-pointer ${
                        isMatched
                          ? 'bg-emerald-100 dark:bg-emerald-950/70 border-emerald-400 text-emerald-700 dark:text-emerald-300'
                          : isWrong
                          ? 'bg-rose-100 dark:bg-rose-950 border-rose-500 text-rose-700'
                          : pickedDeId
                          ? 'bg-white dark:bg-slate-900 border-amber-300 dark:border-amber-600 text-slate-800 dark:text-slate-100 hover:border-indigo-500'
                          : 'bg-white/70 dark:bg-slate-900/70 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {pair.tr}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Hint on wrong answer or Explanation on solved */}
        {showHint && !solved && (
          <div className="mt-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs font-bold text-rose-700 dark:text-rose-200">
            💡 {challenge.hintTr} Tekrar dene!
          </div>
        )}

        {solved && (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-100/80 dark:bg-emerald-900/40 border border-emerald-300 dark:border-emerald-700 text-xs font-bold text-emerald-800 dark:text-emerald-200">
            ✓ Harika! {challenge.explanationTr}
          </div>
        )}
      </motion.div>
    );
  }
);

export const StoriesView: React.FC = memo(() => {
  const {
    profile,
    currentLevel,
    navTarget,
    clearNavTarget,
    addCustomWord,
    recordAnswer,
    recordActivity,
    markStoryDone,
  } = useApp();

  const [levelFilter, setLevelFilter] = useState<CEFRLevel | 'ALL'>(currentLevel);
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [cursor, setCursor] = useState(0);
  const [solvedChallenges, setSolvedChallenges] = useState<Record<string, boolean>>({});
  const [storyCompleted, setStoryCompleted] = useState(false);
  const [showTranslations, setShowTranslations] = useState(false);
  const [autoAudio, setAutoAudio] = useState<boolean>(() => {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const saved = window.localStorage.getItem(AUTO_AUDIO_STORAGE_KEY);
        if (saved === 'false') return false;
        if (saved === 'true') return true;
      }
    } catch {
      /* ignore */
    }
    return true;
  });

  const [selectedWord, setSelectedWord] = useState<SelectedWordState | null>(null);
  const [savedWordsToast, setSavedWordsToast] = useState<string | null>(null);
  const [addedWordKeys, setAddedWordKeys] = useState<Set<string>>(() => new Set());
  const bottomAnchorRef = useRef<HTMLDivElement | null>(null);

  const completedSet = useMemo(
    () => new Set(profile.completedStories || []),
    [profile.completedStories]
  );

  const levelCounts = useMemo(() => {
    const counts: Record<CEFRLevel | 'ALL', number> = {
      ALL: STORIES.length,
      A1: 0,
      A2: 0,
      B1: 0,
      B2: 0,
      C1: 0,
    };
    for (const s of STORIES) {
      counts[s.level] += 1;
    }
    return counts;
  }, []);

  const filteredStories = useMemo(
    () => STORIES.filter((s) => levelFilter === 'ALL' || s.level === levelFilter),
    [levelFilter]
  );

  const characterMap = useMemo(() => {
    const map = new Map<string, StoryCharacter>();
    if (!activeStory) return map;
    for (const ch of activeStory.characters) {
      map.set(ch.id, ch);
    }
    return map;
  }, [activeStory]);

  const toggleAutoAudio = useCallback(() => {
    setAutoAudio((prev) => {
      const next = !prev;
      try {
        if (typeof window !== 'undefined' && window.localStorage) {
          window.localStorage.setItem(AUTO_AUDIO_STORAGE_KEY, String(next));
        }
      } catch {
        /* ignore */
      }
      if (!next) void stopSpeaking();
      return next;
    });
  }, []);

  const openStory = useCallback((story: Story) => {
    void stopSpeaking();
    setActiveStory(story);
    setCursor(0);
    setSolvedChallenges({});
    setStoryCompleted(false);
    setSelectedWord(null);
    setShowTranslations(false);
  }, []);

  const closeStory = useCallback(() => {
    void stopSpeaking();
    setActiveStory(null);
    setSelectedWord(null);
  }, []);

  useEffect(() => {
    if (!navTarget) return;
    const target = STORIES.find((s) => s.id === navTarget);
    if (target) {
      setLevelFilter(target.level);
      openStory(target);
      clearNavTarget();
    }
  }, [navTarget, openStory, clearNavTarget]);

  useBackHandler(activeStory !== null, closeStory);

  // Auto-speak newly revealed dialogue lines when Auto-Audio is enabled & auto-scroll smoothly
  useEffect(() => {
    if (!activeStory) return;
    const currentStep = activeStory.steps[cursor];
    if (currentStep && currentStep.kind === 'line' && autoAudio && profile.soundEnabled) {
      void speakGerman(currentStep.german, profile.speechSpeed);
    }
    const timer = window.setTimeout(() => {
      bottomAnchorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }, 80);
    return () => window.clearTimeout(timer);
  }, [activeStory, cursor, autoAudio, profile.soundEnabled, profile.speechSpeed, storyCompleted]);

  const handleChallengeSolved = useCallback((challengeId: string) => {
    setSolvedChallenges((prev) => ({ ...prev, [challengeId]: true }));
  }, []);

  const handleAdvance = useCallback(() => {
    if (!activeStory) return;
    const currentStep = activeStory.steps[cursor];
    if (currentStep?.kind === 'challenge' && !solvedChallenges[currentStep.id]) {
      return;
    }

    if (cursor < activeStory.steps.length - 1) {
      playClickSound(profile.soundEnabled);
      setCursor((prev) => prev + 1);
      return;
    }

    if (!storyCompleted) {
      setStoryCompleted(true);
      playSuccessSound(profile.soundEnabled);
      recordActivity('reading', true, 50);
      markStoryDone(activeStory.id, activeStory.xpReward);
      try {
        confetti({ particleCount: 100, spread: 75, origin: { y: 0.68 } });
      } catch {
        /* ignore */
      }
    }
  }, [
    activeStory,
    cursor,
    solvedChallenges,
    storyCompleted,
    profile.soundEnabled,
    recordActivity,
    markStoryDone,
  ]);

  const handleWordClick = useCallback(
    (rawToken: string, lineGerman: string, lineTurkish: string) => {
      if (!activeStory) return;
      const key = normalizeTokenKey(rawToken);
      if (!key) return;
      const entry = activeStory.vocabularyMap[key];
      if (!entry) {
        void speakGerman(rawToken.replace(/[.,!?;:"'()]/g, ''), profile.speechSpeed);
        return;
      }
      void speakGerman(
        entry.article !== 'none' ? `${entry.article} ${entry.base}` : entry.base,
        profile.speechSpeed
      );
      setSelectedWord({
        token: key,
        entry,
        lineGerman,
        lineTurkish,
      });
    },
    [activeStory, profile.speechSpeed]
  );

  const handleAddWordToSrs = useCallback(() => {
    if (!selectedWord || !activeStory) return;
    const { entry, lineGerman, lineTurkish, token } = selectedWord;
    const storySourceTag = `Hikaye: ${activeStory.titleTr}`;
    const existing = (profile.customWords || []).find(
      (w) => w.german.toLowerCase() === entry.base.toLowerCase()
    );
    const created =
      existing ||
      addCustomWord({
        german: entry.base,
        turkish: entry.turkish,
        article: entry.article,
        plural: entry.plural,
        level: activeStory.level,
        category: entry.category || activeStory.scenarioTag,
        exampleGerman: entry.exampleDe || lineGerman,
        exampleTurkish: entry.exampleTr || lineTurkish,
        sourceTag: storySourceTag,
      });
    recordAnswer(created.id, false);
    setAddedWordKeys((prev) => new Set(prev).add(token));
    setSavedWordsToast(
      `"${entry.article !== 'none' ? entry.article + ' ' : ''}${entry.base}" (${storySourceTag}) SRS tekrarına eklendi!`
    );
    window.setTimeout(() => setSavedWordsToast(null), 2800);
  }, [selectedWord, activeStory, profile.customWords, addCustomWord, recordAnswer]);

  // ============================================
  // ACTIVE INTERACTIVE STORY THEATRE MODE
  // ============================================
  if (activeStory) {
    const visibleSteps = activeStory.steps.slice(0, cursor + 1);
    const currentStep = activeStory.steps[cursor];
    const isBlockedByChallenge =
      currentStep?.kind === 'challenge' && !solvedChallenges[currentStep.id];
    const isLastStep = cursor >= activeStory.steps.length - 1;
    const progressPct = Math.round(((cursor + 1) / activeStory.steps.length) * 100);
    const totalChallenges = activeStory.steps.filter((s) => s.kind === 'challenge').length;
    const solvedCount = Object.values(solvedChallenges).filter(Boolean).length;

    const renderClickableGerman = (german: string, turkish: string) => {
      const tokens = german.split(/\s+/);
      return (
        <p className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed flex flex-wrap gap-x-1.5 gap-y-1">
          {tokens.map((tok, idx) => {
            const key = normalizeTokenKey(tok);
            const dictEntry = key ? activeStory.vocabularyMap[key] : undefined;
            const isSelected = selectedWord?.token === key;
            if (!dictEntry) {
              return <span key={idx}>{tok}</span>;
            }
            const artColor =
              dictEntry.article !== 'none'
                ? ARTICLE_TEXT_COLOR[dictEntry.article]
                : 'text-indigo-600 dark:text-indigo-400';
            return (
              <button
                key={idx}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleWordClick(tok, german, turkish);
                }}
                className={`px-1 rounded-lg border-b-2 border-dotted transition cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-100 dark:bg-indigo-950 border-indigo-500 ring-2 ring-indigo-300 dark:ring-indigo-700'
                    : 'border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700/70'
                } ${artColor}`}
                title="Anlamını ve artikelini görmek için dokun"
              >
                {tok}
              </button>
            );
          })}
        </p>
      );
    };

    return (
      <div className="max-w-3xl mx-auto px-4 py-4 pb-10 space-y-4 page-enter">
        {/* Sticky Story Top Bar with Progress & Controls */}
        <div className="sticky top-17 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-3.5 rounded-3xl border-2 border-slate-200 dark:border-slate-700 shadow-sm space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={closeStory}
              className="min-h-10 px-2.5 py-1.5 rounded-xl inline-flex items-center gap-1 text-xs sm:text-sm font-black text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
              <span>Hikayeler</span>
            </button>

            <div className="flex items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={toggleAutoAudio}
                aria-pressed={autoAudio}
                className={`min-h-10 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center gap-1.5 transition cursor-pointer ${
                  autoAudio
                    ? 'bg-sky-500 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
                title="Yeni satır açıldığında otomatik seslendirme"
              >
                {autoAudio ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span>Oto Ses</span>
              </button>

              <button
                type="button"
                onClick={() => setShowTranslations((v) => !v)}
                aria-pressed={showTranslations}
                className={`min-h-10 px-3 py-1.5 rounded-xl text-xs font-black inline-flex items-center gap-1.5 transition cursor-pointer ${
                  showTranslations
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                <Languages className="w-4 h-4" />
                <span>{showTranslations ? 'TR Açık' : 'Türkçe'}</span>
              </button>
            </div>
          </div>

          {/* Step Progress Bar */}
          <div className="flex items-center gap-3 px-1">
            <div className="flex-1 h-2.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full rounded-full bg-linear-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            <span className="text-[11px] font-black text-slate-500 dark:text-slate-400 shrink-0">
              {cursor + 1}/{activeStory.steps.length}
            </span>
          </div>
        </div>

        {/* Story Opening Scene Header */}
        <div className="p-5 rounded-3xl bg-linear-to-br from-slate-900 via-indigo-950 to-slate-900 text-white shadow-lg border border-slate-800">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center text-3xl shrink-0">
              {activeStory.emoji}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded-lg bg-amber-400/20 text-amber-300 text-[11px] font-black">
                  {activeStory.level} • {activeStory.scenarioTag}
                </span>
                <span className="text-[11px] font-bold text-emerald-300">
                  +{activeStory.xpReward} XP
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black mt-1 leading-tight">
                {activeStory.titleDe}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300">{activeStory.titleTr}</p>
            </div>
          </div>

          {/* Cast Badges */}
          <div className="mt-3.5 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              {activeStory.characters.map((ch) => (
                <span
                  key={ch.id}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/10 text-xs font-bold text-slate-100"
                >
                  <span>{ch.avatarEmoji}</span>
                  <span>{ch.name}</span>
                  <span className="text-[10px] text-slate-400">({ch.roleTr})</span>
                </span>
              ))}
            </div>
            <span className="text-[11px] text-slate-300 inline-flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Kelimeye dokun =
              <strong className="text-blue-300">der</strong>/
              <strong className="text-rose-300">die</strong>/
              <strong className="text-emerald-300">das</strong> + SRS
            </span>
          </div>
        </div>

        {/* Interactive Word Tap Popover */}
        {selectedWord && (() => {
          const ruleHint = getArticleRuleHint(selectedWord.entry.base, selectedWord.entry.article);
          const speakTarget =
            selectedWord.entry.article !== 'none'
              ? `${selectedWord.entry.article} ${selectedWord.entry.base}`
              : selectedWord.entry.base;
          return (
            <div className="sticky top-42 z-30 rounded-3xl bg-white dark:bg-slate-800 border-2 border-indigo-400 dark:border-indigo-500 p-4 shadow-2xl pop-in">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {selectedWord.entry.article !== 'none' && (
                      <span
                        className={`text-xs font-black px-2 py-0.5 rounded-lg border ${
                          ARTICLE_BADGE_CLASS[selectedWord.entry.article]
                        }`}
                      >
                        {selectedWord.entry.article}
                      </span>
                    )}
                    <span className="text-lg font-black text-slate-900 dark:text-white">
                      {selectedWord.entry.base}
                    </span>
                    {selectedWord.entry.plural && (
                      <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                        (Çoğul: {selectedWord.entry.plural})
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-bold text-emerald-700 dark:text-emerald-400">
                    {selectedWord.entry.turkish}
                  </p>
                  {ruleHint && (
                    <div className="mt-1 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-[11px] font-bold text-amber-800 dark:text-amber-200">
                      <span>💡 {ruleHint.ruleTitleTr}</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => void speakGerman(speakTarget, profile.speechSpeed)}
                    aria-label="Kelimeyi dinle"
                    className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 cursor-pointer"
                    title="Normal dinle"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => void speakGermanSlow(speakTarget)}
                    aria-label="Kelimeyi 0.75x yavaş dinle"
                    className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 cursor-pointer"
                    title="0.75x yavaş dinle"
                  >
                    <Turtle className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedWord(null)}
                    aria-label="Kartı kapat"
                    className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-slate-100 dark:border-slate-700">
                <span className="text-[11px] font-bold text-slate-400">
                  Kaynak: Hikaye · {activeStory.titleTr}
                </span>
                <button
                  type="button"
                  onClick={handleAddWordToSrs}
                  disabled={addedWordKeys.has(selectedWord.token)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black inline-flex items-center gap-1.5 transition cursor-pointer ${
                    addedWordKeys.has(selectedWord.token)
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                  }`}
                >
                  {addedWordKeys.has(selectedWord.token) ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" /> Listene & Tekrara Eklendi
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-4 h-4" /> Kelime Listeme & SRS'e Ekle
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })()}

        {/* Step-by-Step Theatre Dialogue Stream */}
        <div
          onClick={() => {
            if (!isBlockedByChallenge && !storyCompleted) {
              handleAdvance();
            }
          }}
          className="space-y-3.5 min-h-60"
        >
          {visibleSteps.map((step, index) => {
            if (step.kind === 'challenge') {
              return (
                <div
                  key={step.id}
                  onClick={(e) => e.stopPropagation()}
                  className="py-1"
                >
                  <InlineChallengeCard
                    challenge={step}
                    solved={!!solvedChallenges[step.id]}
                    soundEnabled={profile.soundEnabled}
                    onSolved={handleChallengeSolved}
                  />
                </div>
              );
            }

            if (step.isNarrator) {
              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.22 }}
                  className="p-4 rounded-2xl bg-slate-100/90 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-start justify-between gap-3"
                >
                  <div className="min-w-0 flex-1 space-y-1">
                    <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      📖 Anlatıcı
                    </span>
                    {renderClickableGerman(step.german, step.turkish)}
                    {showTranslations && (
                      <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 italic pt-1">
                        {step.turkish}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void speakGerman(step.german, profile.speechSpeed);
                      }}
                      aria-label="Anlatımı dinle"
                      className="p-2.5 rounded-xl bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-200 hover:text-indigo-600 shrink-0 cursor-pointer shadow-2xs"
                      title="Normal hızda dinle"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void speakGermanSlow(step.german);
                      }}
                      aria-label="Anlatımı 0.75x yavaş dinle"
                      className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-300 hover:bg-amber-100 shrink-0 cursor-pointer shadow-2xs"
                      title="0.75x Yavaş Dinle"
                    >
                      <Turtle className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>
              );
            }

            const character = step.characterId ? characterMap.get(step.characterId) : undefined;
            const tone = TONE_CLASSES[character?.bubbleTone || 'indigo'];
            const isRight = character?.side === 'right';
            const isLatest = index === visibleSteps.length - 1;

            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, y: 14, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.22 }}
                className={`flex items-end gap-2.5 ${isRight ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {/* Character Avatar */}
                <div
                  className={`w-11 h-11 rounded-2xl border-2 flex items-center justify-center text-xl shrink-0 shadow-2xs ${tone.avatarBg}`}
                  title={`${character?.name || step.speaker} (${character?.roleTr || ''})`}
                >
                  {character?.avatarEmoji || '💬'}
                </div>

                {/* Speech Bubble */}
                <div
                  className={`flex-1 max-w-[85%] p-4 rounded-3xl bg-white dark:bg-slate-800 border-2 shadow-xs transition ${
                    isLatest
                      ? `${tone.bubbleBorder} ring-2 ring-indigo-100/70 dark:ring-indigo-900/40`
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2.5">
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-xs font-black uppercase tracking-wide ${tone.nameColor}`}>
                          {step.speaker}
                        </span>
                        {character?.roleTr && (
                          <span className="text-[10px] font-bold text-slate-400">
                            • {character.roleTr}
                          </span>
                        )}
                      </div>
                      {renderClickableGerman(step.german, step.turkish)}
                      {showTranslations && (
                        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 italic pt-1">
                          {step.turkish}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void speakGerman(step.german, profile.speechSpeed);
                        }}
                        aria-label="Repliği dinle"
                        className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 shrink-0 cursor-pointer"
                        title="Normal hızda dinle"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void speakGermanSlow(step.german);
                        }}
                        aria-label="Repliği 0.75x yavaş dinle"
                        className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-300 hover:bg-amber-100 shrink-0 cursor-pointer"
                        title="0.75x Yavaş Dinle"
                      >
                        <Turtle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}

          {/* Story Completion Celebration Card */}
          {storyCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-6 rounded-3xl bg-linear-to-r from-emerald-500 to-teal-600 text-white shadow-xl space-y-4"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                  <Trophy className="w-8 h-8 text-amber-300" />
                </div>
                <div>
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-100">
                    Hikaye Tamamlandı!
                  </span>
                  <h3 className="text-xl font-black">{activeStory.titleTr}</h3>
                  <p className="text-xs sm:text-sm text-emerald-50">
                    {solvedCount}/{totalChallenges} ara görevi tamamladın ve +{activeStory.xpReward} XP kazandın.
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    closeStory();
                  }}
                  className="flex-1 min-h-12 px-5 py-3 rounded-2xl bg-white text-emerald-700 font-black text-sm shadow-sm hover:bg-emerald-50 transition cursor-pointer"
                >
                  Diğer Hikayelere Dön
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    openStory(activeStory);
                  }}
                  className="min-h-12 px-4 py-3 rounded-2xl bg-emerald-700/60 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm transition cursor-pointer"
                >
                  Baştan Oynat
                </button>
              </div>
            </motion.div>
          )}

          <div ref={bottomAnchorRef} className="h-2" />
        </div>

        {/* Sticky Bottom "Devam Et (Weiter)" Bar */}
        {!storyCompleted && (
          <div className="sticky bottom-18 md:bottom-4 z-20 pt-2 pb-[max(0.25rem,env(safe-area-inset-bottom))]">
            <button
              type="button"
              disabled={isBlockedByChallenge}
              onClick={handleAdvance}
              className={`w-full min-h-14 rounded-2xl font-black text-base flex items-center justify-center gap-2 transition cursor-pointer ${
                isBlockedByChallenge
                  ? 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-2 border-slate-300 dark:border-slate-700 cursor-not-allowed'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-[0_5px_0_#047857] active:translate-y-0.5 active:shadow-none'
              }`}
            >
              {isBlockedByChallenge ? (
                <span>Devam etmek için ara görevi çöz ↑</span>
              ) : isLastStep ? (
                <>
                  <span>Hikayeyi Tamamla (+{activeStory.xpReward} XP)</span>
                  <CheckCircle2 className="w-5 h-5" />
                </>
              ) : (
                <>
                  <span>Devam Et (Weiter)</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        )}

        {savedWordsToast && (
          <div
            role="status"
            className="fixed left-1/2 -translate-x-1/2 bottom-28 z-50 max-w-[90vw] px-4 py-2.5 rounded-2xl bg-slate-900 text-white text-xs font-bold shadow-xl"
          >
            {savedWordsToast}
          </div>
        )}
      </div>
    );
  }

  // ============================================
  // STORY LIBRARY CATALOG SCREEN
  // ============================================
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 pb-28 space-y-6">
      <div className="p-6 rounded-3xl bg-linear-to-r from-slate-900 via-indigo-900 to-purple-800 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/15 px-3 py-1 rounded-full uppercase tracking-wider">
            Duolingo Stories Formatı • {STORIES.length} Hikaye
          </span>
          <h2 className="text-2xl font-black mt-1.5">İnteraktif Kısa Hikayeler</h2>
          <p className="text-xs sm:text-sm text-indigo-100 mt-1">
            Adım adım ilerleyen karakter diyalogları, hikaye içi ara görevler, otomatik seslendirme ve tek dokunuşla SRS kelime kartı ekleme!
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-xs px-5 py-3 rounded-2xl text-center shrink-0 border border-white/15">
          <span className="text-2xl font-black block">
            {completedSet.size}/{STORIES.length}
          </span>
          <span className="text-[10px] uppercase font-bold text-indigo-100">Tamamlanan</span>
        </div>
      </div>

      {/* Level Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {LEVELS.map((lvl) => (
          <button
            key={lvl}
            type="button"
            onClick={() => setLevelFilter(lvl)}
            className={`px-3.5 py-2 rounded-xl text-xs font-black transition cursor-pointer shrink-0 inline-flex items-center gap-1.5 ${
              levelFilter === lvl
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
            }`}
          >
            <span>{lvl === 'ALL' ? 'Tüm Seviyeler' : lvl}</span>
            <span
              className={`px-1.5 py-0.5 rounded-md text-[10px] ${
                levelFilter === lvl
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300'
              }`}
            >
              {levelCounts[lvl]}
            </span>
          </button>
        ))}
      </div>

      {/* Story Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {filteredStories.map((story) => {
          const isDone = completedSet.has(story.id);
          const challengeCount = story.steps.filter((s) => s.kind === 'challenge').length;
          return (
            <button
              key={story.id}
              type="button"
              onClick={() => openStory(story)}
              className="text-left p-5 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-indigo-400 dark:hover:border-indigo-500 transition shadow-2xs flex flex-col justify-between gap-4 cursor-pointer"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-[11px] font-black">
                    {story.level} • {story.scenarioTag}
                  </span>
                  {isDone ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Okundu
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-400">
                      <Clock className="w-3.5 h-3.5" /> {story.durationMin} dk
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{story.emoji}</span>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white leading-snug">
                      {story.titleTr}
                    </h3>
                    <p className="text-xs font-semibold text-slate-400">{story.titleDe}</p>
                  </div>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed">
                  {story.summaryTr}
                </p>
              </div>
              <div className="pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs font-black text-indigo-600 dark:text-indigo-400">
                <span className="inline-flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4" />
                  <span>Hikayeye Başla</span>
                  <span className="text-[10px] font-bold text-slate-400">
                    ({challengeCount} ara görev)
                  </span>
                </span>
                <span>+{story.xpReward} XP</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
});
