import React, { useState } from 'react';
import {
  BookOpen,
  Layers,
  GraduationCap,
  MessageSquare,
  Dumbbell,
  User,
  Award,
  MoreHorizontal,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

type TabId = 'learn' | 'dtz' | 'words' | 'grammar' | 'practice' | 'profile' | 'dialogues' | 'flashcards';

const primaryItems: { id: TabId; label: string; icon: typeof BookOpen }[] = [
  { id: 'learn', label: 'Öğren', icon: BookOpen },
  { id: 'dtz', label: 'Sınav', icon: Award },
  { id: 'words', label: 'Kelime', icon: Layers },
  { id: 'grammar', label: 'Gramer', icon: GraduationCap },
];

const extraItems: { id: TabId; label: string; icon: typeof BookOpen; description: string }[] = [
  { id: 'flashcards', label: 'Kelime kartları', icon: Layers, description: 'Kelime kartlarını gözden geçir' },
  { id: 'dialogues', label: 'Günlük diyaloglar', icon: MessageSquare, description: 'Gerçek hayat konuşmaları' },
  { id: 'practice', label: 'Alıştırma ve test', icon: Dumbbell, description: 'Karışık soru çöz' },
];

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();
  const [moreOpen, setMoreOpen] = useState(false);
  const extraActive = extraItems.some((item) => item.id === activeTab);

  const navigate = (tab: TabId) => {
    setActiveTab(tab);
    setMoreOpen(false);
  };

  return (
    <nav
      aria-label="Ana gezinme"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-1.5 pt-1 pb-[max(0.25rem,env(safe-area-inset-bottom))] flex items-center justify-around shadow-lg"
    >
      {primaryItems.slice(0, 4).map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => navigate(item.id)}
            aria-current={isActive ? 'page' : undefined}
            className={`flex min-w-0 flex-1 flex-col items-center justify-center py-1.5 px-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
              isActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
            }`}
          >
            <Icon className="w-5 h-5 mb-0.5" />
            <span className="truncate max-w-full">{item.label}</span>
          </button>
        );
      })}

      <div className="relative flex-1 min-w-0">
        {moreOpen && (
          <>
            <button
              type="button"
              aria-label="Menüyü kapat"
              className="fixed inset-0 z-40 cursor-default"
              onClick={() => setMoreOpen(false)}
            />
            <div role="menu" aria-label="Diğer bölümler" className="absolute bottom-full right-0 mb-2 z-50 w-60 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 shadow-2xl">
              <div className="px-3 py-2 text-[10px] font-black uppercase tracking-wider text-slate-400">Diğer bölümler</div>
              {extraItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="menuitem"
                    onClick={() => navigate(item.id)}
                    className={`w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-left transition cursor-pointer ${
                      isActive ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300' : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Icon className="w-5 h-5 shrink-0" />
                    <span className="min-w-0">
                      <span className="block text-xs font-black">{item.label}</span>
                      <span className="block text-[10px] text-slate-400">{item.description}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </>
        )}
        <button
          type="button"
          onClick={() => setMoreOpen((open) => !open)}
          aria-expanded={moreOpen}
          aria-haspopup="menu"
          className={`w-full flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
            moreOpen || extraActive ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
          }`}
        >
          <MoreHorizontal className="w-5 h-5 mb-0.5" />
          <span>Diğer</span>
        </button>
      </div>

      <button
        type="button"
        onClick={() => navigate('profile')}
        aria-current={activeTab === 'profile' ? 'page' : undefined}
        className={`flex min-w-0 flex-1 flex-col items-center justify-center py-1.5 px-1 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
          activeTab === 'profile' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
        }`}
      >
        <User className="w-5 h-5 mb-0.5" />
        <span>Profil</span>
      </button>
    </nav>
  );
};
