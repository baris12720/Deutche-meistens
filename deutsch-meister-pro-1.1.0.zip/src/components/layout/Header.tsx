import React from 'react';
import { Flame, Zap, Heart, Volume2, VolumeX } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { CEFRLevel } from '../../types';

export const Header: React.FC = () => {
  const { profile, currentLevel, setCurrentLevel, toggleSound, setActiveTab } = useApp();

  const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand */}
        <button
          type="button"
          onClick={() => setActiveTab('learn')}
          aria-label="Deutsch Meister ana sayfa"
          className="flex items-center gap-2.5 cursor-pointer select-none shrink-0 text-left"
        >
          <img src={`${import.meta.env.BASE_URL}icon.svg`} alt="Deutsch Meister Logo" className="w-9 h-9 rounded-xl shadow-xs" />
          <div className="hidden sm:block">
            <span className="text-base font-black tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
              Deutsch Meister <span className="text-sm">🇩🇪</span>
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block -mt-1">
              %100 Ücretsiz Almanca
            </span>
          </div>
        </button>

        {/* Accessible level selector: works with touch, keyboard and screen readers. */}
        <label className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-black text-slate-800 dark:text-slate-100">
          <span className="w-2 h-2 rounded-full bg-emerald-500" aria-hidden="true" />
          <span className="hidden sm:inline">Seviye</span>
          <select
            value={currentLevel}
            onChange={(event) => setCurrentLevel(event.target.value as CEFRLevel)}
            aria-label="Öğrenme seviyesini seç"
            className="max-w-[4.5rem] bg-transparent font-black focus:outline-none cursor-pointer"
          >
            {levels.map((level) => <option key={level} value={level}>{level}</option>)}
          </select>
        </label>

        {/* Top Gamification Badges */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Unlimited Lives ∞ (Infinite practice, zero penalty!) */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 font-black text-xs cursor-help"
            title="Deutsch Meister'da can sınırı yok! İstediğin kadar hata yapabilir, dilediğince pratik yapabilirsin."
          >
            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
            <span className="text-sm font-extrabold leading-none">∞</span>
          </div>

          {/* Daily Streak Flame */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300 font-extrabold text-xs"
            title={`${profile.streak} günlük kesintisiz çalışma serisi!`}
          >
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>{profile.streak}</span>
          </div>

          {/* Total XP */}
          <div
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-yellow-50 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-900 text-yellow-800 dark:text-yellow-300 font-extrabold text-xs"
            title="Toplam Deneyim Puanı (XP)"
          >
            <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
            <span>{profile.xp}</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            title={profile.soundEnabled ? 'Sesi Kapat' : 'Sesi Aç'}
          >
            {profile.soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
};
