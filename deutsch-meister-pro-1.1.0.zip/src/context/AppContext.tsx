import React, { createContext, useContext, useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { ALL_BADGES } from '../data/badges';
import { ActivityDay, AiMistake, CEFRLevel, Skill, ThemePreference, UserProfile, UserWordCard } from '../types';
import { playLevelUpSound } from '../utils/audio';

const STORAGE_KEY = 'DEUTSCH_MEISTER_USER_STATE_V1';

const getTodayString = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const createDefaultProfile = (): UserProfile => ({
  name: 'Almanca Kaşifi',
  xp: 0,
  streak: 0,
  lastActiveDate: '',
  dailyGoalXp: 30,
  todayXp: 0,
  completedLessons: [],
  unlockedBadges: [],
  wordCards: {},
  soundEnabled: true,
  speechSpeed: 0.9,
  activeDates: [],
  currentLevel: 'A1',
  themePreference: 'system',
});

const isRecord = (value: unknown): value is Record<string, any> =>
  !!value && typeof value === 'object' && !Array.isArray(value);

const isLevel = (value: unknown): value is CEFRLevel =>
  value === 'A1' || value === 'A2' || value === 'B1' || value === 'B2' || value === 'C1';

const isDateKey = (value: unknown): value is string =>
  typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value);

const safeNumber = (value: unknown, fallback: number, min = 0, max = 10_000_000): number => {
  const number = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
  return Math.min(max, Math.max(min, number));
};

/** Accepts both legacy profile-only backups and the current versioned backup envelope. */
const normalizeProfile = (value: unknown): UserProfile | null => {
  if (!isRecord(value) || typeof value.xp !== 'number' || !Number.isFinite(value.xp)) return null;
  const defaults = createDefaultProfile();
  const skills: Skill[] = ['vocab', 'grammar', 'listening', 'speaking', 'reading', 'writing'];
  const wordCards: UserProfile['wordCards'] = {};

  if (isRecord(value.wordCards)) {
    Object.entries(value.wordCards).slice(0, 10000).forEach(([id, item]) => {
      if (!id || !isRecord(item)) return;
      wordCards[id] = {
        wordId: id,
        status: item.status === 'mastered' ? 'mastered' : 'learning',
        reviewsCount: safeNumber(item.reviewsCount, 0, 0, 1_000_000),
        lastReviewedAt: safeNumber(item.lastReviewedAt, 0, 0, 8_640_000_000_000_000),
        intervalDays: safeNumber(item.intervalDays, 1, 1, 3650),
      };
    });
  }

  const activity: NonNullable<UserProfile['activity']> = {};
  if (isRecord(value.activity)) {
    Object.entries(value.activity).slice(-90).forEach(([date, rawDay]) => {
      if (!isDateKey(date) || !isRecord(rawDay)) return;
      const daySkills: ActivityDay['skills'] = {};
      if (isRecord(rawDay.skills)) {
        skills.forEach((skill) => {
          const entry = rawDay.skills[skill];
          if (isRecord(entry)) {
            daySkills[skill] = {
              r: safeNumber(entry.r, 0, 0, 1_000_000),
              w: safeNumber(entry.w, 0, 0, 1_000_000),
            };
          }
        });
      }
      activity[date] = {
        q: safeNumber(rawDay.q, 0, 0, 1_000_000),
        secs: safeNumber(rawDay.secs, 0, 0, 100_000_000),
        rev: safeNumber(rawDay.rev, 0, 0, 1_000_000),
        skills: daySkills,
      };
    });
  }

  const srs: NonNullable<UserProfile['srs']> = {};
  if (isRecord(value.srs)) {
    Object.entries(value.srs).slice(0, 20000).forEach(([id, item]) => {
      if (!id || !isRecord(item)) return;
      srs[id] = {
        box: safeNumber(item.box, 0, 0, 5),
        due: isDateKey(item.due) ? item.due : getTodayString(),
        right: safeNumber(item.right, 0, 0, 1_000_000),
        wrong: safeNumber(item.wrong, 0, 0, 1_000_000),
        last: isDateKey(item.last) ? item.last : getTodayString(),
      };
    });
  }

  const stringList = (list: unknown, maxItems = 20000): string[] =>
    Array.isArray(list)
      ? Array.from(new Set(list.filter((item): item is string => typeof item === 'string' && item.length > 0).slice(0, maxItems)))
      : [];

  const themePreference: ThemePreference =
    value.themePreference === 'light' || value.themePreference === 'dark' ? value.themePreference : 'system';

  return {
    ...defaults,
    name: typeof value.name === 'string' && value.name.trim() ? value.name.trim().slice(0, 30) : defaults.name,
    xp: safeNumber(value.xp, 0),
    streak: safeNumber(value.streak, 0, 0, 100_000),
    lastActiveDate: isDateKey(value.lastActiveDate) ? value.lastActiveDate : '',
    dailyGoalXp: safeNumber(value.dailyGoalXp, defaults.dailyGoalXp, 10, 500),
    todayXp: safeNumber(value.todayXp, 0, 0, 1_000_000),
    completedLessons: stringList(value.completedLessons),
    unlockedBadges: stringList(value.unlockedBadges, 1000),
    wordCards,
    soundEnabled: typeof value.soundEnabled === 'boolean' ? value.soundEnabled : defaults.soundEnabled,
    speechSpeed: safeNumber(value.speechSpeed, defaults.speechSpeed, 0.6, 1.2),
    activeDates: stringList(value.activeDates, 90).filter(isDateKey).sort(),
    activity,
    dailyMinutes: safeNumber(value.dailyMinutes, 15, 5, 120),
    aiMistakes: Array.isArray(value.aiMistakes)
      ? value.aiMistakes.filter(isRecord).slice(0, 100).map((mistake: any, index: number) => ({
          id: typeof mistake.id === 'string' ? mistake.id.slice(0, 100) : `imported_${index}`,
          date: isDateKey(mistake.date) ? mistake.date : getTodayString(),
          original: typeof mistake.original === 'string' ? mistake.original.slice(0, 2000) : '',
          corrected: typeof mistake.corrected === 'string' ? mistake.corrected.slice(0, 2000) : '',
          explanationTr: typeof mistake.explanationTr === 'string' ? mistake.explanationTr.slice(0, 4000) : '',
          type: typeof mistake.type === 'string' ? mistake.type.slice(0, 100) : 'grammar',
        }))
      : [],
    srs,
    completedWordSets: stringList(value.completedWordSets),
    passedLevelExams: Array.isArray(value.passedLevelExams) ? value.passedLevelExams.filter(isLevel) : [],
    placementLevel: isLevel(value.placementLevel) ? value.placementLevel : undefined,
    currentLevel: isLevel(value.currentLevel) ? value.currentLevel : (isLevel(value.placementLevel) ? value.placementLevel : 'A1'),
    themePreference,
  };
};

const dayDifference = (from: string, to: string): number => {
  if (!isDateKey(from) || !isDateKey(to)) return Number.POSITIVE_INFINITY;
  const [fy, fm, fd] = from.split('-').map(Number);
  const [ty, tm, td] = to.split('-').map(Number);
  return Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(fy, fm - 1, fd)) / 86_400_000);
};

/** A study streak changes only after real learning activity, never just by opening the app. */
const markStudyDay = (profile: UserProfile, today = getTodayString()): UserProfile => {
  if (profile.lastActiveDate === today) {
    if ((profile.activeDates || []).includes(today)) return profile;
    return { ...profile, activeDates: [...(profile.activeDates || []), today].slice(-90) };
  }
  const gap = dayDifference(profile.lastActiveDate, today);
  const streak = !profile.lastActiveDate ? 1 : gap === 1 ? profile.streak + 1 : 1;
  return {
    ...profile,
    streak,
    lastActiveDate: today,
    todayXp: 0,
    activeDates: Array.from(new Set([...(profile.activeDates || []), today])).slice(-90),
  };
};

const loadProfile = (): UserProfile => {
  if (typeof window === 'undefined') return createDefaultProfile();
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (!saved) return createDefaultProfile();
    const parsed = JSON.parse(saved);
    const candidate = isRecord(parsed) && parsed.app === 'Deutsch Meister' ? parsed.profile : parsed;
    const normalized = normalizeProfile(candidate);
    if (!normalized) return createDefaultProfile();
    // Daily XP rolls over on a new calendar day; streaks are updated only when the user studies.
    return normalized.lastActiveDate === getTodayString() ? normalized : { ...normalized, todayXp: 0 };
  } catch (error) {
    console.warn('Failed to load saved user profile:', error);
    return createDefaultProfile();
  }
};
interface CompletionModalData {
  lessonTitle: string;
  earnedXp: number;
  correctCount: number;
  totalQuestions: number;
  newBadges: string[];
}

interface AppContextType {
  profile: UserProfile;
  currentLevel: CEFRLevel;
  activeTab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words';
  activeLessonId: string | null;
  activeGrammarId: string | null;
  activeDialogueId: string | null;
  completionData: CompletionModalData | null;
  isPlacementTestOpen: boolean;
  setCurrentLevel: (level: CEFRLevel) => void;
  setPlacementLevel: (level: CEFRLevel) => void;
  markLevelExamPassed: (level: CEFRLevel) => void;
  markWordSetDone: (setId: string) => void;
  recordAnswer: (refId: string, correct: boolean) => void;
  recordActivity: (skill: Skill, correct: boolean, secs?: number) => void;
  markReviewDone: (count: number) => void;
  setDailyMinutes: (minutes: number) => void;
  addAiMistake: (m: Omit<AiMistake, 'id' | 'date'>) => void;
  navTarget: string | null;
  goTo: (tab: string, target?: string) => void;
  clearNavTarget: () => void;
  setActiveTab: (tab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words') => void;
  openLesson: (lessonId: string) => void;
  closeLesson: () => void;
  openGrammar: (grammarId: string) => void;
  closeGrammar: () => void;
  openDialogue: (dialogueId: string) => void;
  closeDialogue: () => void;
  openPlacementTest: () => void;
  closePlacementTest: () => void;
  closeCompletionModal: () => void;
  completeLessonSession: (lessonId: string, earnedXp: number, correct: number, total: number) => void;
  addXp: (amount: number) => void;
  updateWordStatus: (wordId: string, status: 'learning' | 'mastered') => void;
  toggleSound: () => void;
  setSpeechSpeed: (speed: number) => void;
  setDailyGoalXp: (goal: number) => void;
  updateProfileName: (name: string) => void;
  setThemePreference: (theme: ThemePreference) => void;
  exportData: () => string;
  importData: (jsonData: string) => boolean;
  resetProgress: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<UserProfile>(loadProfile);
  const [currentLevel, setCurrentLevelState] = useState<CEFRLevel>(profile.currentLevel || 'A1');
  const [activeTab, setActiveTab] = useState<'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words'>('learn');
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [activeGrammarId, setActiveGrammarId] = useState<string | null>(null);
  const [activeDialogueId, setActiveDialogueId] = useState<string | null>(null);
  const [completionData, setCompletionData] = useState<CompletionModalData | null>(null);
  const [isPlacementTestOpen, setIsPlacementTestOpen] = useState(false);

  // Sync profile to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.warn('Failed to save profile to localStorage:', e);
    }
  }, [profile]);

  // Apply the selected appearance. System mode follows the device setting automatically.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const dark = profile.themePreference === 'dark' || (profile.themePreference === 'system' && media.matches);
      document.documentElement.classList.toggle('dark', dark);
      document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
    };
    apply();
    if (profile.themePreference !== 'system') return;
    media.addEventListener?.('change', apply);
    return () => media.removeEventListener?.('change', apply);
  }, [profile.themePreference]);

  // Check and unlock badges
  const checkNewBadges = (updated: UserProfile): string[] => {
    const newlyUnlocked: string[] = [];
    const currentBadges = new Set(updated.unlockedBadges);

    ALL_BADGES.forEach((b) => {
      if (currentBadges.has(b.id)) return;

      let shouldUnlock = false;
      if (b.id === 'first_lesson' && updated.completedLessons.length >= 1) shouldUnlock = true;
      if (b.id === 'streak_3' && updated.streak >= 3) shouldUnlock = true;
      if (b.id === 'streak_7' && updated.streak >= 7) shouldUnlock = true;
      if (b.id === 'xp_100' && updated.xp >= 100) shouldUnlock = true;
      if (b.id === 'xp_500' && updated.xp >= 500) shouldUnlock = true;
      if (b.id === 'words_25' && Object.keys(updated.wordCards).length >= 25) shouldUnlock = true;

      if (shouldUnlock) {
        newlyUnlocked.push(b.id);
      }
    });

    return newlyUnlocked;
  };

  const addXp = (amount: number) => {
    const earned = Math.max(0, Math.round(Number.isFinite(amount) ? amount : 0));
    if (!earned) return;
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const updated = { ...studied, xp: studied.xp + earned, todayXp: studied.todayXp + earned };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...studied.unlockedBadges, ...newBadges];
      return updated;
    });
  };

  const completeLessonSession = (lessonId: string, earnedXp: number, correct: number, total: number) => {
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const alreadyCompleted = studied.completedLessons.includes(lessonId);
      const newCompleted = alreadyCompleted ? studied.completedLessons : [...studied.completedLessons, lessonId];
      const safeEarnedXp = Math.max(0, Math.round(Number.isFinite(earnedXp) ? earnedXp : 0));

      const updated = {
        ...studied,
        completedLessons: newCompleted,
        xp: studied.xp + safeEarnedXp,
        todayXp: studied.todayXp + safeEarnedXp,
      };

      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...studied.unlockedBadges, ...newBadges];
      }

      setCompletionData({
        lessonTitle: lessonId,
        earnedXp: safeEarnedXp,
        correctCount: correct,
        totalQuestions: total,
        newBadges,
      });

      if (prev.soundEnabled) {
        playLevelUpSound(true);
      }

      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#22c55e', '#38bdf8', '#facc15', '#f43f5e'],
        });
      } catch {
        // ignore
      }

      return updated;
    });
  };

  const updateWordStatus = (wordId: string, status: 'learning' | 'mastered') => {
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const existing = studied.wordCards[wordId] || {
        wordId,
        status: 'learning',
        reviewsCount: 0,
        lastReviewedAt: Date.now(),
        intervalDays: 1,
      };

      const newInterval = status === 'mastered' ? Math.max(existing.intervalDays * 2, 3) : 1;
      const updatedCard: UserWordCard = {
        ...existing,
        status,
        reviewsCount: existing.reviewsCount + 1,
        lastReviewedAt: Date.now(),
        intervalDays: newInterval,
      };

      const updated = {
        ...studied,
        wordCards: {
          ...studied.wordCards,
          [wordId]: updatedCard,
        },
      };

      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...studied.unlockedBadges, ...newBadges];
      }

      return updated;
    });
  };

  const setCurrentLevel = (level: CEFRLevel) => {
    setCurrentLevelState(level);
    setProfile((prev) => ({ ...prev, currentLevel: level }));
  };

  const setPlacementLevel = (level: CEFRLevel) => {
    const order: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
    setProfile((prev) => {
      const prevIdx = prev.placementLevel ? order.indexOf(prev.placementLevel) : 0;
      if (order.indexOf(level) <= prevIdx) return prev;
      return { ...prev, placementLevel: level };
    });
  };

  const markLevelExamPassed = (level: CEFRLevel) => {
    setProfile((prev) => {
      const list = prev.passedLevelExams || [];
      if (list.includes(level)) return prev;
      return { ...prev, passedLevelExams: [...list, level] };
    });
  };

  // Spaced repetition (Leitner boxes): right answer moves the item up a box, a wrong answer sends it back to box 0.
  const recordAnswer = (refId: string, correct: boolean) => {
    const INTERVALS = [0, 1, 3, 7, 14, 30]; // days until next review per box (day 1, 3, 7, 14, 30)
    const fmt = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    setProfile((prev) => {
      const today = new Date();
      const old = (prev.srs || {})[refId] || { box: 0, due: fmt(today), right: 0, wrong: 0, last: fmt(today) };
      const box = correct ? Math.min(5, old.box + 1) : 0;
      const dueDate = new Date(today);
      dueDate.setDate(today.getDate() + INTERVALS[box]);
      const entry = {
        box,
        due: fmt(dueDate),
        right: old.right + (correct ? 1 : 0),
        wrong: old.wrong + (correct ? 0 : 1),
        last: fmt(today),
      };
      return { ...prev, srs: { ...(prev.srs || {}), [refId]: entry } };
    });
  };

  const dayKeyLocal = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  // Per-day study log: questions, estimated seconds and accuracy per skill (feeds the progress dashboard).
  const recordActivity = (skill: Skill, correct: boolean, secs = 15) => {
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const key = dayKeyLocal(new Date());
      const all = { ...(studied.activity || {}) };
      const day: ActivityDay = all[key] ? { ...all[key], skills: { ...all[key].skills } } : { q: 0, secs: 0, rev: 0, skills: {} };
      const sk = day.skills[skill] || { r: 0, w: 0 };
      day.skills[skill] = { r: sk.r + (correct ? 1 : 0), w: sk.w + (correct ? 0 : 1) };
      day.q += 1;
      day.secs += Math.max(3, Math.min(60, Math.round(secs)));
      all[key] = day;
      // keep about 60 days
      const keys = Object.keys(all).sort();
      while (keys.length > 60) delete all[keys.shift() as string];
      const updated = { ...studied, activity: all };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...studied.unlockedBadges, ...newBadges];
      return updated;
    });
  };

  const markReviewDone = (count: number) => {
    if (count <= 0) return;
    setProfile((prev) => {
      const studied = markStudyDay(prev);
      const key = dayKeyLocal(new Date());
      const all = { ...(studied.activity || {}) };
      const day: ActivityDay = all[key] ? { ...all[key] } : { q: 0, secs: 0, rev: 0, skills: {} };
      day.rev = (day.rev || 0) + count;
      all[key] = day;
      const updated = { ...studied, activity: all };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) updated.unlockedBadges = [...studied.unlockedBadges, ...newBadges];
      return updated;
    });
  };

  const setDailyMinutes = (minutes: number) => setProfile((prev) => ({ ...prev, dailyMinutes: Math.min(120, Math.max(5, Math.round(minutes))) }));

  const addAiMistake = (m: Omit<AiMistake, 'id' | 'date'>) => {
    setProfile((prev) => {
      const entry: AiMistake = { ...m, id: `ai_${Date.now()}`, date: dayKeyLocal(new Date()) };
      return { ...prev, aiMistakes: [entry, ...(prev.aiMistakes || [])].slice(0, 100) };
    });
  };

  const [navTarget, setNavTarget] = useState<string | null>(null);
  const goTo = (tab: string, target?: string) => {
    setNavTarget(target || null);
    setActiveTab(tab as any);
  };
  const clearNavTarget = () => setNavTarget(null);

  const markWordSetDone = (setId: string) => {
    setProfile((prev) => {
      const list = prev.completedWordSets || [];
      if (list.includes(setId)) return prev;
      return { ...prev, completedWordSets: [...list, setId] };
    });
  };

  const toggleSound = () => {
    setProfile((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const setSpeechSpeed = (speed: number) => {
    setProfile((prev) => ({ ...prev, speechSpeed: Math.min(1.2, Math.max(0.6, speed)) }));
  };

  const setDailyGoalXp = (goal: number) => {
    setProfile((prev) => ({ ...prev, dailyGoalXp: Math.min(500, Math.max(10, Math.round(goal))) }));
  };

  const updateProfileName = (name: string) => {
    const cleanName = name.replace(/[<>]/g, '').trim().slice(0, 30);
    setProfile((prev) => ({ ...prev, name: cleanName || 'Almanca Kaşifi' }));
  };

  const setThemePreference = (theme: ThemePreference) => {
    setProfile((prev) => ({ ...prev, themePreference: theme }));
  };

  const exportData = (): string => JSON.stringify({
    app: 'Deutsch Meister',
    schemaVersion: 2,
    exportedAt: new Date().toISOString(),
    profile,
  }, null, 2);

  const importData = (jsonData: string): boolean => {
    try {
      if (jsonData.length > 15_000_000) return false;
      const parsed = JSON.parse(jsonData);
      const candidate = isRecord(parsed) && parsed.app === 'Deutsch Meister' ? parsed.profile : parsed;
      const normalized = normalizeProfile(candidate);
      if (!normalized) return false;
      const today = getTodayString();
      const restored = normalized.lastActiveDate === today ? normalized : { ...normalized, todayXp: 0 };
      setProfile(restored);
      setCurrentLevelState(restored.currentLevel || restored.placementLevel || 'A1');
      return true;
    } catch {
      return false;
    }
  };

  const resetProgress = () => {
    const fresh = createDefaultProfile();
    setProfile(fresh);
    setCurrentLevelState('A1');
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* storage may be unavailable */ }
  };

  const openLesson = (lessonId: string) => {
    setActiveLessonId(lessonId);
  };

  const closeLesson = () => {
    setActiveLessonId(null);
  };

  const openGrammar = (grammarId: string) => {
    setActiveGrammarId(grammarId);
  };

  const closeGrammar = () => {
    setActiveGrammarId(null);
  };

  const openDialogue = (dialogueId: string) => {
    setActiveDialogueId(dialogueId);
  };

  const closeDialogue = () => {
    setActiveDialogueId(null);
  };

  const closeCompletionModal = () => {
    setCompletionData(null);
    setActiveLessonId(null);
  };

  const openPlacementTest = () => {
    setIsPlacementTestOpen(true);
  };

  const closePlacementTest = () => {
    setIsPlacementTestOpen(false);
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        currentLevel,
        activeTab,
        activeLessonId,
        activeGrammarId,
        activeDialogueId,
        completionData,
        isPlacementTestOpen,
        setCurrentLevel,
        setPlacementLevel,
        markLevelExamPassed,
        markWordSetDone,
        recordAnswer,
        recordActivity,
        markReviewDone,
        setDailyMinutes,
        addAiMistake,
        navTarget,
        goTo,
        clearNavTarget,
        setActiveTab,
        openLesson,
        closeLesson,
        openGrammar,
        closeGrammar,
        openDialogue,
        closeDialogue,
        openPlacementTest,
        closePlacementTest,
        closeCompletionModal,
        completeLessonSession,
        addXp,
        updateWordStatus,
        toggleSound,
        setSpeechSpeed,
        setDailyGoalXp,
        updateProfileName,
        setThemePreference,
        exportData,
        importData,
        resetProgress,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
