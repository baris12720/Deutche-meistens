import React, { useState } from 'react';
import { TopicTrainer } from '../common/TopicTrainer';
import { LAB_TOPICS } from '../../data/grammarLab';
import { Search, BookOpen, ChevronRight, Layers, Sparkles } from 'lucide-react';
import { GRAMMAR_TOPICS } from '../../data/grammar';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';

const GrammarLessonsView: React.FC = () => {
  const { openGrammar, currentLevel } = useApp();
  const [selectedLevel, setSelectedLevel] = useState<CEFRLevel | 'ALL'>(currentLevel);
  const [search, setSearch] = useState('');

  const filteredTopics = GRAMMAR_TOPICS.filter((t) => {
    if (selectedLevel !== 'ALL' && t.level !== selectedLevel) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        t.titleTr.toLowerCase().includes(q) ||
        t.titleDe.toLowerCase().includes(q) ||
        t.summaryTr.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-linear-to-r from-purple-700 to-indigo-800 text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
            Kapsamlı Dil Bilgisi
          </span>
          <h2 className="text-2xl font-black mt-1">Almanca Gramer Kütüphanesi</h2>
          <p className="text-xs sm:text-sm text-purple-100 mt-0.5">
            Türkçe detaylı açıklamalar, çekim tabloları, sesli örnekler ve mini testler.
          </p>
        </div>
        <div className="bg-white/10 backdrop-blur-xs px-4 py-2.5 rounded-2xl text-center shrink-0">
          <span className="text-xl font-black block">{GRAMMAR_TOPICS.length} Konu</span>
          <span className="text-[10px] uppercase font-bold text-purple-200">A1'den C1'e</span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Gramer konusu ara (örn: artikel, akkusativ, modal fiiller)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Level Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          {(['ALL', 'A1', 'A2', 'B1', 'B2', 'C1'] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setSelectedLevel(lvl)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedLevel === lvl
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {lvl === 'ALL' ? 'Tüm Seviyeler' : lvl}
            </button>
          ))}
        </div>
      </div>

      {/* Topics List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTopics.map((topic) => (
          <div
            key={topic.id}
            onClick={() => openGrammar(topic.id)}
            className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-purple-400 dark:hover:border-purple-600 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                  {topic.level}
                </span>
                <span className="text-[11px] font-semibold text-slate-400">
                  {topic.exercises.length} Alıştırma
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                {topic.titleTr}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5 font-medium">{topic.titleDe}</p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                {topic.summaryTr}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-bold text-purple-600 dark:text-purple-400">
              <span>Konuyu Oku & Çalış</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const GrammarView: React.FC = () => {
  const [mode, setMode] = useState<'topics' | 'lab'>('topics');
  return (
    <div>
      <div className="max-w-xl mx-auto px-4 pt-4">
        <div className="grid grid-cols-2 gap-1 p-1 rounded-2xl bg-slate-200/70 dark:bg-slate-800" role="tablist" aria-label="Dil bilgisi bölümü">
          {([['topics', 'Konu anlatımı'], ['lab', 'Gramer atölyesi']] as const).map(([id, label]) => (
            <button
              key={id}
              role="tab"
              aria-selected={mode === id}
              onClick={() => setMode(id)}
              className={`h-10 rounded-xl text-sm font-black transition cursor-pointer ${
                mode === id ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {mode === 'topics' ? (
        <GrammarLessonsView />
      ) : (
        <TopicTrainer
          topics={LAB_TOPICS}
          idPrefix="gram"
          heading="Gramer atölyesi"
          intro="Kuralı öğren, sonra alıştırmayla pekiştir: fiil çekimi, çoğul, artikel ve haller, edatlar, Perfekt ve cümle sırası."
        />
      )}
    </div>
  );
};
