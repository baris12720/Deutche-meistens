import React from 'react';
import { ChevronLeft, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { QUEST_WORDS } from '../../data/vocab/words';
import { CONNECTOR_GROUPS } from '../../data/connectors';
import { speakGerman } from '../../utils/audio';
import { useBackHandler } from '../../utils/backStack';

interface Row {
  key: string;
  title: string;
  meaning: string;
  example: string;
  exampleTr: string;
  speak: string;
  wrong: number;
  box: number;
}

/** Notebook of everything the learner got wrong: word, meaning and a sentence to read and listen to. */
export const MistakeNotebook: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { profile } = useApp();
  useBackHandler(true, onClose);

  const rows: Row[] = [];
  Object.entries(profile.srs || {}).forEach(([refId, e]) => {
    if (e.wrong <= 0) return;
    if (refId.startsWith('vq_')) {
      const w = QUEST_WORDS.find((x) => x.id === refId);
      if (!w) return;
      rows.push({
        key: refId,
        title: w.article !== 'none' ? `${w.article} ${w.german}` : w.german,
        meaning: w.turkish,
        example: w.exampleGerman,
        exampleTr: w.exampleTurkish,
        speak: `${w.article !== 'none' ? w.article + ' ' : ''}${w.german}. ${w.exampleGerman}`,
        wrong: e.wrong,
        box: e.box,
      });
    } else if (refId.startsWith('conn:')) {
      const [, groupId, idx] = refId.split(':');
      const g = CONNECTOR_GROUPS.find((x) => x.id === groupId);
      const it = g && idx !== 'rules' ? g.items[Number(idx)] : null;
      if (g && it) {
        const sentence = it.template.replace(/[{}]/g, '');
        rows.push({ key: refId, title: it.word, meaning: it.meaningTr, example: sentence, exampleTr: it.exampleTr, speak: sentence, wrong: e.wrong, box: e.box });
      } else if (g) {
        rows.push({ key: refId, title: `Bağlaç kuralı: ${g.titleTr}`, meaning: g.formulaDe, example: g.ruleTr, exampleTr: '', speak: '', wrong: e.wrong, box: e.box });
      }
    }
  });
  rows.sort((a, b) => a.box - b.box || b.wrong - a.wrong);
  const shown = rows.slice(0, 60);

  return (
    <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
      <div className="flex items-center gap-3 px-4 h-14 shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <button onClick={onClose} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-lg font-black text-slate-900 dark:text-white">Hata defteri</h2>
        <span className="ml-auto text-xs font-bold text-slate-400">{rows.length} öğe</span>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-10">
        <div className="max-w-xl mx-auto space-y-3">
          {shown.length === 0 && (
            <div className="text-center text-sm text-slate-500 dark:text-slate-400 py-16">
              Henüz yanlış yaptığın bir kelime veya bağlaç yok. Bir set çözdükçe yanlışların burada toplanır.
            </div>
          )}
          {shown.map((r) => (
            <div key={r.key} className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-lg font-black text-slate-900 dark:text-white">{r.title}</div>
                  <div className="text-sm text-slate-600 dark:text-slate-300">{r.meaning}</div>
                </div>
                <div className="shrink-0 text-right">
                  <div className="text-[11px] font-black text-rose-500">{r.wrong} yanlış</div>
                  <div className="mt-1 flex gap-0.5 justify-end" aria-label={`Hafıza gücü ${r.box}/5`}>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <span key={n} className={`w-2 h-2 rounded-full ${n <= r.box ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'}`} />
                    ))}
                  </div>
                </div>
              </div>
              {r.example && (
                <div className="mt-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 p-3 text-sm">
                  <div className="font-bold text-slate-800 dark:text-slate-100">{r.example}</div>
                  {r.exampleTr && <div className="text-xs text-slate-500 dark:text-slate-400">{r.exampleTr}</div>}
                  {r.speak && (
                    <button
                      onClick={() => speakGerman(r.speak, profile.speechSpeed)}
                      className="mt-2 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" /> Dinle
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
