import React, { useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { Exercise } from '../../types';
import { getDueItems, getWeakItems } from '../../utils/srs';
import { buildReviewExerciseForWord } from '../../data/vocab/builder';
import { buildReviewExerciseForConnector } from '../../data/connectors';
import { buildReviewExerciseForGrammar } from '../../data/grammarLab';
import { useBackHandler } from '../../utils/backStack';

const MAX_ITEMS = 12;

export const ReviewSession: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { profile, addXp } = useApp();
  const awarded = useRef(false);
  useBackHandler(true, onClose);

  // Built once when the session opens: due items first, then weak ones to fill the session.
  const exercises = useMemo<Exercise[]>(() => {
    const picked = [...getDueItems(profile), ...getWeakItems(profile)].slice(0, MAX_ITEMS);
    const out: Exercise[] = [];
    picked.forEach((it, i) => {
      const ex = it.refId.startsWith('conn:')
        ? buildReviewExerciseForConnector(it.refId, it.entry.box, i + 1)
        : it.refId.startsWith('gram:')
        ? buildReviewExerciseForGrammar(it.refId, i + 1)
        : buildReviewExerciseForWord(it.refId, it.entry.box, i + 1);
      if (ex) out.push(ex);
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (exercises.length === 0) {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col items-center justify-center gap-4 p-6 text-center">
        <div className="text-5xl">🎉</div>
        <h2 className="text-xl font-black text-slate-900 dark:text-white">Bugün tekrar edilecek bir şey yok</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm">
          Yeni kelime setleri ve bağlaç konuları çözdükçe, unutmak üzere olduğun öğeler burada karşına çıkacak.
        </p>
        <button
          onClick={onClose}
          className="px-6 py-3 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer"
        >
          Tamam
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
      <ExerciseRunner
        exercises={exercises}
        allowLengthSelect={false}
        title="Akıllı Tekrar"
        completeLabel="Bitir"
        onExit={onClose}
        onFinish={(correct) => {
          if (awarded.current) return;
          awarded.current = true;
          addXp(5 + correct * 2);
        }}
        onComplete={onClose}
      />
    </div>
  );
};
