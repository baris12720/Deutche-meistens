import React, { useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Lock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { Exercise, CEFRLevel } from '../../types';
import { useBackHandler } from '../../utils/backStack';

export interface TrainerCard {
  title: string;
  bodyTr: string;
  formulaDe?: string;
  tipTr?: string;
  rows?: [string, string][];
}

export interface TrainerTopic {
  id: string;
  level: CEFRLevel;
  emoji: string;
  titleTr: string;
  cards: TrainerCard[];
  build: () => Exercise[];
}

interface Props {
  topics: TrainerTopic[];
  idPrefix: string; // progress ids look like `${idPrefix}_${topic.id}` in completedWordSets
  heading: string;
  intro: string;
}

/** Generic learn-then-practice trainer: explanation cards first, then mixed exercises; topics unlock one after another. */
export const TopicTrainer: React.FC<Props> = ({ topics, idPrefix, heading, intro }) => {
  const { profile, addXp, markWordSetDone } = useApp();
  const [active, setActive] = useState<TrainerTopic | null>(null);
  const [phase, setPhase] = useState<'learn' | 'quiz'>('learn');
  const [step, setStep] = useState(0);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const awardedRef = useRef<string | null>(null);
  const done = profile.completedWordSets || [];
  const doneId = (t: TrainerTopic) => `${idPrefix}_${t.id}`;

  const close = () => setActive(null);
  useBackHandler(active !== null, close);

  const notify = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 7000);
  };

  const open = (t: TrainerTopic, index: number) => {
    const available = index === 0 || done.includes(doneId(topics[index - 1])) || done.includes(doneId(t));
    if (!available) {
      notify('Önce bir önceki konuyu tamamla.');
      return;
    }
    awardedRef.current = null;
    setActive(t);
    setPhase('learn');
    setStep(0);
    setExercises(t.build());
  };

  const handleFinish = (correct: number, total: number) => {
    if (!active || awardedRef.current === active.id) return;
    if (correct / Math.max(1, total) >= 0.5) {
      awardedRef.current = active.id;
      addXp(12 + correct * 2);
      markWordSetDone(doneId(active));
      try {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.65 } });
      } catch {
        /* ignore */
      }
      notify(`Konu tamam: ${correct}/${total}. +${12 + correct * 2} XP. Sıradaki konu açıldı.`);
    }
  };

  if (active && phase === 'quiz') {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
        <ExerciseRunner
          exercises={exercises}
          allowLengthSelect={false}
          passRatio={0.5}
          completeLabel="Konuyu Tamamla"
          title={`${heading}: ${active.titleTr}`}
          onExit={close}
          onFinish={handleFinish}
          onComplete={(correct, total) => {
            if (awardedRef.current !== active.id) {
              notify(`${correct}/${total}: konuyu geçmek için %50 gerekli. Yanlışları tekrar çözüp yeniden dene.`);
            }
            close();
          }}
        />
      </div>
    );
  }

  if (active && phase === 'learn') {
    const card = active.cards[step];
    const last = step === active.cards.length - 1;
    return (
      <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
        <div className="flex items-center gap-3 px-4 h-14 shrink-0">
          <button onClick={close} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="flex-1 h-3 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
            <div className="h-full bg-sky-500 rounded-full transition-all" style={{ width: `${((step + 1) / active.cards.length) * 100}%` }} />
          </div>
          <span className="text-xs font-black text-slate-500 tabular-nums">
            {step + 1}/{active.cards.length}
          </span>
        </div>

        <div key={step} className="page-enter flex-1 overflow-y-auto px-4 pb-4">
          <div className="max-w-md mx-auto mt-4 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 space-y-4">
            <div className="text-4xl text-center">{active.emoji}</div>
            <h3 className="text-xl font-black text-center text-slate-900 dark:text-white">{card.title}</h3>
            <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-200">{card.bodyTr}</p>
            {card.formulaDe && (
              <div className="rounded-2xl bg-sky-50 dark:bg-sky-950/40 border-2 border-sky-200 dark:border-sky-900 p-3 text-center text-sm font-black text-sky-900 dark:text-sky-100">
                {card.formulaDe}
              </div>
            )}
            {card.rows && (
              <div className="rounded-2xl border-2 border-slate-200 dark:border-slate-700 divide-y divide-slate-200 dark:divide-slate-700 overflow-hidden">
                {card.rows.map(([left, right]) => (
                  <div key={left} className="flex gap-3 px-3 py-2 text-sm">
                    <span className="w-32 shrink-0 font-black text-slate-900 dark:text-white">{left}</span>
                    <span className="text-slate-600 dark:text-slate-300">{right}</span>
                  </div>
                ))}
              </div>
            )}
            {card.tipTr && <p className="text-xs font-bold text-amber-700 dark:text-amber-300">💡 {card.tipTr}</p>}
          </div>
        </div>

        <div className="p-4 pb-[max(1rem,env(safe-area-inset-bottom))] shrink-0 flex gap-3 max-w-md w-full mx-auto">
          <button
            disabled={step === 0}
            onClick={() => setStep((i) => i - 1)}
            className="h-14 w-14 rounded-2xl border-2 border-slate-200 dark:border-slate-700 text-slate-500 disabled:opacity-40 inline-flex items-center justify-center cursor-pointer"
            aria-label="Önceki"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => (last ? setPhase('quiz') : setStep((i) => i + 1))}
            className="flex-1 h-14 rounded-2xl bg-sky-500 text-white font-black text-base shadow-[0_5px_0_#0369a1] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            {last ? 'ALIŞTIRMAYA BAŞLA' : 'DEVAM'} <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      <h2 className="text-xl font-black text-slate-900 dark:text-white">{heading}</h2>
      <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{intro}</p>
      <div className="mt-5 space-y-3">
        {topics.map((t, i) => {
          const isDone = done.includes(doneId(t));
          const available = i === 0 || done.includes(doneId(topics[i - 1])) || isDone;
          return (
            <button
              key={t.id}
              onClick={() => open(t, i)}
              className={`w-full text-left rounded-2xl border-2 p-4 flex items-center gap-4 transition active:translate-y-0.5 cursor-pointer ${
                isDone
                  ? 'border-amber-300 dark:border-amber-800 bg-amber-50/60 dark:bg-amber-950/20'
                  : available
                  ? 'border-sky-400 bg-white dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 opacity-70'
              }`}
            >
              <div
                className={`w-14 h-14 rounded-full shrink-0 inline-flex items-center justify-center text-white text-2xl ${
                  isDone ? 'bg-amber-400 shadow-[0_5px_0_#d97706]' : available ? 'bg-sky-500 shadow-[0_5px_0_#0369a1]' : 'bg-slate-300 dark:bg-slate-700 shadow-[0_5px_0_#94a3b8] dark:shadow-[0_5px_0_#334155]'
                }`}
              >
                {isDone ? <Check className="w-7 h-7 stroke-4" /> : available ? t.emoji : <Lock className="w-6 h-6" />}
              </div>
              <div className="min-w-0">
                <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-[10px] font-black text-slate-600 dark:text-slate-300">{t.level}</span>
                <div className="mt-0.5 text-base font-black text-slate-900 dark:text-white">{t.titleTr}</div>
              </div>
            </button>
          );
        })}
      </div>
      {toast && (
        <div role="status" className="fixed left-1/2 -translate-x-1/2 bottom-28 z-40 max-w-[90vw] px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold shadow-xl">
          {toast}
        </div>
      )}
    </div>
  );
};
