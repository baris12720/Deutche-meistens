import { CEFRLevel, Exercise } from '../types';

export interface LabCard {
  title: string;
  bodyTr: string;
  formulaDe?: string;
  tipTr?: string;
  rows?: [string, string][]; // table lines: left bold, right normal
}

export interface LabTopic {
  id: string;
  level: CEFRLevel;
  emoji: string;
  titleTr: string;
  cards: LabCard[];
  build: () => Exercise[];
}

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

type Fill = [sentence: string, answer: string, tr: string, why: string, pool?: string[]];

const fillExercises = (topic: string, level: CEFRLevel, tag: string, items: Fill[], defaultPool: string[]): Exercise[] =>
  items.map(([sentence, answer, tr, why, pool], i) => {
    const p = pool || defaultPool;
    const atStart = sentence.trim().startsWith('___');
    const fix = (x: string) => (atStart ? x.charAt(0).toUpperCase() + x.slice(1) : x);
    const wrong = shuffle(p.filter((x) => x !== answer)).slice(0, 3);
    return {
      id: `gram_${topic}_fill${i}`,
      refId: `gram:${topic}:fill${i}`,
      level,
      topicTag: tag,
      type: 'fill_blank',
      instructionTr: 'Boşluğa doğru kelimeyi seçin:',
      sentenceWithBlank: sentence,
      turkishTranslation: tr,
      options: shuffle([fix(answer), ...wrong.map(fix)]),
      correctAnswer: fix(answer),
      explanationTr: why,
    } as Exercise;
  });

/* ---------- Artikel und Kasus ---------- */
const ART_POOL = ['der', 'die', 'das', 'den', 'dem'];
const ARTIKEL: Fill[] = [
  ['Ich sehe ___ Mann.', 'den', 'Adamı görüyorum.', 'sehen + Akkusativ: der Mann → den Mann.'],
  ['Der Mann gibt ___ Frau das Buch.', 'der', 'Adam kadına kitabı veriyor.', 'geben + Dativ: die Frau → der Frau.'],
  ['Ich kaufe ___ Buch.', 'das', 'Kitabı alıyorum.', 'Akkusativ: das Buch → das Buch (nötr değişmez).'],
  ['Ich helfe ___ Kind.', 'dem', 'Çocuğa yardım ediyorum.', 'helfen + Dativ: das Kind → dem Kind.'],
  ['Wir besuchen ___ Oma.', 'die', 'Büyükannemizi ziyaret ediyoruz.', 'besuchen + Akkusativ: die Oma → die Oma (dişil değişmez).'],
  ['Ich schenke ___ Freund ein Buch.', 'dem', 'Arkadaşıma kitap hediye ediyorum.', 'schenken + Dativ: der Freund → dem Freund.'],
  ['___ Hund ist groß.', 'der', 'Köpek büyük.', 'Özne Nominativ\'dedir: der Hund.'],
  ['Ich lese ___ Zeitung.', 'die', 'Gazeteyi okuyorum.', 'Akkusativ: die Zeitung → die Zeitung.'],
  ['Er gibt ___ Kindern Geld.', 'den', 'Çocuklara para veriyor.', 'Dativ çoğul: den Kindern (isme -n eklenir).'],
  ['Ich brauche ___ Computer.', 'den', 'Bilgisayara ihtiyacım var.', 'brauchen + Akkusativ: der Computer → den Computer.'],
  ['Sie dankt ___ Lehrerin.', 'der', 'Öğretmene teşekkür ediyor.', 'danken + Dativ: die Lehrerin → der Lehrerin.'],
  ['Das ist ___ Tisch.', 'der', 'Bu masa.', 'sein + Nominativ: der Tisch.'],
  ['Ich sehe ___ Kinder.', 'die', 'Çocukları görüyorum.', 'Akkusativ çoğul: die Kinder.'],
  ['Wir wohnen mit ___ Eltern.', 'den', 'Ailemizle birlikte yaşıyoruz.', 'mit + Dativ çoğul: den Eltern.'],
  ['Ich esse ___ Apfel.', 'den', 'Bir elmayı yiyorum.', 'essen + Akkusativ: der Apfel → den Apfel.'],
  ['Er liebt ___ Frau.', 'die', 'O karısını seviyor.', 'lieben + Akkusativ: die Frau → die Frau.'],
  ['Ich gebe ___ Mann das Geld.', 'dem', 'Adama parayı veriyorum.', 'geben + Dativ: der Mann → dem Mann.'],
  ['Das Auto gehört ___ Frau.', 'der', 'Araba kadına ait.', 'gehören + Dativ: die Frau → der Frau.'],
  ['___ Kind spielt im Garten.', 'das', 'Çocuk bahçede oynuyor.', 'Özne Nominativ: das Kind.'],
  ['Ich öffne ___ Fenster.', 'das', 'Pencereyi açıyorum.', 'öffnen + Akkusativ: das Fenster.'],
  ['Wir kaufen ___ Hund.', 'den', 'Bir köpek alıyoruz.', 'kaufen + Akkusativ: der Hund → den Hund.'],
  ['Das Kleid gefällt ___ Mädchen.', 'dem', 'Elbise kızın hoşuna gidiyor.', 'gefallen + Dativ: das Mädchen → dem Mädchen.'],
  ['___ Lehrerin erklärt die Aufgabe.', 'die', 'Öğretmen görevi açıklıyor.', 'Özne Nominativ: die Lehrerin.'],
  ['Ich suche ___ Schlüssel.', 'den', 'Anahtarı arıyorum.', 'suchen + Akkusativ: der Schlüssel → den Schlüssel.'],
];

/* ---------- Präpositionen ---------- */
const PREP: Fill[] = [
  ['Ich fahre mit ___ Bus.', 'dem', 'Otobüsle gidiyorum.', 'mit + Dativ: der Bus → dem Bus.'],
  ['Das Geschenk ist für ___ Mutter.', 'die', 'Hediye anne için.', 'für + Akkusativ: die Mutter → die Mutter.'],
  ['Ich wohne bei ___ Eltern.', 'den', 'Ailemin yanında yaşıyorum.', 'bei + Dativ çoğul: den Eltern.'],
  ['Wir gehen in ___ Kino. (wohin?)', 'das', 'Sinemaya gidiyoruz.', 'Wohin? sorusu: Akkusativ → das Kino.'],
  ['Wir sind in ___ Kino. (wo?)', 'dem', 'Sinemadayız.', 'Wo? sorusu: Dativ → dem Kino.'],
  ['Nach ___ Arbeit gehe ich heim.', 'der', 'İşten sonra eve giderim.', 'nach + Dativ: die Arbeit → der Arbeit.'],
  ['Ich komme aus ___ Türkei.', 'der', 'Türkiye\'denim.', 'aus + Dativ: die Türkei → der Türkei.'],
  ['Das Buch liegt auf ___ Tisch. (wo?)', 'dem', 'Kitap masanın üstünde.', 'Wo? sorusu: Dativ → dem Tisch.'],
  ['Ich lege das Buch auf ___ Tisch. (wohin?)', 'den', 'Kitabı masanın üstüne koyuyorum.', 'Wohin? sorusu: Akkusativ → den Tisch.'],
  ['Sie geht zu ___ Arzt.', 'dem', 'O doktora gidiyor.', 'zu + Dativ: der Arzt → dem Arzt.'],
  ['Ich laufe durch ___ Park.', 'den', 'Parkın içinden yürüyorum.', 'durch + Akkusativ: der Park → den Park.'],
  ['Wir warten auf ___ Bus.', 'den', 'Otobüsü bekliyoruz.', 'warten auf + Akkusativ.'],
  ['Das Bild hängt an ___ Wand. (wo?)', 'der', 'Resim duvarda asılı.', 'Wo? sorusu: Dativ → die Wand → der Wand.'],
  ['Er spricht über ___ Film.', 'den', 'Film hakkında konuşuyor.', 'sprechen über + Akkusativ.'],
  ['Wir fahren ohne ___ Auto.', 'das', 'Arabasız gidiyoruz.', 'ohne + Akkusativ: das Auto.'],
  ['Er kommt von ___ Arbeit.', 'der', 'O işten geliyor.', 'von + Dativ: die Arbeit → der Arbeit.'],
  ['Wir fahren um ___ Stadt herum.', 'die', 'Şehrin etrafında dolaşıyoruz.', 'um + Akkusativ: die Stadt.'],
  ['Das Auto steht vor ___ Haus. (wo?)', 'dem', 'Araba evin önünde duruyor.', 'Wo? sorusu: Dativ → dem Haus.'],
  ['Ich stelle das Auto vor ___ Haus. (wohin?)', 'das', 'Arabayı evin önüne park ediyorum.', 'Wohin? sorusu: Akkusativ → das Haus.'],
  ['Sie sitzt neben ___ Freund.', 'dem', 'O arkadaşının yanında oturuyor.', 'neben (Wo?) + Dativ: dem Freund.'],
  ['Ich bin seit ___ Woche hier.', 'einer', 'Bir haftadır buradayım.', 'seit + Dativ: eine Woche → einer Woche.', ['einer', 'eine', 'einem', 'einen']],
];

/* ---------- Negation ---------- */
const NEG: Fill[] = [
  ['Ich habe ___ Zeit.', 'keine', 'Vaktim yok.', 'Zeit (die) isimdir → kein-: keine Zeit.'],
  ['Das ist ___ mein Buch.', 'nicht', 'Bu benim kitabım değil.', 'Sahiplik zamiri olan isim "nicht" ile olumsuzlanır.'],
  ['Ich trinke ___ Kaffee.', 'keinen', 'Kahve içmiyorum.', 'Kaffee (der) Akkusativ: keinen Kaffee.'],
  ['Er kommt ___ heute.', 'nicht', 'O bugün gelmiyor.', 'Fiil veya zaman olumsuzu "nicht" ile yapılır.'],
  ['Sie hat ___ Auto.', 'kein', 'Onun arabası yok.', 'Auto (das): kein Auto.'],
  ['Wir haben ___ Kinder.', 'keine', 'Çocuğumuz yok.', 'Çoğul: keine Kinder.'],
  ['Das ist ___ Apfel, das ist eine Birne.', 'kein', 'Bu elma değil, armut.', 'Apfel (der) Nominativ: kein Apfel.'],
  ['Er arbeitet ___ gern.', 'nicht', 'O çalışmayı sevmiyor.', '"gern" olumsuzu: nicht gern.'],
  ['Ich esse ___ Fleisch.', 'kein', 'Et yemiyorum.', 'Fleisch (das): kein Fleisch.'],
  ['Ich verstehe das ___.', 'nicht', 'Bunu anlamıyorum.', 'Fiil olumsuzu cümle sonunda: nicht.'],
  ['Ich habe ___ Hunger.', 'keinen', 'Aç değilim.', 'Hunger (der) Akkusativ: keinen Hunger.'],
];

/* ---------- Plural ---------- */
const PLURALS: [string, string, string, string][] = [
  ['der', 'Tisch', 'Tische', 'masa'], ['das', 'Buch', 'Bücher', 'kitap'], ['die', 'Frau', 'Frauen', 'kadın'],
  ['das', 'Kind', 'Kinder', 'çocuk'], ['der', 'Mann', 'Männer', 'adam'], ['die', 'Katze', 'Katzen', 'kedi'],
  ['der', 'Hund', 'Hunde', 'köpek'], ['das', 'Auto', 'Autos', 'araba'], ['der', 'Apfel', 'Äpfel', 'elma'],
  ['die', 'Stadt', 'Städte', 'şehir'], ['das', 'Haus', 'Häuser', 'ev'], ['der', 'Bruder', 'Brüder', 'erkek kardeş'],
  ['die', 'Schwester', 'Schwestern', 'kız kardeş'], ['das', 'Zimmer', 'Zimmer', 'oda'], ['der', 'Lehrer', 'Lehrer', 'öğretmen'],
  ['die', 'Tasche', 'Taschen', 'çanta'], ['das', 'Handy', 'Handys', 'cep telefonu'], ['der', 'Student', 'Studenten', 'öğrenci'],
  ['die', 'Uhr', 'Uhren', 'saat'], ['der', 'Stuhl', 'Stühle', 'sandalye'], ['die', 'Hand', 'Hände', 'el'],
  ['der', 'Vater', 'Väter', 'baba'], ['die', 'Mutter', 'Mütter', 'anne'], ['das', 'Fenster', 'Fenster', 'pencere'],
  ['die', 'Straße', 'Straßen', 'sokak'], ['der', 'Freund', 'Freunde', 'arkadaş'], ['das', 'Bild', 'Bilder', 'resim'],
  ['der', 'Garten', 'Gärten', 'bahçe'], ['die', 'Zeitung', 'Zeitungen', 'gazete'], ['das', 'Hotel', 'Hotels', 'otel'],
];

const buildPlural = (): Exercise[] => {
  const out: Exercise[] = [];
  PLURALS.forEach(([art, sg, pl, tr], i) => {
    const guesses = Array.from(
      new Set([sg + 'e', sg + 'n', sg + 'en', sg + 's', sg + 'er', sg.replace(/[aou]/, (m) => ({ a: 'ä', o: 'ö', u: 'ü' } as any)[m]) + 'e', sg])
    ).filter((g) => g !== pl);
    out.push({
      id: `gram_plural_mc${i}`,
      refId: `gram:plural:${i}`,
      level: 'A1',
      topicTag: 'Gramer: Plural',
      type: 'multiple_choice',
      instructionTr: 'Çoğul hali hangisi?',
      prompt: `${art} ${sg} (${tr})`,
      options: shuffle([pl, ...shuffle(guesses).slice(0, 3)]),
      correctAnswer: pl,
      explanationTr: `${art} ${sg} → die ${pl}. Çoğulda artikel her zaman "die" olur.`,
    } as Exercise);
    if (i % 2 === 0) {
      out.push({
        id: `gram_plural_type${i}`,
        refId: `gram:plural:${i}`,
        level: 'A1',
        topicTag: 'Gramer: Plural',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Çoğul halini yazın:',
        promptTr: `${art} ${sg} (${tr})`,
        hintTr: 'die ...',
        answer: pl,
        accept: [`die ${pl}`],
        explanationTr: `${art} ${sg} → die ${pl}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Perfekt ---------- */
const VERBS: [inf: string, aux: 'hat' | 'ist', pp: string, tr: string][] = [
  ['machen', 'hat', 'gemacht', 'yapmak'], ['spielen', 'hat', 'gespielt', 'oynamak'], ['lernen', 'hat', 'gelernt', 'öğrenmek'],
  ['kaufen', 'hat', 'gekauft', 'satın almak'], ['arbeiten', 'hat', 'gearbeitet', 'çalışmak'], ['wohnen', 'hat', 'gewohnt', 'oturmak'],
  ['sagen', 'hat', 'gesagt', 'söylemek'], ['essen', 'hat', 'gegessen', 'yemek yemek'], ['trinken', 'hat', 'getrunken', 'içmek'],
  ['sehen', 'hat', 'gesehen', 'görmek'], ['lesen', 'hat', 'gelesen', 'okumak'], ['schreiben', 'hat', 'geschrieben', 'yazmak'],
  ['sprechen', 'hat', 'gesprochen', 'konuşmak'], ['nehmen', 'hat', 'genommen', 'almak'], ['geben', 'hat', 'gegeben', 'vermek'],
  ['finden', 'hat', 'gefunden', 'bulmak'], ['helfen', 'hat', 'geholfen', 'yardım etmek'], ['schlafen', 'hat', 'geschlafen', 'uyumak'],
  ['gehen', 'ist', 'gegangen', 'gitmek'], ['kommen', 'ist', 'gekommen', 'gelmek'], ['fahren', 'ist', 'gefahren', 'gitmek (araçla)'],
  ['fliegen', 'ist', 'geflogen', 'uçmak'], ['laufen', 'ist', 'gelaufen', 'koşmak, yürümek'], ['bleiben', 'ist', 'geblieben', 'kalmak'],
  ['sein', 'ist', 'gewesen', 'olmak'], ['werden', 'ist', 'geworden', 'olmak (-leşmek)'], ['aufstehen', 'ist', 'aufgestanden', 'kalkmak'],
  ['ankommen', 'ist', 'angekommen', 'varmak'], ['einkaufen', 'hat', 'eingekauft', 'alışveriş yapmak'], ['anrufen', 'hat', 'angerufen', 'aramak'],
  ['besuchen', 'hat', 'besucht', 'ziyaret etmek'], ['bezahlen', 'hat', 'bezahlt', 'ödemek'], ['verstehen', 'hat', 'verstanden', 'anlamak'],
  ['vergessen', 'hat', 'vergessen', 'unutmak'], ['bekommen', 'hat', 'bekommen', 'almak, elde etmek'], ['studieren', 'hat', 'studiert', 'üniversitede okumak'],
  ['passieren', 'ist', 'passiert', 'olmak (olay)'], ['aussteigen', 'ist', 'ausgestiegen', 'inmek'], ['mitbringen', 'hat', 'mitgebracht', 'yanında getirmek'],
  ['denken', 'hat', 'gedacht', 'düşünmek'], ['bringen', 'hat', 'gebracht', 'getirmek'],
];

const buildPerfekt = (): Exercise[] => {
  const out: Exercise[] = [];
  VERBS.forEach(([inf, aux, pp, tr], i) => {
    const ref = `gram:perfekt:${i}`;
    out.push({
      id: `gram_perfekt_aux${i}`,
      refId: ref,
      level: 'A2',
      topicTag: 'Gramer: Perfekt',
      type: 'multiple_choice',
      instructionTr: 'Perfekt kurarken hangi yardımcı fiil gerekir?',
      prompt: `${inf} (${tr})`,
      options: shuffle(['hat', 'ist']),
      correctAnswer: aux,
      explanationTr: `${inf} → er ${aux} ${pp}. ${aux === 'ist' ? 'Hareket veya durum değişikliği bildiren fiillerde "sein" kullanılır.' : 'Çoğu fiil "haben" ile kurulur.'}`,
    } as Exercise);
    const stem = inf.endsWith('en') ? inf.slice(0, -2) : inf;
    const wrong = Array.from(new Set([`ge${stem}t`, `ge${inf}`, `${stem}t`, `ge${stem}en`])).filter((g) => g !== pp);
    out.push({
      id: `gram_perfekt_pp${i}`,
      refId: ref,
      level: 'A2',
      topicTag: 'Gramer: Perfekt',
      type: 'multiple_choice',
      instructionTr: 'Partizip II hangisi?',
      prompt: `${inf} (${tr})`,
      options: shuffle([pp, ...shuffle(wrong).slice(0, 3)]),
      correctAnswer: pp,
      explanationTr: `${inf} → ${aux} ${pp}`,
    } as Exercise);
    if (i % 2 === 1) {
      out.push({
        id: `gram_perfekt_type${i}`,
        refId: ref,
        level: 'A2',
        topicTag: 'Gramer: Perfekt',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Partizip II yazın:',
        promptTr: `${inf} (${tr})`,
        hintTr: `Yardımcı fiil: ${aux}`,
        answer: pp,
        accept: [`${aux} ${pp}`, `er ${aux} ${pp}`],
        explanationTr: `${inf} → er ${aux} ${pp}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Konjugation ---------- */
const PERSONS = ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'];
const CONJ: [inf: string, tr: string, forms: string[]][] = [
  ['sein', 'olmak', ['bin', 'bist', 'ist', 'sind', 'seid', 'sind']],
  ['haben', 'sahip olmak', ['habe', 'hast', 'hat', 'haben', 'habt', 'haben']],
  ['werden', 'olmak (-leşmek)', ['werde', 'wirst', 'wird', 'werden', 'werdet', 'werden']],
  ['können', '-ebilmek', ['kann', 'kannst', 'kann', 'können', 'könnt', 'können']],
  ['müssen', '-meli', ['muss', 'musst', 'muss', 'müssen', 'müsst', 'müssen']],
  ['wollen', 'istemek', ['will', 'willst', 'will', 'wollen', 'wollt', 'wollen']],
  ['gehen', 'gitmek', ['gehe', 'gehst', 'geht', 'gehen', 'geht', 'gehen']],
  ['fahren', 'gitmek (araçla)', ['fahre', 'fährst', 'fährt', 'fahren', 'fahrt', 'fahren']],
  ['essen', 'yemek yemek', ['esse', 'isst', 'isst', 'essen', 'esst', 'essen']],
  ['sprechen', 'konuşmak', ['spreche', 'sprichst', 'spricht', 'sprechen', 'sprecht', 'sprechen']],
  ['lesen', 'okumak', ['lese', 'liest', 'liest', 'lesen', 'lest', 'lesen']],
  ['schlafen', 'uyumak', ['schlafe', 'schläfst', 'schläft', 'schlafen', 'schlaft', 'schlafen']],
];

const buildConj = (): Exercise[] => {
  const out: Exercise[] = [];
  CONJ.forEach(([inf, tr, forms], vi) => {
    [0, 1, 2, 3].forEach((pi) => {
      const correct = forms[pi];
      const wrong = Array.from(new Set(forms.filter((f) => f !== correct)));
      out.push({
        id: `gram_conj_${vi}_${pi}`,
        refId: `gram:konj:${vi}`,
        level: 'A1',
        topicTag: 'Gramer: Fiil çekimi',
        type: 'verb_conjugation',
        instructionTr: 'Fiili özneye göre çekin:',
        verbInfinitive: inf,
        pronoun: PERSONS[pi],
        turkishTranslation: tr,
        options: shuffle([correct, ...shuffle(wrong).slice(0, 3)]),
        correctAnswer: correct,
        explanationTr: `${PERSONS[pi]} ${correct} (${inf}: ${forms.join(', ')})`,
      } as Exercise);
    });
    // write the irregular du / er form
    if (forms[1] !== forms[0].replace(/e$/, '') + 'st' || ['sein', 'haben', 'werden'].includes(inf)) {
      out.push({
        id: `gram_conj_type${vi}`,
        refId: `gram:konj:${vi}`,
        level: 'A1',
        topicTag: 'Gramer: Fiil çekimi',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Doğru fiil çekimini yazın:',
        promptTr: `du ... (${inf}, ${tr})`,
        hintTr: `${forms[1].length} harf`,
        answer: forms[1],
        explanationTr: `du ${forms[1]}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Satzstellung ---------- */
const ORDER: [sentence: string, tr: string, rule: string][] = [
  ['Ich lerne jeden Tag Deutsch.', 'Her gün Almanca öğreniyorum.', 'Ana cümle: fiil ikinci sırada.'],
  ['Heute gehe ich ins Kino.', 'Bugün sinemaya gidiyorum.', 'Başa zaman gelirse fiil yine ikinci sırada, özne arkasından gelir (Inversion).'],
  ['Morgen fahren wir nach Berlin.', 'Yarın Berlin\'e gidiyoruz.', 'Zaman ifadesi başta: fiil + özne.'],
  ['Ich kann gut schwimmen.', 'İyi yüzebiliyorum.', 'Modal fiil ikinci sırada, ana fiil (mastar) sonda.'],
  ['Er möchte einen Kaffee trinken.', 'O bir kahve içmek istiyor.', 'Modal fiil + ... + mastar.'],
  ['Ich habe gestern Fußball gespielt.', 'Dün futbol oynadım.', 'Perfekt: haben ikinci sırada, Partizip II sonda (Klammer).'],
  ['Wir sind nach Hause gegangen.', 'Eve gittik.', 'Perfekt: sein ikinci sırada, Partizip II sonda.'],
  ['Ich stehe um sieben Uhr auf.', 'Saat yedide kalkıyorum.', 'Ayrılabilen fiil: ön ek (auf) cümle sonuna gider.'],
  ['Er ruft seine Mutter an.', 'O annesini arıyor.', 'Ayrılabilen fiil: ön ek (an) sona gider.'],
  ['Ich weiß, dass er krank ist.', 'Onun hasta olduğunu biliyorum.', '"dass" yan cümlesinde fiil sona gider.'],
  ['Wenn es regnet, bleiben wir zu Hause.', 'Yağmur yağarsa evde kalırız.', 'Yan cümle başta ise ana cümlede fiil hemen gelir.'],
  ['Am Wochenende besuche ich meine Eltern.', 'Hafta sonu ailemi ziyaret ediyorum.', 'Zaman başta, ardından fiil, ardından özne.'],
  ['Kannst du mir bitte helfen?', 'Bana yardım edebilir misin?', 'Evet/hayır sorusunda fiil başta, mastar sonda.'],
  ['Warum lernst du Deutsch?', 'Neden Almanca öğreniyorsun?', 'W-sorusu: soru kelimesi + fiil + özne.'],
  ['Hast du heute Zeit?', 'Bugün vaktin var mı?', 'Evet/hayır sorusu: fiil en başta.'],
  ['Nach der Arbeit gehe ich einkaufen.', 'İşten sonra alışverişe gidiyorum.', 'Başta zaman/yer: fiil ikinci sırada.'],
];

const buildOrder = (): Exercise[] =>
  ORDER.map(([sentence, tr, rule], i) => ({
    id: `gram_order${i}`,
    refId: `gram:satz:${i}`,
    level: 'A2',
    topicTag: 'Gramer: Cümle sırası',
    type: 'sentence_builder',
    instructionTr: 'Cümleyi doğru sırayla kurun:',
    turkishPrompt: tr,
    correctGermanSentence: sentence,
    scrambledWords: sentence.split(' '),
    explanationTr: `${sentence} (${rule})`,
  } as Exercise));

export const LAB_TOPICS: LabTopic[] = [
  {
    id: 'konjugation',
    level: 'A1',
    emoji: '🧩',
    titleTr: 'Fiil çekimi: sein, haben, können...',
    cards: [
      {
        title: 'Fiil özneye göre değişir',
        bodyTr: 'Almancada fiilin sonu özneye göre değişir. En önemli düzensiz fiiller: sein, haben, werden ve modal fiiller. Bunları ezbere bilmek her cümlede işinize yarar.',
        rows: [['sein', 'bin, bist, ist, sind, seid, sind'], ['haben', 'habe, hast, hat, haben, habt, haben'], ['können', 'kann, kannst, kann, können, könnt, können']],
        tipTr: 'Modal fiillerde ich ve er/sie/es aynıdır: ich kann, er kann.',
      },
      {
        title: 'Ünlü değiştiren fiiller',
        bodyTr: 'Bazı fiillerde du ve er/sie/es için kök ünlüsü değişir: essen → du isst, fahren → du fährst, sprechen → du sprichst, lesen → du liest.',
        rows: [['fahren', 'ich fahre, du fährst, er fährt'], ['sprechen', 'ich spreche, du sprichst, er spricht'], ['schlafen', 'ich schlafe, du schläfst, er schläft']],
      },
    ],
    build: buildConj,
  },
  {
    id: 'plural',
    level: 'A1',
    emoji: '👨‍👩‍👧',
    titleTr: 'Çoğul (Plural) oluşturma',
    cards: [
      {
        title: 'Çoğulun 5 yolu',
        bodyTr: 'Almancada çoğul tek bir kurala bağlı değildir. En sık görülen sonlar -e, -er, -(e)n, -s ve değişmeyenlerdir. Birçok kelimede ayrıca ünlü noktalı olur (ä, ö, ü). Çoğulda artikel her zaman "die" olur.',
        rows: [['-e', 'der Tisch → die Tische'], ['-er (+ ¨)', 'das Buch → die Bücher'], ['-(e)n', 'die Frau → die Frauen'], ['-s', 'das Auto → die Autos'], ['değişmez', 'das Zimmer → die Zimmer']],
        tipTr: 'Kelimeyi öğrenirken çoğulunu da birlikte öğrenin: "der Tisch, die Tische".',
      },
    ],
    build: buildPlural,
  },
  {
    id: 'artikel-kasus',
    level: 'A1',
    emoji: '🎯',
    titleTr: 'Artikel ve haller: Nominativ, Akkusativ, Dativ',
    cards: [
      {
        title: 'Üç hal, üç artikel tablosu',
        bodyTr: 'Cümlede kelimenin görevi artikelini değiştirir. Özne Nominativ\'dedir. Doğrudan nesne Akkusativ\'dur (sadece der → den değişir). Dolaylı nesne Dativ\'dur (kime?).',
        rows: [['Nominativ', 'der · die · das · die'], ['Akkusativ', 'den · die · das · die'], ['Dativ', 'dem · der · dem · den (+n)']],
        tipTr: 'Akkusativ\'da sadece eril değişir: der → den.',
      },
      {
        title: 'Hangi fiil hangi hali ister?',
        bodyTr: 'Çoğu fiil Akkusativ ister: sehen, kaufen, brauchen, lesen. Bazı fiiller Dativ ister: helfen, danken, gefallen, gehören. "geben" ve "schenken" ikisini birden ister: kime (Dativ) neyi (Akkusativ).',
        formulaDe: 'Ich gebe dem Kind (Dativ) den Ball (Akkusativ).',
      },
    ],
    build: () => fillExercises('artikel', 'A1', 'Gramer: Artikel ve haller', ARTIKEL, ART_POOL),
  },
  {
    id: 'negation',
    level: 'A1',
    emoji: '🚫',
    titleTr: 'Olumsuzluk: nicht ve kein',
    cards: [
      {
        title: 'kein mı, nicht mi?',
        bodyTr: '"kein" belirsiz artikelin (ein, eine) ve artikelsiz isimlerin olumsuzudur: Ich habe ein Auto → Ich habe kein Auto. "nicht" ise fiili, sıfatı, zamanı ve belirli isimleri olumsuzlar.',
        rows: [['kein / keine / keinen', 'Ich habe keine Zeit.'], ['nicht', 'Ich komme nicht. · Das ist nicht gut.']],
        tipTr: 'kein, "ein" gibi çekimlenir: der → keinen (Akkusativ), die → keine, das → kein.',
      },
    ],
    build: () => fillExercises('negation', 'A1', 'Gramer: Olumsuzluk', NEG, ['kein', 'keine', 'keinen', 'nicht']),
  },
  {
    id: 'praeposition',
    level: 'A2',
    emoji: '📍',
    titleTr: 'Edatlar ve haller: mit, für, in, auf...',
    cards: [
      {
        title: 'Her edatın bir hali var',
        bodyTr: 'Edatlar belirli bir hal ister. Bunları ezberlemek için gruplamak kolaydır.',
        rows: [['+ Dativ', 'mit, nach, bei, seit, von, zu, aus'], ['+ Akkusativ', 'für, ohne, durch, gegen, um'], ['Wechselpräpositionen', 'in, an, auf, neben, vor, hinter, über, unter']],
        tipTr: 'mit + Dativ, für + Akkusativ: iki edatı ilk ezberleyin.',
      },
      {
        title: 'Wo? mu Wohin? mi?',
        bodyTr: 'in, an, auf gibi edatlarda hareket yoksa (Wo? = nerede?) Dativ, hareket varsa (Wohin? = nereye?) Akkusativ kullanılır.',
        rows: [['Wo? → Dativ', 'Ich bin in dem Kino. (im Kino)'], ['Wohin? → Akkusativ', 'Ich gehe in das Kino. (ins Kino)']],
      },
    ],
    build: () => fillExercises('praep', 'A2', 'Gramer: Edatlar ve haller', PREP, ART_POOL),
  },
  {
    id: 'perfekt',
    level: 'A2',
    emoji: '⏪',
    titleTr: 'Perfekt: geçmişi anlatmak',
    cards: [
      {
        title: 'haben/sein + Partizip II',
        bodyTr: 'Konuşma dilinde geçmişi çoğunlukla Perfekt ile anlatırız: yardımcı fiil (haben veya sein) ikinci sırada, Partizip II cümle sonunda. Hareket ve durum değişikliği bildiren fiiller "sein" ile kurulur.',
        formulaDe: 'Ich habe gespielt.  |  Ich bin gegangen.',
        rows: [['Düzenli fiiller', 'ge + kök + t → gemacht, gespielt'], ['Düzensiz fiiller', 'ge + ... + en → gegessen, gesehen'], ['Ayrılabilen fiiller', 'ge ortada → aufgestanden, eingekauft'], ['be-, ver-, ent- ile başlayanlar', 'ge yok → besucht, verstanden']],
        tipTr: 'sein ile kurulanlar: gehen, kommen, fahren, bleiben, sein, werden, aufstehen.',
      },
    ],
    build: buildPerfekt,
  },
  {
    id: 'satzstellung',
    level: 'A2',
    emoji: '🧱',
    titleTr: 'Cümle sırası: fiil nerede durur?',
    cards: [
      {
        title: 'Altın kural: fiil ikinci sırada',
        bodyTr: 'Ana cümlede çekimli fiil her zaman ikinci sıradadır. Cümleye zaman veya yerle başlarsanız özne fiilden sonra gelir (Inversion).',
        rows: [['Normal', 'Ich gehe heute ins Kino.'], ['Inversion', 'Heute gehe ich ins Kino.']],
      },
      {
        title: 'İkinci parça cümle sonuna gider',
        bodyTr: 'Modal fiilde mastar, Perfekt\'te Partizip II ve ayrılabilen fiillerde ön ek cümle sonuna gider. Yan cümlelerde (dass, weil, wenn) çekimli fiil sona gider.',
        rows: [['Modal', 'Ich kann gut schwimmen.'], ['Perfekt', 'Ich habe Fußball gespielt.'], ['Ayrılabilen', 'Ich stehe um sieben auf.'], ['Yan cümle', 'Ich weiß, dass er krank ist.']],
      },
    ],
    build: buildOrder,
  },
];

const REF_TO_TOPIC: Record<string, string> = {
  konj: 'konjugation',
  plural: 'plural',
  perfekt: 'perfekt',
  satz: 'satzstellung',
  artikel: 'artikel-kasus',
  praep: 'praeposition',
  negation: 'negation',
};

/** One review question for a grammar item (refId looks like gram:perfekt:12). */
export function buildReviewExerciseForGrammar(refId: string, seed: number): Exercise | null {
  const topicId = REF_TO_TOPIC[refId.split(':')[1]];
  const topic = LAB_TOPICS.find((t) => t.id === topicId);
  if (!topic) return null;
  const pool = topic.build().filter((e) => e.refId === refId);
  if (pool.length === 0) return null;
  const ex = pool[seed % pool.length];
  return { ...ex, id: `${ex.id}_r${seed}` } as Exercise;
}
