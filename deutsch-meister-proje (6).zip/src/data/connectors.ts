import { CEFRLevel, Exercise } from '../types';

export interface ConnectorItem {
  word: string; // as shown on the card (may contain "...")
  form: string; // single word used in the blank / typing
  meaningTr: string;
  template: string; // example with the connector marked as {form}
  exampleTr: string;
}

export interface ConnectorGroup {
  id: string;
  level: CEFRLevel;
  emoji: string;
  titleTr: string;
  ruleTr: string; // word-order rule explained in Turkish
  formulaDe: string; // short pattern
  tipTr: string;
  items: ConnectorItem[];
  quiz: { q: string; options: string[]; answer: string; explanationTr: string }[];
}

const it = (word: string, form: string, meaningTr: string, template: string, exampleTr: string): ConnectorItem => ({
  word,
  form,
  meaningTr,
  template,
  exampleTr,
});

export const CONNECTOR_GROUPS: ConnectorGroup[] = [
  {
    id: 'weil-denn',
    level: 'A2',
    emoji: '❓',
    titleTr: 'Neden: weil, denn, da',
    ruleTr:
      '"weil" ve "da" yan cümle kurar: çekimli fiil cümlenin EN SONUNA gider. "denn" ise iki ana cümleyi bağlar: fiil normal yerinde (2. sırada) kalır.',
    formulaDe: 'weil + Subjekt ... Verb  |  denn + Subjekt + Verb ...',
    tipTr: 'Kolay kural: weil = fiil sonda, denn = sıra değişmez.',
    items: [
      it('weil', 'weil', 'çünkü (yan cümle)', 'Ich bleibe zu Hause, {weil} ich krank bin.', 'Hasta olduğum için evde kalıyorum.'),
      it('denn', 'denn', 'çünkü (ana cümle)', 'Ich bleibe zu Hause, {denn} ich bin krank.', 'Evde kalıyorum, çünkü hastayım.'),
      it('da', 'da', 'mademki, -diğinden', '{Da} es regnet, bleiben wir zu Hause.', 'Yağmur yağdığı için evde kalıyoruz.'),
      it('nämlich', 'nämlich', 'çünkü (cümle içinde)', 'Ich bleibe zu Hause. Ich bin {nämlich} krank.', 'Evde kalıyorum. Çünkü hastayım.'),
      it('wegen', 'wegen', '-den dolayı (isimle)', '{Wegen} des Regens bleiben wir zu Hause.', 'Yağmur yüzünden evde kalıyoruz.'),
    ],
    quiz: [
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich lerne Deutsch, weil ich in Deutschland arbeite.', 'Ich lerne Deutsch, weil ich arbeite in Deutschland.', 'Ich lerne Deutsch, weil arbeite ich in Deutschland.'],
        answer: 'Ich lerne Deutsch, weil ich in Deutschland arbeite.',
        explanationTr: '"weil" cümlesinde çekimli fiil (arbeite) en sona gider.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Er ist müde, denn er hat wenig geschlafen.', 'Er ist müde, denn er wenig geschlafen hat.', 'Er ist müde, denn hat er wenig geschlafen.'],
        answer: 'Er ist müde, denn er hat wenig geschlafen.',
        explanationTr: '"denn" sonrasında sıra değişmez: özne + fiil.',
      },
    ],
  },
  {
    id: 'deshalb',
    level: 'A2',
    emoji: '➡️',
    titleTr: 'Sonuç: deshalb, deswegen, darum, also',
    ruleTr:
      'Bu sözcükler ilk sırayı (Position 1) alır ve hemen arkasından çekimli fiil gelir. Yani cümle "deshalb + FİİL + özne" şeklinde ilerler.',
    formulaDe: '..., deshalb + Verb + Subjekt ...',
    tipTr: 'deshalb, deswegen ve darum aynı anlamdadır. "deshalb" en yaygın olanıdır.',
    items: [
      it('deshalb', 'deshalb', 'bu yüzden', 'Ich bin müde, {deshalb} gehe ich früh ins Bett.', 'Yorgunum, bu yüzden erken yatıyorum.'),
      it('deswegen', 'deswegen', 'bu nedenle', 'Es regnet, {deswegen} bleiben wir zu Hause.', 'Yağmur yağıyor, bu nedenle evde kalıyoruz.'),
      it('darum', 'darum', 'bu yüzden', 'Er hat Hunger, {darum} kocht er Suppe.', 'Karnı aç, bu yüzden çorba pişiriyor.'),
      it('also', 'also', 'öyleyse, yani', 'Du bist krank, {also} bleibst du im Bett.', 'Hastasın, öyleyse yatakta kal.'),
      it('folglich', 'folglich', 'sonuç olarak', 'Die Preise stiegen, {folglich} kauften weniger Leute ein.', 'Fiyatlar arttı, sonuç olarak daha az insan alışveriş yaptı.'),
    ],
    quiz: [
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich habe Hunger, deshalb esse ich ein Brot.', 'Ich habe Hunger, deshalb ich esse ein Brot.', 'Ich habe Hunger, deshalb ein Brot ich esse.'],
        answer: 'Ich habe Hunger, deshalb esse ich ein Brot.',
        explanationTr: '"deshalb" sonrası fiil hemen gelir, özne ondan sonra.',
      },
      {
        q: 'Hangi sözcük çekimli fiili cümlenin sonuna gönderir?',
        options: ['weil', 'deshalb', 'darum'],
        answer: 'weil',
        explanationTr: '"deshalb" ve "darum" fiili hemen arkasına alır, sadece "weil" fiili sona gönderir.',
      },
    ],
  },
  {
    id: 'dass-ob',
    level: 'A2',
    emoji: '💬',
    titleTr: 'dass, ob, damit ve dolaylı sorular',
    ruleTr:
      '"dass" (-ki, -diğini), "ob" (-ip -mediğini), "damit" (-sin diye) ve dolaylı soru kelimeleri (wie, wann, wo) yan cümle kurar. Çekimli fiil en sona gider. Evet/hayır sorusu dolaylı olunca "ob" kullanılır.',
    formulaDe: 'Hauptsatz, dass/ob/damit + Subjekt ... Verb',
    tipTr: '"Ich glaube, ..." gibi ana cümlelerin ardından hep virgül ve "dass" gelir.',
    items: [
      it('dass', 'dass', '-diğini, -ki', 'Ich glaube, {dass} er recht hat.', 'Onun haklı olduğunu düşünüyorum.'),
      it('ob', 'ob', '-ip -mediğini', 'Ich weiß nicht, {ob} er kommt.', 'Onun gelip gelmeyeceğini bilmiyorum.'),
      it('damit', 'damit', '-sin diye (amaç)', 'Ich lerne viel, {damit} ich die Prüfung bestehe.', 'Sınavı geçeyim diye çok çalışıyorum.'),
      it('wie', 'wie', 'nasıl (dolaylı soru)', 'Ich weiß, {wie} man das schreibt.', 'Bunun nasıl yazıldığını biliyorum.'),
      it('wann', 'wann', 'ne zaman (dolaylı soru)', 'Sag mir, {wann} der Zug fährt.', 'Bana trenin ne zaman kalktığını söyle.'),
    ],
    quiz: [
      {
        q: '"Ich weiß nicht, ___ er heute kommt." (evet/hayır sorusu)',
        options: ['ob', 'dass', 'damit'],
        answer: 'ob',
        explanationTr: 'Evet/hayır içeren dolaylı soru "ob" ile kurulur.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich hoffe, dass du morgen kommst.', 'Ich hoffe, dass kommst du morgen.', 'Ich hoffe, dass du kommst morgen.'],
        answer: 'Ich hoffe, dass du morgen kommst.',
        explanationTr: '"dass" cümlesinde fiil (kommst) en sona gider.',
      },
    ],
  },
  {
    id: 'aber-trotzdem',
    level: 'A2',
    emoji: '↔️',
    titleTr: 'Karşıtlık: aber, sondern, trotzdem, obwohl',
    ruleTr:
      '"aber", "sondern", "doch" ve "jedoch" sıra değiştirmez. "trotzdem" ilk sırayı alır, fiil hemen arkasından gelir. "obwohl" yan cümle kurar, fiil sona gider. "sondern" olumsuzdan sonra "-değil, aksine" anlamında kullanılır.',
    formulaDe: 'aber + S + V  |  trotzdem + V + S  |  obwohl + S ... V',
    tipTr: '"nicht ... sondern ..." her zaman birlikte düşünün: Kahve değil, çay.',
    items: [
      it('aber', 'aber', 'ama', 'Ich möchte kommen, {aber} ich habe keine Zeit.', 'Gelmek istiyorum ama vaktim yok.'),
      it('sondern', 'sondern', '-değil, aksine', 'Ich trinke keinen Kaffee, {sondern} Tee.', 'Kahve değil, çay içiyorum.'),
      it('trotzdem', 'trotzdem', 'buna rağmen', 'Es regnet, {trotzdem} gehen wir spazieren.', 'Yağmur yağıyor, buna rağmen yürüyüşe çıkıyoruz.'),
      it('obwohl', 'obwohl', '-e rağmen (yan cümle)', 'Ich gehe zur Arbeit, {obwohl} ich krank bin.', 'Hasta olmama rağmen işe gidiyorum.'),
      it('doch', 'doch', 'yine de, ama', 'Er ist reich, {doch} er ist nicht glücklich.', 'O zengin, ama mutlu değil.'),
      it('jedoch', 'jedoch', 'ancak', 'Das Hotel ist schön, {jedoch} sehr teuer.', 'Otel güzel, ancak çok pahalı.'),
    ],
    quiz: [
      {
        q: '"Ich fahre nicht nach Berlin, ___ nach München."',
        options: ['sondern', 'aber', 'trotzdem'],
        answer: 'sondern',
        explanationTr: 'Olumsuz bir ifadeden sonra "aksine, ... değil" anlamı için "sondern" kullanılır.',
      },
      {
        q: 'Hangi sözcük fiili cümlenin sonuna gönderir?',
        options: ['obwohl', 'trotzdem', 'aber'],
        answer: 'obwohl',
        explanationTr: '"obwohl" yan cümle kurar. "trotzdem" ve "aber" fiili sona göndermez.',
      },
    ],
  },
  {
    id: 'zeit',
    level: 'B1',
    emoji: '⏰',
    titleTr: 'Zaman: wenn, als, während, bevor, nachdem',
    ruleTr:
      'Zaman bağlaçları yan cümle kurar: fiil sona gider. "als" geçmişte TEK SEFER olan olaylar için, "wenn" tekrar eden olaylar ve şimdiki/gelecek için kullanılır. "nachdem" ile genelde Plusquamperfekt + Präteritum/Perfekt eşleşir.',
    formulaDe: 'wenn/als/während/bevor/nachdem + Subjekt ... Verb',
    tipTr: 'Geçmişte bir kez: als. Her zaman, her seferinde: wenn.',
    items: [
      it('wenn', 'wenn', '-dığında, -sa (tekrar eden)', '{Wenn} ich Zeit habe, lese ich ein Buch.', 'Vaktim olduğunda kitap okurum.'),
      it('als', 'als', '-dığında (geçmişte tek sefer)', '{Als} ich ein Kind war, wohnte ich in Izmir.', 'Çocukken İzmir\'de yaşıyordum.'),
      it('während', 'während', '-ken, süresince', '{Während} ich koche, hört er Musik.', 'Ben yemek yaparken o müzik dinliyor.'),
      it('bevor', 'bevor', '-meden önce', 'Ich dusche, {bevor} ich zur Arbeit gehe.', 'İşe gitmeden önce duş alıyorum.'),
      it('nachdem', 'nachdem', '-dikten sonra', '{Nachdem} ich gegessen hatte, ging ich spazieren.', 'Yemek yedikten sonra yürüyüşe çıktım.'),
      it('seitdem', 'seitdem', '-diğinden beri', 'Ich bin glücklich, {seitdem} ich hier wohne.', 'Burada yaşadığımdan beri mutluyum.'),
      it('bis', 'bis', '-e kadar', 'Ich warte hier, {bis} du kommst.', 'Sen gelene kadar burada bekliyorum.'),
      it('sobald', 'sobald', '-er -mez', 'Ich rufe an, {sobald} ich ankomme.', 'Varır varmaz arıyorum.'),
    ],
    quiz: [
      {
        q: '"___ ich gestern nach Hause kam, schlief mein Sohn schon."',
        options: ['Als', 'Wenn', 'Während'],
        answer: 'Als',
        explanationTr: 'Geçmişte tek bir olay: "als".',
      },
      {
        q: '"___ ich müde bin, trinke ich immer Kaffee." (her seferinde)',
        options: ['Wenn', 'Als', 'Bevor'],
        answer: 'Wenn',
        explanationTr: 'Tekrar eden durum: "wenn".',
      },
    ],
  },
  {
    id: 'bedingung',
    level: 'B1',
    emoji: '🎯',
    titleTr: 'Koşul ve amaç: falls, damit, um ... zu',
    ruleTr:
      '"falls" ve "sofern" koşul yan cümlesi kurar (fiil sonda). Amaç için iki yol var: özneler AYNIYSA "um ... zu + mastar", özneler FARKLIYSA "damit + yan cümle". "ohne ... zu" (-meden) ve "anstatt ... zu" (-mek yerine) de mastarla kurulur.',
    formulaDe: 'um + ... + zu + Infinitiv  |  damit + S ... V',
    tipTr: 'Aynı özne: um ... zu. Farklı özne: damit.',
    items: [
      it('falls', 'falls', 'eğer (olasılık)', '{Falls} es regnet, bleiben wir zu Hause.', 'Yağmur yağarsa evde kalırız.'),
      it('sofern', 'sofern', '-mek şartıyla', 'Wir kommen, {sofern} wir Zeit haben.', 'Vaktimiz olursa geliriz.'),
      it('damit', 'damit', '-sin diye (farklı özne)', 'Ich spare Geld, {damit} wir reisen können.', 'Seyahat edebilelim diye para biriktiriyorum.'),
      it('um ... zu', 'um', '-mek için (aynı özne)', 'Ich lerne Deutsch, {um} in Deutschland zu arbeiten.', 'Almanya\'da çalışmak için Almanca öğreniyorum.'),
      it('ohne ... zu', 'ohne', '-meden', 'Er ging, {ohne} sich zu verabschieden.', 'O vedalaşmadan gitti.'),
      it('anstatt ... zu', 'anstatt', '-mek yerine', '{Anstatt} zu lernen, spielt er Fußball.', 'Ders çalışmak yerine futbol oynuyor.'),
    ],
    quiz: [
      {
        q: '"Ich fahre in die Stadt, ___ Brot zu kaufen."',
        options: ['um', 'damit', 'falls'],
        answer: 'um',
        explanationTr: 'Aynı özne (ich fahre / ich kaufe): "um ... zu".',
      },
      {
        q: '"Ich gebe dir Geld, ___ du ein Ticket kaufen kannst."',
        options: ['damit', 'um', 'ohne'],
        answer: 'damit',
        explanationTr: 'Özneler farklı (ich / du): "damit" ile yan cümle kurulur.',
      },
    ],
  },
  {
    id: 'ekleme',
    level: 'B1',
    emoji: '➕',
    titleTr: 'Ekleme ve seçenek: außerdem, weder ... noch',
    ruleTr:
      '"außerdem" ve "zudem" ilk sırayı alır, fiil hemen arkasından gelir. "sowohl ... als auch", "weder ... noch", "entweder ... oder", "nicht nur ... sondern auch" ve "einerseits ... andererseits" ikili kalıplardır, birlikte kullanılır.',
    formulaDe: 'außerdem + V + S  |  weder ... noch ... | entweder ... oder ...',
    tipTr: 'İkili kalıpları cümle içinde iki yarısıyla birlikte ezberleyin.',
    items: [
      it('außerdem', 'außerdem', 'ayrıca', 'Ich bin müde. {Außerdem} habe ich Hunger.', 'Yorgunum. Ayrıca açım.'),
      it('zudem', 'zudem', 'üstelik', 'Die Wohnung ist günstig, {zudem} liegt sie zentral.', 'Daire ucuz, üstelik merkezde.'),
      it('sowohl ... als auch', 'sowohl', 'hem ... hem de', 'Er spricht {sowohl} Türkisch als auch Deutsch.', 'O hem Türkçe hem Almanca konuşuyor.'),
      it('weder ... noch', 'weder', 'ne ... ne de', 'Ich habe {weder} Zeit noch Geld.', 'Ne vaktim ne de param var.'),
      it('entweder ... oder', 'entweder', 'ya ... ya da', 'Wir fahren {entweder} mit dem Bus oder mit dem Zug.', 'Ya otobüsle ya da trenle gidiyoruz.'),
      it('nicht nur ... sondern auch', 'sondern', 'sadece ... değil, aynı zamanda', 'Sie ist nicht nur klug, {sondern} auch fleißig.', 'O sadece zeki değil, aynı zamanda çalışkan.'),
      it('einerseits ... andererseits', 'einerseits', 'bir yandan ... diğer yandan', '{Einerseits} ist es teuer, andererseits ist es bequem.', 'Bir yandan pahalı, diğer yandan rahat.'),
    ],
    quiz: [
      {
        q: '"Er hat ___ Zeit ___ Lust." (ikisi de yok)',
        options: ['weder ... noch', 'entweder ... oder', 'sowohl ... als auch'],
        answer: 'weder ... noch',
        explanationTr: 'İki şey de yoksa "weder ... noch" kullanılır.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich bin müde. Außerdem habe ich Hunger.', 'Ich bin müde. Außerdem ich habe Hunger.', 'Ich bin müde. Außerdem Hunger ich habe.'],
        answer: 'Ich bin müde. Außerdem habe ich Hunger.',
        explanationTr: '"außerdem" ilk sırayı alır, fiil hemen arkasından gelir.',
      },
    ],
  },
  {
    id: 'fortgeschritten',
    level: 'B2',
    emoji: '🚀',
    titleTr: 'İleri bağlaçlar: sodass, indem, je ... desto',
    ruleTr:
      '"sodass" (böylece) ve "indem" (-erek) yan cümle kurar, fiil sona gider. "je ... desto" karşılaştırmalı ikili kalıptır: her iki yarım cümlede de karşılaştırma hâli kullanılır. "dennoch", "allerdings" ve "infolgedessen" ilk sırayı alır.',
    formulaDe: 'sodass/indem + S ... V  |  je + Komparativ ..., desto + Komparativ + V + S',
    tipTr: '"je mehr ... desto besser": ikinci kısımda fiil hemen "desto" ifadesinden sonra gelir.',
    items: [
      it('sodass', 'sodass', 'böylece, öyle ki', 'Es regnete stark, {sodass} wir nicht losfahren konnten.', 'Yağmur çok şiddetliydi, böylece yola çıkamadık.'),
      it('indem', 'indem', '-erek', 'Man lernt Wörter, {indem} man viel liest.', 'Çok okuyarak kelime öğrenilir.'),
      it('je ... desto', 'je', 'ne kadar ... o kadar', '{Je} mehr du übst, desto besser wirst du.', 'Ne kadar çok çalışırsan o kadar iyi olursun.'),
      it('zwar ... aber', 'zwar', 'doğru ama', 'Das ist {zwar} teuer, aber sehr gut.', 'Bu doğru pahalı, ama çok iyi.'),
      it('dennoch', 'dennoch', 'buna rağmen', 'Es war schwer, {dennoch} habe ich es geschafft.', 'Zordu, buna rağmen başardım.'),
      it('allerdings', 'allerdings', 'ancak, bununla birlikte', 'Das Angebot ist gut, {allerdings} teuer.', 'Teklif iyi, ancak pahalı.'),
      it('infolgedessen', 'infolgedessen', 'bunun sonucunda', 'Es gab einen Unfall, {infolgedessen} war die Straße gesperrt.', 'Bir kaza oldu, bunun sonucunda yol kapandı.'),
    ],
    quiz: [
      {
        q: '"Je mehr du lernst, ___ besser wirst du."',
        options: ['desto', 'dass', 'obwohl'],
        answer: 'desto',
        explanationTr: '"je + Komparativ ..., desto + Komparativ" ikilisi.',
      },
      {
        q: '"Man lernt Wörter, ___ man viel liest."',
        options: ['indem', 'denn', 'also'],
        answer: 'indem',
        explanationTr: '"indem" = -erek: bir şeyi yapmanın yolu.',
      },
    ],
  },
];


type Q = { q: string; options: string[]; answer: string; explanationTr: string };
const qq = (q: string, answer: string, wrong: string[], explanationTr: string): Q => ({ q, options: [answer, ...wrong], answer, explanationTr });

// More rule and usage questions for every group.
const EXTRA_QUIZ: Record<string, Q[]> = {
  'weil-denn': [
    qq('Cümleleri "weil" ile birleştirin: Ich esse viel. Ich habe Hunger.', 'Ich esse viel, weil ich Hunger habe.', ['Ich esse viel, weil ich habe Hunger.', 'Ich esse viel, weil habe ich Hunger.'], '"weil" yan cümlesinde fiil (habe) sona gider.'),
    qq('"Er kommt nicht, ___ er ist krank." (fiil ikinci sırada)', 'denn', ['weil', 'dass'], 'Fiil ikinci sırada kaldığı için "denn" kullanılır.'),
    qq('Hangi cümle YANLIŞ?', 'Sie lacht, weil sie ist glücklich.', ['Sie lacht, denn sie ist glücklich.', 'Sie lacht, weil sie glücklich ist.'], '"weil" sonrasında fiil sonda olmalı: weil sie glücklich ist.'),
    qq('"___ es schneit, fahren wir nicht."', 'Da', ['Denn', 'Deshalb'], '"da" cümlenin başında da kullanılabilen sebep bağlacıdır (yan cümle).'),
    qq('"Wir bleiben hier, ___ des Regens."', 'wegen', ['weil', 'denn'], '"wegen" isimle (Genitiv) kullanılır, yan cümle kurmaz.'),
    qq('"weil" cümlelerinde çekimli fiil nerede durur?', 'Sonda', ['İkinci sırada', 'Başta'], 'Yan cümlede çekimli fiil en sondadır.'),
  ],
  deshalb: [
    qq('"deshalb" ile birleştirin: Es ist kalt. Ich trage eine Jacke.', 'Es ist kalt, deshalb trage ich eine Jacke.', ['Es ist kalt, deshalb ich trage eine Jacke.', 'Es ist kalt, deshalb eine Jacke trage ich.'], '"deshalb" sonrası önce fiil, sonra özne gelir.'),
    qq('"Er ist krank, ___ geht er zum Arzt."', 'deshalb', ['weil', 'dass'], 'Sonuç bildirir, bu yüzden "deshalb".'),
    qq('Hangi cümle YANLIŞ?', 'Ich habe Durst, deswegen ich trinke Wasser.', ['Ich habe Durst, darum trinke ich Wasser.', 'Ich habe Durst, deshalb trinke ich Wasser.'], '"deswegen" sonrasında fiil hemen gelmeli: deswegen trinke ich.'),
    qq('"Warum bleibst du zu Hause?" sorusuna uygun cevap hangisi?', 'Weil ich krank bin.', ['Deshalb ich bin krank.', 'Darum weil krank.'], 'Sebep sorusuna "weil" ile yan cümle cevap verir.'),
    qq('"Du bist müde, ___ solltest du schlafen."', 'also', ['weil', 'obwohl'], '"also" sonucu bildirir: öyleyse.'),
    qq('"bu yüzden" anlamında hangisi kullanılır?', 'deshalb', ['obwohl', 'weil'], '"deshalb" = bu yüzden.'),
  ],
  'dass-ob': [
    qq('"Ich weiß, ___ du Hunger hast."', 'dass', ['ob', 'damit'], 'Bir bilgiyi aktarırken "dass" kullanılır.'),
    qq('"Weißt du, ___ der Bus um acht fährt?" (evet/hayır sorusu)', 'ob', ['dass', 'wie'], 'Evet/hayır içeren dolaylı soru "ob" ile kurulur.'),
    qq('Birleştirin: Ich hoffe. Du kommst.', 'Ich hoffe, dass du kommst.', ['Ich hoffe, dass kommst du.', 'Ich hoffe, dass du kommen.'], '"dass" sonrası özne, fiil sonda.'),
    qq('"Sie fragt, ___ das Hotel teuer ist."', 'ob', ['dass', 'damit'], 'Soru: "Hotel pahalı mı?" evet/hayır = ob.'),
    qq('"Ich lerne, ___ ich eine gute Arbeit finde."', 'damit', ['dass', 'ob'], 'Amaç bildirir: "damit".'),
    qq('Hangi cümle YANLIŞ?', 'Er sagt, dass er hat keine Zeit.', ['Er sagt, dass er keine Zeit hat.', 'Er sagt, er hat keine Zeit.'], '"dass" sonrası fiil sona gitmeli: dass er keine Zeit hat.'),
  ],
  'aber-trotzdem': [
    qq('"Es regnet, ___ gehen wir spazieren."', 'trotzdem', ['obwohl', 'sondern'], '"trotzdem" ana cümlede fiili hemen arkasına alır.'),
    qq('"Wir gehen spazieren, ___ es regnet."', 'obwohl', ['trotzdem', 'aber'], '"obwohl" yan cümle kurar (fiil sonda: regnet).'),
    qq('"Das ist nicht rot, ___ blau."', 'sondern', ['aber', 'doch'], 'Olumsuzdan sonra düzeltme: sondern.'),
    qq('"Er ist klein, ___ stark."', 'aber', ['sondern', 'obwohl'], 'Karşıtlık, olumsuz yok: aber.'),
    qq('Hangi cümle YANLIŞ?', 'Obwohl ich bin müde, arbeite ich.', ['Obwohl ich müde bin, arbeite ich.', 'Ich bin müde, trotzdem arbeite ich.'], '"obwohl" cümlesinde fiil sonda: Obwohl ich müde bin.'),
    qq('Hangi cümle doğru?', 'Ich bin krank, trotzdem gehe ich zur Arbeit.', ['Ich bin krank, trotzdem ich gehe zur Arbeit.', 'Ich bin krank, trotzdem zur Arbeit ich gehe.'], '"trotzdem" + fiil + özne.'),
  ],
  zeit: [
    qq('"___ ich klein war, spielte ich viel."', 'Als', ['Wenn', 'Bevor'], 'Geçmişte süreç/tek durum: "als".'),
    qq('"___ ich Hunger habe, esse ich."', 'Wenn', ['Als', 'Nachdem'], 'Şimdiki zaman ve tekrarlayan durum: "wenn".'),
    qq('"Ich dusche, ___ ich schlafen gehe."', 'bevor', ['nachdem', 'als'], '"bevor" = -meden önce.'),
    qq('"___ er angekommen war, rief er an."', 'Nachdem', ['Bevor', 'Während'], '"nachdem" = -dikten sonra.'),
    qq('"___ ich lese, trinke ich Tee."', 'Während', ['Bis', 'Seit'], 'İki eylem aynı anda: "während".'),
    qq('Hangi cümle YANLIŞ?', 'Wenn ich habe Zeit, rufe ich an.', ['Wenn ich Zeit habe, rufe ich an.', 'Ich rufe an, wenn ich Zeit habe.'], '"wenn" yan cümlesinde fiil sona gider.'),
    qq('"Ich warte, ___ der Bus kommt."', 'bis', ['seit', 'bevor'], '"bis" = -e kadar.'),
  ],
  bedingung: [
    qq('Hangi cümle doğru?', 'Ich spare Geld, um ein Auto zu kaufen.', ['Ich spare Geld, damit ein Auto zu kaufen.', 'Ich spare Geld, um ich ein Auto kaufe.'], 'Aynı özne: "um ... zu + mastar".'),
    qq('"___ es morgen regnet, bleiben wir zu Hause."', 'Falls', ['Damit', 'Ohne'], '"falls" olasılık/koşul bildirir.'),
    qq('"Er ging, ___ ein Wort zu sagen."', 'ohne', ['damit', 'falls'], '"ohne ... zu" = -meden.'),
    qq('"Ich helfe dir, ___ du mehr Zeit hast."', 'damit', ['um', 'ohne'], 'Özneler farklı (ich / du): "damit".'),
    qq('"___ zu arbeiten, schläft er."', 'Anstatt', ['Ohne', 'Damit'], '"anstatt ... zu" = -mek yerine.'),
    qq('Hangi cümle YANLIŞ?', 'Sie lernt, damit die Prüfung zu bestehen.', ['Sie lernt, damit sie die Prüfung besteht.', 'Sie lernt, um die Prüfung zu bestehen.'], '"damit" ile tam yan cümle kurulur, "zu + mastar" "um" ile gelir.'),
  ],
  ekleme: [
    qq('"Ich habe ___ Hunger ___ Durst."', 'weder ... noch', ['entweder ... oder', 'sowohl ... als auch'], 'İkisi de yok: weder ... noch.'),
    qq('"Wir fahren ___ nach Berlin ___ nach München." (biri)', 'entweder ... oder', ['weder ... noch', 'sowohl ... als auch'], 'Ya biri ya diğeri: entweder ... oder.'),
    qq('"Er spricht ___ Englisch ___ Deutsch." (ikisi de)', 'sowohl ... als auch', ['weder ... noch', 'entweder ... oder'], 'İkisi birden: sowohl ... als auch.'),
    qq('Hangi cümle doğru?', 'Das Hotel ist günstig. Zudem liegt es zentral.', ['Das Hotel ist günstig. Zudem es liegt zentral.', 'Das Hotel ist günstig. Zudem zentral es liegt.'], '"zudem" + fiil + özne.'),
    qq('"Ich habe Hunger. ___ bin ich müde."', 'Außerdem', ['Obwohl', 'Weil'], '"außerdem" ekleme yapar.'),
    qq('Hangi cümle doğru?', 'Sie ist nicht nur freundlich, sondern auch klug.', ['Sie ist nicht nur freundlich, aber auch klug.', 'Sie ist nur nicht freundlich, sondern klug.'], 'Kalıp: nicht nur ... sondern auch.'),
  ],
  fortgeschritten: [
    qq('"Je länger ich schlafe, ___ müder bin ich."', 'desto', ['denn', 'dass'], '"je ... desto" ikilisi.'),
    qq('"Er hat viel gelernt, ___ er die Prüfung bestanden hat."', 'sodass', ['obwohl', 'denn'], '"sodass" sonuç yan cümlesi kurar.'),
    qq('"Man spart Geld, ___ man weniger kauft."', 'indem', ['obwohl', 'bevor'], '"indem" = -erek, yöntem bildirir.'),
    qq('"Das Essen ist ___ gut, aber teuer."', 'zwar', ['weder', 'je'], '"zwar ... aber" ikilisi.'),
    qq('"Es war anstrengend; ___ hat es Spaß gemacht."', 'dennoch', ['sodass', 'indem'], '"dennoch" = buna rağmen.'),
    qq('Hangi cümle YANLIŞ?', 'Es regnete stark, sodass blieben wir zu Hause.', ['Es regnete stark, sodass wir zu Hause blieben.', 'Es regnete, infolgedessen blieben wir zu Hause.'], '"sodass" yan cümle kurar: fiil sonda (blieben).'),
  ],
};


// Sentence-combining tasks: the learner builds the joined sentence with the given connector.
const COMBINE: Record<string, { a: string; b: string; conn: string; result: string; tr: string }[]> = {
  'weil-denn': [
    { a: 'Ich bleibe zu Hause.', b: 'Ich bin krank.', conn: 'weil', result: 'Ich bleibe zu Hause, weil ich krank bin.', tr: 'Hasta olduğum için evde kalıyorum.' },
    { a: 'Er kommt nicht.', b: 'Er hat keine Zeit.', conn: 'denn', result: 'Er kommt nicht, denn er hat keine Zeit.', tr: 'Gelmiyor, çünkü vakti yok.' },
  ],
  deshalb: [
    { a: 'Ich habe Hunger.', b: 'Ich esse ein Brot.', conn: 'deshalb', result: 'Ich habe Hunger, deshalb esse ich ein Brot.', tr: 'Açım, bu yüzden ekmek yiyorum.' },
    { a: 'Es regnet.', b: 'Wir bleiben zu Hause.', conn: 'deswegen', result: 'Es regnet, deswegen bleiben wir zu Hause.', tr: 'Yağmur yağıyor, bu nedenle evde kalıyoruz.' },
  ],
  'dass-ob': [
    { a: 'Ich glaube.', b: 'Er hat recht.', conn: 'dass', result: 'Ich glaube, dass er recht hat.', tr: 'Onun haklı olduğunu düşünüyorum.' },
    { a: 'Ich weiß nicht.', b: 'Kommt er heute?', conn: 'ob', result: 'Ich weiß nicht, ob er heute kommt.', tr: 'Bugün gelip gelmeyeceğini bilmiyorum.' },
  ],
  'aber-trotzdem': [
    { a: 'Es regnet.', b: 'Wir gehen spazieren.', conn: 'trotzdem', result: 'Es regnet, trotzdem gehen wir spazieren.', tr: 'Yağmur yağıyor, buna rağmen yürüyüşe çıkıyoruz.' },
    { a: 'Ich gehe zur Arbeit.', b: 'Ich bin müde.', conn: 'obwohl', result: 'Ich gehe zur Arbeit, obwohl ich müde bin.', tr: 'Yorgun olmama rağmen işe gidiyorum.' },
  ],
  zeit: [
    { a: 'Ich esse.', b: 'Ich höre Musik.', conn: 'während', result: 'Ich höre Musik, während ich esse.', tr: 'Yemek yerken müzik dinliyorum.' },
    { a: 'Ich dusche.', b: 'Ich gehe zur Arbeit.', conn: 'bevor', result: 'Ich dusche, bevor ich zur Arbeit gehe.', tr: 'İşe gitmeden önce duş alıyorum.' },
  ],
  bedingung: [
    { a: 'Ich lerne Deutsch.', b: 'Ich will in Deutschland arbeiten.', conn: 'um ... zu', result: 'Ich lerne Deutsch, um in Deutschland zu arbeiten.', tr: 'Almanya\'da çalışmak için Almanca öğreniyorum.' },
    { a: 'Es regnet.', b: 'Wir bleiben zu Hause.', conn: 'falls', result: 'Falls es regnet, bleiben wir zu Hause.', tr: 'Yağmur yağarsa evde kalırız.' },
  ],
  ekleme: [
    { a: 'Ich bin müde.', b: 'Ich habe Hunger.', conn: 'außerdem', result: 'Ich bin müde, außerdem habe ich Hunger.', tr: 'Yorgunum, ayrıca açım.' },
    { a: 'Er spricht Türkisch.', b: 'Er spricht Deutsch.', conn: 'sowohl ... als auch', result: 'Er spricht sowohl Türkisch als auch Deutsch.', tr: 'O hem Türkçe hem Almanca konuşuyor.' },
  ],
  fortgeschritten: [
    { a: 'Man lernt Wörter.', b: 'Man liest viel.', conn: 'indem', result: 'Man lernt Wörter, indem man viel liest.', tr: 'Çok okuyarak kelime öğrenilir.' },
    { a: 'Du übst mehr.', b: 'Du wirst besser.', conn: 'je ... desto', result: 'Je mehr du übst, desto besser wirst du.', tr: 'Ne kadar çok çalışırsan o kadar iyi olursun.' },
  ],
};

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const plain = (t: string) => t.replace(/[{}]/g, '');

export function buildConnectorExercises(group: ConnectorGroup): Exercise[] {
  const allForms = Array.from(new Set(CONNECTOR_GROUPS.flatMap((g) => g.items.map((i) => i.form))));
  const out: Exercise[] = [];
  const tag = `Bağlaç: ${group.titleTr}`;

  group.items.forEach((item, idx) => {
    const ref = `conn:${group.id}:${idx}`;
    const base = { level: group.level, topicTag: tag, refId: ref };
    const sentence = plain(item.template);
    const atStart = item.template.trim().startsWith('{');
    const fix = (x: string) => (atStart ? x.charAt(0).toUpperCase() + x.slice(1) : x);

    // meaning (word -> Turkish)
    const wrongMeanings = shuffle(
      Array.from(new Set(CONNECTOR_GROUPS.flatMap((g) => g.items.map((i) => i.meaningTr)).filter((m) => m !== item.meaningTr)))
    ).slice(0, 3);
    out.push({
      ...base,
      id: `conn_${group.id}_${idx}_mc`,
      type: 'multiple_choice',
      instructionTr: 'Bu bağlacın anlamı nedir?',
      prompt: item.word,
      options: shuffle([item.meaningTr, ...wrongMeanings]),
      correctAnswer: item.meaningTr,
      explanationTr: `${item.word} = ${item.meaningTr}. Örnek: ${sentence} (${item.exampleTr})`,
    } as Exercise);

    // fill blank (choose the connector)
    const sameGroup = group.items.map((i) => i.form).filter((f) => f !== item.form);
    const others = allForms.filter((f) => f !== item.form && !sameGroup.includes(f));
    const wrong = Array.from(new Set([...shuffle(sameGroup).slice(0, 3), ...shuffle(others)])).slice(0, 3);
    out.push({
      ...base,
      id: `conn_${group.id}_${idx}_fill`,
      type: 'fill_blank',
      instructionTr: 'Boşluğa uygun bağlacı seçin:',
      sentenceWithBlank: item.template.replace(/\{[^}]+\}/, '___'),
      turkishTranslation: item.exampleTr,
      options: shuffle([fix(item.form), ...wrong.map(fix)]),
      correctAnswer: fix(item.form),
      explanationTr: `${sentence} (${item.exampleTr})`,
    } as Exercise);

    // word order (sentence builder)
    const words = sentence.split(' ');
    if (words.length >= 4 && words.length <= 11) {
      out.push({
        ...base,
        id: `conn_${group.id}_${idx}_order`,
        type: 'sentence_builder',
        instructionTr: 'Cümleyi doğru kelime sırasıyla kurun:',
        turkishPrompt: item.exampleTr,
        correctGermanSentence: sentence,
        scrambledWords: words,
        explanationTr: `${sentence} (Kural: ${group.formulaDe})`,
      } as Exercise);
    }

    // translate into German using the connector (production)
    out.push({
      ...base,
      id: `conn_${group.id}_${idx}_translate`,
      type: 'typing',
      mode: 'sentence',
      threshold: 88,
      instructionTr: 'Türkçe cümleyi Almancaya çevirin (bağlacı kullanın):',
      promptTr: item.exampleTr,
      hintTr: `Bağlaç: ${item.word}`,
      answer: sentence,
      explanationTr: `${sentence} (Kural: ${group.formulaDe})`,
    } as Exercise);

    // spelling the connector
    if (/^[a-zäöüß]+$/i.test(item.form)) {
      out.push({
        ...base,
        id: `conn_${group.id}_${idx}_type`,
        type: 'typing',
        mode: 'word',
        instructionTr: 'Bağlacı Almanca yazın:',
        promptTr: item.meaningTr,
        hintTr: `${item.form.length} harf, "${item.form.charAt(0)}" ile başlar`,
        answer: item.form,
        explanationTr: `${item.form} = ${item.meaningTr}. ${sentence}`,
      } as Exercise);
    }
  });

  // combine two sentences with the connector
  (COMBINE[group.id] || []).forEach((c, i) => {
    const words = c.result.split(' ');
    out.push({
      level: group.level,
      topicTag: tag,
      refId: `conn:${group.id}:rules`,
      id: `conn_${group.id}_combine${i}`,
      type: 'sentence_builder',
      instructionTr: `Cümleleri "${c.conn}" ile birleştirin:`,
      turkishPrompt: `${c.a}  +  ${c.b}`,
      correctGermanSentence: c.result,
      scrambledWords: words,
      explanationTr: `${c.result} (${c.tr})`,
    } as Exercise);
  });

  // hand-written word-order / rule questions
  [...group.quiz, ...(EXTRA_QUIZ[group.id] || [])].forEach((q, i) => {
    out.push({
      ...base2(group, tag),
      refId: `conn:${group.id}:rules`,
      id: `conn_${group.id}_q${i}`,
      type: 'multiple_choice',
      instructionTr: 'Kuralı uygulayın:',
      prompt: q.q,
      options: shuffle(q.options),
      correctAnswer: q.answer,
      explanationTr: q.explanationTr,
    } as Exercise);
  });

  return out;
}

export function buildLevelConnectorExercises(level: CEFRLevel): Exercise[] {
  return CONNECTOR_GROUPS.filter((g) => g.level === level).flatMap((g) => buildConnectorExercises(g));
}

function base2(group: ConnectorGroup, tag: string) {
  return { level: group.level, topicTag: tag };
}

/** One review question for a connector item (or for the group's word-order rules). */
export function buildReviewExerciseForConnector(refId: string, box: number, seed: number): Exercise | null {
  const [, groupId, key] = refId.split(':');
  const group = CONNECTOR_GROUPS.find((g) => g.id === groupId);
  if (!group) return null;
  const all = buildConnectorExercises(group);
  let pool: Exercise[];
  if (key === 'rules') {
    pool = all.filter((e) => /_(q\d+|combine\d+)$/.test(e.id));
  } else {
    const mine = all.filter((e) => e.refId === refId);
    const easy = mine.filter((e) => /_(mc|fill)$/.test(e.id));
    const hard = mine.filter((e) => /_(order|type|translate)$/.test(e.id));
    pool = box <= 1 ? easy : box <= 3 ? [...easy, ...hard] : hard;
    if (pool.length === 0) pool = mine;
  }
  if (pool.length === 0) return null;
  const ex = pool[seed % pool.length];
  return { ...ex, id: `${ex.id}_r${seed}` } as Exercise;
}
