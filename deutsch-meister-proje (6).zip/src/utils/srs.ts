import { SrsEntry, UserProfile } from '../types';

export const dayKey = (d: Date = new Date()): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export interface SrsItem {
  refId: string;
  entry: SrsEntry;
}

/** Items that should be reviewed today, weakest and most-missed first. */
export function getDueItems(profile: UserProfile): SrsItem[] {
  const today = dayKey();
  return Object.entries(profile.srs || {})
    .filter(([, e]) => e.due <= today)
    .map(([refId, entry]) => ({ refId, entry }))
    .sort((a, b) => a.entry.box - b.entry.box || b.entry.wrong - a.entry.wrong);
}

/** Weak items that are not due yet (used to fill up a short session). */
export function getWeakItems(profile: UserProfile): SrsItem[] {
  const today = dayKey();
  return Object.entries(profile.srs || {})
    .filter(([, e]) => e.due > today && e.box <= 2)
    .map(([refId, entry]) => ({ refId, entry }))
    .sort((a, b) => b.entry.wrong - a.entry.wrong || a.entry.box - b.entry.box);
}

export function getSrsStats(profile: UserProfile) {
  const all = Object.values(profile.srs || {});
  return {
    tracked: all.length,
    due: getDueItems(profile).length,
    weak: all.filter((e) => e.box <= 1 && e.wrong > 0).length,
    strong: all.filter((e) => e.box >= 4).length,
  };
}

/** Memory strength (0 to 5) and number of due items for a group of word ids. */
export function groupStrength(profile: UserProfile, ids: string[]) {
  const srs = profile.srs || {};
  const today = dayKey();
  let known = 0;
  let sum = 0;
  let due = 0;
  ids.forEach((id) => {
    const e = srs[id];
    if (e) {
      known += 1;
      sum += e.box;
      if (e.due <= today) due += 1;
    }
  });
  return { known, avg: known ? sum / ids.length : 0, due };
}
