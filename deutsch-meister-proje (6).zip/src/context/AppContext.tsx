import React, { createContext, useContext, useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { ALL_BADGES } from '../data/badges';
import { CEFRLevel, UserProfile, UserWordCard } from '../types';
import { playLevelUpSound } from '../utils/audio';

const STORAGE_KEY = 'DEUTSCH_MEISTER_USER_STATE_V1';

const getTodayString = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const DEFAULT_PROFILE: UserProfile = {
  name: 'Almanca Kaşifi',
  xp: 0,
  streak: 1,
  lastActiveDate: getTodayString(),
  dailyGoalXp: 30,
  todayXp: 0,
  completedLessons: [],
  unlockedBadges: [],
  wordCards: {},
  soundEnabled: true,
  speechSpeed: 0.9,
  activeDates: [getTodayString()],
};

interface CompletionModalData {
  lessonTitle: string;
  earnedXp: number;
  correctCount: number;
  totalQuestions: number;
  newBadges: string[];
}

interface AppContextType {
  profile: UserProfile;
  currentLevel: CEFRLevel;
  activeTab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words';
  activeLessonId: string | null;
  activeGrammarId: string | null;
  activeDialogueId: string | null;
  completionData: CompletionModalData | null;
  isPlacementTestOpen: boolean;
  setCurrentLevel: (level: CEFRLevel) => void;
  setPlacementLevel: (level: CEFRLevel) => void;
  markLevelExamPassed: (level: CEFRLevel) => void;
  markWordSetDone: (setId: string) => void;
  recordAnswer: (refId: string, correct: boolean) => void;
  setActiveTab: (tab: 'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words') => void;
  openLesson: (lessonId: string) => void;
  closeLesson: () => void;
  openGrammar: (grammarId: string) => void;
  closeGrammar: () => void;
  openDialogue: (dialogueId: string) => void;
  closeDialogue: () => void;
  openPlacementTest: () => void;
  closePlacementTest: () => void;
  closeCompletionModal: () => void;
  completeLessonSession: (lessonId: string, earnedXp: number, correct: number, total: number) => void;
  addXp: (amount: number) => void;
  updateWordStatus: (wordId: string, status: 'learning' | 'mastered') => void;
  toggleSound: () => void;
  setSpeechSpeed: (speed: number) => void;
  setDailyGoalXp: (goal: number) => void;
  exportData: () => string;
  importData: (jsonData: string) => boolean;
  resetProgress: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfile] = useState<UserProfile>(() => {
    if (typeof window === 'undefined') return DEFAULT_PROFILE;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const today = getTodayString();
        // Check streak and todayXp reset
        if (parsed.lastActiveDate !== today) {
          const lastDate = new Date(parsed.lastActiveDate);
          const currentDate = new Date(today);
          const diffDays = Math.round((currentDate.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));
          
          let newStreak = parsed.streak || 1;
          if (diffDays === 1) {
            // Consecutive day
            newStreak += 1;
          } else if (diffDays > 1) {
            // Missed a day
            newStreak = 1;
          }

          const updatedDates = Array.from(new Set([...(parsed.activeDates || []), today]));

          return {
            ...parsed,
            todayXp: 0,
            streak: newStreak,
            lastActiveDate: today,
            activeDates: updatedDates,
          };
        }
        return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse saved user profile:', e);
    }
    return DEFAULT_PROFILE;
  });

  const [currentLevel, setCurrentLevel] = useState<CEFRLevel>('A1');
  const [activeTab, setActiveTab] = useState<'learn' | 'flashcards' | 'grammar' | 'dialogues' | 'practice' | 'profile' | 'dtz' | 'words'>('learn');
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [activeGrammarId, setActiveGrammarId] = useState<string | null>(null);
  const [activeDialogueId, setActiveDialogueId] = useState<string | null>(null);
  const [completionData, setCompletionData] = useState<CompletionModalData | null>(null);
  const [isPlacementTestOpen, setIsPlacementTestOpen] = useState(false);

  // Sync profile to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.warn('Failed to save profile to localStorage:', e);
    }
  }, [profile]);

  // Check and unlock badges
  const checkNewBadges = (updated: UserProfile): string[] => {
    const newlyUnlocked: string[] = [];
    const currentBadges = new Set(updated.unlockedBadges);

    ALL_BADGES.forEach((b) => {
      if (currentBadges.has(b.id)) return;

      let shouldUnlock = false;
      if (b.id === 'first_lesson' && updated.completedLessons.length >= 1) shouldUnlock = true;
      if (b.id === 'streak_3' && updated.streak >= 3) shouldUnlock = true;
      if (b.id === 'streak_7' && updated.streak >= 7) shouldUnlock = true;
      if (b.id === 'xp_100' && updated.xp >= 100) shouldUnlock = true;
      if (b.id === 'xp_500' && updated.xp >= 500) shouldUnlock = true;
      if (b.id === 'words_25' && Object.keys(updated.wordCards).length >= 25) shouldUnlock = true;

      if (shouldUnlock) {
        newlyUnlocked.push(b.id);
      }
    });

    return newlyUnlocked;
  };

  const addXp = (amount: number) => {
    setProfile((prev) => {
      const newXp = prev.xp + amount;
      const newTodayXp = prev.todayXp + amount;
      const updated = {
        ...prev,
        xp: newXp,
        todayXp: newTodayXp,
      };
      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...prev.unlockedBadges, ...newBadges];
      }
      return updated;
    });
  };

  const completeLessonSession = (lessonId: string, earnedXp: number, correct: number, total: number) => {
    setProfile((prev) => {
      const alreadyCompleted = prev.completedLessons.includes(lessonId);
      const newCompleted = alreadyCompleted ? prev.completedLessons : [...prev.completedLessons, lessonId];
      const newXp = prev.xp + earnedXp;
      const newTodayXp = prev.todayXp + earnedXp;

      const updated = {
        ...prev,
        completedLessons: newCompleted,
        xp: newXp,
        todayXp: newTodayXp,
      };

      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...prev.unlockedBadges, ...newBadges];
      }

      setCompletionData({
        lessonTitle: lessonId,
        earnedXp,
        correctCount: correct,
        totalQuestions: total,
        newBadges,
      });

      if (prev.soundEnabled) {
        playLevelUpSound(true);
      }

      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#22c55e', '#38bdf8', '#facc15', '#f43f5e'],
        });
      } catch {
        // ignore
      }

      return updated;
    });
  };

  const updateWordStatus = (wordId: string, status: 'learning' | 'mastered') => {
    setProfile((prev) => {
      const existing = prev.wordCards[wordId] || {
        wordId,
        status: 'learning',
        reviewsCount: 0,
        lastReviewedAt: Date.now(),
        intervalDays: 1,
      };

      const newInterval = status === 'mastered' ? Math.max(existing.intervalDays * 2, 3) : 1;
      const updatedCard: UserWordCard = {
        ...existing,
        status,
        reviewsCount: existing.reviewsCount + 1,
        lastReviewedAt: Date.now(),
        intervalDays: newInterval,
      };

      const updated = {
        ...prev,
        wordCards: {
          ...prev.wordCards,
          [wordId]: updatedCard,
        },
      };

      const newBadges = checkNewBadges(updated);
      if (newBadges.length > 0) {
        updated.unlockedBadges = [...prev.unlockedBadges, ...newBadges];
      }

      return updated;
    });
  };

  const setPlacementLevel = (level: CEFRLevel) => {
    const order: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
    setProfile((prev) => {
      const prevIdx = prev.placementLevel ? order.indexOf(prev.placementLevel) : 0;
      if (order.indexOf(level) <= prevIdx) return prev;
      return { ...prev, placementLevel: level };
    });
  };

  const markLevelExamPassed = (level: CEFRLevel) => {
    setProfile((prev) => {
      const list = prev.passedLevelExams || [];
      if (list.includes(level)) return prev;
      return { ...prev, passedLevelExams: [...list, level] };
    });
  };

  // Spaced repetition (Leitner boxes): right answer moves the item up a box, a wrong answer sends it back to box 0.
  const recordAnswer = (refId: string, correct: boolean) => {
    const INTERVALS = [0, 1, 2, 4, 8, 16]; // days until next review per box
    const fmt = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    setProfile((prev) => {
      const today = new Date();
      const old = (prev.srs || {})[refId] || { box: 0, due: fmt(today), right: 0, wrong: 0, last: fmt(today) };
      const box = correct ? Math.min(5, old.box + 1) : 0;
      const dueDate = new Date(today);
      dueDate.setDate(today.getDate() + INTERVALS[box]);
      const entry = {
        box,
        due: fmt(dueDate),
        right: old.right + (correct ? 1 : 0),
        wrong: old.wrong + (correct ? 0 : 1),
        last: fmt(today),
      };
      return { ...prev, srs: { ...(prev.srs || {}), [refId]: entry } };
    });
  };

  const markWordSetDone = (setId: string) => {
    setProfile((prev) => {
      const list = prev.completedWordSets || [];
      if (list.includes(setId)) return prev;
      return { ...prev, completedWordSets: [...list, setId] };
    });
  };

  const toggleSound = () => {
    setProfile((prev) => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  };

  const setSpeechSpeed = (speed: number) => {
    setProfile((prev) => ({ ...prev, speechSpeed: speed }));
  };

  const setDailyGoalXp = (goal: number) => {
    setProfile((prev) => ({ ...prev, dailyGoalXp: goal }));
  };

  const exportData = (): string => {
    return JSON.stringify(profile, null, 2);
  };

  const importData = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed && typeof parsed.xp === 'number') {
        setProfile(parsed);
        return true;
      }
    } catch {
      // ignore
    }
    return false;
  };

  const resetProgress = () => {
    setProfile(DEFAULT_PROFILE);
    localStorage.removeItem(STORAGE_KEY);
  };

  const openLesson = (lessonId: string) => {
    setActiveLessonId(lessonId);
  };

  const closeLesson = () => {
    setActiveLessonId(null);
  };

  const openGrammar = (grammarId: string) => {
    setActiveGrammarId(grammarId);
  };

  const closeGrammar = () => {
    setActiveGrammarId(null);
  };

  const openDialogue = (dialogueId: string) => {
    setActiveDialogueId(dialogueId);
  };

  const closeDialogue = () => {
    setActiveDialogueId(null);
  };

  const closeCompletionModal = () => {
    setCompletionData(null);
    setActiveLessonId(null);
  };

  const openPlacementTest = () => {
    setIsPlacementTestOpen(true);
  };

  const closePlacementTest = () => {
    setIsPlacementTestOpen(false);
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        currentLevel,
        activeTab,
        activeLessonId,
        activeGrammarId,
        activeDialogueId,
        completionData,
        isPlacementTestOpen,
        setCurrentLevel,
        setPlacementLevel,
        markLevelExamPassed,
        markWordSetDone,
        recordAnswer,
        setActiveTab,
        openLesson,
        closeLesson,
        openGrammar,
        closeGrammar,
        openDialogue,
        closeDialogue,
        openPlacementTest,
        closePlacementTest,
        closeCompletionModal,
        completeLessonSession,
        addXp,
        updateWordStatus,
        toggleSound,
        setSpeechSpeed,
        setDailyGoalXp,
        exportData,
        importData,
        resetProgress,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
