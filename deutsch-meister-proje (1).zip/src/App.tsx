import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { LearnView } from './components/learn/LearnView';
import { FlashcardsView } from './components/flashcards/FlashcardsView';
import { GrammarView } from './components/grammar/GrammarView';
import { DialoguesView } from './components/dialogues/DialoguesView';
import { PracticeArena } from './components/practice/PracticeArena';
import { ProfileView } from './components/profile/ProfileView';
import { DTZView } from './components/dtz/DTZView';
import { WordQuestView } from './components/words/WordQuestView';
import { LessonModal } from './components/lesson/LessonModal';
import { GrammarDetailModal } from './components/grammar/GrammarDetailModal';
import { DialoguePlayerModal } from './components/dialogues/DialoguePlayerModal';
import { CompletionModal } from './components/modals/CompletionModal';
import { PlacementTestModal } from './components/placement/PlacementTestModal';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { ALL_UNITS_BY_LEVEL } from './data/levels';
import { GRAMMAR_TOPICS } from './data/grammar';
import { REAL_LIFE_DIALOGUES } from './data/dialogues';
import { Lesson } from './types';

function MainApp() {
  const {
    activeTab,
    activeLessonId,
    closeLesson,
    activeGrammarId,
    closeGrammar,
    activeDialogueId,
    closeDialogue,
    isPlacementTestOpen,
    closePlacementTest,
  } = useApp();

  // Find active lesson if open
  let currentActiveLesson: Lesson | null = null;
  if (activeLessonId) {
    for (const lvlUnits of Object.values(ALL_UNITS_BY_LEVEL)) {
      for (const u of lvlUnits) {
        const found = u.lessons.find((l) => l.id === activeLessonId);
        if (found) {
          currentActiveLesson = found;
          break;
        }
      }
      if (currentActiveLesson) break;
    }
  }

  // Find active grammar topic if open
  const currentActiveGrammar = activeGrammarId
    ? GRAMMAR_TOPICS.find((g) => g.id === activeGrammarId) || null
    : null;

  // Find active dialogue if open
  const currentActiveDialogue = activeDialogueId
    ? REAL_LIFE_DIALOGUES.find((d) => d.id === activeDialogueId) || null
    : null;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-emerald-200 dark:selection:bg-emerald-900">
      {/* Top Bar */}
      <Header />

      <div className="flex-1 flex max-w-7xl w-full mx-auto pb-20 md:pb-8">
        {/* Left Desktop Sidebar */}
        <Sidebar />

        {/* Center Content View */}
        <main className="flex-1 min-w-0 overflow-y-auto">
          {activeTab === 'learn' && <LearnView />}
          {activeTab === 'dtz' && <DTZView />}
          {activeTab === 'words' && <WordQuestView />}
          {activeTab === 'flashcards' && <FlashcardsView />}
          {activeTab === 'grammar' && <GrammarView />}
          {activeTab === 'dialogues' && <DialoguesView />}
          {activeTab === 'practice' && <PracticeArena />}
          {activeTab === 'profile' && <ProfileView />}
        </main>
      </div>

      {/* Bottom Nav on Mobile */}
      <BottomNav />

      {/* Modals */}
      {currentActiveLesson && (
        <LessonModal lesson={currentActiveLesson} onClose={closeLesson} />
      )}

      {currentActiveGrammar && (
        <GrammarDetailModal topic={currentActiveGrammar} onClose={closeGrammar} />
      )}

      {currentActiveDialogue && (
        <DialoguePlayerModal dialogue={currentActiveDialogue} onClose={closeDialogue} />
      )}

      <CompletionModal />

      {isPlacementTestOpen && (
        <PlacementTestModal onClose={closePlacementTest} />
      )}

      {/* Offline Toast Indicator */}
      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
