import React from 'react';
import {
  BookOpen,
  Layers,
  GraduationCap,
  MessageSquare,
  Dumbbell,
  User,
  Award,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();

  const navItems = [
    { id: 'learn', label: 'Öğren', icon: BookOpen },
    { id: 'dtz', label: 'Sınav', icon: Award },
    { id: 'words', label: 'Kelime', icon: Layers },
    { id: 'grammar', label: 'Dil Bilgisi', icon: GraduationCap },
    { id: 'practice', label: 'Test', icon: Dumbbell },
    { id: 'profile', label: 'Profil', icon: User },
  ] as const;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1 flex items-center justify-around shadow-lg">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-bold transition-all cursor-pointer ${
              isActive
                ? 'text-emerald-600 dark:text-emerald-400 scale-105'
                : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
            }`}
          >
            <Icon className="w-5 h-5 mb-0.5" />
            <span className="truncate max-w-[56px]">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
