import React, { useState } from 'react';
import {
  X,
  Volume2,
  CheckCircle2,
  ArrowRight,
  Target,
  Sparkles,
  BarChart3,
  Award,
  Play,
  RotateCcw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PLACEMENT_QUESTIONS, PlacementQuestion } from '../../data/placementQuestions';
import { useApp } from '../../context/AppContext';
import { CEFRLevel } from '../../types';
import { ALL_UNITS_BY_LEVEL, CEFR_LEVEL_DETAILS } from '../../data/levels';
import { speakGerman, playSuccessSound, playClickSound } from '../../utils/audio';
import { MeisterMax } from '../mascot/MeisterMax';

interface PlacementTestModalProps {
  onClose: () => void;
}

interface LevelScores {
  A1: number;
  A2: number;
  B1: number;
  B2: number;
  C1: number;
}

export const PlacementTestModal: React.FC<PlacementTestModalProps> = ({ onClose }) => {
  const { setCurrentLevel, setPlacementLevel, openLesson, addXp, profile } = useApp();

  const [step, setStep] = useState<'intro' | 'testing' | 'result'>('intro');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const currentQ: PlacementQuestion = PLACEMENT_QUESTIONS[currentIndex];
  const totalQuestions = PLACEMENT_QUESTIONS.length;

  const handleStart = () => {
    setAnswers({});
    setCurrentIndex(0);
    setSelectedOption(null);
    setStep('testing');
    playClickSound(profile.soundEnabled);
  };

  const handleSelectOption = (opt: string) => {
    setSelectedOption(opt);
    playClickSound(profile.soundEnabled);
  };

  const handleAudio = (text: string) => {
    speakGerman(text, profile.speechSpeed);
  };

  const handleNextQuestion = () => {
    if (!selectedOption) return;

    const newAnswers = { ...answers, [currentQ.id]: selectedOption };
    setAnswers(newAnswers);
    setSelectedOption(null);

    if (currentIndex + 1 < totalQuestions) {
      setCurrentIndex((i) => i + 1);
    } else {
      // Finished all questions!
      setStep('result');
      addXp(50); // 50 XP bonus for completing placement test
      playSuccessSound(profile.soundEnabled);
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
          colors: ['#22c55e', '#38bdf8', '#fbbf24', '#a855f7'],
        });
      } catch {
        // ignore
      }
    }
  };

  // Calculate scores per level
  const calculateResults = () => {
    const scores: LevelScores = { A1: 0, A2: 0, B1: 0, B2: 0, C1: 0 };
    const maxPerLevel = { A1: 3, A2: 3, B1: 3, B2: 3, C1: 3 };

    PLACEMENT_QUESTIONS.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        scores[q.level] = (scores[q.level] || 0) + 1;
      }
    });

    const totalCorrect = Object.values(scores).reduce((a, b) => a + b, 0);

    // Determine suggested level based on CEFR threshold mastery
    let suggestedLevel: CEFRLevel = 'A1';
    let suggestedUnitId = 'a1_unit_1';
    let suggestedLessonId = 'a1_u1_l1';
    let reasoningTr = '';

    if (scores.A1 < 2) {
      suggestedLevel = 'A1';
      suggestedUnitId = 'a1_unit_1';
      suggestedLessonId = 'a1_u1_l1';
      reasoningTr =
        'Temel kelimeler, selamlaşma ve basit fiil çekimlerinden başlayarak sağlam bir temel atmanız en doğrusu.';
    } else if (scores.A2 < 2) {
      suggestedLevel = 'A2';
      suggestedUnitId = 'a2_unit_1';
      suggestedLessonId = 'a2_u1_l1';
      reasoningTr =
        'A1 seviyesindeki temelleriniz iyi görünüyor! Geçmiş zaman (Perfekt) ve günlük yaşam diyaloglarıyla A2 seviyesinden devam etmeniz önerilir.';
    } else if (scores.B1 < 2) {
      suggestedLevel = 'B1';
      suggestedUnitId = 'b1_unit_1';
      suggestedLessonId = 'b1_u1_l1';
      reasoningTr =
        'Temel Almancayı tamamlamışsınız! Yan cümleler (weil, dass, wenn) ve iş hayatı konularıyla B1 seviyesine hazırsınız.';
    } else if (scores.B2 < 2) {
      suggestedLevel = 'B2';
      suggestedUnitId = 'b2_unit_1';
      suggestedLessonId = 'b2_u1_l1';
      reasoningTr =
        'Tebrikler, bağımsız bir kullanıcı seviyesindesiniz! Pasif yapı, N-Deklination ve resmi yazışmalarla B2 seviyesinde uzmanlaşabilirsiniz.';
    } else {
      suggestedLevel = 'C1';
      suggestedUnitId = 'c1_unit_1';
      suggestedLessonId = 'c1_u1_l1';
      reasoningTr =
        'Mükemmel bir Almanca seviyeniz var! Nominal stil, Konjunktiv I ve akademik Almanca konularını içeren C1 ileri seviyesine doğrudan başlayabilirsiniz.';
    }

    // Find the suggested unit object
    const targetUnit = (ALL_UNITS_BY_LEVEL[suggestedLevel] || []).find(
      (u) => u.id === suggestedUnitId
    ) || ALL_UNITS_BY_LEVEL[suggestedLevel][0];

    const targetLesson =
      targetUnit?.lessons.find((l) => l.id === suggestedLessonId) || targetUnit?.lessons[0];

    return {
      scores,
      maxPerLevel,
      totalCorrect,
      suggestedLevel,
      suggestedUnit: targetUnit,
      suggestedLesson: targetLesson,
      reasoningTr,
    };
  };

  const results = step === 'result' ? calculateResults() : null;

  const handleApplyRecommendation = () => {
    if (!results) return;
    setPlacementLevel(results.suggestedLevel);
    setCurrentLevel(results.suggestedLevel);
    onClose();
    if (results.suggestedLesson) {
      openLesson(results.suggestedLesson.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900 dark:text-white leading-tight">
                Almanca Seviye Tespit Sınavı
              </h3>
              <p className="text-xs text-slate-400">A1 - C1 Düzey Belirleme & Ders Önerisi</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content based on step */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* STEP 1: INTRO */}
          {step === 'intro' && (
            <div className="text-center py-4 space-y-6 max-w-lg mx-auto">
              <MeisterMax
                mood="encouraging"
                size="lg"
                speechBubble="Almanca seviyeni 5 dakikada belirleyip sana en uygun dersten başlatalım!"
                className="justify-center mb-2"
              />

              <div className="space-y-2">
                <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  Hangi Seviyeden Başlamalısın?
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  Bu test A1 (Başlangıç) seviyesinden C1 (İleri) seviyesine kadar özenle hazırlanmış <strong>15 sorudan</strong> oluşur. Sonuçlarınıza göre size en uygun üniteyi ve dersi otomatik olarak öneririz.
                </p>
              </div>

              {/* Feature pills */}
              <div className="grid grid-cols-3 gap-2 text-left pt-2">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700">
                  <span className="text-base block mb-0.5">⏱️</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">5 Dakika</span>
                  <span className="text-[10px] text-slate-400">Hızlı & Etkili</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700">
                  <span className="text-base block mb-0.5">🎯</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">A1 - C1</span>
                  <span className="text-[10px] text-slate-400">Tüm Seviyeler</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700">
                  <span className="text-base block mb-0.5">⚡</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">+50 XP</span>
                  <span className="text-[10px] text-slate-400">Ödül Puanı</span>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleStart}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm shadow-[0_4px_0_#15803d] active:shadow-none active:translate-y-1 transition flex items-center justify-center gap-2 mx-auto cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white" />
                  <span>Seviye Tespit Sınavını Başlat</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: TESTING */}
          {step === 'testing' && currentQ && (
            <div className="space-y-6 max-w-xl mx-auto">
              {/* Progress and Level badge */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`px-2 py-0.5 rounded-md font-black text-[10px] ${
                        currentQ.level === 'A1'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : currentQ.level === 'A2'
                          ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                          : currentQ.level === 'B1'
                          ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                          : currentQ.level === 'B2'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      }`}
                    >
                      {currentQ.level} Seviyesi
                    </span>
                    <span className="text-slate-400">• {currentQ.category}</span>
                  </div>
                  <span className="text-slate-500">
                    Soru {currentIndex + 1} / {totalQuestions}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                    style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
                  />
                </div>
              </div>

              {/* Question Box */}
              <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400 block">
                  {currentQ.instructionTr}
                </span>
                <div className="flex items-center justify-between gap-3">
                  <p className="text-lg sm:text-xl font-black text-slate-900 dark:text-white leading-relaxed">
                    {currentQ.promptDe}
                  </p>
                  {(currentQ.audioText || currentQ.promptDe) && (
                    <button
                      onClick={() => handleAudio(currentQ.audioText || currentQ.promptDe)}
                      className="p-2 rounded-xl text-emerald-600 bg-white dark:bg-slate-700 shadow-2xs hover:bg-emerald-50 transition shrink-0 cursor-pointer"
                      title="Sesi Dinle"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                {currentQ.turkishHint && (
                  <span className="text-xs text-slate-400 italic block mt-1">
                    İpucu: {currentQ.turkishHint}
                  </span>
                )}
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                {currentQ.options.map((option, idx) => {
                  const isSelected = selectedOption === option;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(option)}
                      className={`w-full p-4 rounded-2xl font-bold text-sm text-left border-2 transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 shadow-sm translate-y-0.5'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:border-slate-300 shadow-[0_3px_0_#e2e8f0] dark:shadow-[0_3px_0_#334155] active:translate-y-0.5 active:shadow-none'
                      }`}
                    >
                      <span>{option}</span>
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center text-xs ${
                          isSelected
                            ? 'border-emerald-500 bg-emerald-500 text-white'
                            : 'border-slate-300'
                        }`}
                      >
                        {isSelected && '✓'}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Next Button */}
              <div className="pt-2">
                <button
                  disabled={!selectedOption}
                  onClick={handleNextQuestion}
                  className={`w-full py-3.5 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    selectedOption
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-[0_4px_0_#15803d] active:shadow-none active:translate-y-1'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span>{currentIndex + 1 < totalQuestions ? 'Sonraki Soru' : 'Testi Tamamla'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: RESULTS & RECOMMENDATION */}
          {step === 'result' && results && (
            <div className="space-y-6 max-w-lg mx-auto py-2">
              <div className="text-center space-y-1">
                <MeisterMax mood="celebrating" size="md" className="justify-center mb-1" />
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                  Seviye Tespit Sonucunuz Hazır! 🎓
                </h3>
                <p className="text-xs text-slate-500">
                  Toplam 15 sorudan <strong>{results.totalCorrect}</strong> tanesini doğru cevapladınız. (+50 XP Kazandınız!)
                </p>
              </div>

              {/* CEFR Level Breakdown Bars */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2.5">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider block">
                  Seviyelere Göre Başarı Dağılımı:
                </span>
                {(['A1', 'A2', 'B1', 'B2', 'C1'] as CEFRLevel[]).map((lvl) => {
                  const correct = results.scores[lvl] || 0;
                  const total = results.maxPerLevel[lvl];
                  const pct = Math.round((correct / total) * 100);

                  return (
                    <div key={lvl} className="space-y-1">
                      <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                        <span>{lvl} Seviyesi</span>
                        <span>{correct} / {total} Doğru (%{pct})</span>
                      </div>
                      <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            pct >= 66 ? 'bg-emerald-500' : pct >= 33 ? 'bg-amber-500' : 'bg-slate-400'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Recommended Starting Point Card */}
              <div className="p-5 rounded-3xl bg-linear-to-r from-emerald-600 to-teal-700 text-white shadow-lg space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold bg-white/20 px-3 py-1 rounded-full uppercase tracking-wider">
                    Önerilen Başlangıç Seviyesi
                  </span>
                  <span className="text-2xl font-black">{results.suggestedLevel}</span>
                </div>

                <div>
                  <h4 className="text-lg font-black">{results.suggestedUnit?.titleTr}</h4>
                  <p className="text-xs text-emerald-100 mt-0.5">
                    İlk Ders: <strong>{results.suggestedLesson?.titleTr}</strong> ({results.suggestedLesson?.titleDe})
                  </p>
                </div>

                <p className="text-xs text-emerald-100 bg-white/10 p-3 rounded-2xl leading-relaxed">
                  💡 {results.reasoningTr}
                </p>

                <button
                  onClick={handleApplyRecommendation}
                  className="w-full py-3.5 rounded-2xl bg-white hover:bg-emerald-50 text-emerald-800 font-black text-sm shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                >
                  <span>Bu Seviyeye Geç ve Derse Başla</span>
                  <ArrowRight className="w-4 h-4 text-emerald-700" />
                </button>
              </div>

              {/* Retake or Close */}
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={handleStart}
                  className="text-xs font-bold text-slate-500 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Testi Yeniden Çöz</span>
                </button>

                <button
                  onClick={onClose}
                  className="text-xs font-bold text-slate-500 hover:text-slate-700 cursor-pointer"
                >
                  Kapat
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
