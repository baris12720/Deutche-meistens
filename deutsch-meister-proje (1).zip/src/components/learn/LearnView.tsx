import React, { useEffect, useState } from 'react';
import { Check, Lock, Star, ChevronRight, Target, Trophy, Headphones } from 'lucide-react';
import { ALL_UNITS_BY_LEVEL, CEFR_LEVEL_DETAILS } from '../../data/levels';
import { useApp } from '../../context/AppContext';
import { MeisterMax } from '../mascot/MeisterMax';
import { CEFRLevel } from '../../types';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { getLevelQuestionPool } from '../../data/questionBank';
import {
  LEVEL_ORDER,
  LessonState,
  getLessonStates,
  isLevelCompleted,
  isLevelUnlocked,
  areLessonsDone,
  EXAM_PASS_RATIO,
  EXAM_MIN_QUESTIONS,
} from '../../utils/progress';

// Zig-zag offsets (px) that make the lesson path wind like a road.
const PATH_OFFSETS = [0, 44, 70, 44, 0, -44, -70, -44];

const LEVEL_THEME: Record<CEFRLevel, { banner: string; node: string; nodeShadow: string }> = {
  A1: { banner: 'from-emerald-500 to-emerald-700', node: 'bg-emerald-500', nodeShadow: 'shadow-[0_6px_0_#047857]' },
  A2: { banner: 'from-sky-500 to-sky-700', node: 'bg-sky-500', nodeShadow: 'shadow-[0_6px_0_#0369a1]' },
  B1: { banner: 'from-indigo-500 to-indigo-700', node: 'bg-indigo-500', nodeShadow: 'shadow-[0_6px_0_#4338ca]' },
  B2: { banner: 'from-amber-500 to-amber-700', node: 'bg-amber-500', nodeShadow: 'shadow-[0_6px_0_#b45309]' },
  C1: { banner: 'from-rose-500 to-rose-700', node: 'bg-rose-500', nodeShadow: 'shadow-[0_6px_0_#be123c]' },
};

export const LearnView: React.FC = () => {
  const { currentLevel, setCurrentLevel, profile, openLesson, openPlacementTest, addXp, setActiveTab, markLevelExamPassed } = useApp();
  const [isLevelTestOpen, setIsLevelTestOpen] = useState(false);
  const [hint, setHint] = useState<string | null>(null);

  useEffect(() => {
    if (!hint) return;
    const t = setTimeout(() => setHint(null), 2400);
    return () => clearTimeout(t);
  }, [hint]);

  const units = ALL_UNITS_BY_LEVEL[currentLevel] || [];
  const levelInfo = CEFR_LEVEL_DETAILS[currentLevel];
  const theme = LEVEL_THEME[currentLevel];
  const levelUnlocked = isLevelUnlocked(currentLevel, profile);
  const levelDone = isLevelCompleted(currentLevel, profile);
  const lessonsDone = areLessonsDone(currentLevel, profile);
  const states = getLessonStates(currentLevel, profile);

  const totalLessons = units.reduce((acc, u) => acc + u.lessons.length, 0);
  const completed = units.reduce(
    (acc, u) => acc + u.lessons.filter((l) => profile.completedLessons.includes(l.id)).length,
    0
  );
  const percent = Math.round((completed / Math.max(1, totalLessons)) * 100);

  const currentLesson = units.flatMap((u) => u.lessons).find((l) => states[l.id] === 'current');
  const nextLevel = LEVEL_ORDER[LEVEL_ORDER.indexOf(currentLevel) + 1] as CEFRLevel | undefined;

  const onNodeClick = (lessonId: string, state: LessonState) => {
    if (state === 'locked') {
      setHint(
        levelUnlocked
          ? 'Bu dersi açmak için önceki dersi tamamla.'
          : 'Bu seviye kilitli. Önceki seviyenin dersleri ve sınavını bitir ya da seviye tespit sınavına gir.'
      );
      return;
    }
    openLesson(lessonId);
  };

  let nodeCounter = 0;

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      {/* Level tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1" role="tablist" aria-label="Seviyeler">
        {LEVEL_ORDER.map((lvl) => {
          const active = lvl === currentLevel;
          const open = isLevelUnlocked(lvl, profile);
          return (
            <button
              key={lvl}
              role="tab"
              aria-selected={active}
              onClick={() => setCurrentLevel(lvl)}
              className={`flex-1 min-w-[64px] h-11 rounded-2xl text-sm font-black flex items-center justify-center gap-1.5 transition active:translate-y-0.5 cursor-pointer ${
                active
                  ? `${LEVEL_THEME[lvl].node} text-white ${LEVEL_THEME[lvl].nodeShadow}`
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-2 border-slate-200 dark:border-slate-700'
              }`}
            >
              {!open && <Lock className="w-3.5 h-3.5" />}
              {lvl}
            </button>
          );
        })}
      </div>

      {/* Level summary */}
      <div className={`mt-4 rounded-3xl bg-linear-to-br ${theme.banner} text-white p-5 flex items-center gap-4`}>
        <div className="min-w-0 flex-1">
          <h2 className="text-lg font-black leading-tight">{levelInfo.nameTr}</h2>
          <p className="text-xs text-white/85 mt-1 leading-relaxed">{levelInfo.descriptionTr}</p>
          <div className="mt-3 flex items-center gap-2">
            <div className="h-3 flex-1 bg-black/25 rounded-full overflow-hidden">
              <div className="h-full bg-yellow-300 rounded-full transition-all duration-500" style={{ width: `${percent}%` }} />
            </div>
            <span className="text-xs font-black tabular-nums">
              {completed}/{totalLessons}
            </span>
          </div>
        </div>
        <div className="shrink-0 hidden sm:block">
          <MeisterMax mood={percent > 50 ? 'celebrating' : 'encouraging'} size="md" />
        </div>
      </div>

      {/* Quick actions */}
      <div className="mt-3 grid grid-cols-2 gap-3">
        <button
          onClick={openPlacementTest}
          className="rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 text-left active:translate-y-0.5 transition cursor-pointer"
        >
          <Target className="w-5 h-5 text-purple-600" />
          <div className="mt-1.5 text-sm font-black text-slate-900 dark:text-white">Seviye tespiti</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">15 soru, kaldığın yeri bul</div>
        </button>
        <button
          onClick={() => setIsLevelTestOpen(true)}
          className="rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 text-left active:translate-y-0.5 transition cursor-pointer"
        >
          <Trophy className="w-5 h-5 text-amber-500" />
          <div className="mt-1.5 text-sm font-black text-slate-900 dark:text-white">{currentLevel} sınavı</div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            {getLevelQuestionPool(currentLevel).length} soruluk havuz
          </div>
        </button>
      </div>

      {!levelUnlocked && (
        <div className="mt-4 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-600 p-4 text-sm text-slate-600 dark:text-slate-300 flex gap-3">
          <Lock className="w-5 h-5 shrink-0 mt-0.5" />
          <p>
            {currentLevel} henüz kilitli. {LEVEL_ORDER[LEVEL_ORDER.indexOf(currentLevel) - 1]} seviyesindeki tüm dersleri ve seviye sınavını (%70)
            bitir ya da seviye tespit sınavıyla doğrudan atla.
          </p>
        </div>
      )}

      {/* Path */}
      <div className="mt-6 space-y-8">
        {units.map((unit) => (
          <section key={unit.id} aria-label={unit.titleTr}>
            <div className={`rounded-2xl bg-linear-to-r ${theme.banner} text-white px-4 py-3 shadow-[0_4px_0_rgba(0,0,0,0.18)]`}>
              <div className="text-xs font-bold text-white/80">Ünite {unit.unitNumber}</div>
              <div className="text-base font-black leading-tight">{unit.titleTr}</div>
              <div className="text-xs text-white/85 mt-0.5">{unit.titleDe}</div>
            </div>

            <div className="mt-6 flex flex-col items-center gap-5">
              {unit.lessons.map((lesson) => {
                const state: LessonState = states[lesson.id] || 'locked';
                const offset = PATH_OFFSETS[nodeCounter % PATH_OFFSETS.length];
                nodeCounter += 1;

                const base =
                  state === 'locked'
                    ? 'bg-slate-300 dark:bg-slate-700 shadow-[0_6px_0_#94a3b8] dark:shadow-[0_6px_0_#334155] text-slate-500 dark:text-slate-400'
                    : state === 'done'
                    ? 'bg-amber-400 shadow-[0_6px_0_#d97706] text-white'
                    : `${theme.node} ${theme.nodeShadow} text-white`;
                const size = state === 'current' ? 'w-20 h-20' : 'w-16 h-16';

                return (
                  <div key={lesson.id} className="relative flex flex-col items-center" style={{ transform: `translateX(${offset}px)` }}>
                    {state === 'current' && (
                      <div className="absolute -top-11 z-10 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-600 text-xs font-black text-emerald-600 dark:text-emerald-400 animate-bounce">
                        BAŞLAT
                        <span className="absolute left-1/2 -bottom-1.5 w-2.5 h-2.5 -translate-x-1/2 rotate-45 bg-white dark:bg-slate-800 border-r-2 border-b-2 border-slate-200 dark:border-slate-600" />
                      </div>
                    )}
                    <button
                      onClick={() => onNodeClick(lesson.id, state)}
                      aria-label={`${lesson.titleTr}${state === 'locked' ? ' (kilitli)' : state === 'done' ? ' (tamamlandı)' : ''}`}
                      className={`${size} rounded-full flex items-center justify-center transition active:translate-y-1 active:shadow-none cursor-pointer focus-visible:outline-3 focus-visible:outline-offset-4 focus-visible:outline-sky-500 ${base} ${
                        state === 'current' ? 'ring-8 ring-emerald-500/20' : ''
                      }`}
                    >
                      {state === 'locked' ? (
                        <Lock className="w-6 h-6" />
                      ) : state === 'done' ? (
                        <Check className="w-8 h-8 stroke-4" />
                      ) : (
                        <Star className="w-8 h-8 fill-white" />
                      )}
                    </button>
                    <span
                      className={`mt-2 max-w-[150px] text-center text-[11px] leading-tight font-bold ${
                        state === 'locked' ? 'text-slate-400 dark:text-slate-500' : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      {lesson.titleTr}
                    </span>
                  </div>
                );
              })}
            </div>
          </section>
        ))}

        {/* End of level */}
        <div className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-5 text-center">
          {levelDone && nextLevel ? (
            <>
              <div className="text-3xl">🏆</div>
              <h3 className="mt-1 text-lg font-black text-slate-900 dark:text-white">{currentLevel} tamamlandı!</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{nextLevel} seviyesi açıldı.</p>
              <button
                onClick={() => setCurrentLevel(nextLevel)}
                className="mt-4 px-6 py-3 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none transition inline-flex items-center gap-1.5 cursor-pointer"
              >
                {nextLevel} seviyesine geç <ChevronRight className="w-4 h-4" />
              </button>
            </>
          ) : levelDone ? (
            <>
              <div className="text-3xl">🎓</div>
              <h3 className="mt-1 text-lg font-black text-slate-900 dark:text-white">Tüm seviyeler tamam!</h3>
            </>
          ) : (
            <>
              <Headphones className="w-6 h-6 mx-auto text-slate-400" />
              <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                {lessonsDone
                  ? `Dersler tamam. ${nextLevel ? nextLevel + ' seviyesini açmak için' : 'Seviyeyi tamamlamak için'} ${currentLevel} sınavını en az %70 ile geç.`
                  : nextLevel
                  ? `Bütün dersleri bitirip ${currentLevel} sınavını %70 ile geçince ${nextLevel} açılır.`
                  : 'Bütün dersleri bitirip sınavı geçerek Almancada ustalaş.'}
              </p>
              {lessonsDone && (
                <button
                  onClick={() => setIsLevelTestOpen(true)}
                  className="mt-3 px-5 py-2.5 rounded-2xl bg-amber-500 text-white font-black shadow-[0_4px_0_#b45309] active:translate-y-1 active:shadow-none transition cursor-pointer"
                >
                  {currentLevel} sınavına gir
                </button>
              )}
              <button
                onClick={() => setActiveTab('dtz')}
                className="mt-3 text-sm font-black text-emerald-600 dark:text-emerald-400 cursor-pointer"
              >
                Dinleme ve sınav pratiği yap
              </button>
            </>
          )}
        </div>
      </div>

      {/* Continue bar */}
      {currentLesson && (
        <div className="fixed left-0 right-0 bottom-20 md:bottom-6 z-30 px-4 pointer-events-none">
          <div className="max-w-xl mx-auto pointer-events-auto">
            <button
              onClick={() => openLesson(currentLesson.id)}
              className="w-full h-14 rounded-2xl bg-emerald-500 text-white font-black text-base shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
            >
              Devam et: {currentLesson.titleTr}
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Hint toast */}
      {hint && (
        <div
          role="status"
          className="fixed left-1/2 -translate-x-1/2 bottom-40 md:bottom-28 z-40 max-w-[90vw] px-4 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold shadow-xl"
        >
          {hint}
        </div>
      )}

      {/* Level exam */}
      {isLevelTestOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-2 sm:p-4">
          <div className="w-full max-w-3xl h-[92vh] bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
            <ExerciseRunner
              exercises={getLevelQuestionPool(currentLevel)}
              title={`${currentLevel} Genel Seviye Sınavı`}
              onComplete={(correct, total) => {
                addXp(correct * 5);
                setIsLevelTestOpen(false);
                const ratio = correct / Math.max(1, total);
                const enough = total >= Math.min(EXAM_MIN_QUESTIONS, getLevelQuestionPool(currentLevel).length);
                if (ratio >= EXAM_PASS_RATIO && enough) {
                  markLevelExamPassed(currentLevel);
                  setHint(`Sınavı geçtin: ${correct}/${total}. ${nextLevel ? nextLevel + ' seviyesi açıldı.' : 'Tebrikler!'}`);
                } else if (!enough) {
                  setHint(`Seviyeyi geçmek için en az ${EXAM_MIN_QUESTIONS} soruluk sınav çöz.`);
                } else {
                  setHint(`${correct}/${total}: geçmek için %70 gerekli. Tekrar dene.`);
                }
              }}
              onExit={() => setIsLevelTestOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
