import { CEFRLevel, Exercise } from '../../types';
import { QUEST_WORDS, QuestWord } from './words';

export const WORDS_PER_SET = 8;

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const display = (w: QuestWord) => (w.article !== 'none' ? `${w.article} ${w.german}` : w.german);

export const getLevelWords = (level: CEFRLevel): QuestWord[] => QUEST_WORDS.filter((w) => w.level === level);

export interface WordSet {
  id: string;
  level: CEFRLevel;
  index: number;
  words: QuestWord[];
  topics: string[];
}

export function getWordSets(level: CEFRLevel): WordSet[] {
  const words = getLevelWords(level);
  const sets: WordSet[] = [];
  for (let i = 0; i < words.length; i += WORDS_PER_SET) {
    const chunk = words.slice(i, i + WORDS_PER_SET);
    sets.push({
      id: `${level}_set_${sets.length + 1}`,
      level,
      index: sets.length + 1,
      words: chunk,
      topics: Array.from(new Set(chunk.map((w) => w.category))),
    });
  }
  return sets;
}

type Kind = 'mc' | 'reverse' | 'fill' | 'builder' | 'listen' | 'article';

function build(w: QuestWord, pool: QuestWord[], kind: Kind): Exercise | null {
  const others = pool.filter((o) => o.id !== w.id);
  const tag = `Kelime: ${w.category}`;
  const base = { id: `${w.id}_${kind}`, level: w.level, topicTag: tag };
  const pick = <T,>(arr: T[], n: number) => shuffle(arr).slice(0, n);

  switch (kind) {
    case 'mc': {
      const wrong = pick(Array.from(new Set(others.map((o) => o.turkish))).filter((t) => t !== w.turkish), 3);
      return {
        ...base,
        type: 'multiple_choice',
        instructionTr: 'Bu kelimenin Türkçesi nedir?',
        prompt: display(w),
        options: shuffle([w.turkish, ...wrong]),
        correctAnswer: w.turkish,
        explanationTr: `${display(w)} = ${w.turkish}. Örnek: ${w.exampleGerman} (${w.exampleTurkish})`,
      } as Exercise;
    }
    case 'reverse': {
      const wrong = pick(others.filter((o) => o.german !== w.german).map(display), 3);
      return {
        ...base,
        type: 'reverse_multiple_choice',
        instructionTr: 'Bu kelimenin Almancası hangisi?',
        prompt: w.turkish,
        options: shuffle([display(w), ...wrong]),
        correctAnswer: display(w),
        explanationTr: `${w.turkish} = ${display(w)}. Örnek: ${w.exampleGerman}`,
      } as Exercise;
    }
    case 'fill': {
      const isNoun = w.article !== 'none';
      const candidates = others.filter((o) => (o.article !== 'none') === isNoun && o.category !== w.category && o.form !== w.form);
      const wrong = pick(Array.from(new Set(candidates.map((o) => o.form))), 3);
      if (wrong.length < 3) return null;
      const atStart = w.template.trim().startsWith('{');
      const fix = (x: string) => (atStart ? x.charAt(0).toUpperCase() + x.slice(1) : x);
      return {
        ...base,
        type: 'fill_blank',
        instructionTr: 'Boşluğa uyan kelimeyi seçin:',
        sentenceWithBlank: w.template.replace(/\{[^}]+\}/, '___'),
        turkishTranslation: w.exampleTurkish,
        options: shuffle([fix(w.form), ...wrong.map(fix)]),
        correctAnswer: fix(w.form),
        explanationTr: `Doğru cümle: ${w.exampleGerman} (${w.exampleTurkish})`,
      } as Exercise;
    }
    case 'builder': {
      const words = w.exampleGerman.split(' ');
      if (words.length < 3 || words.length > 9) return null;
      return {
        ...base,
        type: 'sentence_builder',
        instructionTr: 'Cümleyi doğru sırayla kurun:',
        turkishPrompt: w.exampleTurkish,
        correctGermanSentence: w.exampleGerman,
        scrambledWords: words,
        explanationTr: `${w.exampleGerman} - ${display(w)} = ${w.turkish}`,
      } as Exercise;
    }
    case 'listen': {
      const wrong = pick(others.map((o) => o.exampleTurkish).filter((t) => t !== w.exampleTurkish), 3);
      return {
        ...base,
        type: 'listening',
        instructionTr: 'Dinleyin ve anlamını seçin:',
        germanAudioText: w.exampleGerman,
        turkishMeaning: w.exampleTurkish,
        options: shuffle([w.exampleTurkish, ...wrong]),
        correctAnswer: w.exampleTurkish,
        explanationTr: `${w.exampleGerman} = ${w.exampleTurkish}`,
      } as Exercise;
    }
    case 'article': {
      if (w.article === 'none') return null;
      return {
        ...base,
        type: 'article_select',
        instructionTr: 'Doğru artikeli seçin:',
        word: w.german,
        turkish: w.turkish,
        correctArticle: w.article as 'der' | 'die' | 'das',
        explanationTr: `${w.article} ${w.german} = ${w.turkish}`,
      } as Exercise;
    }
  }
}

/** Mixed practice for one set: every word is seen in several forms, always inside a sentence at least once. */
export function buildSetExercises(set: WordSet): Exercise[] {
  const pool = getLevelWords(set.level);
  const rotation: Kind[] = ['builder', 'listen', 'article', 'reverse'];
  const out: Exercise[] = [];
  set.words.forEach((w, i) => {
    const kinds: Kind[] = ['mc', 'fill', rotation[i % rotation.length], rotation[(i + 1) % rotation.length]];
    kinds.forEach((k) => {
      const ex = build(w, pool, k) || (k === 'article' ? build(w, pool, 'reverse') : null);
      if (ex && !out.some((e) => e.id === ex.id)) out.push(ex);
    });
  });
  // easy to hard: meaning first, sentence use last
  const order: Record<string, number> = { multiple_choice: 0, reverse_multiple_choice: 1, article_select: 1, fill_blank: 2, listening: 3, sentence_builder: 4 };
  return out.sort((a, b) => (order[a.type] ?? 5) - (order[b.type] ?? 5));
}

/** Extra sentence-based questions that enlarge the level exam pool. */
export function buildLevelVocabExercises(level: CEFRLevel): Exercise[] {
  const pool = getLevelWords(level);
  const out: Exercise[] = [];
  pool.forEach((w) => {
    (['fill', 'builder', 'listen'] as Kind[]).forEach((k) => {
      const ex = build(w, pool, k);
      if (ex) out.push(ex);
    });
  });
  return out;
}
