import { DTZQuestion } from '../../types';

// Goethe-Zertifikat A1-C1: Hören, Lesen, Schreiben, Sprechen
export const GOETHE_QUESTIONS: DTZQuestion[] = [
 {
  "id": "go_a1_h_1",
  "section": "hoeren",
  "level": "A1",
  "topicTag": "Hören Teil 1 - Am Bahnhof",
  "titleTr": "Gespräch: İstasyonda",
  "contextDe": "Sie hören ein kurzes Gespräch am Bahnhof.",
  "contextTr": "İstasyonda kısa bir konuşma dinliyorsunuz.",
  "questionDe": "Wann fährt der Zug nach Hamburg?",
  "questionTr": "Hamburg treni ne zaman kalkıyor?",
  "options": [
   "Um 10:15 Uhr",
   "Um 10:50 Uhr",
   "Um 15:10 Uhr"
  ],
  "correctAnswer": "Um 10:15 Uhr",
  "explanationTr": "\"zehn Uhr fünfzehn\" = 10:15. \"Fünfzehn\" (15) ile \"fünfzig\" (50) karıştırılmasın; sınavda saatler hep böyle tuzak olur.",
  "audioPromptDe": "Entschuldigung, wann fährt der Zug nach Hamburg? – Um zehn Uhr fünfzehn, von Gleis drei. – Danke schön!",
  "transcriptDe": "Entschuldigung, wann fährt der Zug nach Hamburg? – Um zehn Uhr fünfzehn, von Gleis drei. – Danke schön!"
 },
 {
  "id": "go_a1_h_2",
  "section": "hoeren",
  "level": "A1",
  "topicTag": "Hören Teil 1 - Im Café",
  "titleTr": "Gespräch: Kafede sipariş",
  "contextDe": "Sie hören ein Gespräch im Café.",
  "contextTr": "Kafede bir sipariş konuşması dinliyorsunuz.",
  "questionDe": "Wie viel kostet das zusammen?",
  "questionTr": "Toplam ne kadar tutuyor?",
  "options": [
   "4,50 Euro",
   "5,40 Euro",
   "14,50 Euro"
  ],
  "correctAnswer": "4,50 Euro",
  "explanationTr": "\"vier Euro fünfzig\" = 4,50 €. \"Zusammen\" toplam fiyat demektir.",
  "audioPromptDe": "Guten Tag. Ich hätte gern einen Kaffee und ein Stück Apfelkuchen. – Gern. Das macht zusammen vier Euro fünfzig.",
  "transcriptDe": "Guten Tag. Ich hätte gern einen Kaffee und ein Stück Apfelkuchen. – Gern. Das macht zusammen vier Euro fünfzig."
 },
 {
  "id": "go_a1_h_3",
  "section": "hoeren",
  "level": "A1",
  "topicTag": "Hören Teil 2 - Durchsage im Kaufhaus",
  "titleTr": "Durchsage: Mağaza anonsu",
  "contextDe": "Sie hören eine Durchsage im Kaufhaus.",
  "contextTr": "Alışveriş merkezinde bir anons dinliyorsunuz.",
  "questionDe": "Was sollen die Kunden jetzt tun?",
  "questionTr": "Müşteriler şimdi ne yapmalı?",
  "options": [
   "Zur Kasse gehen",
   "Zehn Minuten warten",
   "Morgen wiederkommen"
  ],
  "correctAnswer": "Zur Kasse gehen",
  "explanationTr": "\"Schließt in zehn Minuten\" = on dakika sonra kapanıyor. \"Bitte gehen Sie zur Kasse\" = kasaya gidin.",
  "audioPromptDe": "Achtung, liebe Kunden! Das Kaufhaus schließt in zehn Minuten. Bitte gehen Sie jetzt zur Kasse. Vielen Dank und einen schönen Abend!",
  "transcriptDe": "Achtung, liebe Kunden! Das Kaufhaus schließt in zehn Minuten. Bitte gehen Sie jetzt zur Kasse. Vielen Dank und einen schönen Abend!"
 },
 {
  "id": "go_a1_h_4",
  "section": "hoeren",
  "level": "A1",
  "topicTag": "Hören Teil 3 - Telefonansage Arztpraxis",
  "titleTr": "Telefonansage: Doktor muayenehanesi",
  "contextDe": "Sie rufen bei einer Arztpraxis an und hören eine Ansage.",
  "contextTr": "Bir doktoru arıyorsunuz ve kayıt dinliyorsunuz.",
  "questionDe": "Wann ist die Praxis am Dienstag geöffnet?",
  "questionTr": "Muayenehane salı günü ne zaman açık?",
  "options": [
   "Von 8 bis 12 Uhr",
   "Von 14 bis 16 Uhr",
   "Von 8 bis 16 Uhr"
  ],
  "correctAnswer": "Von 8 bis 12 Uhr",
  "explanationTr": "Öğleden sonra saatleri (14-16) sadece çarşamba için geçerli. Salı için \"Montag bis Freitag 8-12\" kuralı geçerli.",
  "audioPromptDe": "Praxis Doktor Berger. Unsere Sprechzeiten: Montag bis Freitag von acht bis zwölf Uhr. Am Mittwochnachmittag von vierzehn bis sechzehn Uhr. Bitte rufen Sie später noch einmal an.",
  "transcriptDe": "Praxis Doktor Berger. Unsere Sprechzeiten: Montag bis Freitag von acht bis zwölf Uhr. Am Mittwochnachmittag von vierzehn bis sechzehn Uhr. Bitte rufen Sie später noch einmal an."
 },
 {
  "id": "go_a1_h_5",
  "section": "hoeren",
  "level": "A1",
  "topicTag": "Hören Teil 3 - Nachricht auf dem Anrufbeantworter",
  "titleTr": "Telesekreter mesajı",
  "contextDe": "Sie hören eine Nachricht auf dem Anrufbeantworter.",
  "contextTr": "Telesekreterde bir mesaj dinliyorsunuz.",
  "questionDe": "Wann treffen sich Anna und Tom?",
  "questionTr": "Anna ve Tom ne zaman buluşuyor?",
  "options": [
   "Am Samstag um 15 Uhr",
   "Heute um 15 Uhr",
   "Am Sonntag um 5 Uhr"
  ],
  "correctAnswer": "Am Samstag um 15 Uhr",
  "explanationTr": "\"Heute nicht, aber am Samstag\" - Tom bugün gelemiyor, buluşma cumartesi saat 15:00 (fünfzehn Uhr).",
  "audioPromptDe": "Hallo Anna, hier ist Tom. Ich kann heute leider nicht kommen, ich bin krank. Aber wir können uns am Samstag um fünfzehn Uhr im Park treffen. Tschüss!",
  "transcriptDe": "Hallo Anna, hier ist Tom. Ich kann heute leider nicht kommen, ich bin krank. Aber wir können uns am Samstag um fünfzehn Uhr im Park treffen. Tschüss!"
 },
 {
  "id": "go_a1_l_1",
  "section": "lesen",
  "level": "A1",
  "topicTag": "Lesen Teil 1 - E-Mail",
  "titleTr": "E-Mail: Julia'nın daveti",
  "contextDe": "Liebe Marta,\n\nich wohne jetzt in München. Meine Wohnung ist klein, aber schön. Sie hat zwei Zimmer und einen Balkon. Am Samstag mache ich eine Party. Kommst du? Die Party beginnt um 19 Uhr.\n\nLiebe Grüße\nJulia",
  "contextTr": "Kısa e-postayı okuyun ve ifadenin doğru mu yanlış mı olduğuna karar verin.",
  "questionDe": "Die Party beginnt am Sonntag.",
  "questionTr": "Parti pazar günü başlıyor.",
  "options": [
   "Richtig",
   "Falsch"
  ],
  "correctAnswer": "Falsch",
  "explanationTr": "Metinde \"Am Samstag mache ich eine Party\" yazıyor; parti cumartesi, pazar değil."
 },
 {
  "id": "go_a1_l_2",
  "section": "lesen",
  "level": "A1",
  "topicTag": "Lesen Teil 1 - E-Mail",
  "titleTr": "E-Mail: Julia'nın evi",
  "contextDe": "Liebe Marta,\n\nich wohne jetzt in München. Meine Wohnung ist klein, aber schön. Sie hat zwei Zimmer und einen Balkon. Am Samstag mache ich eine Party. Kommst du? Die Party beginnt um 19 Uhr.\n\nLiebe Grüße\nJulia",
  "contextTr": "Aynı e-postayı okuyun.",
  "questionDe": "Julias Wohnung hat einen Balkon.",
  "questionTr": "Julia'nın dairesinde balkon var.",
  "options": [
   "Richtig",
   "Falsch"
  ],
  "correctAnswer": "Richtig",
  "explanationTr": "\"Sie hat zwei Zimmer und einen Balkon\" cümlesi doğrudan bunu söylüyor."
 },
 {
  "id": "go_a1_l_3",
  "section": "lesen",
  "level": "A1",
  "topicTag": "Lesen Teil 2 - Anzeige",
  "titleTr": "Kiralık daire ilanı",
  "contextDe": "Zu vermieten: 2-Zimmer-Wohnung, 55 m², Küche, Bad, 480 Euro warm, ab 1. Mai frei.\nKontakt: Herr Braun, Tel. 0171 5550123",
  "contextTr": "Aşağıdaki ilana bakın.",
  "questionDe": "Was kostet die Wohnung?",
  "questionTr": "Daire ne kadar?",
  "options": [
   "480 Euro (warm)",
   "55 Euro",
   "Ab 1. Mai kostenlos"
  ],
  "correctAnswer": "480 Euro (warm)",
  "explanationTr": "\"480 Euro warm\" = ısınma ve yan giderler dahil 480 €. 55 m² metrekaredir, fiyat değil."
 },
 {
  "id": "go_a1_l_4",
  "section": "lesen",
  "level": "A1",
  "topicTag": "Lesen Teil 3 - Schild",
  "titleTr": "Tabela: Öğle arası",
  "contextDe": "Schild an einer Bürotür:\n\n\"Mittagspause von 12 bis 14 Uhr. Bitte kommen Sie später wieder.\"",
  "contextTr": "Ofis kapısındaki tabelayı okuyun.",
  "questionDe": "Sie kommen um 12:30 Uhr. Was machen Sie?",
  "questionTr": "Saat 12:30'da geliyorsunuz. Ne yaparsınız?",
  "options": [
   "Sie kommen nach 14 Uhr wieder.",
   "Sie gehen sofort ins Büro.",
   "Sie rufen morgen an."
  ],
  "correctAnswer": "Sie kommen nach 14 Uhr wieder.",
  "explanationTr": "Öğle arası 12-14 arası; \"später wieder kommen\" = daha sonra tekrar gelin."
 },
 {
  "id": "go_a1_l_5",
  "section": "lesen",
  "level": "A1",
  "topicTag": "Lesen Teil 3 - Schild",
  "titleTr": "Tabela: Sigara yasağı",
  "contextDe": "Schild im Krankenhaus:\n\n\"Rauchen verboten! Auch auf dem Parkplatz.\"",
  "contextTr": "Hastanedeki tabelayı okuyun.",
  "questionDe": "Was bedeutet das Schild?",
  "questionTr": "Tabela ne anlama geliyor?",
  "options": [
   "Man darf hier nicht rauchen.",
   "Man darf hier nicht parken.",
   "Man muss hier leise sein."
  ],
  "correctAnswer": "Man darf hier nicht rauchen.",
  "explanationTr": "\"Verboten\" = yasak. \"Rauchen verboten\" = sigara içmek yasak. \"Auch\" = otoparkta da."
 },
 {
  "id": "go_a1_s_1",
  "section": "schreiben",
  "level": "A1",
  "topicTag": "Schreiben Teil 1 - Formular",
  "titleTr": "Form doldurma: Dil kursu kaydı",
  "contextDe": "Sie melden sich für einen Deutschkurs an. Füllen Sie das Formular aus.",
  "contextTr": "Bir Almanca kursuna kayıt oluyorsunuz. Formu doldurun.",
  "questionDe": "Name, Vorname, Geburtsdatum, Wohnort, Land, Telefon, Muttersprache",
  "questionTr": "Formdaki her alanı kısa ve doğru yazın:",
  "writingPointsTr": [
   "Soyad ve ad",
   "Doğum tarihi (Tag.Monat.Jahr)",
   "Yaşadığınız şehir ve ülke",
   "Telefon numarası",
   "Ana dil"
  ],
  "sampleSolutionDe": "Name: Kaya\nVorname: Elif\nGeburtsdatum: 14.03.1995\nWohnort: Köln\nLand: Türkei\nTelefon: 0176 1234567\nMuttersprache: Türkisch",
  "criteriaTr": [
   "Her alan dolu",
   "Tarih Almanca sırayla: gün.ay.yıl",
   "Şehir ve ülke ayrı yazılmış",
   "Kısa cevap, tam cümle gerekmiyor"
  ],
  "explanationTr": "Goethe A1 Schreiben Teil 1'de form doldurulur; tam cümle gerekmez, doğru bilgi ve doğru yazım önemlidir."
 },
 {
  "id": "go_a1_s_2",
  "section": "schreiben",
  "level": "A1",
  "topicTag": "Schreiben Teil 2 - Kurze Nachricht",
  "titleTr": "Kısa mesaj: Hastalık",
  "contextDe": "Sie sind krank und können morgen nicht zum Deutschkurs kommen.",
  "contextTr": "Hastasınız ve yarın Almanca kursuna gelemeyeceksiniz.",
  "questionDe": "Schreiben Sie eine E-Mail an Ihre Lehrerin, Frau Weber (20-30 Wörter).",
  "questionTr": "Frau Weber'e 20-30 kelimelik e-posta yazın:",
  "writingPointsTr": [
   "Neden gelemiyorsunuz? (krank)",
   "Ne zaman tekrar geleceksiniz?",
   "Ödev hakkında bir soru sorun"
  ],
  "sampleSolutionDe": "Liebe Frau Weber,\n\nich bin krank und kann morgen nicht kommen. Am Donnerstag komme ich wieder. Was sind die Hausaufgaben?\n\nViele Grüße\nElif Kaya",
  "criteriaTr": [
   "Anrede ve Gruß var (Liebe Frau Weber / Viele Grüße)",
   "3 maddenin üçüne de değinildi",
   "20-30 kelime",
   "Basit ama doğru cümleler (ich bin, ich kann, ich komme)"
  ],
  "explanationTr": "A1'de her madde ayrı bir cümle olsun; Anrede ve Gruß olmadan puan kaybedersiniz."
 },
 {
  "id": "go_a1_s_3",
  "section": "schreiben",
  "level": "A1",
  "topicTag": "Schreiben Teil 2 - Einladung",
  "titleTr": "Kısa mesaj: Doğum günü daveti",
  "contextDe": "Sie haben Geburtstag und laden einen Freund ein.",
  "contextTr": "Doğum gününüz var ve bir arkadaşınızı davet ediyorsunuz.",
  "questionDe": "Schreiben Sie eine Nachricht an Ihren Freund Paul (20-30 Wörter).",
  "questionTr": "Paul'e 20-30 kelimelik mesaj yazın:",
  "writingPointsTr": [
   "Ne zaman? (Samstag, 18 Uhr)",
   "Nerede? (bei mir zu Hause)",
   "Ne getirmeli? (Kuchen / Getränke)"
  ],
  "sampleSolutionDe": "Lieber Paul,\n\nich habe am Samstag Geburtstag. Die Party ist um 18 Uhr bei mir zu Hause. Bitte bring Getränke mit. Kommst du?\n\nBis bald\nElif",
  "criteriaTr": [
   "Lieber (erkek) / Liebe (kadın) doğru kullanılmış",
   "Zaman ve yer net",
   "Rica cümlesi: Bitte bring ... mit",
   "Soru ile bitiyor: Kommst du?"
  ],
  "explanationTr": "Davet mesajında zaman, yer ve rica mutlaka yer almalıdır; \"mitbringen\" ayrılabilen fiildir: Bring ... mit."
 },
 {
  "id": "go_a1_p_1",
  "section": "sprechen",
  "level": "A1",
  "topicTag": "Sprechen Teil 1 - Sich vorstellen",
  "titleTr": "Bölüm 1: Kendini tanıtma",
  "contextDe": "Sie stellen sich der Prüferin vor.",
  "contextTr": "Sınavın ilk bölümünde kendinizi tanıtıyorsunuz.",
  "questionDe": "Name, Alter, Land, Wohnort, Sprachen, Beruf, Hobby",
  "questionTr": "Bu 7 bilgiyi tam cümlelerle söyleyin.",
  "speakingGoalDe": "Sich mit sieben Informationen verständlich vorstellen.",
  "suggestedPhrasesDe": [
   "Mein Name ist Elif Kaya.",
   "Ich bin 28 Jahre alt.",
   "Ich komme aus der Türkei.",
   "Ich wohne in Köln.",
   "Ich spreche Türkisch und ein bisschen Deutsch.",
   "Ich bin Verkäuferin von Beruf.",
   "Mein Hobby ist Schwimmen."
  ],
  "explanationTr": "Teil 1 bir ezber değil; yedi bilgiyi de söylemek puan getirir. Yavaş ve net konuşun."
 },
 {
  "id": "go_a1_p_2",
  "section": "sprechen",
  "level": "A1",
  "topicTag": "Sprechen Teil 2 - Fragen und Antworten",
  "titleTr": "Bölüm 2: Kartlarla soru-cevap",
  "contextDe": "Sie ziehen eine Wortkarte und stellen eine Frage dazu.",
  "contextTr": "Bir kelime kartı çekip ona uygun soru soruyorsunuz.",
  "questionDe": "Karte: \"Geschäft - Wann?\" / Karte: \"Essen - Was?\"",
  "questionTr": "Kartı kullanarak soru sorun, sonra partnerin sorusunu cevaplayın.",
  "speakingGoalDe": "Eine W-Frage stellen und kurz antworten.",
  "suggestedPhrasesDe": [
   "Wann öffnet das Geschäft?",
   "Das Geschäft öffnet um neun Uhr.",
   "Was essen Sie gern?",
   "Ich esse gern Reis und Salat.",
   "Wo kaufen Sie ein?"
  ],
  "explanationTr": "Soru kelimeleri: wann, was, wo, wie, wer, wie viel. Cevapta tam cümle kurun: Subjekt + Verb ikinci sırada."
 },
 {
  "id": "go_a1_p_3",
  "section": "sprechen",
  "level": "A1",
  "topicTag": "Sprechen Teil 3 - Bitten",
  "titleTr": "Bölüm 3: Rica etme",
  "contextDe": "Sie bekommen ein Bild und formulieren eine Bitte.",
  "contextTr": "Bir resim görüp rica cümlesi kuruyorsunuz.",
  "questionDe": "Bild: Salz am Tisch / geschlossenes Fenster / Stift",
  "questionTr": "Resme göre nazik bir rica kurun ve kabul veya ret cevabı verin.",
  "speakingGoalDe": "Eine höfliche Bitte formulieren und darauf reagieren.",
  "suggestedPhrasesDe": [
   "Können Sie mir bitte das Salz geben?",
   "Machen Sie bitte das Fenster zu.",
   "Kann ich bitte einen Stift haben?",
   "Ja, gern. / Ja, natürlich.",
   "Tut mir leid, das geht nicht."
  ],
  "explanationTr": "Rica için iki kalıp yeterli: \"Können Sie ... bitte ...?\" ve \"Bitte + Imperativ\". \"Bitte\" kelimesini unutmayın."
 },
 {
  "id": "go_a2_h_1",
  "section": "hoeren",
  "level": "A2",
  "topicTag": "Hören Teil 1 - Durchsage Bahnhof",
  "titleTr": "Anons: Tren gecikmesi",
  "contextDe": "Sie hören eine Durchsage am Bahnhof.",
  "contextTr": "İstasyonda anons dinliyorsunuz.",
  "questionDe": "Was ist richtig?",
  "questionTr": "Hangisi doğru?",
  "options": [
   "Der Zug kommt später und fährt von Gleis 6.",
   "Der Zug fällt aus.",
   "Der Zug fährt von Gleis 4 ab."
  ],
  "correctAnswer": "Der Zug kommt später und fährt von Gleis 6.",
  "explanationTr": "\"Zwanzig Minuten Verspätung\" = 20 dk gecikme; \"nicht ... sondern ...\" değişikliği gösterir: peron 4 değil, 6.",
  "audioPromptDe": "Achtung am Gleis sechs! Der Regionalexpress nach Nürnberg hat heute zwanzig Minuten Verspätung. Er fährt nicht von Gleis vier, sondern von Gleis sechs ab. Wir bitten um Entschuldigung.",
  "transcriptDe": "Achtung am Gleis sechs! Der Regionalexpress nach Nürnberg hat heute zwanzig Minuten Verspätung. Er fährt nicht von Gleis vier, sondern von Gleis sechs ab. Wir bitten um Entschuldigung."
 },
 {
  "id": "go_a2_h_2",
  "section": "hoeren",
  "level": "A2",
  "topicTag": "Hören Teil 2 - Telefonat Termin",
  "titleTr": "Telefon: Kuaför randevusu",
  "contextDe": "Sie hören ein Telefongespräch.",
  "contextTr": "Bir telefon konuşması dinliyorsunuz.",
  "questionDe": "Wann bekommt die Frau den Termin?",
  "questionTr": "Kadın randevuyu ne zaman alıyor?",
  "options": [
   "Freitag um 10:30 Uhr",
   "Donnerstag um 10:30 Uhr",
   "Montag um 14 Uhr"
  ],
  "correctAnswer": "Freitag um 10:30 Uhr",
  "explanationTr": "\"Halb elf\" = 10:30 (yarım on bir değil). Perşembe dolu, pazartesi kadın çalışıyor.",
  "audioPromptDe": "Salon Haarwerk, guten Tag. – Guten Tag, ich möchte einen Termin für Donnerstag. – Donnerstag ist leider schon voll. Ich hätte noch Freitag um halb elf oder Montag um vierzehn Uhr. – Montag arbeite ich bis fünf. Freitag passt mir gut. – Gut, dann also Freitag, halb elf.",
  "transcriptDe": "Salon Haarwerk, guten Tag. – Guten Tag, ich möchte einen Termin für Donnerstag. – Donnerstag ist leider schon voll. Ich hätte noch Freitag um halb elf oder Montag um vierzehn Uhr. – Montag arbeite ich bis fünf. Freitag passt mir gut. – Gut, dann also Freitag, halb elf."
 },
 {
  "id": "go_a2_h_3",
  "section": "hoeren",
  "level": "A2",
  "topicTag": "Hören Teil 3 - Nachricht Hausverwaltung",
  "titleTr": "Mesaj: Daire gezme iptali",
  "contextDe": "Sie hören eine Nachricht auf Ihrem Handy.",
  "contextTr": "Telefonunuzda bir mesaj dinliyorsunuz.",
  "questionDe": "Was sollen Sie tun, wenn der neue Termin nicht passt?",
  "questionTr": "Yeni randevu uymazsa ne yapmalısınız?",
  "options": [
   "Herrn Meier zurückrufen",
   "Zur Hausverwaltung fahren",
   "Den Schlüssel holen"
  ],
  "correctAnswer": "Herrn Meier zurückrufen",
  "explanationTr": "\"Rufen Sie zurück\" = geri arayın. \"Ausfallen\" = iptal olmak.",
  "audioPromptDe": "Guten Tag, hier ist Meier von der Hausverwaltung. Die Wohnungsbesichtigung morgen muss leider ausfallen, weil der Schlüssel fehlt. Der neue Termin ist am Mittwoch um siebzehn Uhr. Bitte rufen Sie mich zurück, wenn Sie da nicht können.",
  "transcriptDe": "Guten Tag, hier ist Meier von der Hausverwaltung. Die Wohnungsbesichtigung morgen muss leider ausfallen, weil der Schlüssel fehlt. Der neue Termin ist am Mittwoch um siebzehn Uhr. Bitte rufen Sie mich zurück, wenn Sie da nicht können."
 },
 {
  "id": "go_a2_l_1",
  "section": "lesen",
  "level": "A2",
  "topicTag": "Lesen Teil 1 - Anzeige Verein",
  "titleTr": "İlan: Bisiklet kursu",
  "contextDe": "Fahrradkurs für Frauen\nSie möchten Fahrrad fahren lernen? Der Verein \"Mobil in Köln\" bietet jeden Samstag von 10 bis 12 Uhr einen Kurs an. Die Fahrräder bekommen Sie kostenlos. Der Kurs kostet 20 Euro im Monat. Anmeldung bis zum 25. des Vormonats.",
  "contextTr": "İlanı okuyun.",
  "questionDe": "Was stimmt?",
  "questionTr": "Hangisi doğru?",
  "options": [
   "Man braucht kein eigenes Fahrrad.",
   "Der Kurs ist kostenlos.",
   "Der Kurs findet sonntags statt."
  ],
  "correctAnswer": "Man braucht kein eigenes Fahrrad.",
  "explanationTr": "\"Die Fahrräder bekommen Sie kostenlos\": bisiklet ücretsiz, kurs ücretsiz değil (20 €/ay)."
 },
 {
  "id": "go_a2_l_2",
  "section": "lesen",
  "level": "A2",
  "topicTag": "Lesen Teil 2 - E-Mail Arbeit",
  "titleTr": "E-posta: Vardiya değişimi",
  "contextDe": "Von: Herr Lang\nBetreff: Schichtwechsel\n\nSehr geehrte Frau Aksoy,\nich kann am Freitag leider nicht arbeiten, weil mein Sohn krank ist. Könnten Sie die Frühschicht für mich übernehmen? Dafür arbeite ich am Samstag für Sie. Bitte geben Sie mir bis morgen Bescheid.\nMit freundlichen Grüßen\nM. Lang",
  "contextTr": "E-postayı okuyun.",
  "questionDe": "Was möchte Herr Lang?",
  "questionTr": "Bay Lang ne istiyor?",
  "options": [
   "Er möchte mit Frau Aksoy die Schicht tauschen.",
   "Er möchte am Samstag frei haben.",
   "Er möchte Urlaub nehmen."
  ],
  "correctAnswer": "Er möchte mit Frau Aksoy die Schicht tauschen.",
  "explanationTr": "Freitag çalışamıyor, onun yerine cumartesi çalışacak: vardiya takası (Schichtwechsel)."
 },
 {
  "id": "go_a2_l_3",
  "section": "lesen",
  "level": "A2",
  "topicTag": "Lesen Teil 3 - Fahrplanänderung",
  "titleTr": "Duyuru: Otobüs hattı değişikliği",
  "contextDe": "Wegen einer Baustelle fährt die Buslinie 12 vom 3. bis 14. Juni nicht bis zum Marktplatz. Fahrgäste steigen bitte an der Haltestelle \"Rathaus\" aus. Von dort sind es zu Fuß etwa fünf Minuten. Ein Ersatzbus fährt nicht.",
  "contextTr": "Duyuruyu okuyun.",
  "questionDe": "Was müssen Fahrgäste im Juni tun?",
  "questionTr": "Yolcular haziranda ne yapmalı?",
  "options": [
   "An der Haltestelle \"Rathaus\" aussteigen und laufen",
   "Auf den Ersatzbus warten",
   "Die Linie 12 nicht benutzen"
  ],
  "correctAnswer": "An der Haltestelle \"Rathaus\" aussteigen und laufen",
  "explanationTr": "Hat Rathaus'a kadar gidiyor; oradan 5 dk yürünür. \"Ein Ersatzbus fährt nicht\" = yedek otobüs yok."
 },
 {
  "id": "go_a2_s_1",
  "section": "schreiben",
  "level": "A2",
  "topicTag": "Schreiben Teil 1 - Einladung",
  "titleTr": "E-posta: Taşınma partisi daveti",
  "contextDe": "Sie sind umgezogen und möchten Ihre Freundin Lena zur Einweihungsfeier einladen.",
  "contextTr": "Taşındınız ve arkadaşınız Lena'yı ev partisine davet ediyorsunuz.",
  "questionDe": "Schreiben Sie an Lena (ca. 40 Wörter).",
  "questionTr": "Lena'ya yaklaşık 40 kelimelik e-posta yazın:",
  "writingPointsTr": [
   "Neden yazıyorsunuz? (Umzug / Party)",
   "Ne zaman ve nerede?",
   "Ne getirebilir? (Salat / Getränke)",
   "Yol tarifi: Bus 5 bis Hauptstraße"
  ],
  "sampleSolutionDe": "Liebe Lena,\n\nich bin umgezogen und möchte am Samstag um 18 Uhr eine Einweihungsfeier machen. Die neue Adresse ist Blumenstraße 12. Kannst du bitte einen Salat mitbringen? Mit dem Bus 5 bis Hauptstraße kommst du direkt zu mir.\n\nLiebe Grüße\nElif",
  "criteriaTr": [
   "4 maddenin tamamı",
   "Anrede + Gruß",
   "Perfekt: ich bin umgezogen",
   "Rica: Kannst du bitte ... mitbringen?"
  ],
  "explanationTr": "A2'de dört maddeye de bir cümleyle değinmek şarttır; Perfekt ve \"weil\" kullanmak puan getirir."
 },
 {
  "id": "go_a2_s_2",
  "section": "schreiben",
  "level": "A2",
  "topicTag": "Schreiben Teil 2 - Beschwerde",
  "titleTr": "E-posta: Bozuk kalorifer",
  "contextDe": "Die Heizung in Ihrer Wohnung ist seit drei Tagen kaputt.",
  "contextTr": "Dairenizde kalorifer üç gündür bozuk.",
  "questionDe": "Schreiben Sie an Ihren Vermieter, Herrn Schulz (ca. 40 Wörter).",
  "questionTr": "Ev sahibi Bay Schulz'a yazın:",
  "writingPointsTr": [
   "Sorun ne ve ne zamandan beri?",
   "Evde ne yapıyorsunuz? (kalt, Kinder krank)",
   "Teknisyen için ricada bulunun"
  ],
  "sampleSolutionDe": "Sehr geehrter Herr Schulz,\n\nseit drei Tagen funktioniert die Heizung in meiner Wohnung nicht mehr. Es ist sehr kalt, und meine Kinder sind schon krank geworden. Bitte schicken Sie so schnell wie möglich einen Techniker.\n\nMit freundlichen Grüßen\nElif Kaya",
  "criteriaTr": [
   "Resmi Anrede: Sehr geehrter Herr ...",
   "Seit + Dativ: seit drei Tagen",
   "Nazik rica: Bitte schicken Sie ...",
   "Mit freundlichen Grüßen"
  ],
  "explanationTr": "Resmi yazışmada \"Sie\" ve \"Mit freundlichen Grüßen\" zorunlu; \"seit drei Tagen\" sürmekte olan durumu anlatır."
 },
 {
  "id": "go_a2_p_1",
  "section": "sprechen",
  "level": "A2",
  "topicTag": "Sprechen Teil 1 - Über sich sprechen",
  "titleTr": "Bölüm 1: Gündelik hayatınız",
  "contextDe": "Die Prüferin stellt Fragen zu Ihrem Alltag.",
  "contextTr": "Sınavcı günlük hayatınız hakkında soru soruyor.",
  "questionDe": "Thema: Tagesablauf und Freizeit",
  "questionTr": "Günün nasıl geçtiğini ve boş zamanınızı anlatın.",
  "speakingGoalDe": "Über den eigenen Alltag in zusammenhängenden Sätzen sprechen.",
  "suggestedPhrasesDe": [
   "Ich stehe um sieben Uhr auf und frühstücke.",
   "Danach fahre ich mit dem Bus zur Arbeit.",
   "Nach der Arbeit gehe ich einkaufen.",
   "In meiner Freizeit treffe ich Freunde, weil ich gern rede.",
   "Am Wochenende koche ich oft für meine Familie."
  ],
  "explanationTr": "A2'de zaman ifadeleri (danach, dann, nach der Arbeit) ve \"weil\" cümleleri konuşmayı akıcı gösterir."
 },
 {
  "id": "go_a2_p_2",
  "section": "sprechen",
  "level": "A2",
  "topicTag": "Sprechen Teil 2 - Gemeinsam planen",
  "titleTr": "Bölüm 2: Birlikte plan yapma",
  "contextDe": "Sie planen mit einem Partner einen Ausflug.",
  "contextTr": "Partnerinizle bir gezi planlıyorsunuz.",
  "questionDe": "Aufgabe: Ausflug am Samstag (Ort, Zeit, Verkehrsmittel, Essen)",
  "questionTr": "Ortak bir plan yapın; öner, kabul et, itiraz et.",
  "speakingGoalDe": "Vorschläge machen, zustimmen und höflich ablehnen.",
  "suggestedPhrasesDe": [
   "Wie wäre es mit einem Ausflug zum See?",
   "Ich schlage vor, dass wir um neun Uhr losfahren.",
   "Das ist eine gute Idee!",
   "Ich finde, wir nehmen lieber den Zug, weil das billiger ist.",
   "Hast du Lust, ein Picknick zu machen?"
  ],
  "explanationTr": "\"Wie wäre es mit ...?\", \"Ich schlage vor, ...\" ve \"Hast du Lust ...?\" planlama görevinin temel kalıplarıdır."
 },
 {
  "id": "go_b1_h_1",
  "section": "hoeren",
  "level": "B1",
  "topicTag": "Hören Teil 1 - Radiointerview",
  "titleTr": "Radyo röportajı: Şehirde bisiklet",
  "contextDe": "Sie hören ein Radiointerview.",
  "contextTr": "Radyoda bir röportaj dinliyorsunuz.",
  "questionDe": "Was fordert der Verband?",
  "questionTr": "Dernek ne talep ediyor?",
  "options": [
   "Mehr getrennte Radwege",
   "Weniger Parkplätze",
   "Günstigere Autos"
  ],
  "correctAnswer": "Mehr getrennte Radwege",
  "explanationTr": "\"Deshalb fordert unser Verband mehr getrennte Wege\" - nedeni: güvenlik sorunu ve eksik bisiklet yolları.",
  "audioPromptDe": "Moderatorin: Frau Weiss, immer mehr Menschen fahren in der Stadt mit dem Rad. Warum? – Frau Weiss: Viele sagen, dass man damit schneller ist als im Auto, vor allem im Berufsverkehr. Außerdem spart man Geld für Benzin und Parkplatz. Das Problem ist die Sicherheit: Es fehlen gute Radwege. Deshalb fordert unser Verband mehr getrennte Wege.",
  "transcriptDe": "Moderatorin: Frau Weiss, immer mehr Menschen fahren in der Stadt mit dem Rad. Warum? – Frau Weiss: Viele sagen, dass man damit schneller ist als im Auto, vor allem im Berufsverkehr. Außerdem spart man Geld für Benzin und Parkplatz. Das Problem ist die Sicherheit: Es fehlen gute Radwege. Deshalb fordert unser Verband mehr getrennte Wege."
 },
 {
  "id": "go_b1_h_2",
  "section": "hoeren",
  "level": "B1",
  "topicTag": "Hören Teil 2 - Vortrag",
  "titleTr": "Sunum: Evden çalışma",
  "contextDe": "Sie hören einen Vortrag.",
  "contextTr": "Bir sunum dinliyorsunuz.",
  "questionDe": "Was empfehlen die Experten?",
  "questionTr": "Uzmanlar ne öneriyor?",
  "options": [
   "Einen Teil der Woche im Büro zu arbeiten",
   "Nur noch zu Hause zu arbeiten",
   "Das Homeoffice abzuschaffen"
  ],
  "correctAnswer": "Einen Teil der Woche im Büro zu arbeiten",
  "explanationTr": "\"Zwei bis drei Tage pro Woche im Büro\" = haftanın bir kısmı ofiste. \"Allerdings\" = ancak (karşıt görüş).",
  "audioPromptDe": "Viele Firmen bieten heute Homeoffice an. Studien zeigen, dass Mitarbeiter zu Hause oft konzentrierter arbeiten. Allerdings fühlen sich manche einsam, weil der Kontakt zu Kollegen fehlt. Deshalb empfehlen Experten, zwei bis drei Tage pro Woche im Büro zu sein.",
  "transcriptDe": "Viele Firmen bieten heute Homeoffice an. Studien zeigen, dass Mitarbeiter zu Hause oft konzentrierter arbeiten. Allerdings fühlen sich manche einsam, weil der Kontakt zu Kollegen fehlt. Deshalb empfehlen Experten, zwei bis drei Tage pro Woche im Büro zu sein."
 },
 {
  "id": "go_b1_h_3",
  "section": "hoeren",
  "level": "B1",
  "topicTag": "Hören Teil 3 - Gespräch Kollegen",
  "titleTr": "Konuşma: İş arkadaşları",
  "contextDe": "Zwei Kollegen sprechen über einen Fortbildungskurs.",
  "contextTr": "İki iş arkadaşı bir eğitim kursu hakkında konuşuyor.",
  "questionDe": "Warum zögert die Frau?",
  "questionTr": "Kadın neden tereddüt ediyor?",
  "options": [
   "Sie hat abends familiäre Pflichten.",
   "Der Kurs ist zu teuer.",
   "Sie braucht Excel nicht."
  ],
  "correctAnswer": "Sie hat abends familiäre Pflichten.",
  "explanationTr": "Kurs akşam; kızını yatırıyor. Ücreti şirket ödüyor, beceriye ihtiyacı var - engel zaman.",
  "audioPromptDe": "Hast du dich schon für den Excel-Kurs angemeldet? – Noch nicht. Ich weiß nicht, ob ich Zeit habe. Der Kurs ist abends, und ich bringe meine Tochter immer ins Bett. – Aber die Firma zahlt doch alles. – Das stimmt, und ich brauche die Kenntnisse. Ich frage meinen Mann, ob er an den Abenden übernehmen kann.",
  "transcriptDe": "Hast du dich schon für den Excel-Kurs angemeldet? – Noch nicht. Ich weiß nicht, ob ich Zeit habe. Der Kurs ist abends, und ich bringe meine Tochter immer ins Bett. – Aber die Firma zahlt doch alles. – Das stimmt, und ich brauche die Kenntnisse. Ich frage meinen Mann, ob er an den Abenden übernehmen kann."
 },
 {
  "id": "go_b1_l_1",
  "section": "lesen",
  "level": "B1",
  "topicTag": "Lesen Teil 1 - Leserbrief",
  "titleTr": "Okur mektubu: Cep telefonu yasağı",
  "contextDe": "Leserbrief zum Thema Handyverbot in Schulen:\n\"Ich bin dafür, dass Handys im Unterricht verboten werden. Ich unterrichte seit 20 Jahren Mathematik und sehe, wie schwer sich Schüler konzentrieren können. In den Pausen sollten sie das Handy aber benutzen dürfen, denn dann lernen sie, verantwortungsvoll damit umzugehen.\" - Petra K.",
  "contextTr": "Okur mektubunu okuyun.",
  "questionDe": "Wie denkt Petra K. über Handys in der Schule?",
  "questionTr": "Petra K. okulda cep telefonları hakkında ne düşünüyor?",
  "options": [
   "Im Unterricht verbieten, in den Pausen erlauben",
   "Immer erlauben",
   "Immer verbieten"
  ],
  "correctAnswer": "Im Unterricht verbieten, in den Pausen erlauben",
  "explanationTr": "İki kısmı da dikkate almak gerekir: \"im Unterricht verboten\" ve \"in den Pausen ... dürfen\"."
 },
 {
  "id": "go_b1_l_2",
  "section": "lesen",
  "level": "B1",
  "topicTag": "Lesen Teil 2 - Zeitungsartikel",
  "titleTr": "Gazete: Tamirat kafesi",
  "contextDe": "In vielen Städten entstehen \"Repair-Cafés\". Dort reparieren Freiwillige gemeinsam mit Besuchern kaputte Geräte, zum Beispiel Toaster oder Lampen. Das Angebot ist kostenlos, Spenden sind willkommen. Ziel ist es, Müll zu vermeiden und Menschen zusammenzubringen. Viele Besucher sagen, dass sie dabei auch selbst etwas lernen.",
  "contextTr": "Haber metnini okuyun.",
  "questionDe": "Welches Ziel haben Repair-Cafés?",
  "questionTr": "Repair-Cafés'nin amacı nedir?",
  "options": [
   "Müll vermeiden und Kontakte fördern",
   "Neue Geräte verkaufen",
   "Kostenlose Kurse für Techniker anbieten"
  ],
  "correctAnswer": "Müll vermeiden und Kontakte fördern",
  "explanationTr": "\"Ziel ist es, Müll zu vermeiden und Menschen zusammenzubringen.\""
 },
 {
  "id": "go_b1_l_3",
  "section": "lesen",
  "level": "B1",
  "topicTag": "Lesen Teil 3 - Stellenanzeige",
  "titleTr": "İş ilanı: Müşteri hizmetleri",
  "contextDe": "Wir suchen ab sofort eine Servicekraft (m/w/d) in Teilzeit (20 Std./Woche). Sie haben Erfahrung im Kundenkontakt, sind freundlich und flexibel? Sehr gute Deutschkenntnisse (mind. B1) sind Voraussetzung. Wir bieten ein nettes Team und Fortbildungen. Bewerbung bitte nur per E-Mail an personal@cafe-sonne.de.",
  "contextTr": "İş ilanını okuyun.",
  "questionDe": "Was muss man tun, um sich zu bewerben?",
  "questionTr": "Başvurmak için ne yapmak gerekir?",
  "options": [
   "Eine E-Mail schreiben",
   "Persönlich vorbeikommen",
   "Ein Formular im Café ausfüllen"
  ],
  "correctAnswer": "Eine E-Mail schreiben",
  "explanationTr": "\"Bewerbung bitte nur per E-Mail\" = başvuru sadece e-posta ile."
 },
 {
  "id": "go_b1_s_1",
  "section": "schreiben",
  "level": "B1",
  "topicTag": "Schreiben Teil 1 - Forumsbeitrag",
  "titleTr": "Forum yazısı: Evden çalışma",
  "contextDe": "In einem Forum fragt jemand: \"Ist Homeoffice besser als Büroarbeit?\"",
  "contextTr": "Bir forumda \"Evden çalışma ofis çalışmasından iyi mi?\" sorusu soruluyor.",
  "questionDe": "Schreiben Sie Ihre Meinung (ca. 80 Wörter).",
  "questionTr": "Görüşünüzü yazın (yaklaşık 80 kelime):",
  "writingPointsTr": [
   "Kendi görüşünüz",
   "Bir avantaj ve gerekçesi",
   "Bir dezavantaj ve gerekçesi",
   "Kendi deneyiminiz",
   "Sonuç / öneri"
  ],
  "sampleSolutionDe": "Hallo zusammen,\n\nmeiner Meinung nach hat Homeoffice mehr Vorteile als Nachteile. Der größte Vorteil ist, dass man keine Zeit im Verkehr verliert. Ich spare zum Beispiel jeden Tag eine Stunde. Allerdings fehlt der Kontakt zu den Kollegen, und manchmal ist es schwer, abzuschalten. Deshalb arbeite ich zwei Tage im Büro und drei Tage zu Hause. Das finde ich ideal.\n\nViele Grüße\nElif",
  "criteriaTr": [
   "Görüş cümlesi: meiner Meinung nach",
   "Bağlaçlar: weil, deshalb, allerdings",
   "Örnek / kişisel deneyim",
   "Net sonuç"
  ],
  "explanationTr": "B1'de görüş + gerekçe + örnek zinciri puan getirir. \"Allerdings\" ile karşı görüşü verin."
 },
 {
  "id": "go_b1_s_2",
  "section": "schreiben",
  "level": "B1",
  "topicTag": "Schreiben Teil 2 - Formelle E-Mail",
  "titleTr": "Resmi e-posta: Kurs bilgisi",
  "contextDe": "Sie interessieren sich für einen Abendkurs an der Volkshochschule.",
  "contextTr": "Halk eğitim merkezinde bir akşam kursuyla ilgileniyorsunuz.",
  "questionDe": "Schreiben Sie eine formelle E-Mail (ca. 60 Wörter).",
  "questionTr": "Resmi e-posta yazın:",
  "writingPointsTr": [
   "Hangi kursla ilgileniyorsunuz?",
   "Fiyat ve süre hakkında soru",
   "Başlangıç seviyesi için uygun mu?",
   "Kayıt için ne gerekli?"
  ],
  "sampleSolutionDe": "Sehr geehrte Damen und Herren,\n\nich interessiere mich für den Abendkurs \"Deutsch B1\" und hätte dazu einige Fragen. Wie lange dauert der Kurs, und was kostet er? Außerdem würde ich gern wissen, ob ich vorher einen Einstufungstest machen muss. Welche Unterlagen brauche ich für die Anmeldung?\n\nVielen Dank im Voraus.\nMit freundlichen Grüßen\nElif Kaya",
  "criteriaTr": [
   "Resmi hitap",
   "4 soru",
   "Nazik kalıp: Ich würde gern wissen, ob ...",
   "Teşekkür ve resmi bitiş"
  ],
  "explanationTr": "\"Ich würde gern wissen, ob ...\" dolaylı soru (Nebensatz, fiil sonda) B1'in temel kalıbıdır."
 },
 {
  "id": "go_b1_p_1",
  "section": "sprechen",
  "level": "B1",
  "topicTag": "Sprechen Teil 1 - Präsentation",
  "titleTr": "Bölüm 1: Kısa sunum",
  "contextDe": "Sie halten eine kurze Präsentation.",
  "contextTr": "Kısa bir sunum yapıyorsunuz.",
  "questionDe": "Thema: Mein Beruf / Mein Lieblingsort",
  "questionTr": "Giriş, ana fikir, örnek ve sonuç ile 2 dakikalık sunum.",
  "speakingGoalDe": "Eine Präsentation klar gliedern und Fragen beantworten.",
  "suggestedPhrasesDe": [
   "Ich möchte Ihnen heute mein Thema vorstellen.",
   "Zuerst erzähle ich etwas über ..., danach über ...",
   "Ein Beispiel dafür ist ...",
   "Zum Schluss möchte ich sagen, dass ...",
   "Vielen Dank für Ihre Aufmerksamkeit."
  ],
  "explanationTr": "Sunumda yapı (zuerst, danach, zum Schluss) ve bir örnek B1 puanının büyük kısmıdır."
 },
 {
  "id": "go_b1_p_2",
  "section": "sprechen",
  "level": "B1",
  "topicTag": "Sprechen Teil 2 - Gemeinsam planen",
  "titleTr": "Bölüm 2: Ortak planlama",
  "contextDe": "Sie planen mit einem Partner eine Party für Kollegen.",
  "contextTr": "Partnerinizle iş arkadaşları için parti planlıyorsunuz.",
  "questionDe": "Aufgabe: Ort, Essen, Programm, Kosten",
  "questionTr": "Ortak karar verin; öner, itiraz et, uzlaş.",
  "speakingGoalDe": "Meinungen austauschen und gemeinsam eine Entscheidung treffen.",
  "suggestedPhrasesDe": [
   "Ich schlage vor, dass wir ... machen.",
   "Was hältst du davon?",
   "Da bin ich anderer Meinung, weil ...",
   "Wir könnten uns darauf einigen, dass ...",
   "Gut, dann machen wir es so."
  ],
  "explanationTr": "\"Was hältst du davon?\" ve \"Wir könnten uns darauf einigen, dass ...\" müzakere kalıplarıdır."
 },
 {
  "id": "go_b2_h_1",
  "section": "hoeren",
  "level": "B2",
  "topicTag": "Hören Teil 1 - Radiobeitrag",
  "titleTr": "Radyo: Uyku araştırması",
  "contextDe": "Sie hören einen Radiobeitrag.",
  "contextTr": "Radyoda bir haber dinliyorsunuz.",
  "questionDe": "Was ist die Aussage der Studie?",
  "questionTr": "Çalışmanın bulgusu nedir?",
  "options": [
   "Wenig Schlaf verschlechtert die Konzentration.",
   "Mittagsschlaf löst das Problem.",
   "Bildschirme verbessern den Schlaf."
  ],
  "correctAnswer": "Wenig Schlaf verschlechtert die Konzentration.",
  "explanationTr": "Mittagsschlafın etkisi \"umstritten\" (tartışmalı), yani kesin bir bulgu değil.",
  "audioPromptDe": "Eine aktuelle Studie der Universität Lübeck zeigt, dass schon eine Stunde weniger Schlaf die Konzentration deutlich verschlechtert. Besonders betroffen sind Schichtarbeiter. Die Forscher raten, regelmäßige Schlafzeiten einzuhalten und abends auf Bildschirme zu verzichten. Ob ein Mittagsschlaf den Mangel ausgleichen kann, bleibt allerdings umstritten.",
  "transcriptDe": "Eine aktuelle Studie der Universität Lübeck zeigt, dass schon eine Stunde weniger Schlaf die Konzentration deutlich verschlechtert. Besonders betroffen sind Schichtarbeiter. Die Forscher raten, regelmäßige Schlafzeiten einzuhalten und abends auf Bildschirme zu verzichten. Ob ein Mittagsschlaf den Mangel ausgleichen kann, bleibt allerdings umstritten."
 },
 {
  "id": "go_b2_h_2",
  "section": "hoeren",
  "level": "B2",
  "topicTag": "Hören Teil 2 - Vortrag",
  "titleTr": "Sunum: Enerji dönüşümü",
  "contextDe": "Sie hören einen Vortrag.",
  "contextTr": "Bir konferans konuşması dinliyorsunuz.",
  "questionDe": "Worin sieht die Referentin das Hauptproblem?",
  "questionTr": "Konuşmacı ana sorunu nerede görüyor?",
  "options": [
   "Im Stromnetz und fehlenden Speichern",
   "Im Mangel an Windanlagen",
   "In zu hohen Strompreisen"
  ],
  "correctAnswer": "Im Stromnetz und fehlenden Speichern",
  "explanationTr": "\"Das Stromnetz hält nicht Schritt\" ve \"ohne neue Leitungen und Speicher\" ana sorunu gösterir.",
  "audioPromptDe": "Der Ausbau erneuerbarer Energien schreitet voran, doch das Stromnetz hält nicht Schritt. Gerade im Norden wird mehr Windstrom erzeugt, als abtransportiert werden kann. Die Folge: Anlagen werden zeitweise abgeschaltet, obwohl Strom gebraucht wird. Ohne neue Leitungen und Speicher, so die Referentin, drohe die Energiewende ins Stocken zu geraten.",
  "transcriptDe": "Der Ausbau erneuerbarer Energien schreitet voran, doch das Stromnetz hält nicht Schritt. Gerade im Norden wird mehr Windstrom erzeugt, als abtransportiert werden kann. Die Folge: Anlagen werden zeitweise abgeschaltet, obwohl Strom gebraucht wird. Ohne neue Leitungen und Speicher, so die Referentin, drohe die Energiewende ins Stocken zu geraten."
 },
 {
  "id": "go_b2_h_3",
  "section": "hoeren",
  "level": "B2",
  "topicTag": "Hören Teil 3 - Diskussion",
  "titleTr": "Tartışma: Dört günlük hafta",
  "contextDe": "Sie hören eine Diskussion.",
  "contextTr": "Bir tartışma dinliyorsunuz.",
  "questionDe": "Welche Position vertritt Frau Demir?",
  "questionTr": "Bayan Demir hangi görüşü savunuyor?",
  "options": [
   "Sie hält die Vier-Tage-Woche nicht für überall machbar.",
   "Sie lehnt jede Arbeitszeitverkürzung ab.",
   "Sie glaubt, Büros brauchen mehr Personal."
  ],
  "correctAnswer": "Sie hält die Vier-Tage-Woche nicht für überall machbar.",
  "explanationTr": "\"Das lässt sich nicht überall umsetzen\" - sektöre bağlı itiraz, genel ret değil. Tuzak: \"jede\" mutlak ifade.",
  "audioPromptDe": "Herr Roth: Die Vier-Tage-Woche steigert die Produktivität, das zeigen Pilotprojekte. – Frau Demir: Das mag in Büros stimmen. In der Pflege oder im Handel fehlt aber schon jetzt Personal. Dort würde sie das Problem verschärfen. – Herr Roth: Dann müssen wir die Arbeit anders organisieren. – Frau Demir: Das lässt sich nicht überall umsetzen.",
  "transcriptDe": "Herr Roth: Die Vier-Tage-Woche steigert die Produktivität, das zeigen Pilotprojekte. – Frau Demir: Das mag in Büros stimmen. In der Pflege oder im Handel fehlt aber schon jetzt Personal. Dort würde sie das Problem verschärfen. – Herr Roth: Dann müssen wir die Arbeit anders organisieren. – Frau Demir: Das lässt sich nicht überall umsetzen."
 },
 {
  "id": "go_b2_l_1",
  "section": "lesen",
  "level": "B2",
  "topicTag": "Lesen Teil 1 - Kommentar",
  "titleTr": "Yorum yazısı: Dört günlük hafta",
  "contextDe": "Kommentar: Weniger arbeiten, mehr leisten?\nPilotprojekte zur Vier-Tage-Woche liefern ermutigende Ergebnisse: Die Beschäftigten sind zufriedener, die Fehlzeiten sinken. Doch wer daraus ein Patentrezept ableitet, macht es sich zu einfach. In Branchen mit festen Öffnungszeiten lässt sich Arbeitszeit nicht beliebig bündeln, ohne dass Dienstleistungen leiden. Die Politik sollte deshalb Spielräume schaffen, statt ein Modell vorzuschreiben.",
  "contextTr": "Yorumu okuyun.",
  "questionDe": "Was fordert der Autor?",
  "questionTr": "Yazar ne talep ediyor?",
  "options": [
   "Flexible Regeln statt eines festen Modells",
   "Die Vier-Tage-Woche für alle sofort",
   "Ein Verbot der Vier-Tage-Woche"
  ],
  "correctAnswer": "Flexible Regeln statt eines festen Modells",
  "explanationTr": "\"Spielräume schaffen, statt ein Modell vorzuschreiben\" = esneklik, tek model dayatması değil."
 },
 {
  "id": "go_b2_l_2",
  "section": "lesen",
  "level": "B2",
  "topicTag": "Lesen Teil 2 - Sachtext",
  "titleTr": "Bilgi metni: Bakımda dijitalleşme",
  "contextDe": "Die Digitalisierung der Pflege soll Fachkräfte entlasten. Sensoren melden Stürze, Software erstellt Dienstpläne, und Tablets ersetzen Papierakten. Kritiker warnen jedoch, dass Technik menschliche Zuwendung nicht ersetzen dürfe. Entscheidend sei, ob die gewonnene Zeit tatsächlich den Patienten zugutekomme oder in zusätzlicher Dokumentation versickere.",
  "contextTr": "Metni okuyun.",
  "questionDe": "Was ist laut Text entscheidend?",
  "questionTr": "Metne göre belirleyici olan nedir?",
  "options": [
   "Ob die gewonnene Zeit bei den Patienten ankommt",
   "Ob alle Papierakten verschwinden",
   "Ob mehr Sensoren gekauft werden"
  ],
  "correctAnswer": "Ob die gewonnene Zeit bei den Patienten ankommt",
  "explanationTr": "\"Entscheidend sei, ob ... den Patienten zugutekomme\" - Konjunktiv I ile aktarılan görüş."
 },
 {
  "id": "go_b2_l_3",
  "section": "lesen",
  "level": "B2",
  "topicTag": "Lesen Teil 3 - Leserbrief",
  "titleTr": "Okur mektubu: Konut sorunu",
  "contextDe": "\"Es wird behauptet, die Mietpreisbremse habe nichts gebracht. Das stimmt so nicht. In Städten, wo sie konsequent kontrolliert wird, steigen die Mieten langsamer. Das Problem ist nicht das Instrument, sondern der Vollzug.\" - Jonas B.",
  "contextTr": "Mektubu okuyun.",
  "questionDe": "Was kritisiert Jonas B.?",
  "questionTr": "Jonas B. neyi eleştiriyor?",
  "options": [
   "Dass das Gesetz nicht streng durchgesetzt wird",
   "Dass die Mietpreisbremse existiert",
   "Dass die Mieten zu langsam steigen"
  ],
  "correctAnswer": "Dass das Gesetz nicht streng durchgesetzt wird",
  "explanationTr": "\"Das Problem ist nicht das Instrument, sondern der Vollzug\" - sorun yasada değil, uygulamada."
 },
 {
  "id": "go_b2_s_1",
  "section": "schreiben",
  "level": "B2",
  "topicTag": "Schreiben Teil 1 - Forumsbeitrag",
  "titleTr": "Forum: Dört günlük hafta",
  "contextDe": "In einem Online-Forum wird diskutiert: \"Sollte die Vier-Tage-Woche Standard werden?\"",
  "contextTr": "Bir online forumda \"Dört günlük hafta standart olmalı mı?\" tartışılıyor.",
  "questionDe": "Schreiben Sie Ihre Meinung (ca. 150 Wörter).",
  "questionTr": "Görüşünüzü yazın (yaklaşık 150 kelime):",
  "writingPointsTr": [
   "Tezinizi açıkça belirtin",
   "İki argüman ve örnek",
   "Karşı görüşü ele alın",
   "Sonuç ve öneri"
  ],
  "sampleSolutionDe": "Beitrag zum Thema Vier-Tage-Woche\n\nIch halte die Vier-Tage-Woche für eine sinnvolle Option, aber nicht für einen Standard, der überall gelten kann. Erstens zeigen Studien, dass Beschäftigte bei kürzerer Arbeitszeit konzentrierter und seltener krank sind. Zweitens erleichtert sie es, Familie und Beruf zu vereinbaren. Dem steht jedoch entgegen, dass in Pflege, Handel oder Gastronomie die Öffnungs- und Betreuungszeiten gesichert werden müssen. Dort würde eine starre Regelung zu Personalengpässen führen. Aus meiner Sicht sollten Unternehmen deshalb selbst entscheiden dürfen, ob und wie sie das Modell einführen. Der Staat kann dies fördern, statt es vorzuschreiben.",
  "criteriaTr": [
   "Net tez",
   "Bağlaçlar: erstens, zweitens, jedoch, deshalb",
   "Karşı argüman ele alınmış",
   "Resmi, yapılı dil"
  ],
  "explanationTr": "B2 değerlendirmesi yapı, argüman derinliği ve dil çeşitliliğine bakar; karşı argümanı ele almak şart."
 },
 {
  "id": "go_b2_s_2",
  "section": "schreiben",
  "level": "B2",
  "topicTag": "Schreiben Teil 2 - Beschwerde",
  "titleTr": "Resmi şikâyet: Hatalı sipariş",
  "contextDe": "Sie haben online einen Laptop bestellt. Geliefert wurde ein falsches Gerät, der Kundenservice reagiert nicht.",
  "contextTr": "Online bir dizüstü bilgisayar sipariş ettiniz; yanlış cihaz geldi, müşteri hizmeti cevap vermiyor.",
  "questionDe": "Schreiben Sie eine formelle Beschwerde (ca. 120 Wörter).",
  "questionTr": "Resmi şikâyet yazın:",
  "writingPointsTr": [
   "Sipariş bilgisi ve sorun",
   "Önceki girişim (Anruf, Mail)",
   "Net talep ve süre",
   "Sonuç, hukuki hatırlatma"
  ],
  "sampleSolutionDe": "Sehr geehrte Damen und Herren,\n\nam 3. November habe ich bei Ihnen den Laptop Modell X (Bestellnummer 48213) bestellt. Geliefert wurde jedoch ein anderes Gerät mit schwächerer Ausstattung. Ich habe Ihren Kundenservice bereits zweimal telefonisch und einmal per E-Mail kontaktiert, bislang ohne Antwort. Ich fordere Sie daher auf, mir bis zum 20. November das bestellte Gerät zuzusenden oder den Kaufpreis zu erstatten. Sollte ich bis dahin keine Rückmeldung erhalten, werde ich rechtliche Schritte prüfen.\n\nMit freundlichen Grüßen\nElif Kaya",
  "criteriaTr": [
   "Sachliche Darstellung",
   "Konkrete Fristsetzung",
   "Höflicher aber bestimmter Ton",
   "Formelle Wendungen"
  ],
  "explanationTr": "B2 şikâyette ton resmî ve net olmalı; \"Ich fordere Sie auf, ... bis zum ...\" süre belirten kalıptır."
 },
 {
  "id": "go_b2_p_1",
  "section": "sprechen",
  "level": "B2",
  "topicTag": "Sprechen Teil 1 - Präsentation",
  "titleTr": "Bölüm 1: Grafik sunumu",
  "contextDe": "Sie präsentieren eine Statistik zum Thema Homeoffice.",
  "contextTr": "Evden çalışma istatistiğini sunuyorsunuz.",
  "questionDe": "Aufgabe: Grafik beschreiben, Ursachen nennen, Meinung äußern",
  "questionTr": "Grafiği tarif edin, nedenleri açıklayın, görüşünüzü söyleyin.",
  "speakingGoalDe": "Daten beschreiben, Ursachen erläutern und Stellung nehmen.",
  "suggestedPhrasesDe": [
   "Die Grafik zeigt, dass ...",
   "Auffällig ist, dass der Anteil von ... auf ... gestiegen ist.",
   "Das lässt sich damit erklären, dass ...",
   "Meiner Einschätzung nach ...",
   "Abschließend lässt sich festhalten, dass ..."
  ],
  "explanationTr": "Grafik sunumunda sıra: Thema nennen, Daten beschreiben, Gründe, eigene Meinung."
 },
 {
  "id": "go_b2_p_2",
  "section": "sprechen",
  "level": "B2",
  "topicTag": "Sprechen Teil 2 - Diskussion",
  "titleTr": "Bölüm 2: Pro ve Kontra",
  "contextDe": "Sie diskutieren mit einem Partner über Tempolimit auf Autobahnen.",
  "contextTr": "Partnerinizle otoyol hız sınırını tartışıyorsunuz.",
  "questionDe": "Aufgabe: Pro und Kontra abwägen, auf Argumente reagieren",
  "questionTr": "Argüman getirin, karşı argümana tepki verin.",
  "speakingGoalDe": "Argumente abwägen und auf Gegenargumente eingehen.",
  "suggestedPhrasesDe": [
   "Einerseits spricht dafür, dass ...",
   "Andererseits darf man nicht vergessen, dass ...",
   "Da stimme ich Ihnen nur teilweise zu.",
   "Das Argument überzeugt mich nicht, denn ...",
   "Wenn man alles abwägt, ..."
  ],
  "explanationTr": "Tartışmada \"einerseits ... andererseits\" ve nazik itiraz (\"nur teilweise\") B2 kalıplarıdır."
 },
 {
  "id": "go_c1_h_1",
  "section": "hoeren",
  "level": "C1",
  "topicTag": "Hören Teil 1 - Vorlesung",
  "titleTr": "Ders: Davranışsal ekonomi",
  "contextDe": "Sie hören einen Ausschnitt aus einer Vorlesung.",
  "contextTr": "Bir üniversite dersinden bir parça dinliyorsunuz.",
  "questionDe": "Wie beurteilt die Dozentin die menschliche Rationalität?",
  "questionTr": "Öğretim üyesi insan rasyonalitesini nasıl değerlendiriyor?",
  "options": [
   "Sie ist begrenzt, aber nicht abwesend.",
   "Sie existiert nicht.",
   "Sie ist vollkommen."
  ],
  "correctAnswer": "Sie ist begrenzt, aber nicht abwesend.",
  "explanationTr": "\"Nicht irrational, sondern begrenzt rational\" - ince ayrım, C1 dinlemede sık sorulur.",
  "audioPromptDe": "Die klassische Ökonomie ging lange davon aus, dass Menschen rational entscheiden. Die Verhaltensökonomik hat dieses Bild relativiert: Wir orientieren uns an Voreinstellungen, scheuen Verluste stärker, als wir Gewinne schätzen, und lassen uns von Vergleichsgrößen leiten. Das heißt nicht, dass Menschen irrational wären, sondern dass ihre Rationalität begrenzt ist.",
  "transcriptDe": "Die klassische Ökonomie ging lange davon aus, dass Menschen rational entscheiden. Die Verhaltensökonomik hat dieses Bild relativiert: Wir orientieren uns an Voreinstellungen, scheuen Verluste stärker, als wir Gewinne schätzen, und lassen uns von Vergleichsgrößen leiten. Das heißt nicht, dass Menschen irrational wären, sondern dass ihre Rationalität begrenzt ist."
 },
 {
  "id": "go_c1_h_2",
  "section": "hoeren",
  "level": "C1",
  "topicTag": "Hören Teil 2 - Interview",
  "titleTr": "Röportaj: Yazar",
  "contextDe": "Sie hören ein Interview mit einem Schriftsteller.",
  "contextTr": "Bir yazarla röportaj dinliyorsunuz.",
  "questionDe": "Was ist dem Autor wichtiger?",
  "questionTr": "Yazar için daha önemli olan nedir?",
  "options": [
   "Die Atmosphäre eines Textes",
   "Eine spannende Handlung",
   "Schnelle Leserzahlen"
  ],
  "correctAnswer": "Die Atmosphäre eines Textes",
  "explanationTr": "\"Weniger ... als ...\" karşılaştırması: asıl amaç atmosfer; olay örgüsü sadece iskelet.",
  "audioPromptDe": "Mir geht es weniger darum, Geschichten zu erzählen, als Atmosphären zu erzeugen. Handlung ist für mich ein notwendiges Gerüst, aber nicht der Kern. Leser, die schnelle Spannung erwarten, werden von meinen Büchern häufig enttäuscht. Dennoch erhalte ich Zuschriften von Menschen, die sagen, sie hätten sich selten so verstanden gefühlt.",
  "transcriptDe": "Mir geht es weniger darum, Geschichten zu erzählen, als Atmosphären zu erzeugen. Handlung ist für mich ein notwendiges Gerüst, aber nicht der Kern. Leser, die schnelle Spannung erwarten, werden von meinen Büchern häufig enttäuscht. Dennoch erhalte ich Zuschriften von Menschen, die sagen, sie hätten sich selten so verstanden gefühlt."
 },
 {
  "id": "go_c1_l_1",
  "section": "lesen",
  "level": "C1",
  "topicTag": "Lesen Teil 1 - Feuilleton",
  "titleTr": "Köşe yazısı: Dijital dikkat",
  "contextDe": "Die Aufmerksamkeit ist zur knappsten Ressource geworden. Plattformen konkurrieren nicht mehr um Inhalte, sondern um Verweildauer, und ihre Algorithmen belohnen, was Empörung auslöst. Es wäre jedoch verfehlt, darin allein ein Technikproblem zu sehen: Die Mechanismen greifen nur, weil sie an menschliche Neigungen anknüpfen, die älter sind als jedes Netzwerk.",
  "contextTr": "Metni okuyun.",
  "questionDe": "Welche These vertritt der Autor?",
  "questionTr": "Yazar hangi tezi savunuyor?",
  "options": [
   "Die Plattformen nutzen bestehende menschliche Neigungen aus.",
   "Technik allein ist an allem schuld.",
   "Aufmerksamkeit ist kein knappes Gut."
  ],
  "correctAnswer": "Die Plattformen nutzen bestehende menschliche Neigungen aus.",
  "explanationTr": "\"Es wäre verfehlt, darin allein ein Technikproblem zu sehen\" - yazar teknolojiyi tek suçlu görmeyi reddediyor."
 },
 {
  "id": "go_c1_l_2",
  "section": "lesen",
  "level": "C1",
  "topicTag": "Lesen Teil 2 - Wissenschaftlicher Text",
  "titleTr": "Bilimsel metin: Nominalstil",
  "contextDe": "Die Etablierung digitaler Verwaltungsverfahren führte zu einer signifikanten Reduktion der Bearbeitungszeiten, wobei sich die Akzeptanz seitens der Bürger erst nach der Behebung anfänglicher Zugangsbarrieren einstellte. Gleichwohl bleibt die Frage nach der Datensicherheit ungeklärt.",
  "contextTr": "Metni okuyun.",
  "questionDe": "Welche Aussage entspricht dem Text?",
  "questionTr": "Hangi ifade metne uygundur?",
  "options": [
   "Die Bürger akzeptierten das System erst, als Zugangsprobleme gelöst waren.",
   "Die Datensicherheit ist vollständig geklärt.",
   "Die Bearbeitungszeiten sind gestiegen."
  ],
  "correctAnswer": "Die Bürger akzeptierten das System erst, als Zugangsprobleme gelöst waren.",
  "explanationTr": "Nominalstil'i fiile çevirin: \"Behebung der Barrieren\" = Barrieren wurden behoben; \"gleichwohl\" = yine de."
 },
 {
  "id": "go_c1_l_3",
  "section": "lesen",
  "level": "C1",
  "topicTag": "Lesen Teil 3 - Konjunktiv I",
  "titleTr": "Dolaylı anlatım",
  "contextDe": "Der Minister erklärte, die Reform sei notwendig, man werde jedoch die Kritik der Verbände berücksichtigen. Er habe die Gespräche bereits aufgenommen.",
  "contextTr": "Haber metnini okuyun.",
  "questionDe": "Was hat der Minister laut Text gesagt?",
  "questionTr": "Metne göre bakan ne söyledi?",
  "options": [
   "Er hält die Reform für nötig und will Kritik berücksichtigen.",
   "Er lehnt die Reform ab.",
   "Er hat Gespräche abgelehnt."
  ],
  "correctAnswer": "Er hält die Reform für nötig und will Kritik berücksichtigen.",
  "explanationTr": "Konjunktiv I (sei, werde, habe) = başkasının sözünü aktarır; gazeteciliğin standart dili."
 },
 {
  "id": "go_c1_s_1",
  "section": "schreiben",
  "level": "C1",
  "topicTag": "Schreiben Teil 1 - Erörterung",
  "titleTr": "Tartışma yazısı (Erörterung)",
  "contextDe": "Thema: \"Sollten Universitäten Anwesenheitspflicht abschaffen?\"",
  "contextTr": "Konu: \"Üniversiteler zorunlu devamı kaldırmalı mı?\"",
  "questionDe": "Verfassen Sie eine Erörterung (ca. 250 Wörter).",
  "questionTr": "Erörterung yazın (yaklaşık 250 kelime):",
  "writingPointsTr": [
   "Giriş: güncel bağlam ve soru",
   "Argümanlar (Pro)",
   "Karşı argümanlar (Kontra)",
   "Ağırlıklandırılmış sonuç"
  ],
  "sampleSolutionDe": "Die Frage, ob Universitäten die Anwesenheitspflicht abschaffen sollten, wird seit Jahren kontrovers diskutiert.\n\nFür eine Abschaffung spricht zunächst der Gedanke der Selbstbestimmung: Studierende, die ihr Lernen eigenverantwortlich organisieren, erwerben Kompetenzen, die im Berufsleben gefragt sind. Hinzu kommt, dass viele neben dem Studium arbeiten müssen und starre Präsenzzeiten sie benachteiligen.\n\nDem lässt sich jedoch entgegenhalten, dass der Austausch im Seminar durch keine Aufzeichnung vollständig ersetzt wird. Wer regelmäßig fehlt, verliert den Anschluss und beeinträchtigt zudem die Diskussionsqualität.\n\nAbwägend lässt sich festhalten, dass eine pauschale Pflicht nicht zeitgemäß erscheint. Sinnvoller wäre eine differenzierte Regelung: Präsenz dort, wo Interaktion den Kern der Lehre bildet, Flexibilität bei Vorlesungen.",
  "criteriaTr": [
   "Gliederung",
   "Differenzierte Argumentation",
   "Gehobener Wortschatz, Nominalstil",
   "Abwägendes Fazit"
  ],
  "explanationTr": "C1'de \"Zwar ... aber\", Nominalisierung ve ağırlıklı sonuç beklenir; sadece liste yetmez."
 },
 {
  "id": "go_c1_s_2",
  "section": "schreiben",
  "level": "C1",
  "topicTag": "Schreiben Teil 2 - Bericht",
  "titleTr": "Rapor: Çalışma saatleri",
  "contextDe": "Sie arbeiten in einer Personalabteilung und sollen die Ergebnisse einer Mitarbeiterbefragung zusammenfassen.",
  "contextTr": "İnsan kaynaklarında çalışan anketi sonuçlarını özetleyeceksiniz.",
  "questionDe": "Schreiben Sie einen Bericht (ca. 200 Wörter).",
  "questionTr": "Rapor yazın:",
  "writingPointsTr": [
   "Amaç ve yöntem",
   "Ana bulgular",
   "Yorum ve öneri"
  ],
  "sampleSolutionDe": "Bericht zur Mitarbeiterbefragung 2026\n\nZiel der Befragung war es, die Zufriedenheit mit den aktuellen Arbeitszeiten zu ermitteln. Befragt wurden 340 Beschäftigte, die Rücklaufquote betrug 72 Prozent.\n\nDie Auswertung zeigt, dass 64 Prozent der Befragten eine flexiblere Gestaltung der Arbeitszeit wünschen. Besonders ausgeprägt ist dieser Wunsch bei Beschäftigten mit Betreuungsaufgaben. Demgegenüber äußern 21 Prozent Bedenken hinsichtlich der Erreichbarkeit im Team.\n\nAus den Ergebnissen lässt sich ableiten, dass ein Gleitzeitmodell mit festen Kernzeiten die Mehrheit der Anliegen berücksichtigen würde. Es empfiehlt sich, dieses Modell zunächst probeweise in zwei Abteilungen einzuführen.",
  "criteriaTr": [
   "Sachlicher Stil",
   "Zahlen korrekt wiedergegeben",
   "Passiv / Nominalstil",
   "Klare Empfehlung"
  ],
  "explanationTr": "C1 raporu nesnel, pasif ve nominal ağırlıklı olmalı; yorum ile bulgu ayrı verilir."
 },
 {
  "id": "go_c1_p_1",
  "section": "sprechen",
  "level": "C1",
  "topicTag": "Sprechen Teil 1 - Vortrag",
  "titleTr": "Bölüm 1: Akademik sunum",
  "contextDe": "Sie halten einen Kurzvortrag zu einem gesellschaftlichen Thema.",
  "contextTr": "Toplumsal bir konuda kısa sunum yapıyorsunuz.",
  "questionDe": "Thema: Wie verändert Künstliche Intelligenz die Arbeitswelt?",
  "questionTr": "Giriş, 3 ana nokta, örnek ve sonuçla 3 dakikalık sunum.",
  "speakingGoalDe": "Einen Vortrag differenziert gliedern und flüssig vortragen.",
  "suggestedPhrasesDe": [
   "Ich möchte mich mit der Frage befassen, inwiefern ...",
   "Zunächst gilt es zu klären, was ...",
   "Besonders bemerkenswert ist ...",
   "Dies lässt sich am Beispiel von ... veranschaulichen.",
   "Zusammenfassend lässt sich festhalten, dass ..."
  ],
  "explanationTr": "C1 sunumunda üst düzey kalıplar ve akıcılık değerlendirilir: \"inwiefern\", \"es gilt\", \"lässt sich\"."
 },
 {
  "id": "go_c1_p_2",
  "section": "sprechen",
  "level": "C1",
  "topicTag": "Sprechen Teil 2 - Diskussion",
  "titleTr": "Bölüm 2: Tartışma",
  "contextDe": "Sie diskutieren mit einem Partner über ein kontroverses Thema.",
  "contextTr": "Partnerinizle tartışmalı bir konuyu tartışıyorsunuz.",
  "questionDe": "Thema: Sollte es eine allgemeine Impfpflicht für Kinder geben?",
  "questionTr": "Nazik ama net itiraz edin, karşı argümanı ele alın, ara kararla uzlaşın.",
  "speakingGoalDe": "Differenziert argumentieren, Einwände entkräften, Kompromisse formulieren.",
  "suggestedPhrasesDe": [
   "Ich möchte dem entgegenhalten, dass ...",
   "Das mag zutreffen, dennoch darf man nicht außer Acht lassen, dass ...",
   "Geht man davon aus, dass ..., so ergibt sich ...",
   "Wir könnten uns auf einen Kompromiss einigen: ...",
   "Ich gebe zu bedenken, dass ..."
  ],
  "explanationTr": "C1 tartışmada \"entgegenhalten\", \"außer Acht lassen\", \"zu bedenken geben\" gibi ifadeler üst düzey puan getirir."
 }
];
