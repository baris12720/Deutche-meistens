import { CEFRLevel, Exercise, DTZQuestion } from '../../types';
import { A1_QUESTION_BANK } from './a1Questions';
import { A2_QUESTION_BANK } from './a2Questions';
import { B1_QUESTION_BANK } from './b1Questions';
import { B2_QUESTION_BANK } from './b2Questions';
import { C1_QUESTION_BANK } from './c1Questions';
import { DTZ_QUESTIONS } from './dtzQuestions';
import { buildLevelVocabExercises } from '../vocab/builder';

export const A1_QUESTIONS = A1_QUESTION_BANK;
export const A2_QUESTIONS = A2_QUESTION_BANK;
export const B1_QUESTIONS = B1_QUESTION_BANK;
export const B2_QUESTIONS = B2_QUESTION_BANK;
export const C1_QUESTIONS = C1_QUESTION_BANK;

export {
  A1_QUESTION_BANK,
  A2_QUESTION_BANK,
  B1_QUESTION_BANK,
  B2_QUESTION_BANK,
  C1_QUESTION_BANK,
  DTZ_QUESTIONS,
};

export function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function getLevelQuestionPool(level: CEFRLevel): Exercise[] {
  const bank =
    level === 'A1' ? A1_QUESTION_BANK
    : level === 'A2' ? A2_QUESTION_BANK
    : level === 'B1' ? B1_QUESTION_BANK
    : level === 'B2' ? B2_QUESTION_BANK
    : level === 'C1' ? C1_QUESTION_BANK
    : A1_QUESTION_BANK;
  return [...bank, ...buildLevelVocabExercises(level)];
}

export function getLevelQuestions(
  level: CEFRLevel,
  count: number | 'all' = 'all',
  shuffle = true
): Exercise[] {
  const pool = getLevelQuestionPool(level);
  const workingPool = shuffle ? shuffleArray(pool) : [...pool];
  if (count === 'all' || count >= workingPool.length) {
    return workingPool;
  }
  return workingPool.slice(0, count);
}

export function getDTZQuestions(options?: {
  section?: 'hoeren' | 'lesen' | 'schreiben' | 'sprechen' | 'all';
  level?: 'A2' | 'B1' | 'all';
  count?: number | 'all';
  shuffle?: boolean;
}): DTZQuestion[] {
  const {
    section = 'all',
    level = 'all',
    count = 'all',
    shuffle = true,
  } = options || {};

  let pool = [...DTZ_QUESTIONS];

  if (section !== 'all') {
    pool = pool.filter((q) => q.section === section);
  }

  if (level !== 'all') {
    pool = pool.filter((q) => q.level === level);
  }

  const working = shuffle ? shuffleArray(pool) : pool;
  if (count === 'all' || count >= working.length) {
    return working;
  }
  return working.slice(0, count);
}

export function getAllQuestionsStats() {
  return {
    A1: A1_QUESTION_BANK.length,
    A2: A2_QUESTION_BANK.length,
    B1: B1_QUESTION_BANK.length,
    B2: B2_QUESTION_BANK.length,
    C1: C1_QUESTION_BANK.length,
    DTZ: DTZ_QUESTIONS.length,
    totalCEFR:
      A1_QUESTION_BANK.length +
      A2_QUESTION_BANK.length +
      B1_QUESTION_BANK.length +
      B2_QUESTION_BANK.length +
      C1_QUESTION_BANK.length,
    grandTotal:
      A1_QUESTION_BANK.length +
      A2_QUESTION_BANK.length +
      B1_QUESTION_BANK.length +
      B2_QUESTION_BANK.length +
      C1_QUESTION_BANK.length +
      DTZ_QUESTIONS.length,
  };
}
