#!/usr/bin/env bash
# GitHub Actions icinde calisir: projeyi bulur, Capacitor ile Android debug APK uretir.
set -euo pipefail

ROOT="$(pwd)"
RUN="${GITHUB_RUN_NUMBER:-1}"

if [ -f package.json ]; then
  PROJECT_DIR="$ROOT"
else
  PKG="$(find _p -maxdepth 3 -name package.json -not -path '*/node_modules/*' -not -path '*/__MACOSX/*' | head -n1)"
  if [ -z "$PKG" ]; then
    echo "::error::package.json bulunamadi. Proje zip'ini depoya yukleyin."
    exit 1
  fi
  PROJECT_DIR="$ROOT/$(dirname "$PKG")"
fi
echo "Proje klasoru: $PROJECT_DIR"
cd "$PROJECT_DIR"

echo "== Android SDK lisanslari =="
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null 2>&1 || true

echo "== Bagimliliklar =="
npm install --legacy-peer-deps --no-audit --no-fund
npm install --legacy-peer-deps --no-audit --no-fund @capacitor/core@7 @capacitor/android@7
npm install --legacy-peer-deps --no-audit --no-fund --save-dev @capacitor/cli@7

if [ ! -f capacitor.config.json ] && [ ! -f capacitor.config.ts ]; then
  cat > capacitor.config.json <<'JSON'
{
  "appId": "com.deutschmeister.app",
  "appName": "Deutsch Meister",
  "webDir": "dist",
  "server": { "androidScheme": "https" }
}
JSON
fi

echo "== Web derlemesi =="
BASE_PATH=/ npm run build

echo "== Android projesi =="
if [ ! -d android ]; then npx cap add android; fi

echo "== Ikon (basarisiz olursa varsayilan kalir) =="
(
  if [ -f public/pwa-512x512.png ]; then
    mkdir -p assets
    convert public/pwa-512x512.png -resize 1024x1024 assets/icon-only.png
    cp assets/icon-only.png assets/icon-foreground.png
    convert -size 1024x1024 xc:'#22c55e' assets/icon-background.png
    npx --yes @capacitor/assets generate --android --iconBackgroundColor '#22c55e' --iconBackgroundColorDark '#22c55e'
  fi
) || echo "Ikon olusturulamadi, varsayilan ikon kullanilacak."

echo "== Sync ve surum =="
npx cap sync android
GRADLE=android/app/build.gradle
sed -i "s/versionCode [0-9]*/versionCode $RUN/" "$GRADLE"
sed -i "s/versionName \"[^\"]*\"/versionName \"1.0.$RUN\"/" "$GRADLE"

echo "== APK derleme =="
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
cd ..

mkdir -p "$ROOT/out"
cp android/app/build/outputs/apk/debug/app-debug.apk "$ROOT/out/deutsch-meister-$RUN.apk"
ls -la "$ROOT/out"
echo "APK hazir."
