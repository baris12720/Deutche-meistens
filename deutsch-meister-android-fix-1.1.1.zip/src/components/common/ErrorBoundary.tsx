import React from 'react';

interface State {
  hasError: boolean;
  message: string;
  componentStack: string;
}

/**
 * Prevents a rendering crash from becoming an unexplained white screen.
 * Recovery clears only disposable web caches/service workers and never touches
 * localStorage, where the learner's progress is stored.
 */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false, message: '', componentStack: '' };

  static getDerivedStateFromError(error: unknown): Partial<State> {
    const message = error instanceof Error ? `${error.name}: ${error.message}` : String(error || 'Bilinmeyen uygulama hatası');
    return { hasError: true, message, componentStack: '' };
  }

  componentDidCatch(error: unknown, info: React.ErrorInfo) {
    const report = {
      message: error instanceof Error ? `${error.name}: ${error.message}` : String(error),
      stack: error instanceof Error ? error.stack || '' : '',
      componentStack: info.componentStack || '',
      time: new Date().toISOString(),
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown',
    };

    this.setState({ componentStack: report.componentStack });
    try {
      localStorage.setItem('dm_last_runtime_error_v1', JSON.stringify(report));
    } catch {
      // Diagnostics are optional; storage failure must not hide the fallback.
    }
    console.error('Deutsch Meister render error:', error, info.componentStack);
  }

  private getReport() {
    return [
      'Deutsch Meister hata raporu',
      `Hata: ${this.state.message || 'Bilinmiyor'}`,
      `Zaman: ${new Date().toISOString()}`,
      `Cihaz: ${typeof navigator !== 'undefined' ? navigator.userAgent : 'Bilinmiyor'}`,
      `Bileşen yolu: ${this.state.componentStack || 'Yok'}`,
    ].join('\\n');
  }

  private copyReport = async () => {
    const report = this.getReport();
    try {
      await navigator.clipboard.writeText(report);
      window.alert('Hata raporu kopyalandı. Destek için buraya yapıştırabilirsiniz.');
    } catch {
      window.prompt('Hata raporunu kopyalayın:', report);
    }
  };

  private repairAndReload = async () => {
    // Remove stale web assets without deleting the learner's saved progress.
    try {
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map((registration) => registration.unregister()));
      }
    } catch {
      // Continue; service workers are not available in every WebView.
    }

    try {
      if ('caches' in window) {
        const keys = await window.caches.keys();
        await Promise.all(keys.map((key) => window.caches.delete(key)));
      }
    } catch {
      // Cache API may be unavailable in some WebViews.
    }

    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <main className="min-h-screen flex flex-col items-center justify-center gap-4 p-6 text-center bg-slate-50 text-slate-900">
        <div className="text-5xl" role="img" aria-label="Üzgün yüz">😕</div>
        <h1 className="text-2xl font-black">Bir şeyler ters gitti</h1>
        <p className="text-sm text-slate-600 max-w-sm">
          Uygulama açılırken bir hata oluştu. Öğrenme ilerlemeniz silinmedi.
          Hata raporunu kopyalayıp destek için gönderebilirsiniz.
        </p>

        <section className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-3 text-left">
          <p className="text-xs font-bold text-slate-500 mb-1">Hata ayrıntısı</p>
          <pre className="whitespace-pre-wrap break-words text-xs text-slate-700 max-h-36 overflow-auto">
            {this.state.message || 'Hata ayrıntısı alınamadı.'}
          </pre>
          {this.state.componentStack && (
            <details className="mt-2">
              <summary className="cursor-pointer text-xs font-bold text-slate-600">Teknik ayrıntılar</summary>
              <pre className="mt-2 whitespace-pre-wrap break-words text-[10px] text-slate-500 max-h-40 overflow-auto">
                {this.state.componentStack}
              </pre>
            </details>
          )}
        </section>

        <div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm">
          <button
            type="button"
            onClick={this.copyReport}
            className="flex-1 px-5 py-3 rounded-2xl border-2 border-slate-200 bg-white text-slate-800 font-bold"
          >
            Hata raporunu kopyala
          </button>
          <button
            type="button"
            onClick={this.repairAndReload}
            className="flex-1 px-5 py-3 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none"
          >
            Onar ve yeniden aç
          </button>
        </div>
      </main>
    );
  }
}
