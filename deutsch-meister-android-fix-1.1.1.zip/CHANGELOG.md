# Değişiklik günlüğü

## 1.1.0 — Kullanılabilirlik ve güvenilirlik güncellemesi

- Günlük çalışma serisi artık uygulamanın açılmasıyla değil, gerçek bir öğrenme etkinliğiyle ilerler.
- Günlük XP yeni takvim gününde sıfırlanır; günler arası fark hesaplaması yaz/kış saati değişimlerinden etkilenmez.
- Son seçilen CEFR seviyesi yeniden açılışta korunur.
- Açık/koyu/cihaz teması tercihi eklendi ve sistem temasını otomatik izler.
- Mobil gezinmede kelime kartları, günlük diyaloglar ve karışık testler için ek menü eklendi.
- Seviye seçici fareyle üzerine gelme gerektirmeyen, dokunmatik ve klavye uyumlu bir kontrole dönüştürüldü.
- Profil adı düzenlenebilir hâle geldi.
- JSON yedekleri uygulama adı ve şema sürümüyle dışa aktarılır; eski biçimdeki yedekler de içe aktarılabilir.
- Yedek içe aktarımında alanlar doğrulanır ve sınırlandırılır; bozuk/uygunsuz veri doğrudan uygulama durumuna yazılmaz.
- Yedek dosyası seçerek geri yükleme eklendi.
- GitHub Pages altında ikon yolları düzeltildi; sayfa dili Türkçe olarak ayarlandı ve yakınlaştırmayı engelleyen viewport kısıtlaması kaldırıldı.
- Klavye odağı daha görünür hâle getirildi.

## 1.1.1 — Android açılış ve hata tanılama düzeltmesi

- Android APK derlemesinde PWA service worker kaydı kapatıldı; eski web önbelleğinin yeni APK JavaScript dosyalarıyla karışması önlenir.
- Her APK derlemesinden önce eski `dist` klasörü temizlenir.
- Uygulama açılışında React hatası oluşursa artık hata mesajı ve bileşen yolu gösterilir.
- Hata raporu panoya kopyalanabilir; destek için gerekli cihaz ve hata bilgileri eklenir.
- Onarım düğmesi yalnızca Service Worker ve Cache Storage önbelleklerini temizler; öğrenme ilerlemesinin bulunduğu localStorage verilerine dokunmaz.
