import { CEFRLevel, Exercise } from '../types';

export interface ConnectorItem {
  word: string; // as shown on the card (may contain "...")
  form: string; // single word used in the blank / typing
  meaningTr: string;
  template: string; // example with the connector marked as {form}
  exampleTr: string;
}

export interface ConnectorGroup {
  id: string;
  level: CEFRLevel;
  emoji: string;
  titleTr: string;
  ruleTr: string; // word-order rule explained in Turkish
  formulaDe: string; // short pattern
  tipTr: string;
  items: ConnectorItem[];
  quiz: { q: string; options: string[]; answer: string; explanationTr: string }[];
}

const it = (word: string, form: string, meaningTr: string, template: string, exampleTr: string): ConnectorItem => ({
  word,
  form,
  meaningTr,
  template,
  exampleTr,
});

export const CONNECTOR_GROUPS: ConnectorGroup[] = [
  {
    id: 'weil-denn',
    level: 'A2',
    emoji: '❓',
    titleTr: 'Neden: weil, denn, da',
    ruleTr:
      '"weil" ve "da" yan cümle kurar: çekimli fiil cümlenin EN SONUNA gider. "denn" ise iki ana cümleyi bağlar: fiil normal yerinde (2. sırada) kalır.',
    formulaDe: 'weil + Subjekt ... Verb  |  denn + Subjekt + Verb ...',
    tipTr: 'Kolay kural: weil = fiil sonda, denn = sıra değişmez.',
    items: [
      it('weil', 'weil', 'çünkü (yan cümle)', 'Ich bleibe zu Hause, {weil} ich krank bin.', 'Hasta olduğum için evde kalıyorum.'),
      it('denn', 'denn', 'çünkü (ana cümle)', 'Ich bleibe zu Hause, {denn} ich bin krank.', 'Evde kalıyorum, çünkü hastayım.'),
      it('da', 'da', 'mademki, -diğinden', '{Da} es regnet, bleiben wir zu Hause.', 'Yağmur yağdığı için evde kalıyoruz.'),
      it('nämlich', 'nämlich', 'çünkü (cümle içinde)', 'Ich bleibe zu Hause. Ich bin {nämlich} krank.', 'Evde kalıyorum. Çünkü hastayım.'),
      it('wegen', 'wegen', '-den dolayı (isimle)', '{Wegen} des Regens bleiben wir zu Hause.', 'Yağmur yüzünden evde kalıyoruz.'),
    ],
    quiz: [
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich lerne Deutsch, weil ich in Deutschland arbeite.', 'Ich lerne Deutsch, weil ich arbeite in Deutschland.', 'Ich lerne Deutsch, weil arbeite ich in Deutschland.'],
        answer: 'Ich lerne Deutsch, weil ich in Deutschland arbeite.',
        explanationTr: '"weil" cümlesinde çekimli fiil (arbeite) en sona gider.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Er ist müde, denn er hat wenig geschlafen.', 'Er ist müde, denn er wenig geschlafen hat.', 'Er ist müde, denn hat er wenig geschlafen.'],
        answer: 'Er ist müde, denn er hat wenig geschlafen.',
        explanationTr: '"denn" sonrasında sıra değişmez: özne + fiil.',
      },
    ],
  },
  {
    id: 'deshalb',
    level: 'A2',
    emoji: '➡️',
    titleTr: 'Sonuç: deshalb, deswegen, darum, also',
    ruleTr:
      'Bu sözcükler ilk sırayı (Position 1) alır ve hemen arkasından çekimli fiil gelir. Yani cümle "deshalb + FİİL + özne" şeklinde ilerler.',
    formulaDe: '..., deshalb + Verb + Subjekt ...',
    tipTr: 'deshalb, deswegen ve darum aynı anlamdadır. "deshalb" en yaygın olanıdır.',
    items: [
      it('deshalb', 'deshalb', 'bu yüzden', 'Ich bin müde, {deshalb} gehe ich früh ins Bett.', 'Yorgunum, bu yüzden erken yatıyorum.'),
      it('deswegen', 'deswegen', 'bu nedenle', 'Es regnet, {deswegen} bleiben wir zu Hause.', 'Yağmur yağıyor, bu nedenle evde kalıyoruz.'),
      it('darum', 'darum', 'bu yüzden', 'Er hat Hunger, {darum} kocht er Suppe.', 'Karnı aç, bu yüzden çorba pişiriyor.'),
      it('also', 'also', 'öyleyse, yani', 'Du bist krank, {also} bleibst du im Bett.', 'Hastasın, öyleyse yatakta kal.'),
      it('folglich', 'folglich', 'sonuç olarak', 'Die Preise stiegen, {folglich} kauften weniger Leute ein.', 'Fiyatlar arttı, sonuç olarak daha az insan alışveriş yaptı.'),
    ],
    quiz: [
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich habe Hunger, deshalb esse ich ein Brot.', 'Ich habe Hunger, deshalb ich esse ein Brot.', 'Ich habe Hunger, deshalb ein Brot ich esse.'],
        answer: 'Ich habe Hunger, deshalb esse ich ein Brot.',
        explanationTr: '"deshalb" sonrası fiil hemen gelir, özne ondan sonra.',
      },
      {
        q: 'Hangi sözcük çekimli fiili cümlenin sonuna gönderir?',
        options: ['weil', 'deshalb', 'darum'],
        answer: 'weil',
        explanationTr: '"deshalb" ve "darum" fiili hemen arkasına alır, sadece "weil" fiili sona gönderir.',
      },
    ],
  },
  {
    id: 'dass-ob',
    level: 'A2',
    emoji: '💬',
    titleTr: 'dass, ob, damit ve dolaylı sorular',
    ruleTr:
      '"dass" (-ki, -diğini), "ob" (-ip -mediğini), "damit" (-sin diye) ve dolaylı soru kelimeleri (wie, wann, wo) yan cümle kurar. Çekimli fiil en sona gider. Evet/hayır sorusu dolaylı olunca "ob" kullanılır.',
    formulaDe: 'Hauptsatz, dass/ob/damit + Subjekt ... Verb',
    tipTr: '"Ich glaube, ..." gibi ana cümlelerin ardından hep virgül ve "dass" gelir.',
    items: [
      it('dass', 'dass', '-diğini, -ki', 'Ich glaube, {dass} er recht hat.', 'Onun haklı olduğunu düşünüyorum.'),
      it('ob', 'ob', '-ip -mediğini', 'Ich weiß nicht, {ob} er kommt.', 'Onun gelip gelmeyeceğini bilmiyorum.'),
      it('damit', 'damit', '-sin diye (amaç)', 'Ich lerne viel, {damit} ich die Prüfung bestehe.', 'Sınavı geçeyim diye çok çalışıyorum.'),
      it('wie', 'wie', 'nasıl (dolaylı soru)', 'Ich weiß, {wie} man das schreibt.', 'Bunun nasıl yazıldığını biliyorum.'),
      it('wann', 'wann', 'ne zaman (dolaylı soru)', 'Sag mir, {wann} der Zug fährt.', 'Bana trenin ne zaman kalktığını söyle.'),
    ],
    quiz: [
      {
        q: '"Ich weiß nicht, ___ er heute kommt." (evet/hayır sorusu)',
        options: ['ob', 'dass', 'damit'],
        answer: 'ob',
        explanationTr: 'Evet/hayır içeren dolaylı soru "ob" ile kurulur.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich hoffe, dass du morgen kommst.', 'Ich hoffe, dass kommst du morgen.', 'Ich hoffe, dass du kommst morgen.'],
        answer: 'Ich hoffe, dass du morgen kommst.',
        explanationTr: '"dass" cümlesinde fiil (kommst) en sona gider.',
      },
    ],
  },
  {
    id: 'aber-trotzdem',
    level: 'A2',
    emoji: '↔️',
    titleTr: 'Karşıtlık: aber, sondern, trotzdem, obwohl',
    ruleTr:
      '"aber", "sondern", "doch" ve "jedoch" sıra değiştirmez. "trotzdem" ilk sırayı alır, fiil hemen arkasından gelir. "obwohl" yan cümle kurar, fiil sona gider. "sondern" olumsuzdan sonra "-değil, aksine" anlamında kullanılır.',
    formulaDe: 'aber + S + V  |  trotzdem + V + S  |  obwohl + S ... V',
    tipTr: '"nicht ... sondern ..." her zaman birlikte düşünün: Kahve değil, çay.',
    items: [
      it('aber', 'aber', 'ama', 'Ich möchte kommen, {aber} ich habe keine Zeit.', 'Gelmek istiyorum ama vaktim yok.'),
      it('sondern', 'sondern', '-değil, aksine', 'Ich trinke keinen Kaffee, {sondern} Tee.', 'Kahve değil, çay içiyorum.'),
      it('trotzdem', 'trotzdem', 'buna rağmen', 'Es regnet, {trotzdem} gehen wir spazieren.', 'Yağmur yağıyor, buna rağmen yürüyüşe çıkıyoruz.'),
      it('obwohl', 'obwohl', '-e rağmen (yan cümle)', 'Ich gehe zur Arbeit, {obwohl} ich krank bin.', 'Hasta olmama rağmen işe gidiyorum.'),
      it('doch', 'doch', 'yine de, ama', 'Er ist reich, {doch} er ist nicht glücklich.', 'O zengin, ama mutlu değil.'),
      it('jedoch', 'jedoch', 'ancak', 'Das Hotel ist schön, {jedoch} sehr teuer.', 'Otel güzel, ancak çok pahalı.'),
    ],
    quiz: [
      {
        q: '"Ich fahre nicht nach Berlin, ___ nach München."',
        options: ['sondern', 'aber', 'trotzdem'],
        answer: 'sondern',
        explanationTr: 'Olumsuz bir ifadeden sonra "aksine, ... değil" anlamı için "sondern" kullanılır.',
      },
      {
        q: 'Hangi sözcük fiili cümlenin sonuna gönderir?',
        options: ['obwohl', 'trotzdem', 'aber'],
        answer: 'obwohl',
        explanationTr: '"obwohl" yan cümle kurar. "trotzdem" ve "aber" fiili sona göndermez.',
      },
    ],
  },
  {
    id: 'zeit',
    level: 'B1',
    emoji: '⏰',
    titleTr: 'Zaman: wenn, als, während, bevor, nachdem',
    ruleTr:
      'Zaman bağlaçları yan cümle kurar: fiil sona gider. "als" geçmişte TEK SEFER olan olaylar için, "wenn" tekrar eden olaylar ve şimdiki/gelecek için kullanılır. "nachdem" ile genelde Plusquamperfekt + Präteritum/Perfekt eşleşir.',
    formulaDe: 'wenn/als/während/bevor/nachdem + Subjekt ... Verb',
    tipTr: 'Geçmişte bir kez: als. Her zaman, her seferinde: wenn.',
    items: [
      it('wenn', 'wenn', '-dığında, -sa (tekrar eden)', '{Wenn} ich Zeit habe, lese ich ein Buch.', 'Vaktim olduğunda kitap okurum.'),
      it('als', 'als', '-dığında (geçmişte tek sefer)', '{Als} ich ein Kind war, wohnte ich in Izmir.', 'Çocukken İzmir\'de yaşıyordum.'),
      it('während', 'während', '-ken, süresince', '{Während} ich koche, hört er Musik.', 'Ben yemek yaparken o müzik dinliyor.'),
      it('bevor', 'bevor', '-meden önce', 'Ich dusche, {bevor} ich zur Arbeit gehe.', 'İşe gitmeden önce duş alıyorum.'),
      it('nachdem', 'nachdem', '-dikten sonra', '{Nachdem} ich gegessen hatte, ging ich spazieren.', 'Yemek yedikten sonra yürüyüşe çıktım.'),
      it('seitdem', 'seitdem', '-diğinden beri', 'Ich bin glücklich, {seitdem} ich hier wohne.', 'Burada yaşadığımdan beri mutluyum.'),
      it('bis', 'bis', '-e kadar', 'Ich warte hier, {bis} du kommst.', 'Sen gelene kadar burada bekliyorum.'),
      it('sobald', 'sobald', '-er -mez', 'Ich rufe an, {sobald} ich ankomme.', 'Varır varmaz arıyorum.'),
    ],
    quiz: [
      {
        q: '"___ ich gestern nach Hause kam, schlief mein Sohn schon."',
        options: ['Als', 'Wenn', 'Während'],
        answer: 'Als',
        explanationTr: 'Geçmişte tek bir olay: "als".',
      },
      {
        q: '"___ ich müde bin, trinke ich immer Kaffee." (her seferinde)',
        options: ['Wenn', 'Als', 'Bevor'],
        answer: 'Wenn',
        explanationTr: 'Tekrar eden durum: "wenn".',
      },
    ],
  },
  {
    id: 'bedingung',
    level: 'B1',
    emoji: '🎯',
    titleTr: 'Koşul ve amaç: falls, damit, um ... zu',
    ruleTr:
      '"falls" ve "sofern" koşul yan cümlesi kurar (fiil sonda). Amaç için iki yol var: özneler AYNIYSA "um ... zu + mastar", özneler FARKLIYSA "damit + yan cümle". "ohne ... zu" (-meden) ve "anstatt ... zu" (-mek yerine) de mastarla kurulur.',
    formulaDe: 'um + ... + zu + Infinitiv  |  damit + S ... V',
    tipTr: 'Aynı özne: um ... zu. Farklı özne: damit.',
    items: [
      it('falls', 'falls', 'eğer (olasılık)', '{Falls} es regnet, bleiben wir zu Hause.', 'Yağmur yağarsa evde kalırız.'),
      it('sofern', 'sofern', '-mek şartıyla', 'Wir kommen, {sofern} wir Zeit haben.', 'Vaktimiz olursa geliriz.'),
      it('damit', 'damit', '-sin diye (farklı özne)', 'Ich spare Geld, {damit} wir reisen können.', 'Seyahat edebilelim diye para biriktiriyorum.'),
      it('um ... zu', 'um', '-mek için (aynı özne)', 'Ich lerne Deutsch, {um} in Deutschland zu arbeiten.', 'Almanya\'da çalışmak için Almanca öğreniyorum.'),
      it('ohne ... zu', 'ohne', '-meden', 'Er ging, {ohne} sich zu verabschieden.', 'O vedalaşmadan gitti.'),
      it('anstatt ... zu', 'anstatt', '-mek yerine', '{Anstatt} zu lernen, spielt er Fußball.', 'Ders çalışmak yerine futbol oynuyor.'),
    ],
    quiz: [
      {
        q: '"Ich fahre in die Stadt, ___ Brot zu kaufen."',
        options: ['um', 'damit', 'falls'],
        answer: 'um',
        explanationTr: 'Aynı özne (ich fahre / ich kaufe): "um ... zu".',
      },
      {
        q: '"Ich gebe dir Geld, ___ du ein Ticket kaufen kannst."',
        options: ['damit', 'um', 'ohne'],
        answer: 'damit',
        explanationTr: 'Özneler farklı (ich / du): "damit" ile yan cümle kurulur.',
      },
    ],
  },
  {
    id: 'ekleme',
    level: 'B1',
    emoji: '➕',
    titleTr: 'Ekleme ve seçenek: außerdem, weder ... noch',
    ruleTr:
      '"außerdem" ve "zudem" ilk sırayı alır, fiil hemen arkasından gelir. "sowohl ... als auch", "weder ... noch", "entweder ... oder", "nicht nur ... sondern auch" ve "einerseits ... andererseits" ikili kalıplardır, birlikte kullanılır.',
    formulaDe: 'außerdem + V + S  |  weder ... noch ... | entweder ... oder ...',
    tipTr: 'İkili kalıpları cümle içinde iki yarısıyla birlikte ezberleyin.',
    items: [
      it('außerdem', 'außerdem', 'ayrıca', 'Ich bin müde. {Außerdem} habe ich Hunger.', 'Yorgunum. Ayrıca açım.'),
      it('zudem', 'zudem', 'üstelik', 'Die Wohnung ist günstig, {zudem} liegt sie zentral.', 'Daire ucuz, üstelik merkezde.'),
      it('sowohl ... als auch', 'sowohl', 'hem ... hem de', 'Er spricht {sowohl} Türkisch als auch Deutsch.', 'O hem Türkçe hem Almanca konuşuyor.'),
      it('weder ... noch', 'weder', 'ne ... ne de', 'Ich habe {weder} Zeit noch Geld.', 'Ne vaktim ne de param var.'),
      it('entweder ... oder', 'entweder', 'ya ... ya da', 'Wir fahren {entweder} mit dem Bus oder mit dem Zug.', 'Ya otobüsle ya da trenle gidiyoruz.'),
      it('nicht nur ... sondern auch', 'sondern', 'sadece ... değil, aynı zamanda', 'Sie ist nicht nur klug, {sondern} auch fleißig.', 'O sadece zeki değil, aynı zamanda çalışkan.'),
      it('einerseits ... andererseits', 'einerseits', 'bir yandan ... diğer yandan', '{Einerseits} ist es teuer, andererseits ist es bequem.', 'Bir yandan pahalı, diğer yandan rahat.'),
    ],
    quiz: [
      {
        q: '"Er hat ___ Zeit ___ Lust." (ikisi de yok)',
        options: ['weder ... noch', 'entweder ... oder', 'sowohl ... als auch'],
        answer: 'weder ... noch',
        explanationTr: 'İki şey de yoksa "weder ... noch" kullanılır.',
      },
      {
        q: 'Hangi cümle doğru?',
        options: ['Ich bin müde. Außerdem habe ich Hunger.', 'Ich bin müde. Außerdem ich habe Hunger.', 'Ich bin müde. Außerdem Hunger ich habe.'],
        answer: 'Ich bin müde. Außerdem habe ich Hunger.',
        explanationTr: '"außerdem" ilk sırayı alır, fiil hemen arkasından gelir.',
      },
    ],
  },
  {
    id: 'fortgeschritten',
    level: 'B2',
    emoji: '🚀',
    titleTr: 'İleri bağlaçlar: sodass, indem, je ... desto',
    ruleTr:
      '"sodass" (böylece) ve "indem" (-erek) yan cümle kurar, fiil sona gider. "je ... desto" karşılaştırmalı ikili kalıptır: her iki yarım cümlede de karşılaştırma hâli kullanılır. "dennoch", "allerdings" ve "infolgedessen" ilk sırayı alır.',
    formulaDe: 'sodass/indem + S ... V  |  je + Komparativ ..., desto + Komparativ + V + S',
    tipTr: '"je mehr ... desto besser": ikinci kısımda fiil hemen "desto" ifadesinden sonra gelir.',
    items: [
      it('sodass', 'sodass', 'böylece, öyle ki', 'Es regnete stark, {sodass} wir nicht losfahren konnten.', 'Yağmur çok şiddetliydi, böylece yola çıkamadık.'),
      it('indem', 'indem', '-erek', 'Man lernt Wörter, {indem} man viel liest.', 'Çok okuyarak kelime öğrenilir.'),
      it('je ... desto', 'je', 'ne kadar ... o kadar', '{Je} mehr du übst, desto besser wirst du.', 'Ne kadar çok çalışırsan o kadar iyi olursun.'),
      it('zwar ... aber', 'zwar', 'doğru ama', 'Das ist {zwar} teuer, aber sehr gut.', 'Bu doğru pahalı, ama çok iyi.'),
      it('dennoch', 'dennoch', 'buna rağmen', 'Es war schwer, {dennoch} habe ich es geschafft.', 'Zordu, buna rağmen başardım.'),
      it('allerdings', 'allerdings', 'ancak, bununla birlikte', 'Das Angebot ist gut, {allerdings} teuer.', 'Teklif iyi, ancak pahalı.'),
      it('infolgedessen', 'infolgedessen', 'bunun sonucunda', 'Es gab einen Unfall, {infolgedessen} war die Straße gesperrt.', 'Bir kaza oldu, bunun sonucunda yol kapandı.'),
    ],
    quiz: [
      {
        q: '"Je mehr du lernst, ___ besser wirst du."',
        options: ['desto', 'dass', 'obwohl'],
        answer: 'desto',
        explanationTr: '"je + Komparativ ..., desto + Komparativ" ikilisi.',
      },
      {
        q: '"Man lernt Wörter, ___ man viel liest."',
        options: ['indem', 'denn', 'also'],
        answer: 'indem',
        explanationTr: '"indem" = -erek: bir şeyi yapmanın yolu.',
      },
    ],
  },
];

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const plain = (t: string) => t.replace(/[{}]/g, '');

export function buildConnectorExercises(group: ConnectorGroup): Exercise[] {
  const allForms = Array.from(new Set(CONNECTOR_GROUPS.flatMap((g) => g.items.map((i) => i.form))));
  const out: Exercise[] = [];
  const tag = `Bağlaç: ${group.titleTr}`;

  group.items.forEach((item, idx) => {
    const base = { level: group.level, topicTag: tag };
    const sentence = plain(item.template);
    const atStart = item.template.trim().startsWith('{');
    const fix = (x: string) => (atStart ? x.charAt(0).toUpperCase() + x.slice(1) : x);

    // meaning (word -> Turkish)
    const wrongMeanings = shuffle(
      Array.from(new Set(CONNECTOR_GROUPS.flatMap((g) => g.items.map((i) => i.meaningTr)).filter((m) => m !== item.meaningTr)))
    ).slice(0, 3);
    out.push({
      ...base,
      id: `conn_${group.id}_${idx}_mc`,
      type: 'multiple_choice',
      instructionTr: 'Bu bağlacın anlamı nedir?',
      prompt: item.word,
      options: shuffle([item.meaningTr, ...wrongMeanings]),
      correctAnswer: item.meaningTr,
      explanationTr: `${item.word} = ${item.meaningTr}. Örnek: ${sentence} (${item.exampleTr})`,
    } as Exercise);

    // fill blank (choose the connector)
    const sameGroup = group.items.map((i) => i.form).filter((f) => f !== item.form);
    const others = allForms.filter((f) => f !== item.form && !sameGroup.includes(f));
    const wrong = Array.from(new Set([...shuffle(sameGroup).slice(0, 3), ...shuffle(others)])).slice(0, 3);
    out.push({
      ...base,
      id: `conn_${group.id}_${idx}_fill`,
      type: 'fill_blank',
      instructionTr: 'Boşluğa uygun bağlacı seçin:',
      sentenceWithBlank: item.template.replace(/\{[^}]+\}/, '___'),
      turkishTranslation: item.exampleTr,
      options: shuffle([fix(item.form), ...wrong.map(fix)]),
      correctAnswer: fix(item.form),
      explanationTr: `${sentence} (${item.exampleTr})`,
    } as Exercise);

    // word order (sentence builder)
    const words = sentence.split(' ');
    if (words.length >= 4 && words.length <= 11) {
      out.push({
        ...base,
        id: `conn_${group.id}_${idx}_order`,
        type: 'sentence_builder',
        instructionTr: 'Cümleyi doğru kelime sırasıyla kurun:',
        turkishPrompt: item.exampleTr,
        correctGermanSentence: sentence,
        scrambledWords: words,
        explanationTr: `${sentence} (Kural: ${group.formulaDe})`,
      } as Exercise);
    }

    // spelling the connector
    if (/^[a-zäöüß]+$/i.test(item.form)) {
      out.push({
        ...base,
        id: `conn_${group.id}_${idx}_type`,
        type: 'typing',
        mode: 'word',
        instructionTr: 'Bağlacı Almanca yazın:',
        promptTr: item.meaningTr,
        hintTr: `${item.form.length} harf, "${item.form.charAt(0)}" ile başlar`,
        answer: item.form,
        explanationTr: `${item.form} = ${item.meaningTr}. ${sentence}`,
      } as Exercise);
    }
  });

  // hand-written word-order / rule questions
  group.quiz.forEach((q, i) => {
    out.push({
      ...base2(group, tag),
      id: `conn_${group.id}_q${i}`,
      type: 'multiple_choice',
      instructionTr: 'Kuralı uygulayın:',
      prompt: q.q,
      options: shuffle(q.options),
      correctAnswer: q.answer,
      explanationTr: q.explanationTr,
    } as Exercise);
  });

  return out;
}

function base2(group: ConnectorGroup, tag: string) {
  return { level: group.level, topicTag: tag };
}
