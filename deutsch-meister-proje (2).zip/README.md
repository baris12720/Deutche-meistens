# Deutsch Meister

Türkçe konuşanlar için Almanca öğrenme uygulaması (PWA). A1'den C1'e seviyeli dersler, kelime oyunu, Goethe ve DTZ sınav hazırlığı.

## Özellikler

- **Öğrenim haritası:** Duolingo tarzı yol. Dersler sırayla açılır, her seviye için seviye sınavı vardır.
- **Seviye geçişi:** Bir sonraki seviye için tüm dersler bitmeli ve seviye sınavı en az %70 ile geçilmeli. Seviye tespit sınavı ile doğrudan atlama mümkündür.
- **Kelime oyunu:** 1660'tan fazla kelime (seviye başına 320-360), 8'erli setler. Önce kartlarda artikel, anlam ve örnek cümle, sonra boşluk doldurma, dinleme, cümle kurma ve artikel soruları.
- **Goethe & DTZ Sınav Merkezi:** A1-C1 için Hören, Lesen, Schreiben ve Sprechen görevleri, sınav simülasyonu.
- Günlük özet: günlük hedef halkası, haftalık seri takvimi, günün kelimesi, konfeti ve titreşim geri bildirimi.
- Android'de telefonun kendi Almanca sesiyle okuma.
- Yazarak cevap soruları: kelimeyi ve cümleyi (dikte) doğru yazmayı öğretir, ä ö ü ß tuşları vardır.
- Bağlaçlar bölümü: weil/denn, deshalb/deswegen, dass/ob, obwohl/trotzdem, wenn/als, um...zu/damit ve daha fazlası; kural kartı, örnek, kelime sırası ve yazma alıştırmaları.
- Mini oyunlar: eşleştirme, artikel yarışı, dikte, adam asmaca, zaman yarışı, hafıza kartları.
- Oyunlaştırma: oyuncu seviyesi ve rütbe, günlük sandıklar, doğru cevap serisi (combo), yıldız değerlendirmesi.
- Android geri tuşu desteği (önce açık pencereyi kapatır, sonra ana ekrana döner).
- Dil bilgisi, günlük diyaloglar, kelime kartları, alıştırmalar, XP ve seri takibi.
- Çevrimdışı çalışır ve telefona yüklenebilir (PWA).

## Yerel çalıştırma

Gerekli: Node.js 20.19 veya üzeri.

```bash
npm install
npm run dev
```

Üretim derlemesi: `npm run build`, önizleme: `npm run preview`.

## GitHub Pages ile yayınlama

1. Projeyi bir GitHub deposuna `main` dalı ile yükleyin.
2. Depoda **Settings > Pages > Build and deployment > Source** değerini **GitHub Actions** yapın.
3. `main` dalına her push'ta `.github/workflows/deploy.yml` uygulamayı derleyip yayınlar. Adres: `https://KULLANICI.github.io/DEPO-ADI/`.

Derleme, `BASE_PATH` ortam değişkenini depo adına göre otomatik ayarlar. Özel alan adı kullanırsanız `BASE_PATH` değerini `/` yapın.

## Android APK (GitHub Actions)

`.github/workflows/apk.yml` Capacitor ile debug APK üretir. İki kullanım şekli vardır:

- **Zip ile (telefondan kolay):** Depoya sadece bu proje zip'ini (açmadan) ve `apk.yml` dosyasını koyun. Workflow zip'i kendisi açar.
- **Normal depo:** Proje dosyaları depo kökündeyse doğrudan onları kullanır.

Her push'ta APK üretilir. Sonucu **Releases** bölümünden veya **Actions > çalıştırma > Artifacts** altından indirin. Debug APK doğrudan kurulabilir, Google Play için imzalı release derlemesi ayrıca gerekir.

## Proje yapısı

```
src/
  components/    arayüz (learn, words, dtz, exercise, grammar, ...)
  context/       uygulama durumu (AppContext)
  data/
    levels/        ders içerikleri A1-C1
    questionBank/  seviye soru havuzları, Goethe ve DTZ görevleri
    vocab/         kelime listesi ve soru üretici
  utils/         ilerleme ve kilit mantığı, ses
```

## İçerik ekleme

- **Yeni kelime:** `src/data/vocab/words.ts` dosyasına aynı biçimde ekleyin. `template` alanında hedef kelime `{süslü parantez}` içinde yazılır, sorular otomatik üretilir.
- **Yeni sınav görevi:** `src/data/questionBank/goetheQuestions.ts` dosyasına mevcut görevlerle aynı alanlarla ekleyin.
- **Yeni ders:** `src/data/levels/` altındaki ilgili seviye dosyasına ekleyin.

Goethe görevleri bu uygulama için yazılmış çalışma metinleridir, resmi sınav değildir. Gerçek sınav öncesinde Goethe-Institut'un ücretsiz örnek sınavlarıyla da çalışmanız önerilir.
