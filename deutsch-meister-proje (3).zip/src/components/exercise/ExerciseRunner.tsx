import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  Volume2,
  Mic,
  MicOff,
  CheckCircle2,
  XCircle,
  ArrowRight,
  RotateCcw,
  Sparkles,
  BarChart3,
  Award,
  ChevronDown,
  ChevronUp,
  SlidersHorizontal,
} from 'lucide-react';
import { Exercise, QuestionReviewItem } from '../../types';
import { useApp } from '../../context/AppContext';
import {
  playSuccessSound,
  playWrongSound,
  speakGerman, calculateTextSimilarity,
  startSpeechRecognition,
} from '../../utils/audio';
import { shuffleArray } from '../../data/questionBank';

interface ExerciseRunnerProps {
  exercises: Exercise[];
  onComplete: (correctCount: number, total: number) => void;
  onExit: () => void;
  title?: string;
  allowLengthSelect?: boolean;
  initialCount?: number; // how many questions to start with (default 10)
}

export const ExerciseRunner: React.FC<ExerciseRunnerProps> = ({
  exercises,
  onComplete,
  onExit,
  title,
  allowLengthSelect = true,
  initialCount = 10,
}) => {
  const { profile } = useApp();

  // Test setup & question pool
  const [selectedLength, setSelectedLength] = useState<number | 'all'>('all');
  const [activeExercises, setActiveExercises] = useState<Exercise[]>([]);
  const [isConfiguring, setIsConfiguring] = useState<boolean>(false);

  // Active quiz state
  const [currentIndex, setCurrentIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [combo, setCombo] = useState(0);
  const seenRef = useRef<Set<string>>(new Set());
  const [typedText, setTypedText] = useState('');
  const [isFinished, setIsFinished] = useState(false);
  const [reviewItems, setReviewItems] = useState<QuestionReviewItem[]>([]);
  const [isRetryingWrong, setIsRetryingWrong] = useState(false);

  // Question interaction state
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<'der' | 'die' | 'das' | null>(null);
  const [trueFalseAnswer, setTrueFalseAnswer] = useState<boolean | null>(null);

  // Speech practice state
  const [isRecording, setIsRecording] = useState(false);
  const [spokenTranscript, setSpokenTranscript] = useState<string>('');
  const [speechScore, setSpeechScore] = useState<number | null>(null);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [speechStopper, setSpeechStopper] = useState<{ stop: () => void } | null>(null);

  // Evaluation state
  const [hasChecked, setHasChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [explanationText, setExplanationText] = useState<string>('');
  const [correctAnswerDisplay, setCorrectAnswerDisplay] = useState<string>('');
  const [showWrongReview, setShowWrongReview] = useState(true);

  const prepareExercises = (list: Exercise[]): Exercise[] =>
    list.map((ex) => {
      const anyEx = ex as any;
      if (ex.type !== 'sentence_builder' && Array.isArray(anyEx.options) && anyEx.options.length > 1) {
        return { ...anyEx, options: shuffleArray(anyEx.options) } as Exercise;
      }
      return ex;
    });

  // Initialize questions: start right away (no length picker), first batch is initialCount questions
  useEffect(() => {
    const shuffled = prepareExercises(shuffleArray(exercises));
    seenRef.current = new Set();
    if (allowLengthSelect && shuffled.length > initialCount) {
      const first = shuffled.slice(0, initialCount);
      first.forEach((e) => seenRef.current.add(e.id));
      setSelectedLength(initialCount);
      setActiveExercises(first);
    } else {
      setActiveExercises(shuffled);
    }
    setIsConfiguring(false);
  }, [exercises, allowLengthSelect, initialCount]); // eslint-disable-line react-hooks/exhaustive-deps

  const startTestWithLength = (len: number | 'all') => {
    setSelectedLength(len);
    const shuffled = prepareExercises(shuffleArray(exercises));
    const sliced = len === 'all' || len >= shuffled.length ? shuffled : shuffled.slice(0, len);
    setActiveExercises(sliced);
    setCurrentIndex(0);
    setCorrectCount(0);
    setCombo(0);
    setReviewItems([]);
    setIsFinished(false);
    setIsRetryingWrong(false);
    setIsConfiguring(false);
  };

  const currentEx = activeExercises[currentIndex];
  const progressPercent = activeExercises.length > 0
    ? Math.round(((currentIndex) / activeExercises.length) * 100)
    : 0;

  // Reset exercise-specific state when changing questions
  useEffect(() => {
    setSelectedOption(null);
    setTypedText('');
    setSelectedArticle(null);
    setTrueFalseAnswer(null);
    setHasChecked(false);
    setIsCorrect(false);
    setExplanationText('');
    setCorrectAnswerDisplay('');
    setIsRecording(false);
    setSpokenTranscript('');
    setSpeechScore(null);
    setSpeechError(null);

    if (currentEx) {
      if (currentEx.type === 'sentence_builder') {
        setSelectedWords([]);
        const words = (currentEx as any).scrambledWords || [];
        setAvailableWords(shuffleArray([...words]));
      }

      if (currentEx.type === 'typing' && (currentEx as any).audioText && profile.soundEnabled) {
        speakGerman((currentEx as any).audioText, profile.speechSpeed);
      }

      if (currentEx.type === 'listening' && profile.soundEnabled) {
        speakGerman((currentEx as any).germanAudioText, profile.speechSpeed);
      }
    }
  }, [currentIndex, currentEx, profile.soundEnabled, profile.speechSpeed]);

  // Celebrate a good result (must stay above every early return: hook order)
  useEffect(() => {
    if (isFinished && correctCount / Math.max(1, activeExercises.length) >= 0.8) {
      try {
        confetti({ particleCount: 140, spread: 80, origin: { y: 0.55 } });
      } catch {
        /* ignore */
      }
    }
  }, [isFinished]); // eslint-disable-line react-hooks/exhaustive-deps

  if (activeExercises.length === 0) return null;

  if (isConfiguring) {
    return (
      <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 p-6 max-w-xl mx-auto justify-center select-none animate-in fade-in">
        <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl space-y-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
            <SlidersHorizontal className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {title || 'Test Uzunluğunu Belirleyin'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Bu test için soru havuzunda toplam <strong>{exercises.length} farklı soru</strong> bulunmaktadır. Kaç soru çözmek istersiniz?
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            {[
              { count: 10, label: '10 Soru', sub: 'Hızlı Tekrar (~3 dk)' },
              { count: 20, label: '20 Soru', sub: 'Standart Alıştırma (~6 dk)' },
              { count: 50, label: '50 Soru', sub: 'Kapsamlı Test (~15 dk)' },
              { count: 'all' as const, label: `Tüm Havuz (${exercises.length})`, sub: 'Bütün Soruları Çöz' },
            ].map((opt) => {
              const isDisabled = typeof opt.count === 'number' && opt.count > exercises.length;
              return (
                <button
                  key={String(opt.count)}
                  disabled={isDisabled}
                  onClick={() => startTestWithLength(opt.count)}
                  className={`p-4 rounded-2xl border-2 text-left transition-all cursor-pointer ${
                    isDisabled
                      ? 'opacity-40 border-slate-200 dark:border-slate-800 cursor-not-allowed'
                      : 'border-slate-200 dark:border-slate-700 hover:border-emerald-500 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 shadow-[0_3px_0_#e2e8f0] dark:shadow-[0_3px_0_#1e293b] active:translate-y-0.5 active:shadow-none'
                  }`}
                >
                  <span className="block font-black text-base text-slate-900 dark:text-white">
                    {opt.label}
                  </span>
                  <span className="block text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {opt.sub}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 flex justify-between items-center text-xs text-slate-400">
            <span>✅ Sorular her seferinde karıştırılır</span>
            <button
              onClick={onExit}
              className="text-slate-500 hover:text-slate-700 font-bold underline cursor-pointer"
            >
              Vazgeç ve Çık
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (isFinished) {
    const wrongCount = activeExercises.length - correctCount;
    const percentage = Math.round((correctCount / Math.max(1, activeExercises.length)) * 100);

    // Group reviews by topicTag
    const topicBreakdown: Record<string, { total: number; correct: number }> = {};
    reviewItems.forEach((item) => {
      const tag = item.topicTag || 'Genel Konular';
      if (!topicBreakdown[tag]) {
        topicBreakdown[tag] = { total: 0, correct: 0 };
      }
      topicBreakdown[tag].total += 1;
      if (item.isCorrect) {
        topicBreakdown[tag].correct += 1;
      }
    });

    const failedItems = reviewItems.filter((i) => !i.isCorrect);

    const handleRetryFailed = () => {
      const missedExercises = failedItems.map((f) => f.exercise);
      if (missedExercises.length === 0) return;
      setActiveExercises(prepareExercises(shuffleArray(missedExercises)));
      setCurrentIndex(0);
      setCorrectCount(0);
      setCombo(0);
      setReviewItems([]);
      setIsFinished(false);
      setIsRetryingWrong(true);
    };

    const MORE_COUNT = 20;
    const canContinue = allowLengthSelect && !isRetryingWrong && exercises.length > 0;
    const handleMore = () => {
      const unseen = exercises.filter((e) => !seenRef.current.has(e.id));
      if (unseen.length < 5) seenRef.current = new Set();
      const pool = unseen.length < 5 ? exercises : unseen;
      const picked = prepareExercises(shuffleArray(pool)).slice(0, MORE_COUNT);
      picked.forEach((e) => seenRef.current.add(e.id));
      setSelectedLength(picked.length);
      setActiveExercises(picked);
      setCurrentIndex(0);
      setCorrectCount(0);
      setCombo(0);
      setReviewItems([]);
      setIsFinished(false);
      setIsRetryingWrong(false);
    };

    const handleRestartAll = () => {
      const shuffled = prepareExercises(shuffleArray(exercises));
      const sliced = selectedLength === 'all' || selectedLength >= shuffled.length
        ? shuffled
        : shuffled.slice(0, selectedLength);
      setActiveExercises(sliced);
      setCurrentIndex(0);
      setCorrectCount(0);
      setCombo(0);
      setReviewItems([]);
      setIsFinished(false);
      setIsRetryingWrong(false);
    };

    return (
      <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-y-auto p-4 sm:p-6 select-none animate-in fade-in">
        <div className="max-w-2xl w-full mx-auto space-y-6 py-4">
          {/* Header Score Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-linear-to-br from-emerald-600 via-teal-600 to-emerald-700 text-white shadow-xl text-center space-y-4">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>{isRetryingWrong ? 'Yanlışları Tekrar Çözme Turu' : 'Test Sonuç Raporu'}</span>
            </div>

            <div className="space-y-1">
              <div className="text-4xl sm:text-5xl font-black tracking-tight">
                %{percentage} Başarı
              </div>
              <div className="pop-in text-4xl" aria-label="Yıldız değerlendirmesi">
                {percentage >= 85 ? '⭐⭐⭐' : percentage >= 60 ? '⭐⭐☆' : '⭐☆☆'}
              </div>
              <p className="text-emerald-100 text-sm font-medium">
                {percentage >= 85
                  ? 'Mükemmel! Konuya son derece hakimsiniz. 🌟'
                  : percentage >= 70
                  ? 'Tebrikler! Oldukça başarılı bir sonuç. 👍'
                  : percentage >= 50
                  ? 'İyi başlangıç! Yanlışları tekrar çözerek pekiştirebilirsin.'
                  : 'Bu konuyu biraz daha çalışarak tekrar çözmeni tavsiye ederiz.'}
              </p>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-2">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs">
                <span className="block text-2xl font-black">{correctCount}</span>
                <span className="block text-[11px] font-semibold text-emerald-100">Doğru</span>
              </div>
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs">
                <span className="block text-2xl font-black">{wrongCount}</span>
                <span className="block text-[11px] font-semibold text-emerald-100">Yanlış</span>
              </div>
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs">
                <span className="block text-2xl font-black">{activeExercises.length}</span>
                <span className="block text-[11px] font-semibold text-emerald-100">Toplam Soru</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            {failedItems.length > 0 && (
              <button
                onClick={handleRetryFailed}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black text-sm shadow-[0_4px_0_#d97706] active:translate-y-0.5 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Yanlışları Tekrar Çöz ({failedItems.length} Soru)</span>
              </button>
            )}

            {canContinue && (
              <button
                onClick={handleMore}
                className="flex-1 py-3.5 px-4 rounded-2xl bg-sky-500 hover:bg-sky-600 text-white font-black text-sm shadow-[0_4px_0_#0369a1] active:translate-y-0.5 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>20 Yeni Soru Daha Çöz</span>
              </button>
            )}

            <button
              onClick={handleRestartAll}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-sm border-2 border-slate-200 dark:border-slate-700 shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Bu Soruları Tekrar Çöz</span>
            </button>

            <button
              onClick={() => onComplete(correctCount, activeExercises.length)}
              className="flex-1 py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm shadow-[0_4px_0_#15803d] active:translate-y-0.5 active:shadow-none transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Dersi Tamamla</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Topic Breakdown Card */}
          {Object.keys(topicBreakdown).length > 0 && (
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-600" />
                <h4 className="font-extrabold text-slate-900 dark:text-white text-base">
                  Konulara Göre Başarı Dağılımı
                </h4>
              </div>

              <div className="space-y-3">
                {Object.entries(topicBreakdown).map(([tag, stat]) => {
                  const tagPercent = Math.round((stat.correct / stat.total) * 100);
                  return (
                    <div key={tag} className="space-y-1">
                      <div className="flex justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                        <span>{tag}</span>
                        <span>
                          {stat.correct}/{stat.total} (%{tagPercent})
                        </span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            tagPercent >= 80
                              ? 'bg-emerald-500'
                              : tagPercent >= 50
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${tagPercent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Missed Questions Detailed Review */}
          {failedItems.length > 0 && (
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
              <div
                onClick={() => setShowWrongReview(!showWrongReview)}
                className="flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-rose-500" />
                  <h4 className="font-extrabold text-slate-900 dark:text-white text-base">
                    Yanlış Yapılan Soruların İncelemesi ({failedItems.length})
                  </h4>
                </div>
                {showWrongReview ? (
                  <ChevronUp className="w-5 h-5 text-slate-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>

              {showWrongReview && (
                <div className="space-y-3 pt-2">
                  {failedItems.map((item, idx) => {
                    const ex = item.exercise;
                    const promptText = (ex as any).prompt ||
                      (ex as any).sentenceWithBlank ||
                      (ex as any).word ||
                      (ex as any).turkishPrompt ||
                      (ex as any).statementDe ||
                      (ex as any).germanAudioText ||
                      (ex as any).targetSentenceDe ||
                      '';

                    return (
                      <div
                        key={idx}
                        className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between text-[11px] text-rose-700 dark:text-rose-400 font-bold">
                          <span>{item.topicTag || 'Alıştırma'}</span>
                          <span>Soru #{idx + 1}</span>
                        </div>

                        <p className="font-bold text-sm text-slate-900 dark:text-white">
                          {ex.instructionTr}
                        </p>

                        {promptText && (
                          <div className="p-2.5 bg-white dark:bg-slate-800 rounded-xl font-bold text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700">
                            {promptText}
                          </div>
                        )}

                        <div className="flex flex-col sm:flex-row gap-2 pt-1 font-semibold">
                          <div className="flex-1 p-2 bg-rose-100 dark:bg-rose-900/40 text-rose-800 dark:text-rose-200 rounded-lg">
                            ❌ Sizin Cevabınız: <span className="font-black">{item.userAnswer || 'Boş'}</span>
                          </div>
                          <div className="flex-1 p-2 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-200 rounded-lg">
                            ✅ Doğru Cevap: <span className="font-black">{item.correctAnswer}</span>
                          </div>
                        </div>

                        {ex.explanationTr && (
                          <p className="text-slate-600 dark:text-slate-300 italic pt-1 border-t border-rose-200/60 dark:border-rose-900/40">
                            💡 {ex.explanationTr}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (!currentEx) {
    return null;
  }

  // Sentence builder word handling
  const handlePickWord = (word: string, index: number) => {
    if (hasChecked) return;
    const newAvail = [...availableWords];
    newAvail.splice(index, 1);
    setAvailableWords(newAvail);
    setSelectedWords([...selectedWords, word]);
  };

  const handleRemoveWord = (word: string, index: number) => {
    if (hasChecked) return;
    const newSel = [...selectedWords];
    newSel.splice(index, 1);
    setSelectedWords(newSel);
    setAvailableWords([...availableWords, word]);
  };

  // Speech Practice handler
  const handleToggleSpeech = () => {
    if (isRecording) {
      speechStopper?.stop();
      setIsRecording(false);
      return;
    }

    setSpeechError(null);
    setIsRecording(true);

    const target = (currentEx as any).targetSentenceDe || (currentEx as any).prompt || '';
    const stopper = startSpeechRecognition(
      target,
      (res) => {
        setSpokenTranscript(res.transcript);
        setSpeechScore(res.score);
        setIsRecording(false);
      },
      (error: string) => {
        setSpeechError(error);
        setIsRecording(false);
      }
    );

    setSpeechStopper(stopper);
  };

  const handlePlayAudio = (text: string) => {
    speakGerman(text, profile.speechSpeed);
  };

  // Check validation state
  const isCheckEnabled = (): boolean => {
    if (hasChecked) return false;
    switch (currentEx.type) {
      case 'multiple_choice':
      case 'reverse_multiple_choice':
      case 'fill_blank':
      case 'verb_conjugation':
        return selectedOption !== null;
      case 'article_select':
        return selectedArticle !== null;
      case 'sentence_builder':
        return selectedWords.length > 0;
      case 'true_false':
        return trueFalseAnswer !== null;
      case 'listening':
        return selectedOption !== null;
      case 'typing':
        return typedText.trim().length > 0;
      case 'speech_practice':
        return spokenTranscript.length > 0 || speechScore !== null;
      default:
        return false;
    }
  };


  const optionClass = (value: string, isSelected: boolean): string => {
    const correctAns = (currentEx as any).correctAnswer;
    const base =
      'w-full p-4 rounded-2xl text-left font-bold text-base border-2 border-b-4 transition-all cursor-pointer ';
    if (hasChecked) {
      if (value === correctAns) return base + 'border-emerald-500 bg-emerald-100 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-100';
      if (isSelected) return base + 'border-rose-500 bg-rose-100 dark:bg-rose-950 text-rose-900 dark:text-rose-100 shake';
      return base + 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-400 opacity-60';
    }
    return (
      base +
      (isSelected
        ? 'border-sky-500 bg-sky-50 dark:bg-sky-950 text-sky-900 dark:text-sky-100 translate-y-0.5'
        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 active:translate-y-0.5')
    );
  };

  // Evaluate current question
  const handleCheckAnswer = () => {
    let correct = false;
    let expected = '';
    let userGiven = '';
    let explanation = currentEx.explanationTr || '';

    switch (currentEx.type) {
      case 'multiple_choice':
      case 'reverse_multiple_choice':
        expected = currentEx.correctAnswer;
        userGiven = selectedOption || '';
        correct = userGiven === expected;
        break;

      case 'article_select':
        expected = currentEx.correctArticle;
        userGiven = selectedArticle || '';
        correct = userGiven === expected;
        break;

      case 'sentence_builder': {
        const assembled = selectedWords.join(' ');
        expected = currentEx.correctGermanSentence;
        userGiven = assembled;
        correct =
          assembled.trim().replace(/[.,!?]/g, '').toLowerCase() ===
          expected.trim().replace(/[.,!?]/g, '').toLowerCase();
        break;
      }

      case 'fill_blank':
      case 'verb_conjugation':
      case 'listening':
        expected = currentEx.correctAnswer;
        userGiven = selectedOption || '';
        correct = userGiven === expected;
        break;

      case 'true_false':
        expected = currentEx.isCorrect ? 'Doğru' : 'Yanlış';
        userGiven = trueFalseAnswer ? 'Doğru' : 'Yanlış';
        correct = trueFalseAnswer === currentEx.isCorrect;
        break;

      case 'typing': {
        const ex = currentEx as any;
        const norm = (t: string) => t.trim().replace(/\s+/g, ' ').replace(/[.!?]+$/, '');
        const given = norm(typedText);
        expected = ex.answer;
        userGiven = typedText.trim();
        if (ex.mode === 'sentence') {
          correct = calculateTextSimilarity(given, ex.answer) >= 92;
        } else {
          const accepted: string[] = [ex.answer, ...(ex.accept || [])].map(norm);
          correct = accepted.some((a) => a.toLowerCase() === given.toLowerCase());
          if (correct && !accepted.includes(given)) {
            explanation = `Büyük/küçük harfe dikkat: doğru yazım "${ex.answer}". ${explanation}`;
          }
        }
        break;
      }

      case 'speech_practice':
        correct = (speechScore || 0) >= 65;
        expected = (currentEx as any).targetSentenceDe;
        userGiven = spokenTranscript;
        break;
    }

    setIsCorrect(correct);
    setCombo((c) => (correct ? c + 1 : 0));
    setCorrectAnswerDisplay(expected);
    setExplanationText(explanation);
    setHasChecked(true);

    // Record review item
    setReviewItems((prev) => [
      ...prev,
      {
        exercise: currentEx,
        userAnswer: userGiven,
        correctAnswer: expected,
        isCorrect: correct,
        topicTag: currentEx.topicTag,
      },
    ]);

    if (correct) {
      setCorrectCount((c) => c + 1);
      playSuccessSound(profile.soundEnabled);
    } else {
      playWrongSound(profile.soundEnabled);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < activeExercises.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setIsFinished(true);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 select-none">
      {/* Top Header & Progress */}
      <div className="px-4 pt-3 pb-2 bg-white dark:bg-slate-800 flex items-center gap-3">
        <button
          onClick={onExit}
          aria-label="Alıştırmadan çık"
          className="w-9 h-9 shrink-0 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 text-lg font-black cursor-pointer"
        >
          ✕
        </button>
        <div className="flex-1 h-4 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
          <div
            className="relative h-full rounded-full bg-linear-to-r from-emerald-400 to-emerald-600 transition-all duration-500"
            style={{ width: `${Math.max(6, progressPercent)}%` }}
          >
            <div className="absolute top-1 left-2 right-2 h-1 rounded-full bg-white/40" />
          </div>
        </div>
        {combo >= 2 ? (
          <div key={combo} className="pop-in shrink-0 px-2.5 py-1 rounded-full bg-orange-100 dark:bg-orange-950 text-orange-600 text-xs font-black">
            🔥 {combo}
          </div>
        ) : (
          <div className="shrink-0 text-xs font-black text-slate-400 tabular-nums">
            {currentIndex + 1}/{activeExercises.length}
          </div>
        )}
      </div>

      {/* Main Question Arena */}
      <div key={currentIndex} className="page-enter flex-1 overflow-y-auto p-4 sm:p-6 max-w-2xl w-full mx-auto flex flex-col justify-center">
        {/* Instruction */}
        <div className="mb-5">
          {currentEx.topicTag && (
            <span className="inline-block mb-2 px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-[11px] font-black uppercase tracking-wide">
              {currentEx.topicTag}
            </span>
          )}
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-snug">
            {currentEx.instructionTr}
          </h2>
        </div>

        {/* 1. Multiple Choice & Reverse */}
        {(currentEx.type === 'multiple_choice' || currentEx.type === 'reverse_multiple_choice') && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-between">
              <span className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {currentEx.prompt}
              </span>
              <button
                onClick={() => handlePlayAudio(currentEx.prompt)}
                className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 hover:bg-emerald-100 transition cursor-pointer"
                title="Telaffuzu Dinle"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {currentEx.options.map((option, idx) => {
                const isSelected = selectedOption === option;
                return (
                  <button
                    key={idx}
                    disabled={hasChecked}
                    onClick={() => setSelectedOption(option)}
                    className={optionClass(option, isSelected)}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. Article Select */}
        {currentEx.type === 'article_select' && (
          <div className="space-y-6 text-center">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xs">
              <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white block">
                {currentEx.word}
              </span>
              <span className="text-sm font-medium text-slate-500 dark:text-slate-400 mt-1 block">
                ({currentEx.turkish}) {currentEx.plural ? `• Çoğul: ${currentEx.plural}` : ''}
              </span>
              <button
                onClick={() => handlePlayAudio(currentEx.word)}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold hover:bg-emerald-100 transition cursor-pointer"
              >
                <Volume2 className="w-4 h-4" /> Dinle
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 max-w-md mx-auto">
              <button
                disabled={hasChecked}
                onClick={() => setSelectedArticle('der')}
                className={`py-4 rounded-2xl font-black text-lg border-2 transition-all cursor-pointer ${
                  selectedArticle === 'der'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/40 text-blue-700 shadow-inner'
                    : 'border-blue-200 bg-white dark:bg-slate-800 text-blue-600 shadow-[0_4px_0_#bfdbfe] hover:border-blue-300 active:shadow-none active:translate-y-1'
                }`}
              >
                der
                <span className="block text-[10px] font-medium text-slate-400">Eril (Maskulin)</span>
              </button>

              <button
                disabled={hasChecked}
                onClick={() => setSelectedArticle('die')}
                className={`py-4 rounded-2xl font-black text-lg border-2 transition-all cursor-pointer ${
                  selectedArticle === 'die'
                    ? 'border-rose-500 bg-rose-50 dark:bg-rose-950/40 text-rose-700 shadow-inner'
                    : 'border-rose-200 bg-white dark:bg-slate-800 text-rose-600 shadow-[0_4px_0_#fecdd3] hover:border-rose-300 active:shadow-none active:translate-y-1'
                }`}
              >
                die
                <span className="block text-[10px] font-medium text-slate-400">Dişil (Feminin)</span>
              </button>

              <button
                disabled={hasChecked}
                onClick={() => setSelectedArticle('das')}
                className={`py-4 rounded-2xl font-black text-lg border-2 transition-all cursor-pointer ${
                  selectedArticle === 'das'
                    ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 shadow-inner'
                    : 'border-emerald-200 bg-white dark:bg-slate-800 text-emerald-600 shadow-[0_4px_0_#a7f3d0] hover:border-emerald-300 active:shadow-none active:translate-y-1'
                }`}
              >
                das
                <span className="block text-[10px] font-medium text-slate-400">Nötr (Neutrum)</span>
              </button>
            </div>
          </div>
        )}

        {/* 3. Sentence Builder */}
        {currentEx.type === 'sentence_builder' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800">
              <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block">
                Türkçe Anlamı
              </span>
              <span className="text-lg font-bold text-slate-800 dark:text-slate-100 mt-1 block">
                "{currentEx.turkishPrompt}"
              </span>
            </div>

            <div className="min-h-20 p-3 rounded-2xl bg-white dark:bg-slate-800 border-2 border-dashed border-slate-300 dark:border-slate-700 flex flex-wrap gap-2 items-center">
              {selectedWords.length === 0 ? (
                <span className="text-xs font-medium text-slate-400 mx-auto">
                  Kelimeleri doğru sırayla dizmek için aşağıdan dokunun
                </span>
              ) : (
                selectedWords.map((word, idx) => (
                  <button
                    key={idx}
                    disabled={hasChecked}
                    onClick={() => handleRemoveWord(word, idx)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 font-bold text-sm border border-emerald-300 dark:border-emerald-700 shadow-xs hover:bg-emerald-200 transition active:scale-95 cursor-pointer"
                  >
                    {word}
                  </button>
                ))
              )}
            </div>

            <div className="flex flex-wrap gap-2 pt-2 justify-center">
              {availableWords.map((word, idx) => (
                <button
                  key={idx}
                  disabled={hasChecked}
                  onClick={() => handlePickWord(word, idx)}
                  className="px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-sm border-2 border-slate-200 dark:border-slate-700 shadow-[0_3px_0_#e2e8f0] dark:shadow-[0_3px_0_#334155] hover:border-slate-400 active:shadow-none active:translate-y-0.5 transition cursor-pointer"
                >
                  {word}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 4. Fill in the Blank */}
        {currentEx.type === 'fill_blank' && (
          <div className="space-y-5">
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 shadow-xs">
              <span className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white block leading-relaxed">
                {currentEx.sentenceWithBlank}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 mt-2 block">
                {currentEx.turkishTranslation}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {currentEx.options.map((option, idx) => {
                const isSelected = selectedOption === option;
                return (
                  <button
                    key={idx}
                    disabled={hasChecked}
                    onClick={() => setSelectedOption(option)}
                    className={optionClass(option, isSelected)}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 5. True or False */}
        {currentEx.type === 'true_false' && (
          <div className="space-y-5 text-center">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700">
              <span className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white block">
                "{currentEx.statementDe}"
              </span>
              <span className="text-sm text-slate-500 dark:text-slate-400 mt-2 block">
                {currentEx.statementTr}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
              <button
                disabled={hasChecked}
                onClick={() => setTrueFalseAnswer(true)}
                className={`py-4 rounded-2xl font-bold text-base border-2 transition cursor-pointer ${
                  trueFalseAnswer === true
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800 shadow-inner'
                    : 'border-slate-200 bg-white dark:bg-slate-800 text-slate-700 hover:border-emerald-400 shadow-[0_3px_0_#e2e8f0]'
                }`}
              >
                ✓ Doğru
              </button>
              <button
                disabled={hasChecked}
                onClick={() => setTrueFalseAnswer(false)}
                className={`py-4 rounded-2xl font-bold text-base border-2 transition cursor-pointer ${
                  trueFalseAnswer === false
                    ? 'border-rose-500 bg-rose-50 text-rose-800 shadow-inner'
                    : 'border-slate-200 bg-white dark:bg-slate-800 text-slate-700 hover:border-rose-400 shadow-[0_3px_0_#e2e8f0]'
                }`}
              >
                ✕ Yanlış
              </button>
            </div>
          </div>
        )}

        {/* 6. Listening Exercise */}
        {currentEx.type === 'listening' && (
          <div className="space-y-5 text-center">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 flex flex-col items-center">
              <button
                onClick={() => handlePlayAudio(currentEx.germanAudioText)}
                className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-lg hover:bg-emerald-600 transition active:scale-95 cursor-pointer"
                title="Tekrar Dinle"
              >
                <Volume2 className="w-8 h-8" />
              </button>
              <span className="text-xs font-semibold text-slate-400 mt-3">
                Sesi dinlemek için butona dokunun
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2.5 max-w-md mx-auto">
              {currentEx.options.map((option, idx) => {
                const isSelected = selectedOption === option;
                return (
                  <button
                    key={idx}
                    disabled={hasChecked}
                    onClick={() => setSelectedOption(option)}
                    className={optionClass(option, isSelected)}
                  >
                    {option}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 7. Verb Conjugation */}
        {currentEx.type === 'verb_conjugation' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-center">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">
                Mastar: {currentEx.verbInfinitive}
              </span>
              <span className="text-2xl font-black text-slate-900 dark:text-white mt-1 block">
                {currentEx.pronoun} + [ ... ]
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 mt-1 block">
                ({currentEx.turkishTranslation})
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
              {currentEx.options.map((opt, idx) => {
                const isSelected = selectedOption === opt;
                return (
                  <button
                    key={idx}
                    disabled={hasChecked}
                    onClick={() => setSelectedOption(opt)}
                    className={optionClass(opt, isSelected)}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 9. Typing (write the answer) */}
        {currentEx.type === 'typing' && (
          <div className="space-y-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 text-center space-y-2">
              {(currentEx as any).promptTr && (
                <div className="text-2xl font-black text-slate-900 dark:text-white">{(currentEx as any).promptTr}</div>
              )}
              {(currentEx as any).hintTr && (
                <div className="text-xs font-bold text-slate-400">{(currentEx as any).hintTr}</div>
              )}
              {(currentEx as any).audioText && (
                <button
                  onClick={() => handlePlayAudio((currentEx as any).audioText)}
                  className="w-16 h-16 rounded-full bg-sky-500 text-white shadow-[0_5px_0_#0369a1] active:translate-y-1 active:shadow-none transition inline-flex items-center justify-center cursor-pointer"
                  aria-label="Cümleyi dinle"
                >
                  <Volume2 className="w-8 h-8" />
                </button>
              )}
            </div>
            <input
              type="text"
              value={typedText}
              disabled={hasChecked}
              onChange={(e) => setTypedText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && isCheckEnabled()) handleCheckAnswer();
              }}
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              placeholder="Almanca yazın..."
              className={`w-full h-14 px-4 rounded-2xl border-2 border-b-4 bg-white dark:bg-slate-800 text-lg font-bold text-slate-900 dark:text-white focus:outline-none ${
                hasChecked
                  ? isCorrect
                    ? 'border-emerald-500'
                    : 'border-rose-500'
                  : 'border-slate-200 dark:border-slate-700 focus:border-sky-500'
              }`}
            />
            {!hasChecked && (
              <div className="flex flex-wrap gap-2" aria-label="Özel harfler">
                {['ä', 'ö', 'ü', 'ß', 'Ä', 'Ö', 'Ü'].map((ch) => (
                  <button
                    key={ch}
                    onClick={() => setTypedText((t) => t + ch)}
                    className="w-11 h-11 rounded-xl bg-white dark:bg-slate-800 border-2 border-b-4 border-slate-200 dark:border-slate-700 text-lg font-black text-slate-800 dark:text-slate-100 active:translate-y-0.5 cursor-pointer"
                  >
                    {ch}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 8. Speech Practice */}
        {currentEx.type === 'speech_practice' && (
          <div className="space-y-5 text-center">
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700">
              <span className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white block">
                "{currentEx.targetSentenceDe}"
              </span>
              <span className="text-sm text-slate-500 dark:text-slate-400 mt-1 block">
                {currentEx.translationTr}
              </span>
              <button
                onClick={() => handlePlayAudio(currentEx.targetSentenceDe)}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 transition cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-emerald-600" /> Örnek Telaffuzu Dinle
              </button>
            </div>

            <div className="flex flex-col items-center justify-center gap-2">
              <button
                disabled={hasChecked}
                onClick={handleToggleSpeech}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  isRecording
                    ? 'bg-rose-500 text-white animate-pulse shadow-rose-300 shadow-xl scale-105'
                    : 'bg-emerald-500 text-white shadow-emerald-200 shadow-lg hover:bg-emerald-600 active:scale-95'
                }`}
              >
                {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
              </button>
              <span className="text-xs font-medium text-slate-500">
                {isRecording ? 'Dinleniyor... Almanca konuşun' : 'Mikrofona dokunun ve konuşun'}
              </span>
            </div>

            {spokenTranscript && (
              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 max-w-md mx-auto">
                <span className="font-bold">Algılanan Cümle:</span> "{spokenTranscript}"
                {speechScore !== null && (
                  <span className="block mt-1 font-semibold text-emerald-600">
                    Eşleşme Oranı: %{speechScore}
                  </span>
                )}
              </div>
            )}

            {speechError && (
              <p className="text-xs text-rose-500 max-w-sm mx-auto">{speechError}</p>
            )}
          </div>
        )}
      </div>

      {/* Bottom Sticky Action / Evaluation Bar */}
      <div
        className={`border-t-2 px-4 pt-4 pb-[max(1rem,env(safe-area-inset-bottom))] transition-colors ${
          !hasChecked
            ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700'
            : isCorrect
            ? 'sheet-up bg-emerald-100 dark:bg-emerald-950 border-emerald-300 dark:border-emerald-800'
            : 'sheet-up bg-rose-100 dark:bg-rose-950 border-rose-300 dark:border-rose-800'
        }`}
      >
        <div className="max-w-2xl mx-auto space-y-3">
          {hasChecked && (
            <div className="flex items-start gap-3">
              <div
                className={`w-11 h-11 shrink-0 rounded-full flex items-center justify-center ${
                  isCorrect ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'
                }`}
              >
                {isCorrect ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
              </div>
              <div className="min-w-0">
                <div className={`text-lg font-black ${isCorrect ? 'text-emerald-700 dark:text-emerald-300' : 'text-rose-700 dark:text-rose-300'}`}>
                  {isCorrect
                    ? ['Harika!', 'Mükemmel!', 'Süpersin!', 'Tam isabet!', 'Bravo!'][currentIndex % 5]
                    : 'Olmadı, tekrar bakalım'}
                </div>
                {!isCorrect && correctAnswerDisplay && (
                  <p className="text-sm font-bold text-rose-800 dark:text-rose-200 mt-0.5">
                    Doğrusu: <span className="underline">{correctAnswerDisplay}</span>
                  </p>
                )}
                {explanationText && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">{explanationText}</p>
                )}
              </div>
            </div>
          )}

          {!hasChecked ? (
            <button
              disabled={!isCheckEnabled()}
              onClick={handleCheckAnswer}
              className={`w-full h-14 rounded-2xl font-black text-base tracking-wide transition-all cursor-pointer ${
                isCheckEnabled()
                  ? 'bg-emerald-500 text-white shadow-[0_5px_0_#047857] active:shadow-none active:translate-y-1'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-400 cursor-not-allowed'
              }`}
            >
              KONTROL ET
            </button>
          ) : (
            <button
              onClick={handleNext}
              className={`w-full h-14 rounded-2xl font-black text-base tracking-wide text-white transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isCorrect
                  ? 'bg-emerald-500 shadow-[0_5px_0_#047857] active:shadow-none active:translate-y-1'
                  : 'bg-rose-500 shadow-[0_5px_0_#be123c] active:shadow-none active:translate-y-1'
              }`}
            >
              <span>{currentIndex + 1 < activeExercises.length ? 'DEVAM' : 'SONUÇLARI GÖR'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
