import { CEFRLevel, Skill, UserProfile } from '../types';
import { dayKey } from './srs';
import { QUEST_WORDS } from '../data/vocab/words';
import { CONNECTOR_GROUPS } from '../data/connectors';
import { LAB_TOPICS } from '../data/grammarLab';
import { ALL_UNITS_BY_LEVEL } from '../data/levels';
import { getWordSets } from '../data/vocab/builder';

export const SKILLS: { id: Skill; label: string; emoji: string; color: string }[] = [
  { id: 'vocab', label: 'Kelime bilgisi', emoji: '📚', color: 'bg-emerald-500' },
  { id: 'grammar', label: 'Gramer', emoji: '🧩', color: 'bg-sky-500' },
  { id: 'listening', label: 'Dinleme', emoji: '🎧', color: 'bg-indigo-500' },
  { id: 'speaking', label: 'Konuşma', emoji: '🎤', color: 'bg-rose-500' },
  { id: 'reading', label: 'Okuma', emoji: '📖', color: 'bg-amber-500' },
  { id: 'writing', label: 'Yazma', emoji: '✍️', color: 'bg-violet-500' },
];

export const lastDayKeys = (n: number): string[] => {
  const out: string[] = [];
  const now = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    out.push(dayKey(d));
  }
  return out;
};

export const minutesOf = (secs: number) => (secs > 0 ? Math.max(1, Math.round(secs / 60)) : 0);

/** Accuracy per skill over the last N days (null = not enough data yet). */
export function skillAccuracy(profile: UserProfile, days = 30): Record<Skill, { pct: number | null; n: number }> {
  const keys = new Set(lastDayKeys(days));
  const tot: Record<string, { r: number; w: number }> = {};
  Object.entries(profile.activity || {}).forEach(([k, day]) => {
    if (!keys.has(k)) return;
    Object.entries(day.skills || {}).forEach(([sk, v]) => {
      const t = tot[sk] || { r: 0, w: 0 };
      t.r += v?.r || 0;
      t.w += v?.w || 0;
      tot[sk] = t;
    });
  });
  const res = {} as Record<Skill, { pct: number | null; n: number }>;
  SKILLS.forEach(({ id }) => {
    const t = tot[id] || { r: 0, w: 0 };
    const n = t.r + t.w;
    res[id] = { pct: n >= 5 ? Math.round((t.r / n) * 100) : null, n };
  });
  return res;
}

export function weeklySeries(profile: UserProfile) {
  const labels = ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'];
  return lastDayKeys(7).map((key) => {
    const day = (profile.activity || {})[key];
    const [y, m, d] = key.split('-').map(Number);
    return { key, label: labels[new Date(y, m - 1, d).getDay()], minutes: minutesOf(day?.secs || 0), q: day?.q || 0 };
  });
}

export const todayActivity = (profile: UserProfile) =>
  (profile.activity || {})[dayKey()] || { q: 0, secs: 0, rev: 0, skills: {} };

const GRAMMAR_REF_NAMES: Record<string, string> = {
  konj: 'Fiil çekimi', plural: 'Çoğul', perfekt: 'Perfekt', satz: 'Cümle sırası', artikel: 'Artikel ve haller',
  praep: 'Edatlar', negation: 'Olumsuzluk', modal: 'Modal fiiller', trenn: 'Ayrılabilen fiiller', praet: 'Präteritum',
  futur: 'Futur', genitiv: 'Genitiv', adjekt: 'Sıfat çekimi', relativ: 'Relativsätze', konj2: 'Konjunktiv II', passiv: 'Passiv',
};

/** Weakest topics, aggregated from the memory engine (wrong answers) and AI teacher findings. */
export function weakTopics(profile: UserProfile): { label: string; wrong: number }[] {
  const acc: Record<string, number> = {};
  const add = (label: string, n: number) => (acc[label] = (acc[label] || 0) + n);
  Object.entries(profile.srs || {}).forEach(([refId, e]) => {
    if (e.wrong <= 0) return;
    if (refId.startsWith('vq_')) {
      const w = QUEST_WORDS.find((x) => x.id === refId);
      add(`Kelime: ${w ? w.category : 'diğer'}`, e.wrong);
    } else if (refId.startsWith('conn:')) {
      const g = CONNECTOR_GROUPS.find((x) => x.id === refId.split(':')[1]);
      add(`Bağlaç: ${g ? g.titleTr : 'diğer'}`, e.wrong);
    } else if (refId.startsWith('gram:')) {
      add(`Gramer: ${GRAMMAR_REF_NAMES[refId.split(':')[1]] || 'diğer'}`, e.wrong);
    } else if (refId.startsWith('dlg:')) {
      add('Diyalog ve dinleme', e.wrong);
    }
  });
  (profile.aiMistakes || []).forEach((m) => add(`AI öğretmen: ${m.type || 'genel'}`, 1));
  return Object.entries(acc)
    .map(([label, wrong]) => ({ label, wrong }))
    .sort((a, b) => b.wrong - a.wrong)
    .slice(0, 6);
}

export interface TargetRow {
  label: string;
  done: number;
  total: number;
}

/** CEFR level goals: real skills (known words, grammar topics, connectors, exam), not XP. */
export function levelTargets(profile: UserProfile, level: CEFRLevel): TargetRow[] {
  const done = profile.completedWordSets || [];
  const srs = profile.srs || {};
  const lessons = (ALL_UNITS_BY_LEVEL[level] || []).flatMap((u) => u.lessons);
  const words = QUEST_WORDS.filter((w) => w.level === level);
  const known = words.filter((w) => (srs[w.id]?.box || 0) >= 2).length;
  const sets = getWordSets(level);
  const conn = CONNECTOR_GROUPS.filter((g) => g.level === level);
  const gram = LAB_TOPICS.filter((t) => t.level === level);
  const rows: TargetRow[] = [
    { label: 'Dersler', done: lessons.filter((l) => profile.completedLessons.includes(l.id)).length, total: lessons.length },
    { label: 'Kelime setleri', done: sets.filter((s) => done.includes(s.id)).length, total: sets.length },
    { label: 'Kalıcı bilinen kelime', done: known, total: words.length },
  ];
  if (conn.length) rows.push({ label: 'Bağlaç konuları', done: conn.filter((g) => done.includes(`conn_${g.id}`)).length, total: conn.length });
  if (gram.length) rows.push({ label: 'Gramer atölyesi', done: gram.filter((t) => done.includes(`gram_${t.id}`)).length, total: gram.length });
  rows.push({ label: 'Seviye sınavı (%70)', done: (profile.passedLevelExams || []).includes(level) ? 1 : 0, total: 1 });
  return rows;
}

export function memoryStats(profile: UserProfile) {
  const entries = Object.entries(profile.srs || {});
  const vocab = entries.filter(([id]) => id.startsWith('vq_'));
  const gram = entries.filter(([id]) => id.startsWith('gram:') || id.startsWith('conn:'));
  const rate = (list: [string, { right: number; wrong: number }][]) => {
    const r = list.reduce((a, [, e]) => a + e.right, 0);
    const w = list.reduce((a, [, e]) => a + e.wrong, 0);
    return r + w >= 5 ? Math.round((r / (r + w)) * 100) : null;
  };
  return {
    wordsLearned: vocab.length,
    wordsRemembered: vocab.filter(([, e]) => e.box >= 3).length,
    grammarRate: rate(gram as any),
    vocabRate: rate(vocab as any),
  };
}
