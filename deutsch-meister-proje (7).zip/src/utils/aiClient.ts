import { CEFRLevel } from '../types';

// The AI teacher talks to YOUR OWN server (see server/ai-proxy). The API key never lives in the app.
export interface AiConfig {
  endpoint: string;
  token: string;
}

const CFG_KEY = 'dm_ai_config_v1';

export function loadAiConfig(): AiConfig {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { endpoint: String(p.endpoint || ''), token: String(p.token || '') };
    }
  } catch {
    /* ignore */
  }
  return { endpoint: '', token: '' };
}

export function saveAiConfig(cfg: AiConfig) {
  try {
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
  } catch {
    /* ignore */
  }
}

export interface AiTurn {
  role: 'user' | 'assistant';
  text: string;
}

export interface AiCorrection {
  original: string;
  corrected: string;
  explanationTr: string;
  errorType: string;
}

export interface AiReply {
  reply: string; // German answer of the teacher
  replyTr?: string; // Turkish translation of the answer
  correction: AiCorrection | null;
  followUp?: string; // next question in German
  tipTr?: string;
}

export interface AiRequest {
  message: string;
  history: AiTurn[];
  level: CEFRLevel;
  topic: string;
  weakAreas: string[];
  knownErrors: string[];
}

const norm = (t: string) => t.toLowerCase().replace(/[.,!?;:"']/g, '').replace(/\s+/g, ' ').trim();
const cache = new Map<string, AiReply>();
let lastCall = 0;

export async function askTeacher(cfg: AiConfig, req: AiRequest): Promise<AiReply> {
  if (!cfg.endpoint) throw new Error('Sunucu adresi ayarlanmamış.');
  const message = req.message.trim();
  if (message.length < 2) throw new Error('Lütfen bir cümle yaz.');

  // avoid useless API calls: same question in the same context is answered from memory
  const key = JSON.stringify([message, req.history.slice(-4), req.level, req.topic]);
  const hit = cache.get(key);
  if (hit) return hit;

  const wait = 1500 - (Date.now() - lastCall);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCall = Date.now();

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  let res: Response;
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cfg.token) headers.Authorization = `Bearer ${cfg.token}`;
    res = await fetch(`${cfg.endpoint.replace(/\/+$/, '')}/teach`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ ...req, message, history: req.history.slice(-8) }),
      signal: ctrl.signal,
    });
  } catch {
    throw new Error('Sunucuya ulaşılamadı. İnternet bağlantını ve sunucu adresini kontrol et.');
  } finally {
    clearTimeout(timer);
  }
  if (res.status === 401 || res.status === 403) throw new Error('Erişim reddedildi. Erişim anahtarını kontrol et.');
  if (res.status === 429) throw new Error('Çok fazla istek gönderildi. Biraz bekleyip tekrar dene.');
  if (!res.ok) throw new Error(`Sunucu hatası (${res.status}). Biraz sonra tekrar dene.`);

  let data: any;
  try {
    data = await res.json();
  } catch {
    throw new Error('Sunucudan geçersiz cevap geldi.');
  }
  if (!data || typeof data.reply !== 'string') throw new Error('Sunucudan beklenmeyen biçimde cevap geldi.');

  let correction: AiCorrection | null = null;
  const c = data.correction;
  if (c && typeof c.original === 'string' && typeof c.corrected === 'string' && norm(c.original) !== norm(c.corrected)) {
    correction = {
      original: c.original,
      corrected: c.corrected,
      explanationTr: String(c.explanationTr || ''),
      errorType: String(c.errorType || 'genel'),
    };
  }
  const out: AiReply = {
    reply: data.reply,
    replyTr: typeof data.replyTr === 'string' ? data.replyTr : undefined,
    correction,
    followUp: typeof data.followUp === 'string' ? data.followUp : undefined,
    tipTr: typeof data.tipTr === 'string' ? data.tipTr : undefined,
  };
  cache.set(key, out);
  return out;
}
