import { Exercise, RealLifeDialogue } from '../types';
import { REAL_LIFE_DIALOGUES } from './dialogues';

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

const clean = (t: string) => t.replace(/[.,!?;:]/g, '');
const tag = (d: RealLifeDialogue, what: string) => `${what}: ${d.titleTr}`;

const findDialogue = (id: string) => REAL_LIFE_DIALOGUES.find((d) => d.id === id);

function listeningFor(d: RealLifeDialogue, i: number): Exercise | null {
  const line = d.lines[i];
  if (!line) return null;
  const others = shuffle(REAL_LIFE_DIALOGUES.flatMap((x) => x.lines).filter((l) => l.turkish !== line.turkish)).slice(0, 3);
  return {
    id: `dlg_${d.id}_${i}_listen`,
    refId: `dlg:${d.id}:${i}`,
    level: d.level,
    topicTag: tag(d, 'Dinleme'),
    type: 'listening',
    instructionTr: 'Dinleyin ve anlamını seçin:',
    germanAudioText: line.german,
    turkishMeaning: line.turkish,
    options: shuffle([line.turkish, ...others.map((o) => o.turkish)]),
    correctAnswer: line.turkish,
    explanationTr: `${line.german} = ${line.turkish}`,
  } as Exercise;
}

function clozeFor(d: RealLifeDialogue, i: number): Exercise | null {
  const line = d.lines[i];
  if (!line) return null;
  const words = line.german.split(' ');
  const idx = words.findIndex((w, k) => k > 0 && /^[A-Za-zÄÖÜäöüß]{4,}[.,!?]?$/.test(w));
  if (idx < 0) return null;
  const target = clean(words[idx]);
  const pool = Array.from(
    new Set(
      REAL_LIFE_DIALOGUES.flatMap((x) => x.lines.flatMap((l) => l.german.split(' ').map(clean)))
        .filter((w) => /^[A-Za-zÄÖÜäöüß]{4,}$/.test(w) && w.toLowerCase() !== target.toLowerCase())
    )
  );
  const wrong = shuffle(pool).slice(0, 3);
  if (wrong.length < 3) return null;
  const blanked = words.map((w, k) => (k === idx ? w.replace(target, '___') : w)).join(' ');
  return {
    id: `dlg_${d.id}_${i}_cloze`,
    refId: `dlg:${d.id}:${i}`,
    level: d.level,
    topicTag: tag(d, 'Boşluk'),
    type: 'fill_blank',
    instructionTr: 'Diyalogdaki eksik kelimeyi seçin:',
    sentenceWithBlank: blanked,
    turkishTranslation: line.turkish,
    options: shuffle([target, ...wrong]),
    correctAnswer: target,
    explanationTr: `${line.german} (${line.turkish})`,
  } as Exercise;
}

function dictationFor(d: RealLifeDialogue, i: number): Exercise | null {
  const line = d.lines[i];
  if (!line || line.german.split(' ').length < 3) return null;
  return {
    id: `dlg_${d.id}_${i}_dict`,
    refId: `dlg:${d.id}:${i}`,
    level: d.level,
    topicTag: tag(d, 'Dikte'),
    type: 'typing',
    mode: 'sentence',
    instructionTr: 'Duyduğunuz cümleyi yazın:',
    promptTr: '',
    audioText: line.german,
    answer: line.german,
    explanationTr: `${line.german} (${line.turkish})`,
  } as Exercise;
}

/** Listening practice for one dialogue: understand, fill the gap, write what you hear. */
export function buildDialogueListeningExercises(d: RealLifeDialogue): Exercise[] {
  const out: Exercise[] = [];
  d.lines.forEach((_, i) => {
    [listeningFor(d, i), i % 2 === 0 ? clozeFor(d, i) : null, i % 3 === 0 ? dictationFor(d, i) : null].forEach((e) => {
      if (e) out.push(e);
    });
  });
  return out;
}

function roleplayFor(d: RealLifeDialogue, i: number): Exercise | null {
  if (i < 1) return null;
  const line = d.lines[i];
  const prev = d.lines[i - 1];
  if (!line || !prev || line.speaker === prev.speaker) return null;
  const sameLevel = REAL_LIFE_DIALOGUES.filter((x) => x.id !== d.id && x.level === d.level);
  const source = (sameLevel.length >= 2 ? sameLevel : REAL_LIFE_DIALOGUES.filter((x) => x.id !== d.id)).flatMap((x) => x.lines);
  const wrong = shuffle(source.filter((l) => l.german !== line.german)).slice(0, 3);
  const context = d.lines
    .slice(Math.max(0, i - 2), i)
    .map((l) => `${l.speaker}: ${l.german}`)
    .join('\n');
  return {
    id: `dlg_rp_${d.id}_${i}`,
    refId: `dlg:rp:${d.id}:${i}`,
    level: d.level,
    topicTag: tag(d, 'Rol yapma'),
    type: 'multiple_choice',
    instructionTr: `Sen "${line.speaker}" rolündesin. Hangi cevap uygun?`,
    prompt: context,
    options: shuffle([line.german, ...wrong.map((w) => w.german)]),
    correctAnswer: line.german,
    explanationTr: `${line.german} (${line.turkish})`,
  } as Exercise;
}

/** Role-play: the learner answers in the partner role; wrong options come from unrelated situations. */
export function buildRoleplayExercises(d: RealLifeDialogue): Exercise[] {
  return d.lines.map((_, i) => roleplayFor(d, i)).filter((e): e is Exercise => !!e);
}

/** Review question for refs like dlg:<id>:<line> and dlg:rp:<id>:<line>. */
export function buildReviewExerciseForDialogue(refId: string, seed: number): Exercise | null {
  const parts = refId.split(':');
  const isRp = parts[1] === 'rp';
  const d = findDialogue(isRp ? parts[2] : parts[1]);
  const i = Number(isRp ? parts[3] : parts[2]);
  if (!d || Number.isNaN(i)) return null;
  const ex = isRp ? roleplayFor(d, i) : [listeningFor(d, i), clozeFor(d, i), dictationFor(d, i)].filter(Boolean)[seed % 2 === 0 ? 0 : 1] || listeningFor(d, i);
  return ex ? ({ ...(ex as Exercise), id: `${ex.id}_r${seed}` } as Exercise) : null;
}
