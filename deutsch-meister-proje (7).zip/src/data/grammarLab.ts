import { CEFRLevel, Exercise } from '../types';

export interface LabCard {
  title: string;
  bodyTr: string;
  formulaDe?: string;
  tipTr?: string;
  rows?: [string, string][]; // table lines: left bold, right normal
}

export interface LabTopic {
  id: string;
  level: CEFRLevel;
  emoji: string;
  titleTr: string;
  cards: LabCard[];
  build: () => Exercise[];
}

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

type Fill = [sentence: string, answer: string, tr: string, why: string, pool?: string[]];

const fillExercises = (topic: string, level: CEFRLevel, tag: string, items: Fill[], defaultPool: string[]): Exercise[] =>
  items.map(([sentence, answer, tr, why, pool], i) => {
    const p = pool || defaultPool;
    const atStart = sentence.trim().startsWith('___');
    const fix = (x: string) => (atStart ? x.charAt(0).toUpperCase() + x.slice(1) : x);
    const wrong = shuffle(p.filter((x) => x !== answer)).slice(0, 3);
    return {
      id: `gram_${topic}_fill${i}`,
      refId: `gram:${topic}:fill${i}`,
      level,
      topicTag: tag,
      type: 'fill_blank',
      instructionTr: 'Boşluğa doğru kelimeyi seçin:',
      sentenceWithBlank: sentence,
      turkishTranslation: tr,
      options: shuffle([fix(answer), ...wrong.map(fix)]),
      correctAnswer: fix(answer),
      explanationTr: why,
    } as Exercise;
  });

/* ---------- Artikel und Kasus ---------- */
const ART_POOL = ['der', 'die', 'das', 'den', 'dem'];
const ARTIKEL: Fill[] = [
  ['Ich sehe ___ Mann.', 'den', 'Adamı görüyorum.', 'sehen + Akkusativ: der Mann → den Mann.'],
  ['Der Mann gibt ___ Frau das Buch.', 'der', 'Adam kadına kitabı veriyor.', 'geben + Dativ: die Frau → der Frau.'],
  ['Ich kaufe ___ Buch.', 'das', 'Kitabı alıyorum.', 'Akkusativ: das Buch → das Buch (nötr değişmez).'],
  ['Ich helfe ___ Kind.', 'dem', 'Çocuğa yardım ediyorum.', 'helfen + Dativ: das Kind → dem Kind.'],
  ['Wir besuchen ___ Oma.', 'die', 'Büyükannemizi ziyaret ediyoruz.', 'besuchen + Akkusativ: die Oma → die Oma (dişil değişmez).'],
  ['Ich schenke ___ Freund ein Buch.', 'dem', 'Arkadaşıma kitap hediye ediyorum.', 'schenken + Dativ: der Freund → dem Freund.'],
  ['___ Hund ist groß.', 'der', 'Köpek büyük.', 'Özne Nominativ\'dedir: der Hund.'],
  ['Ich lese ___ Zeitung.', 'die', 'Gazeteyi okuyorum.', 'Akkusativ: die Zeitung → die Zeitung.'],
  ['Er gibt ___ Kindern Geld.', 'den', 'Çocuklara para veriyor.', 'Dativ çoğul: den Kindern (isme -n eklenir).'],
  ['Ich brauche ___ Computer.', 'den', 'Bilgisayara ihtiyacım var.', 'brauchen + Akkusativ: der Computer → den Computer.'],
  ['Sie dankt ___ Lehrerin.', 'der', 'Öğretmene teşekkür ediyor.', 'danken + Dativ: die Lehrerin → der Lehrerin.'],
  ['Das ist ___ Tisch.', 'der', 'Bu masa.', 'sein + Nominativ: der Tisch.'],
  ['Ich sehe ___ Kinder.', 'die', 'Çocukları görüyorum.', 'Akkusativ çoğul: die Kinder.'],
  ['Wir wohnen mit ___ Eltern.', 'den', 'Ailemizle birlikte yaşıyoruz.', 'mit + Dativ çoğul: den Eltern.'],
  ['Ich esse ___ Apfel.', 'den', 'Bir elmayı yiyorum.', 'essen + Akkusativ: der Apfel → den Apfel.'],
  ['Er liebt ___ Frau.', 'die', 'O karısını seviyor.', 'lieben + Akkusativ: die Frau → die Frau.'],
  ['Ich gebe ___ Mann das Geld.', 'dem', 'Adama parayı veriyorum.', 'geben + Dativ: der Mann → dem Mann.'],
  ['Das Auto gehört ___ Frau.', 'der', 'Araba kadına ait.', 'gehören + Dativ: die Frau → der Frau.'],
  ['___ Kind spielt im Garten.', 'das', 'Çocuk bahçede oynuyor.', 'Özne Nominativ: das Kind.'],
  ['Ich öffne ___ Fenster.', 'das', 'Pencereyi açıyorum.', 'öffnen + Akkusativ: das Fenster.'],
  ['Wir kaufen ___ Hund.', 'den', 'Bir köpek alıyoruz.', 'kaufen + Akkusativ: der Hund → den Hund.'],
  ['Das Kleid gefällt ___ Mädchen.', 'dem', 'Elbise kızın hoşuna gidiyor.', 'gefallen + Dativ: das Mädchen → dem Mädchen.'],
  ['___ Lehrerin erklärt die Aufgabe.', 'die', 'Öğretmen görevi açıklıyor.', 'Özne Nominativ: die Lehrerin.'],
  ['Ich suche ___ Schlüssel.', 'den', 'Anahtarı arıyorum.', 'suchen + Akkusativ: der Schlüssel → den Schlüssel.'],
];

/* ---------- Präpositionen ---------- */
const PREP: Fill[] = [
  ['Ich fahre mit ___ Bus.', 'dem', 'Otobüsle gidiyorum.', 'mit + Dativ: der Bus → dem Bus.'],
  ['Das Geschenk ist für ___ Mutter.', 'die', 'Hediye anne için.', 'für + Akkusativ: die Mutter → die Mutter.'],
  ['Ich wohne bei ___ Eltern.', 'den', 'Ailemin yanında yaşıyorum.', 'bei + Dativ çoğul: den Eltern.'],
  ['Wir gehen in ___ Kino. (wohin?)', 'das', 'Sinemaya gidiyoruz.', 'Wohin? sorusu: Akkusativ → das Kino.'],
  ['Wir sind in ___ Kino. (wo?)', 'dem', 'Sinemadayız.', 'Wo? sorusu: Dativ → dem Kino.'],
  ['Nach ___ Arbeit gehe ich heim.', 'der', 'İşten sonra eve giderim.', 'nach + Dativ: die Arbeit → der Arbeit.'],
  ['Ich komme aus ___ Türkei.', 'der', 'Türkiye\'denim.', 'aus + Dativ: die Türkei → der Türkei.'],
  ['Das Buch liegt auf ___ Tisch. (wo?)', 'dem', 'Kitap masanın üstünde.', 'Wo? sorusu: Dativ → dem Tisch.'],
  ['Ich lege das Buch auf ___ Tisch. (wohin?)', 'den', 'Kitabı masanın üstüne koyuyorum.', 'Wohin? sorusu: Akkusativ → den Tisch.'],
  ['Sie geht zu ___ Arzt.', 'dem', 'O doktora gidiyor.', 'zu + Dativ: der Arzt → dem Arzt.'],
  ['Ich laufe durch ___ Park.', 'den', 'Parkın içinden yürüyorum.', 'durch + Akkusativ: der Park → den Park.'],
  ['Wir warten auf ___ Bus.', 'den', 'Otobüsü bekliyoruz.', 'warten auf + Akkusativ.'],
  ['Das Bild hängt an ___ Wand. (wo?)', 'der', 'Resim duvarda asılı.', 'Wo? sorusu: Dativ → die Wand → der Wand.'],
  ['Er spricht über ___ Film.', 'den', 'Film hakkında konuşuyor.', 'sprechen über + Akkusativ.'],
  ['Wir fahren ohne ___ Auto.', 'das', 'Arabasız gidiyoruz.', 'ohne + Akkusativ: das Auto.'],
  ['Er kommt von ___ Arbeit.', 'der', 'O işten geliyor.', 'von + Dativ: die Arbeit → der Arbeit.'],
  ['Wir fahren um ___ Stadt herum.', 'die', 'Şehrin etrafında dolaşıyoruz.', 'um + Akkusativ: die Stadt.'],
  ['Das Auto steht vor ___ Haus. (wo?)', 'dem', 'Araba evin önünde duruyor.', 'Wo? sorusu: Dativ → dem Haus.'],
  ['Ich stelle das Auto vor ___ Haus. (wohin?)', 'das', 'Arabayı evin önüne park ediyorum.', 'Wohin? sorusu: Akkusativ → das Haus.'],
  ['Sie sitzt neben ___ Freund.', 'dem', 'O arkadaşının yanında oturuyor.', 'neben (Wo?) + Dativ: dem Freund.'],
  ['Ich bin seit ___ Woche hier.', 'einer', 'Bir haftadır buradayım.', 'seit + Dativ: eine Woche → einer Woche.', ['einer', 'eine', 'einem', 'einen']],
];

/* ---------- Negation ---------- */
const NEG: Fill[] = [
  ['Ich habe ___ Zeit.', 'keine', 'Vaktim yok.', 'Zeit (die) isimdir → kein-: keine Zeit.'],
  ['Das ist ___ mein Buch.', 'nicht', 'Bu benim kitabım değil.', 'Sahiplik zamiri olan isim "nicht" ile olumsuzlanır.'],
  ['Ich trinke ___ Kaffee.', 'keinen', 'Kahve içmiyorum.', 'Kaffee (der) Akkusativ: keinen Kaffee.'],
  ['Er kommt ___ heute.', 'nicht', 'O bugün gelmiyor.', 'Fiil veya zaman olumsuzu "nicht" ile yapılır.'],
  ['Sie hat ___ Auto.', 'kein', 'Onun arabası yok.', 'Auto (das): kein Auto.'],
  ['Wir haben ___ Kinder.', 'keine', 'Çocuğumuz yok.', 'Çoğul: keine Kinder.'],
  ['Das ist ___ Apfel, das ist eine Birne.', 'kein', 'Bu elma değil, armut.', 'Apfel (der) Nominativ: kein Apfel.'],
  ['Er arbeitet ___ gern.', 'nicht', 'O çalışmayı sevmiyor.', '"gern" olumsuzu: nicht gern.'],
  ['Ich esse ___ Fleisch.', 'kein', 'Et yemiyorum.', 'Fleisch (das): kein Fleisch.'],
  ['Ich verstehe das ___.', 'nicht', 'Bunu anlamıyorum.', 'Fiil olumsuzu cümle sonunda: nicht.'],
  ['Ich habe ___ Hunger.', 'keinen', 'Aç değilim.', 'Hunger (der) Akkusativ: keinen Hunger.'],
];

/* ---------- Plural ---------- */
const PLURALS: [string, string, string, string][] = [
  ['der', 'Tisch', 'Tische', 'masa'], ['das', 'Buch', 'Bücher', 'kitap'], ['die', 'Frau', 'Frauen', 'kadın'],
  ['das', 'Kind', 'Kinder', 'çocuk'], ['der', 'Mann', 'Männer', 'adam'], ['die', 'Katze', 'Katzen', 'kedi'],
  ['der', 'Hund', 'Hunde', 'köpek'], ['das', 'Auto', 'Autos', 'araba'], ['der', 'Apfel', 'Äpfel', 'elma'],
  ['die', 'Stadt', 'Städte', 'şehir'], ['das', 'Haus', 'Häuser', 'ev'], ['der', 'Bruder', 'Brüder', 'erkek kardeş'],
  ['die', 'Schwester', 'Schwestern', 'kız kardeş'], ['das', 'Zimmer', 'Zimmer', 'oda'], ['der', 'Lehrer', 'Lehrer', 'öğretmen'],
  ['die', 'Tasche', 'Taschen', 'çanta'], ['das', 'Handy', 'Handys', 'cep telefonu'], ['der', 'Student', 'Studenten', 'öğrenci'],
  ['die', 'Uhr', 'Uhren', 'saat'], ['der', 'Stuhl', 'Stühle', 'sandalye'], ['die', 'Hand', 'Hände', 'el'],
  ['der', 'Vater', 'Väter', 'baba'], ['die', 'Mutter', 'Mütter', 'anne'], ['das', 'Fenster', 'Fenster', 'pencere'],
  ['die', 'Straße', 'Straßen', 'sokak'], ['der', 'Freund', 'Freunde', 'arkadaş'], ['das', 'Bild', 'Bilder', 'resim'],
  ['der', 'Garten', 'Gärten', 'bahçe'], ['die', 'Zeitung', 'Zeitungen', 'gazete'], ['das', 'Hotel', 'Hotels', 'otel'],
];

const buildPlural = (): Exercise[] => {
  const out: Exercise[] = [];
  PLURALS.forEach(([art, sg, pl, tr], i) => {
    const guesses = Array.from(
      new Set([sg + 'e', sg + 'n', sg + 'en', sg + 's', sg + 'er', sg.replace(/[aou]/, (m) => ({ a: 'ä', o: 'ö', u: 'ü' } as any)[m]) + 'e', sg])
    ).filter((g) => g !== pl);
    out.push({
      id: `gram_plural_mc${i}`,
      refId: `gram:plural:${i}`,
      level: 'A1',
      topicTag: 'Gramer: Plural',
      type: 'multiple_choice',
      instructionTr: 'Çoğul hali hangisi?',
      prompt: `${art} ${sg} (${tr})`,
      options: shuffle([pl, ...shuffle(guesses).slice(0, 3)]),
      correctAnswer: pl,
      explanationTr: `${art} ${sg} → die ${pl}. Çoğulda artikel her zaman "die" olur.`,
    } as Exercise);
    if (i % 2 === 0) {
      out.push({
        id: `gram_plural_type${i}`,
        refId: `gram:plural:${i}`,
        level: 'A1',
        topicTag: 'Gramer: Plural',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Çoğul halini yazın:',
        promptTr: `${art} ${sg} (${tr})`,
        hintTr: 'die ...',
        answer: pl,
        accept: [`die ${pl}`],
        explanationTr: `${art} ${sg} → die ${pl}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Perfekt ---------- */
const VERBS: [inf: string, aux: 'hat' | 'ist', pp: string, tr: string][] = [
  ['machen', 'hat', 'gemacht', 'yapmak'], ['spielen', 'hat', 'gespielt', 'oynamak'], ['lernen', 'hat', 'gelernt', 'öğrenmek'],
  ['kaufen', 'hat', 'gekauft', 'satın almak'], ['arbeiten', 'hat', 'gearbeitet', 'çalışmak'], ['wohnen', 'hat', 'gewohnt', 'oturmak'],
  ['sagen', 'hat', 'gesagt', 'söylemek'], ['essen', 'hat', 'gegessen', 'yemek yemek'], ['trinken', 'hat', 'getrunken', 'içmek'],
  ['sehen', 'hat', 'gesehen', 'görmek'], ['lesen', 'hat', 'gelesen', 'okumak'], ['schreiben', 'hat', 'geschrieben', 'yazmak'],
  ['sprechen', 'hat', 'gesprochen', 'konuşmak'], ['nehmen', 'hat', 'genommen', 'almak'], ['geben', 'hat', 'gegeben', 'vermek'],
  ['finden', 'hat', 'gefunden', 'bulmak'], ['helfen', 'hat', 'geholfen', 'yardım etmek'], ['schlafen', 'hat', 'geschlafen', 'uyumak'],
  ['gehen', 'ist', 'gegangen', 'gitmek'], ['kommen', 'ist', 'gekommen', 'gelmek'], ['fahren', 'ist', 'gefahren', 'gitmek (araçla)'],
  ['fliegen', 'ist', 'geflogen', 'uçmak'], ['laufen', 'ist', 'gelaufen', 'koşmak, yürümek'], ['bleiben', 'ist', 'geblieben', 'kalmak'],
  ['sein', 'ist', 'gewesen', 'olmak'], ['werden', 'ist', 'geworden', 'olmak (-leşmek)'], ['aufstehen', 'ist', 'aufgestanden', 'kalkmak'],
  ['ankommen', 'ist', 'angekommen', 'varmak'], ['einkaufen', 'hat', 'eingekauft', 'alışveriş yapmak'], ['anrufen', 'hat', 'angerufen', 'aramak'],
  ['besuchen', 'hat', 'besucht', 'ziyaret etmek'], ['bezahlen', 'hat', 'bezahlt', 'ödemek'], ['verstehen', 'hat', 'verstanden', 'anlamak'],
  ['vergessen', 'hat', 'vergessen', 'unutmak'], ['bekommen', 'hat', 'bekommen', 'almak, elde etmek'], ['studieren', 'hat', 'studiert', 'üniversitede okumak'],
  ['passieren', 'ist', 'passiert', 'olmak (olay)'], ['aussteigen', 'ist', 'ausgestiegen', 'inmek'], ['mitbringen', 'hat', 'mitgebracht', 'yanında getirmek'],
  ['denken', 'hat', 'gedacht', 'düşünmek'], ['bringen', 'hat', 'gebracht', 'getirmek'],
];

const buildPerfekt = (): Exercise[] => {
  const out: Exercise[] = [];
  VERBS.forEach(([inf, aux, pp, tr], i) => {
    const ref = `gram:perfekt:${i}`;
    out.push({
      id: `gram_perfekt_aux${i}`,
      refId: ref,
      level: 'A2',
      topicTag: 'Gramer: Perfekt',
      type: 'multiple_choice',
      instructionTr: 'Perfekt kurarken hangi yardımcı fiil gerekir?',
      prompt: `${inf} (${tr})`,
      options: shuffle(['hat', 'ist']),
      correctAnswer: aux,
      explanationTr: `${inf} → er ${aux} ${pp}. ${aux === 'ist' ? 'Hareket veya durum değişikliği bildiren fiillerde "sein" kullanılır.' : 'Çoğu fiil "haben" ile kurulur.'}`,
    } as Exercise);
    const stem = inf.endsWith('en') ? inf.slice(0, -2) : inf;
    const wrong = Array.from(new Set([`ge${stem}t`, `ge${inf}`, `${stem}t`, `ge${stem}en`])).filter((g) => g !== pp);
    out.push({
      id: `gram_perfekt_pp${i}`,
      refId: ref,
      level: 'A2',
      topicTag: 'Gramer: Perfekt',
      type: 'multiple_choice',
      instructionTr: 'Partizip II hangisi?',
      prompt: `${inf} (${tr})`,
      options: shuffle([pp, ...shuffle(wrong).slice(0, 3)]),
      correctAnswer: pp,
      explanationTr: `${inf} → ${aux} ${pp}`,
    } as Exercise);
    if (i % 2 === 1) {
      out.push({
        id: `gram_perfekt_type${i}`,
        refId: ref,
        level: 'A2',
        topicTag: 'Gramer: Perfekt',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Partizip II yazın:',
        promptTr: `${inf} (${tr})`,
        hintTr: `Yardımcı fiil: ${aux}`,
        answer: pp,
        accept: [`${aux} ${pp}`, `er ${aux} ${pp}`],
        explanationTr: `${inf} → er ${aux} ${pp}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Konjugation ---------- */
const PERSONS = ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'];
const CONJ: [inf: string, tr: string, forms: string[]][] = [
  ['sein', 'olmak', ['bin', 'bist', 'ist', 'sind', 'seid', 'sind']],
  ['haben', 'sahip olmak', ['habe', 'hast', 'hat', 'haben', 'habt', 'haben']],
  ['werden', 'olmak (-leşmek)', ['werde', 'wirst', 'wird', 'werden', 'werdet', 'werden']],
  ['können', '-ebilmek', ['kann', 'kannst', 'kann', 'können', 'könnt', 'können']],
  ['müssen', '-meli', ['muss', 'musst', 'muss', 'müssen', 'müsst', 'müssen']],
  ['wollen', 'istemek', ['will', 'willst', 'will', 'wollen', 'wollt', 'wollen']],
  ['gehen', 'gitmek', ['gehe', 'gehst', 'geht', 'gehen', 'geht', 'gehen']],
  ['fahren', 'gitmek (araçla)', ['fahre', 'fährst', 'fährt', 'fahren', 'fahrt', 'fahren']],
  ['essen', 'yemek yemek', ['esse', 'isst', 'isst', 'essen', 'esst', 'essen']],
  ['sprechen', 'konuşmak', ['spreche', 'sprichst', 'spricht', 'sprechen', 'sprecht', 'sprechen']],
  ['lesen', 'okumak', ['lese', 'liest', 'liest', 'lesen', 'lest', 'lesen']],
  ['schlafen', 'uyumak', ['schlafe', 'schläfst', 'schläft', 'schlafen', 'schlaft', 'schlafen']],
];

const buildConj = (): Exercise[] => {
  const out: Exercise[] = [];
  CONJ.forEach(([inf, tr, forms], vi) => {
    [0, 1, 2, 3].forEach((pi) => {
      const correct = forms[pi];
      const wrong = Array.from(new Set(forms.filter((f) => f !== correct)));
      out.push({
        id: `gram_conj_${vi}_${pi}`,
        refId: `gram:konj:${vi}`,
        level: 'A1',
        topicTag: 'Gramer: Fiil çekimi',
        type: 'verb_conjugation',
        instructionTr: 'Fiili özneye göre çekin:',
        verbInfinitive: inf,
        pronoun: PERSONS[pi],
        turkishTranslation: tr,
        options: shuffle([correct, ...shuffle(wrong).slice(0, 3)]),
        correctAnswer: correct,
        explanationTr: `${PERSONS[pi]} ${correct} (${inf}: ${forms.join(', ')})`,
      } as Exercise);
    });
    // write the irregular du / er form
    if (forms[1] !== forms[0].replace(/e$/, '') + 'st' || ['sein', 'haben', 'werden'].includes(inf)) {
      out.push({
        id: `gram_conj_type${vi}`,
        refId: `gram:konj:${vi}`,
        level: 'A1',
        topicTag: 'Gramer: Fiil çekimi',
        type: 'typing',
        mode: 'word',
        instructionTr: 'Doğru fiil çekimini yazın:',
        promptTr: `du ... (${inf}, ${tr})`,
        hintTr: `${forms[1].length} harf`,
        answer: forms[1],
        explanationTr: `du ${forms[1]}`,
      } as Exercise);
    }
  });
  return out;
};

/* ---------- Satzstellung ---------- */
const ORDER: [sentence: string, tr: string, rule: string][] = [
  ['Ich lerne jeden Tag Deutsch.', 'Her gün Almanca öğreniyorum.', 'Ana cümle: fiil ikinci sırada.'],
  ['Heute gehe ich ins Kino.', 'Bugün sinemaya gidiyorum.', 'Başa zaman gelirse fiil yine ikinci sırada, özne arkasından gelir (Inversion).'],
  ['Morgen fahren wir nach Berlin.', 'Yarın Berlin\'e gidiyoruz.', 'Zaman ifadesi başta: fiil + özne.'],
  ['Ich kann gut schwimmen.', 'İyi yüzebiliyorum.', 'Modal fiil ikinci sırada, ana fiil (mastar) sonda.'],
  ['Er möchte einen Kaffee trinken.', 'O bir kahve içmek istiyor.', 'Modal fiil + ... + mastar.'],
  ['Ich habe gestern Fußball gespielt.', 'Dün futbol oynadım.', 'Perfekt: haben ikinci sırada, Partizip II sonda (Klammer).'],
  ['Wir sind nach Hause gegangen.', 'Eve gittik.', 'Perfekt: sein ikinci sırada, Partizip II sonda.'],
  ['Ich stehe um sieben Uhr auf.', 'Saat yedide kalkıyorum.', 'Ayrılabilen fiil: ön ek (auf) cümle sonuna gider.'],
  ['Er ruft seine Mutter an.', 'O annesini arıyor.', 'Ayrılabilen fiil: ön ek (an) sona gider.'],
  ['Ich weiß, dass er krank ist.', 'Onun hasta olduğunu biliyorum.', '"dass" yan cümlesinde fiil sona gider.'],
  ['Wenn es regnet, bleiben wir zu Hause.', 'Yağmur yağarsa evde kalırız.', 'Yan cümle başta ise ana cümlede fiil hemen gelir.'],
  ['Am Wochenende besuche ich meine Eltern.', 'Hafta sonu ailemi ziyaret ediyorum.', 'Zaman başta, ardından fiil, ardından özne.'],
  ['Kannst du mir bitte helfen?', 'Bana yardım edebilir misin?', 'Evet/hayır sorusunda fiil başta, mastar sonda.'],
  ['Warum lernst du Deutsch?', 'Neden Almanca öğreniyorsun?', 'W-sorusu: soru kelimesi + fiil + özne.'],
  ['Hast du heute Zeit?', 'Bugün vaktin var mı?', 'Evet/hayır sorusu: fiil en başta.'],
  ['Nach der Arbeit gehe ich einkaufen.', 'İşten sonra alışverişe gidiyorum.', 'Başta zaman/yer: fiil ikinci sırada.'],
];

const buildOrder = (): Exercise[] =>
  ORDER.map(([sentence, tr, rule], i) => ({
    id: `gram_order${i}`,
    refId: `gram:satz:${i}`,
    level: 'A2',
    topicTag: 'Gramer: Cümle sırası',
    type: 'sentence_builder',
    instructionTr: 'Cümleyi doğru sırayla kurun:',
    turkishPrompt: tr,
    correctGermanSentence: sentence,
    scrambledWords: sentence.split(' '),
    explanationTr: `${sentence} (${rule})`,
  } as Exercise));

const BASE_TOPICS: LabTopic[] = [
  {
    id: 'konjugation',
    level: 'A1',
    emoji: '🧩',
    titleTr: 'Fiil çekimi: sein, haben, können...',
    cards: [
      {
        title: 'Fiil özneye göre değişir',
        bodyTr: 'Almancada fiilin sonu özneye göre değişir. En önemli düzensiz fiiller: sein, haben, werden ve modal fiiller. Bunları ezbere bilmek her cümlede işinize yarar.',
        rows: [['sein', 'bin, bist, ist, sind, seid, sind'], ['haben', 'habe, hast, hat, haben, habt, haben'], ['können', 'kann, kannst, kann, können, könnt, können']],
        tipTr: 'Modal fiillerde ich ve er/sie/es aynıdır: ich kann, er kann.',
      },
      {
        title: 'Ünlü değiştiren fiiller',
        bodyTr: 'Bazı fiillerde du ve er/sie/es için kök ünlüsü değişir: essen → du isst, fahren → du fährst, sprechen → du sprichst, lesen → du liest.',
        rows: [['fahren', 'ich fahre, du fährst, er fährt'], ['sprechen', 'ich spreche, du sprichst, er spricht'], ['schlafen', 'ich schlafe, du schläfst, er schläft']],
      },
    ],
    build: buildConj,
  },
  {
    id: 'plural',
    level: 'A1',
    emoji: '👨‍👩‍👧',
    titleTr: 'Çoğul (Plural) oluşturma',
    cards: [
      {
        title: 'Çoğulun 5 yolu',
        bodyTr: 'Almancada çoğul tek bir kurala bağlı değildir. En sık görülen sonlar -e, -er, -(e)n, -s ve değişmeyenlerdir. Birçok kelimede ayrıca ünlü noktalı olur (ä, ö, ü). Çoğulda artikel her zaman "die" olur.',
        rows: [['-e', 'der Tisch → die Tische'], ['-er (+ ¨)', 'das Buch → die Bücher'], ['-(e)n', 'die Frau → die Frauen'], ['-s', 'das Auto → die Autos'], ['değişmez', 'das Zimmer → die Zimmer']],
        tipTr: 'Kelimeyi öğrenirken çoğulunu da birlikte öğrenin: "der Tisch, die Tische".',
      },
    ],
    build: buildPlural,
  },
  {
    id: 'artikel-kasus',
    level: 'A1',
    emoji: '🎯',
    titleTr: 'Artikel ve haller: Nominativ, Akkusativ, Dativ',
    cards: [
      {
        title: 'Üç hal, üç artikel tablosu',
        bodyTr: 'Cümlede kelimenin görevi artikelini değiştirir. Özne Nominativ\'dedir. Doğrudan nesne Akkusativ\'dur (sadece der → den değişir). Dolaylı nesne Dativ\'dur (kime?).',
        rows: [['Nominativ', 'der · die · das · die'], ['Akkusativ', 'den · die · das · die'], ['Dativ', 'dem · der · dem · den (+n)']],
        tipTr: 'Akkusativ\'da sadece eril değişir: der → den.',
      },
      {
        title: 'Hangi fiil hangi hali ister?',
        bodyTr: 'Çoğu fiil Akkusativ ister: sehen, kaufen, brauchen, lesen. Bazı fiiller Dativ ister: helfen, danken, gefallen, gehören. "geben" ve "schenken" ikisini birden ister: kime (Dativ) neyi (Akkusativ).',
        formulaDe: 'Ich gebe dem Kind (Dativ) den Ball (Akkusativ).',
      },
    ],
    build: () => fillExercises('artikel', 'A1', 'Gramer: Artikel ve haller', ARTIKEL, ART_POOL),
  },
  {
    id: 'negation',
    level: 'A1',
    emoji: '🚫',
    titleTr: 'Olumsuzluk: nicht ve kein',
    cards: [
      {
        title: 'kein mı, nicht mi?',
        bodyTr: '"kein" belirsiz artikelin (ein, eine) ve artikelsiz isimlerin olumsuzudur: Ich habe ein Auto → Ich habe kein Auto. "nicht" ise fiili, sıfatı, zamanı ve belirli isimleri olumsuzlar.',
        rows: [['kein / keine / keinen', 'Ich habe keine Zeit.'], ['nicht', 'Ich komme nicht. · Das ist nicht gut.']],
        tipTr: 'kein, "ein" gibi çekimlenir: der → keinen (Akkusativ), die → keine, das → kein.',
      },
    ],
    build: () => fillExercises('negation', 'A1', 'Gramer: Olumsuzluk', NEG, ['kein', 'keine', 'keinen', 'nicht']),
  },
  {
    id: 'praeposition',
    level: 'A2',
    emoji: '📍',
    titleTr: 'Edatlar ve haller: mit, für, in, auf...',
    cards: [
      {
        title: 'Her edatın bir hali var',
        bodyTr: 'Edatlar belirli bir hal ister. Bunları ezberlemek için gruplamak kolaydır.',
        rows: [['+ Dativ', 'mit, nach, bei, seit, von, zu, aus'], ['+ Akkusativ', 'für, ohne, durch, gegen, um'], ['Wechselpräpositionen', 'in, an, auf, neben, vor, hinter, über, unter']],
        tipTr: 'mit + Dativ, für + Akkusativ: iki edatı ilk ezberleyin.',
      },
      {
        title: 'Wo? mu Wohin? mi?',
        bodyTr: 'in, an, auf gibi edatlarda hareket yoksa (Wo? = nerede?) Dativ, hareket varsa (Wohin? = nereye?) Akkusativ kullanılır.',
        rows: [['Wo? → Dativ', 'Ich bin in dem Kino. (im Kino)'], ['Wohin? → Akkusativ', 'Ich gehe in das Kino. (ins Kino)']],
      },
    ],
    build: () => fillExercises('praep', 'A2', 'Gramer: Edatlar ve haller', PREP, ART_POOL),
  },
  {
    id: 'perfekt',
    level: 'A2',
    emoji: '⏪',
    titleTr: 'Perfekt: geçmişi anlatmak',
    cards: [
      {
        title: 'haben/sein + Partizip II',
        bodyTr: 'Konuşma dilinde geçmişi çoğunlukla Perfekt ile anlatırız: yardımcı fiil (haben veya sein) ikinci sırada, Partizip II cümle sonunda. Hareket ve durum değişikliği bildiren fiiller "sein" ile kurulur.',
        formulaDe: 'Ich habe gespielt.  |  Ich bin gegangen.',
        rows: [['Düzenli fiiller', 'ge + kök + t → gemacht, gespielt'], ['Düzensiz fiiller', 'ge + ... + en → gegessen, gesehen'], ['Ayrılabilen fiiller', 'ge ortada → aufgestanden, eingekauft'], ['be-, ver-, ent- ile başlayanlar', 'ge yok → besucht, verstanden']],
        tipTr: 'sein ile kurulanlar: gehen, kommen, fahren, bleiben, sein, werden, aufstehen.',
      },
    ],
    build: buildPerfekt,
  },
  {
    id: 'satzstellung',
    level: 'A2',
    emoji: '🧱',
    titleTr: 'Cümle sırası: fiil nerede durur?',
    cards: [
      {
        title: 'Altın kural: fiil ikinci sırada',
        bodyTr: 'Ana cümlede çekimli fiil her zaman ikinci sıradadır. Cümleye zaman veya yerle başlarsanız özne fiilden sonra gelir (Inversion).',
        rows: [['Normal', 'Ich gehe heute ins Kino.'], ['Inversion', 'Heute gehe ich ins Kino.']],
      },
      {
        title: 'İkinci parça cümle sonuna gider',
        bodyTr: 'Modal fiilde mastar, Perfekt\'te Partizip II ve ayrılabilen fiillerde ön ek cümle sonuna gider. Yan cümlelerde (dass, weil, wenn) çekimli fiil sona gider.',
        rows: [['Modal', 'Ich kann gut schwimmen.'], ['Perfekt', 'Ich habe Fußball gespielt.'], ['Ayrılabilen', 'Ich stehe um sieben auf.'], ['Yan cümle', 'Ich weiß, dass er krank ist.']],
      },
    ],
    build: buildOrder,
  },
];


/* ================= More topics: A1 to B2 ================= */
const MODAL: Fill[] = [
  ['Ich ___ gut schwimmen.', 'kann', 'İyi yüzebiliyorum.', 'können: ich kann.'],
  ['Du ___ heute lernen.', 'musst', 'Bugün çalışmalısın.', 'müssen: du musst.'],
  ['Er ___ nach Hause gehen.', 'will', 'O eve gitmek istiyor.', 'wollen: er will.'],
  ['Wir ___ hier nicht rauchen.', 'dürfen', 'Burada sigara içemeyiz (yasak).', 'dürfen: wir dürfen. "nicht dürfen" = yasak.'],
  ['Ihr ___ pünktlich kommen.', 'sollt', 'Zamanında gelmelisiniz.', 'sollen: ihr sollt.'],
  ['Ich ___ einen Kaffee.', 'möchte', 'Bir kahve istiyorum.', 'möchten: ich möchte (nazik istek).'],
  ['___ du mir helfen?', 'kannst', 'Bana yardım edebilir misin?', 'können: du kannst. Soruda fiil başta.'],
  ['Sie ___ Deutsch lernen. (zorunlu)', 'muss', 'O Almanca öğrenmek zorunda.', 'müssen: sie muss.'],
  ['Wir ___ morgen ins Kino gehen. (istiyoruz)', 'wollen', 'Yarın sinemaya gitmek istiyoruz.', 'wollen: wir wollen.'],
  ['Hier ___ man parken. (izin var)', 'darf', 'Burada park edilebilir.', 'dürfen: man darf.'],
];
const MODAL_POOL = ['kann', 'kannst', 'muss', 'musst', 'will', 'dürfen', 'sollt', 'möchte', 'wollen', 'darf'];

const GENITIV: Fill[] = [
  ['Das ist das Auto ___ Mannes.', 'des', 'Bu adamın arabası.', 'Genitiv eril/nötr: des + isim (-s/-es).', ['des', 'der', 'dem', 'den']],
  ['Das ist die Tasche ___ Frau.', 'der', 'Bu kadının çantası.', 'Genitiv dişil: der Frau.', ['des', 'der', 'dem', 'den']],
  ['Das ist das Haus ___ Kindes.', 'des', 'Bu çocuğun evi.', 'Genitiv nötr: des Kindes.', ['des', 'der', 'dem', 'den']],
  ['Die Bücher ___ Kinder sind neu.', 'der', 'Çocukların kitapları yeni.', 'Genitiv çoğul: der Kinder.', ['des', 'der', 'dem', 'den']],
  ['Wegen ___ Regens bleiben wir hier.', 'des', 'Yağmur yüzünden burada kalıyoruz.', 'wegen + Genitiv: des Regens.', ['des', 'der', 'dem', 'den']],
  ['Trotz ___ Kälte gehen wir raus.', 'der', 'Soğuğa rağmen dışarı çıkıyoruz.', 'trotz + Genitiv: der Kälte.', ['des', 'der', 'dem', 'den']],
  ['Während ___ Sommers ist es heiß.', 'des', 'Yaz boyunca hava sıcak.', 'während + Genitiv: des Sommers.', ['des', 'der', 'dem', 'den']],
  ['Das ist die Meinung ___ Lehrers.', 'des', 'Bu öğretmenin görüşü.', 'Genitiv eril: des Lehrers.', ['des', 'der', 'dem', 'den']],
  ['Der Name ___ Stadt ist Köln.', 'der', 'Şehrin adı Köln.', 'Genitiv dişil: der Stadt.', ['des', 'der', 'dem', 'den']],
  ['Die Farbe ___ Autos ist rot.', 'des', 'Arabanın rengi kırmızı.', 'Genitiv nötr: des Autos.', ['des', 'der', 'dem', 'den']],
];

const PRAET: Fill[] = [
  ['Gestern ___ ich zu Hause. (sein)', 'war', 'Dün evdeydim.', 'sein → war.', ['war', 'waren', 'bin', 'wäre']],
  ['Er ___ keine Zeit. (haben)', 'hatte', 'Onun vakti yoktu.', 'haben → hatte.', ['hatte', 'hatten', 'hat', 'hätte']],
  ['Wir ___ nach Berlin. (fahren)', 'fuhren', 'Berlin\'e gittik.', 'fahren → fuhr, fuhren.', ['fuhren', 'fahren', 'fuhr', 'gefahren']],
  ['Sie ___ ein Buch. (lesen)', 'las', 'O bir kitap okudu.', 'lesen → las.', ['las', 'liest', 'lesen', 'gelesen']],
  ['Ich ___ ihn gestern. (sehen)', 'sah', 'Onu dün gördüm.', 'sehen → sah.', ['sah', 'sehe', 'sehen', 'gesehen']],
  ['Er ___ um acht. (kommen)', 'kam', 'O sekizde geldi.', 'kommen → kam.', ['kam', 'kommt', 'kommen', 'gekommen']],
  ['Wir ___ Fußball. (spielen)', 'spielten', 'Futbol oynadık.', 'Düzenli fiil: kök + te + n → spielten.', ['spielten', 'spielen', 'spielte', 'gespielt']],
  ['Ich ___ Hunger. (haben)', 'hatte', 'Açtım.', 'haben → hatte.', ['hatte', 'hatten', 'habe', 'hätte']],
  ['Sie ___ in Köln. (wohnen)', 'wohnte', 'O Köln\'de oturuyordu.', 'Düzenli fiil: kök + te → wohnte.', ['wohnte', 'wohnt', 'wohnten', 'gewohnt']],
  ['Das Wetter ___ schön. (sein)', 'war', 'Hava güzeldi.', 'sein → war.', ['war', 'waren', 'ist', 'wäre']],
];

const KONJ2: Fill[] = [
  ['Wenn ich Zeit ___, würde ich reisen.', 'hätte', 'Vaktim olsaydı seyahat ederdim.', 'haben → hätte (Konjunktiv II).', ['hätte', 'hatte', 'habe', 'wäre']],
  ['Wenn ich reich ___, würde ich ein Haus kaufen.', 'wäre', 'Zengin olsaydım ev alırdım.', 'sein → wäre.', ['wäre', 'war', 'bin', 'hätte']],
  ['Ich ___ gern ein Eis.', 'hätte', 'Bir dondurma alabilir miyim.', 'Nazik istek: ich hätte gern.', ['hätte', 'hatte', 'habe', 'wäre']],
  ['___ Sie mir helfen?', 'Könnten', 'Bana yardım edebilir misiniz?', 'Nazik rica: Könnten Sie ...?', ['Könnten', 'Können', 'Konnten', 'Kann']],
  ['Ich ___ an deiner Stelle zum Arzt gehen.', 'würde', 'Senin yerinde olsam doktora giderdim.', 'Tavsiye: ich würde + mastar.', ['würde', 'werde', 'wurde', 'wäre']],
  ['Wenn wir ein Auto ___, könnten wir fahren.', 'hätten', 'Arabamız olsaydı gidebilirdik.', 'haben → hätten.', ['hätten', 'hatten', 'haben', 'wären']],
  ['Ich ___ gern nach Japan reisen.', 'würde', 'Japonya\'ya seyahat etmek isterdim.', 'würde + mastar: isteği nazikçe ifade eder.', ['würde', 'werde', 'wurde', 'wäre']],
  ['___ du bitte das Fenster schließen?', 'Würdest', 'Pencereyi kapatır mısın lütfen?', 'Nazik rica: Würdest du ...?', ['Würdest', 'Wirst', 'Wurdest', 'Würde']],
];

const ADJEKT: Fill[] = [
  ['Das ist ein klein___ Kind.', 'es', 'Bu küçük bir çocuk.', 'ein + nötr Nominativ: -es.', ['e', 'en', 'er', 'es']],
  ['Ich sehe einen groß___ Hund.', 'en', 'Büyük bir köpek görüyorum.', 'einen + eril Akkusativ: -en.', ['e', 'en', 'er', 'es']],
  ['Der alt___ Mann liest.', 'e', 'Yaşlı adam okuyor.', 'der + Nominativ: -e.', ['e', 'en', 'er', 'es']],
  ['Sie hat eine neu___ Tasche.', 'e', 'Onun yeni bir çantası var.', 'eine + dişil: -e.', ['e', 'en', 'er', 'es']],
  ['Das ist ein gut___ Freund.', 'er', 'Bu iyi bir arkadaş.', 'ein + eril Nominativ: -er.', ['e', 'en', 'er', 'es']],
  ['Ich kaufe ein neu___ Auto.', 'es', 'Yeni bir araba alıyorum.', 'ein + nötr Akkusativ: -es.', ['e', 'en', 'er', 'es']],
  ['Die klein___ Kinder spielen.', 'en', 'Küçük çocuklar oynuyor.', 'die + çoğul: -en.', ['e', 'en', 'er', 'es']],
  ['Wir haben einen schön___ Garten.', 'en', 'Güzel bir bahçemiz var.', 'einen + eril Akkusativ: -en.', ['e', 'en', 'er', 'es']],
  ['Das ist ein interessant___ Buch.', 'es', 'Bu ilginç bir kitap.', 'ein + nötr Nominativ: -es.', ['e', 'en', 'er', 'es']],
  ['Der jung___ Student lernt.', 'e', 'Genç öğrenci çalışıyor.', 'der + Nominativ: -e.', ['e', 'en', 'er', 'es']],
];

const RELATIV: Fill[] = [
  ['Das ist der Mann, ___ dort wohnt.', 'der', 'Orada oturan adam bu.', 'Özne (eril, Nominativ): der.', ['der', 'die', 'das', 'den', 'dem']],
  ['Das ist die Frau, ___ ich kenne.', 'die', 'Bu tanıdığım kadın.', 'Nesne (dişil, Akkusativ): die.', ['der', 'die', 'das', 'den', 'dem']],
  ['Das ist das Kind, ___ im Garten spielt.', 'das', 'Bahçede oynayan çocuk bu.', 'Özne (nötr): das.', ['der', 'die', 'das', 'den', 'dem']],
  ['Das ist der Hund, ___ ich gesehen habe.', 'den', 'Bu gördüğüm köpek.', 'Nesne (eril, Akkusativ): den.', ['der', 'die', 'das', 'den', 'dem']],
  ['Das Buch, ___ ich lese, ist spannend.', 'das', 'Okuduğum kitap heyecanlı.', 'Nesne (nötr): das.', ['der', 'die', 'das', 'den', 'dem']],
  ['Der Mann, ___ ich helfe, ist alt.', 'dem', 'Yardım ettiğim adam yaşlı.', 'helfen + Dativ (eril): dem.', ['der', 'die', 'das', 'den', 'dem']],
  ['Die Frau, ___ ich das Buch gebe, ist Lehrerin.', 'der', 'Kitabı verdiğim kadın öğretmen.', 'geben + Dativ (dişil): der.', ['der', 'die', 'das', 'den', 'dem']],
  ['Das ist die Stadt, in ___ ich wohne.', 'der', 'Bu yaşadığım şehir.', 'in + Dativ (dişil): in der.', ['der', 'die', 'das', 'den', 'dem']],
  ['Der Film, ___ wir gestern gesehen haben, war gut.', 'den', 'Dün izlediğimiz film iyiydi.', 'Nesne (eril, Akkusativ): den.', ['der', 'die', 'das', 'den', 'dem']],
];

const PASSIV: Fill[] = [
  ['Das Haus ___ gebaut.', 'wird', 'Ev inşa ediliyor.', 'Präsens Passiv: wird + Partizip II.', ['wird', 'werden', 'wurde', 'ist']],
  ['Die Häuser ___ gebaut.', 'werden', 'Evler inşa ediliyor.', 'Çoğul: werden + Partizip II.', ['wird', 'werden', 'wurde', 'sind']],
  ['Der Brief ___ gestern geschrieben.', 'wurde', 'Mektup dün yazıldı.', 'Präteritum Passiv: wurde + Partizip II.', ['wird', 'werden', 'wurde', 'ist']],
  ['Hier ___ Deutsch gesprochen.', 'wird', 'Burada Almanca konuşuluyor.', 'Präsens Passiv: wird gesprochen.', ['wird', 'werden', 'wurde', 'ist']],
  ['Das Auto ___ gerade repariert.', 'wird', 'Araba şu an tamir ediliyor.', 'Şimdiki durum: wird repariert.', ['wird', 'werden', 'wurde', 'ist']],
  ['Die Bücher ___ gelesen.', 'werden', 'Kitaplar okunuyor.', 'Çoğul: werden gelesen.', ['wird', 'werden', 'wurde', 'sind']],
  ['Das Essen ___ jeden Tag gekocht.', 'wird', 'Yemek her gün pişiriliyor.', 'Präsens Passiv: wird gekocht.', ['wird', 'werden', 'wurde', 'ist']],
  ['Der Film ___ vor einem Jahr gedreht.', 'wurde', 'Film bir yıl önce çekildi.', 'Geçmiş: wurde gedreht.', ['wird', 'werden', 'wurde', 'ist']],
];

const FUTUR: Fill[] = [
  ['Ich ___ morgen kommen.', 'werde', 'Yarın geleceğim.', 'Futur: werden + mastar. ich werde.', ['werde', 'wirst', 'wird', 'werden']],
  ['Du ___ es schaffen.', 'wirst', 'Başaracaksın.', 'du wirst.', ['werde', 'wirst', 'wird', 'werden']],
  ['Er ___ bald ankommen.', 'wird', 'O yakında varacak.', 'er wird.', ['werde', 'wirst', 'wird', 'werden']],
  ['Wir ___ nächstes Jahr reisen.', 'werden', 'Gelecek yıl seyahat edeceğiz.', 'wir werden.', ['werde', 'wirst', 'wird', 'werden']],
  ['Ihr ___ viel lernen.', 'werdet', 'Çok öğreneceksiniz.', 'ihr werdet.', ['werdet', 'wirst', 'wird', 'werden']],
  ['Es ___ bald regnen.', 'wird', 'Yakında yağmur yağacak.', 'es wird.', ['werde', 'wirst', 'wird', 'werden']],
];

const buildTrenn = (): Exercise[] => {
  const items: [string, string][] = [
    ['Ich rufe dich morgen an.', 'Seni yarın arayacağım.'],
    ['Der Zug kommt um acht Uhr an.', 'Tren saat sekizde varıyor.'],
    ['Wir kaufen heute im Supermarkt ein.', 'Bugün süpermarkette alışveriş yapıyoruz.'],
    ['Sie steht jeden Tag früh auf.', 'O her gün erken kalkıyor.'],
    ['Er macht das Fenster auf.', 'O pencereyi açıyor.'],
    ['Ich bringe dir ein Geschenk mit.', 'Sana bir hediye getiriyorum.'],
    ['Der Unterricht fängt um neun Uhr an.', 'Ders saat dokuzda başlıyor.'],
    ['Wann fährt der Bus ab?', 'Otobüs ne zaman kalkıyor?'],
  ];
  return items.map(([sentence, tr], i) => ({
    id: `gram_trenn${i}`,
    refId: `gram:trenn:${i}`,
    level: 'A2',
    topicTag: 'Gramer: Ayrılabilen fiiller',
    type: 'sentence_builder',
    instructionTr: 'Cümleyi doğru sırayla kurun:',
    turkishPrompt: tr,
    correctGermanSentence: sentence,
    scrambledWords: sentence.split(' '),
    explanationTr: `${sentence} (Ayrılabilen fiilde ön ek cümle sonuna gider.)`,
  } as Exercise));
};

const buildFuturOrder = (): Exercise[] => {
  const items: [string, string][] = [
    ['Ich werde morgen einkaufen gehen.', 'Yarın alışverişe gideceğim.'],
    ['Wir werden im Sommer nach Spanien fahren.', 'Yazın İspanya\'ya gideceğiz.'],
    ['Es wird bald regnen.', 'Yakında yağmur yağacak.'],
  ];
  return items.map(([sentence, tr], i) => ({
    id: `gram_futur_order${i}`,
    refId: `gram:futur:o${i}`,
    level: 'B1',
    topicTag: 'Gramer: Futur',
    type: 'sentence_builder',
    instructionTr: 'Cümleyi doğru sırayla kurun:',
    turkishPrompt: tr,
    correctGermanSentence: sentence,
    scrambledWords: sentence.split(' '),
    explanationTr: `${sentence} (Futur: werden ikinci sırada, mastar sonda.)`,
  } as Exercise));
};

const MORE_TOPICS: Record<string, LabTopic> = {
  modalverben: {
    id: 'modalverben', level: 'A1', emoji: '🔧', titleTr: 'Modal fiiller: können, müssen, wollen...',
    cards: [{
      title: 'Modal fiiller ne işe yarar?',
      bodyTr: 'Modal fiiller yeteneği, zorunluluğu, isteği, izni ve tavsiyeyi anlatır. Çekimli modal fiil ikinci sırada, ana fiil mastar olarak cümlenin sonunda durur.',
      formulaDe: 'Ich kann gut schwimmen.',
      rows: [['können', 'yapabilmek: ich kann'], ['müssen', 'zorunluluk: ich muss'], ['wollen', 'istemek: ich will'], ['dürfen', 'izin: ich darf'], ['sollen', 'tavsiye/görev: ich soll'], ['möchten', 'nazik istek: ich möchte']],
      tipTr: 'ich ve er/sie/es her zaman aynıdır: ich kann, er kann.',
    }],
    build: () => fillExercises('modal', 'A1', 'Gramer: Modal fiiller', MODAL, MODAL_POOL),
  },
  trennbare: {
    id: 'trennbare', level: 'A2', emoji: '✂️', titleTr: 'Ayrılabilen fiiller (trennbare Verben)',
    cards: [{
      title: 'Ön ek cümle sonuna gider',
      bodyTr: 'aufstehen, anrufen, einkaufen, mitbringen gibi fiillerde ön ek çekimde fiilden ayrılır ve cümle sonuna gider. Mastarda ve yan cümlede birleşik kalır.',
      rows: [['aufstehen', 'Ich stehe um sieben auf.'], ['anrufen', 'Er ruft seine Mutter an.'], ['einkaufen', 'Wir kaufen heute ein.'], ['ankommen', 'Der Zug kommt um acht an.']],
      tipTr: 'Perfekt\'te ge ortaya girer: aufgestanden, angerufen, eingekauft.',
    }],
    build: buildTrenn,
  },
  praeteritum: {
    id: 'praeteritum', level: 'B1', emoji: '📖', titleTr: 'Präteritum: yazı dilinde geçmiş',
    cards: [{
      title: 'Präteritum nerede kullanılır?',
      bodyTr: 'Hikâye, haber ve yazı dilinde geçmiş genelde Präteritum ile anlatılır. Sık kullanılan fiillerin (sein, haben, modal fiiller) Präteritum\'u konuşmada da yaygındır.',
      rows: [['sein', 'war, warst, war, waren, wart, waren'], ['haben', 'hatte, hattest, hatte, hatten...'], ['Düzenli', 'kök + te: spielte, wohnte'], ['Düzensiz', 'kök değişir: ging, kam, sah, las, fuhr']],
      tipTr: 'Konuşmada çoğu fiilde Perfekt, sein/haben/modallerde Präteritum tercih edilir.',
    }],
    build: () => fillExercises('praet', 'B1', 'Gramer: Präteritum', PRAET, ['war', 'hatte']),
  },
  futur: {
    id: 'futur', level: 'B1', emoji: '🔮', titleTr: 'Futur: gelecek zaman',
    cards: [{
      title: 'werden + mastar',
      bodyTr: 'Gelecek zaman werden + mastar ile kurulur. Konuşmada gelecek için çoğu zaman Präsens + zaman ifadesi de yeterlidir: "Morgen fahre ich nach Berlin."',
      rows: [['ich', 'werde'], ['du', 'wirst'], ['er/sie/es', 'wird'], ['wir/sie', 'werden'], ['ihr', 'werdet']],
      formulaDe: 'Ich werde morgen kommen.',
    }],
    build: () => [...fillExercises('futur', 'B1', 'Gramer: Futur', FUTUR, ['werde', 'wirst', 'wird', 'werden', 'werdet']), ...buildFuturOrder()],
  },
  genitiv: {
    id: 'genitiv', level: 'B1', emoji: '🏷️', titleTr: 'Genitiv: aitlik ve edatlar',
    cards: [{
      title: 'Aitlik bildiren hal',
      bodyTr: 'Genitiv "-in" aitlik anlamı verir (adamın arabası). Eril ve nötr isimler "des" alır ve isme -s/-es eklenir; dişil ve çoğul "der" alır. wegen, trotz, während gibi edatlar Genitiv ister.',
      rows: [['eril', 'des Mannes'], ['dişil', 'der Frau'], ['nötr', 'des Kindes'], ['çoğul', 'der Kinder']],
      tipTr: 'Konuşmada çoğu zaman "von + Dativ" kullanılır: das Auto von dem Mann.',
    }],
    build: () => fillExercises('genitiv', 'B1', 'Gramer: Genitiv', GENITIV, ['des', 'der', 'dem', 'den']),
  },
  adjektivdeklination: {
    id: 'adjektivdeklination', level: 'B1', emoji: '🎨', titleTr: 'Sıfat çekimi (Adjektivdeklination)',
    cards: [{
      title: 'Sıfatın sonu artikele göre değişir',
      bodyTr: 'İsmin önündeki sıfat çekim eki alır. Temel: "ein" ile eril Nominativ -er, nötr Nominativ/Akkusativ -es, dişil -e. "der/die/das" ile Nominativ ve dişil/nötr Akkusativ -e, diğer hallerde ve çoğulda -en.',
      rows: [['ein groß-er Mann', 'eril Nominativ'], ['ein groß-es Haus', 'nötr Nominativ/Akkusativ'], ['eine groß-e Stadt', 'dişil'], ['einen groß-en Hund', 'eril Akkusativ'], ['die groß-en Kinder', 'çoğul']],
      tipTr: 'Pratik kural: eksik kalan artikel işaretini sıfat taşır (ein Haus → großes).',
    }],
    build: () => fillExercises('adjekt', 'B1', 'Gramer: Sıfat çekimi', ADJEKT, ['e', 'en', 'er', 'es']),
  },
  relativsaetze: {
    id: 'relativsaetze', level: 'B1', emoji: '🔗', titleTr: 'Relativsätze: der Mann, der ...',
    cards: [{
      title: 'İlgi zamiri',
      bodyTr: 'Relativsatz bir ismi ek bilgiyle tanımlar. İlgi zamirinin cinsi (der/die/das) tanımladığı isme, hali ise cümledeki görevine uyar. Fiil yan cümlenin sonundadır.',
      formulaDe: 'Das ist der Mann, der dort wohnt.',
      rows: [['Nominativ', 'der · die · das · die'], ['Akkusativ', 'den · die · das · die'], ['Dativ', 'dem · der · dem · denen']],
      tipTr: 'Önce cinsi bulun (Mann = eril), sonra görevini (özne mi, nesne mi?).',
    }],
    build: () => fillExercises('relativ', 'B1', 'Gramer: Relativsätze', RELATIV, ['der', 'die', 'das', 'den', 'dem']),
  },
  konjunktiv2: {
    id: 'konjunktiv2', level: 'B2', emoji: '💭', titleTr: 'Konjunktiv II: dilekler ve nazik rica',
    cards: [{
      title: 'Gerçek dışı ve nazik ifadeler',
      bodyTr: 'Konjunktiv II gerçek olmayan durumları (Wenn ich Zeit hätte, ...), dilekleri ve nazik rica/tavsiyeyi anlatır. Çoğu fiil için würde + mastar yeterlidir; sein, haben ve modal fiillerin kendi formu kullanılır.',
      rows: [['sein', 'wäre'], ['haben', 'hätte'], ['können', 'könnte'], ['werden', 'würde + mastar'], ['nazik rica', 'Könnten Sie ...? / Würden Sie ...?']],
      tipTr: 'Nazik istek: Ich hätte gern ... / Ich möchte ...',
    }],
    build: () => fillExercises('konj2', 'B2', 'Gramer: Konjunktiv II', KONJ2, ['hätte', 'wäre', 'würde']),
  },
  passiv: {
    id: 'passiv', level: 'B2', emoji: '🔄', titleTr: 'Passiv: eylemi yapan değil, eylem önemli',
    cards: [{
      title: 'werden + Partizip II',
      bodyTr: 'Passiv, eylemi kimin yaptığı önemli olmadığında kullanılır. Şimdiki zaman: werden + Partizip II. Geçmiş: wurde + Partizip II. Yapan kişi gerekirse "von + Dativ" ile söylenir.',
      rows: [['Präsens', 'Das Haus wird gebaut.'], ['Präteritum', 'Das Haus wurde gebaut.'], ['çoğul', 'Die Häuser werden gebaut.'], ['yapan kişi', 'Das Haus wird von dem Mann gebaut.']],
    }],
    build: () => fillExercises('passiv', 'B2', 'Gramer: Passiv', PASSIV, ['wird', 'werden', 'wurde']),
  },
};

const pick = (...ids: string[]) => ids.map((id) => MORE_TOPICS[id]);

/** Order by level so topics unlock one after another. */
export const LAB_TOPICS: LabTopic[] = [
  ...BASE_TOPICS.slice(0, 4),
  ...pick('modalverben'),
  ...BASE_TOPICS.slice(4, 7),
  ...pick('trennbare', 'praeteritum', 'futur', 'genitiv', 'adjektivdeklination', 'relativsaetze', 'konjunktiv2', 'passiv'),
];

const REF_TO_TOPIC: Record<string, string> = {
  modal: 'modalverben',
  trenn: 'trennbare',
  praet: 'praeteritum',
  futur: 'futur',
  genitiv: 'genitiv',
  adjekt: 'adjektivdeklination',
  relativ: 'relativsaetze',
  konj2: 'konjunktiv2',
  passiv: 'passiv',
  konj: 'konjugation',
  plural: 'plural',
  perfekt: 'perfekt',
  satz: 'satzstellung',
  artikel: 'artikel-kasus',
  praep: 'praeposition',
  negation: 'negation',
};

/** One review question for a grammar item (refId looks like gram:perfekt:12). */
export function buildReviewExerciseForGrammar(refId: string, seed: number): Exercise | null {
  const topicId = REF_TO_TOPIC[refId.split(':')[1]];
  const topic = LAB_TOPICS.find((t) => t.id === topicId);
  if (!topic) return null;
  const pool = topic.build().filter((e) => e.refId === refId);
  if (pool.length === 0) return null;
  const ex = pool[seed % pool.length];
  return { ...ex, id: `${ex.id}_r${seed}` } as Exercise;
}
