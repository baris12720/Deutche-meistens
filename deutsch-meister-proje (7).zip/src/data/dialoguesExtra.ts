import { RealLifeDialogue } from '../types';

// Additional real-life dialogues, stories and news for the listening lab and role-play.
export const EXTRA_DIALOGUES: RealLifeDialogue[] = [
 {
  "id": "dia_smalltalk",
  "titleTr": "9. Küçük Sohbet: Hava ve Hafta Sonu",
  "titleDe": "Smalltalk: Wetter und Wochenende",
  "category": "Günlük Sohbet",
  "level": "A1",
  "contextTr": "İki iş arkadaşının hava durumu ve hafta sonu planları hakkında kısa sohbeti.",
  "vocabulary": [
   {
    "german": "Viel Spaß!",
    "turkish": "İyi eğlenceler!"
   },
   {
    "german": "Bis Montag!",
    "turkish": "Pazartesi görüşürüz!"
   }
  ],
  "lines": [
   {
    "id": "dia_smalltalk_1",
    "speaker": "Anna",
    "german": "Hallo Paul! Wie geht es dir?",
    "turkish": "Merhaba Paul! Nasılsın?"
   },
   {
    "id": "dia_smalltalk_2",
    "speaker": "Paul",
    "german": "Gut, danke. Und dir?",
    "turkish": "İyiyim, teşekkürler. Ya sen?"
   },
   {
    "id": "dia_smalltalk_3",
    "speaker": "Anna",
    "german": "Auch gut. Das Wetter ist heute schön, oder?",
    "turkish": "Ben de iyiyim. Hava bugün güzel, değil mi?"
   },
   {
    "id": "dia_smalltalk_4",
    "speaker": "Paul",
    "german": "Ja, die Sonne scheint. Was machst du am Wochenende?",
    "turkish": "Evet, güneş parlıyor. Hafta sonu ne yapıyorsun?"
   },
   {
    "id": "dia_smalltalk_5",
    "speaker": "Anna",
    "german": "Ich besuche meine Oma. Und du?",
    "turkish": "Büyükannemi ziyaret ediyorum. Ya sen?"
   },
   {
    "id": "dia_smalltalk_6",
    "speaker": "Paul",
    "german": "Ich spiele Fußball mit Freunden.",
    "turkish": "Arkadaşlarımla futbol oynuyorum."
   },
   {
    "id": "dia_smalltalk_7",
    "speaker": "Anna",
    "german": "Viel Spaß! Bis Montag.",
    "turkish": "İyi eğlenceler! Pazartesi görüşürüz."
   },
   {
    "id": "dia_smalltalk_8",
    "speaker": "Paul",
    "german": "Danke, bis Montag!",
    "turkish": "Teşekkürler, pazartesi görüşürüz!"
   }
  ]
 },
 {
  "id": "dia_freunde",
  "titleTr": "10. Arkadaş Edinmek: Hobiler",
  "titleDe": "Freunde finden: Hobbys",
  "category": "Sosyal Hayat",
  "level": "A2",
  "contextTr": "Almanca kursunda tanışan iki kişinin hobileri hakkında konuşması.",
  "vocabulary": [
   {
    "german": "Sitzt hier noch jemand?",
    "turkish": "Burada oturan var mı?"
   },
   {
    "german": "Vielleicht kochen wir mal zusammen.",
    "turkish": "Belki bir gün birlikte yemek yaparız."
   }
  ],
  "lines": [
   {
    "id": "dia_freunde_1",
    "speaker": "Mia",
    "german": "Entschuldigung, sitzt hier noch jemand?",
    "turkish": "Pardon, burada oturan var mı?"
   },
   {
    "id": "dia_freunde_2",
    "speaker": "Can",
    "german": "Nein, bitte setz dich. Ich bin Can.",
    "turkish": "Hayır, lütfen otur. Ben Can."
   },
   {
    "id": "dia_freunde_3",
    "speaker": "Mia",
    "german": "Ich bin Mia. Bist du neu im Deutschkurs?",
    "turkish": "Ben Mia. Almanca kursunda yeni misin?"
   },
   {
    "id": "dia_freunde_4",
    "speaker": "Can",
    "german": "Ja, seit gestern. Ich lerne Deutsch, weil ich hier arbeiten möchte.",
    "turkish": "Evet, dünden beri. Burada çalışmak istediğim için Almanca öğreniyorum."
   },
   {
    "id": "dia_freunde_5",
    "speaker": "Mia",
    "german": "Das ist super! Was machst du gern in deiner Freizeit?",
    "turkish": "Harika! Boş zamanında ne yapmayı seversin?"
   },
   {
    "id": "dia_freunde_6",
    "speaker": "Can",
    "german": "Ich laufe gern und ich koche gern türkisch.",
    "turkish": "Koşmayı severim ve Türk yemekleri pişirmeyi severim."
   },
   {
    "id": "dia_freunde_7",
    "speaker": "Mia",
    "german": "Wirklich? Vielleicht kochen wir mal zusammen!",
    "turkish": "Gerçekten mi? Belki bir gün birlikte yemek yaparız!"
   },
   {
    "id": "dia_freunde_8",
    "speaker": "Can",
    "german": "Sehr gern! Hast du am Samstag Zeit?",
    "turkish": "Çok isterim! Cumartesi vaktin var mı?"
   }
  ]
 },
 {
  "id": "dia_telefon",
  "titleTr": "11. Telefonda Randevu Almak",
  "titleDe": "Am Telefon: Termin vereinbaren",
  "category": "Telefon",
  "level": "A2",
  "contextTr": "Bir muayenehaneyi arayıp randevu alma.",
  "vocabulary": [
   {
    "german": "einen Termin vereinbaren",
    "turkish": "randevu almak"
   },
   {
    "german": "Auf Wiederhören!",
    "turkish": "Hoşça kalın! (telefonda)"
   }
  ],
  "lines": [
   {
    "id": "dia_telefon_1",
    "speaker": "Praxis",
    "german": "Praxis Doktor Weber, guten Tag.",
    "turkish": "Doktor Weber muayenehanesi, merhaba."
   },
   {
    "id": "dia_telefon_2",
    "speaker": "Patient",
    "german": "Guten Tag, hier ist Ali Demir. Ich möchte einen Termin vereinbaren.",
    "turkish": "Merhaba, ben Ali Demir. Bir randevu almak istiyorum."
   },
   {
    "id": "dia_telefon_3",
    "speaker": "Praxis",
    "german": "Worum geht es denn?",
    "turkish": "Konu nedir?"
   },
   {
    "id": "dia_telefon_4",
    "speaker": "Patient",
    "german": "Ich habe seit drei Tagen Rückenschmerzen.",
    "turkish": "Üç gündür sırt ağrım var."
   },
   {
    "id": "dia_telefon_5",
    "speaker": "Praxis",
    "german": "Wie wäre es mit Donnerstag um neun Uhr?",
    "turkish": "Perşembe saat dokuz nasıl olur?"
   },
   {
    "id": "dia_telefon_6",
    "speaker": "Patient",
    "german": "Leider kann ich da nicht. Hätten Sie auch am Freitag etwas frei?",
    "turkish": "Maalesef o saatte gelemem. Cuma günü de boş yeriniz var mı?"
   },
   {
    "id": "dia_telefon_7",
    "speaker": "Praxis",
    "german": "Ja, Freitag um halb elf.",
    "turkish": "Evet, cuma günü saat on buçuk."
   },
   {
    "id": "dia_telefon_8",
    "speaker": "Patient",
    "german": "Das passt gut. Vielen Dank, auf Wiederhören!",
    "turkish": "Bu uyar. Çok teşekkürler, hoşça kalın!"
   }
  ]
 },
 {
  "id": "dia_story",
  "titleTr": "12. Hikâye: Benim Hafta Sonum",
  "titleDe": "Geschichte: Mein Wochenende",
  "category": "Hikâye",
  "level": "A2",
  "contextTr": "Perfekt zamanıyla anlatılan kısa bir hafta sonu hikâyesi. Sadece dinleyin ve anlamaya çalışın.",
  "vocabulary": [
   {
    "german": "danach",
    "turkish": "sonra"
   },
   {
    "german": "getroffen",
    "turkish": "buluştum (Perfekt)"
   }
  ],
  "lines": [
   {
    "id": "dia_story_1",
    "speaker": "Erzählerin",
    "german": "Am Samstag bin ich früh aufgestanden.",
    "turkish": "Cumartesi günü erken kalktım."
   },
   {
    "id": "dia_story_2",
    "speaker": "Erzählerin",
    "german": "Ich habe gefrühstückt und danach bin ich mit dem Bus in die Stadt gefahren.",
    "turkish": "Kahvaltı yaptım ve sonra otobüsle şehre gittim."
   },
   {
    "id": "dia_story_3",
    "speaker": "Erzählerin",
    "german": "Dort habe ich meine Freundin getroffen.",
    "turkish": "Orada arkadaşımla buluştum."
   },
   {
    "id": "dia_story_4",
    "speaker": "Erzählerin",
    "german": "Wir haben zusammen eingekauft und einen Kaffee getrunken.",
    "turkish": "Birlikte alışveriş yaptık ve kahve içtik."
   },
   {
    "id": "dia_story_5",
    "speaker": "Erzählerin",
    "german": "Am Abend bin ich müde nach Hause gekommen.",
    "turkish": "Akşam yorgun bir şekilde eve geldim."
   },
   {
    "id": "dia_story_6",
    "speaker": "Erzählerin",
    "german": "Es war ein schöner Tag.",
    "turkish": "Güzel bir gündü."
   }
  ]
 },
 {
  "id": "dia_bank",
  "titleTr": "13. Bankada Hesap Açmak",
  "titleDe": "Bei der Bank: Konto eröffnen",
  "category": "Bankacılık",
  "level": "B1",
  "contextTr": "Bankada vadesiz hesap açma ve ücretler hakkında danışmanlık alma.",
  "vocabulary": [
   {
    "german": "ein Girokonto eröffnen",
    "turkish": "vadesiz hesap açmak"
   },
   {
    "german": "Gehaltseingang",
    "turkish": "maaş girişi"
   }
  ],
  "lines": [
   {
    "id": "dia_bank_1",
    "speaker": "Berater",
    "german": "Guten Tag, wie kann ich Ihnen helfen?",
    "turkish": "İyi günler, size nasıl yardımcı olabilirim?"
   },
   {
    "id": "dia_bank_2",
    "speaker": "Kunde",
    "german": "Guten Tag. Ich möchte ein Girokonto eröffnen.",
    "turkish": "İyi günler. Bir vadesiz hesap açmak istiyorum."
   },
   {
    "id": "dia_bank_3",
    "speaker": "Berater",
    "german": "Gern. Haben Sie Ihren Ausweis und Ihre Meldebescheinigung dabei?",
    "turkish": "Memnuniyetle. Kimliğiniz ve ikamet belgeniz yanınızda mı?"
   },
   {
    "id": "dia_bank_4",
    "speaker": "Kunde",
    "german": "Ja, hier bitte. Wie hoch sind die monatlichen Gebühren?",
    "turkish": "Evet, buyurun. Aylık ücretler ne kadar?"
   },
   {
    "id": "dia_bank_5",
    "speaker": "Berater",
    "german": "Das Konto kostet fünf Euro im Monat, bei einem Gehaltseingang ist es kostenlos.",
    "turkish": "Hesap ayda beş euro, maaş yatarsa ücretsiz."
   },
   {
    "id": "dia_bank_6",
    "speaker": "Kunde",
    "german": "Bekomme ich auch eine Karte, mit der ich im Ausland bezahlen kann?",
    "turkish": "Yurt dışında ödeme yapabileceğim bir kart da alıyor muyum?"
   },
   {
    "id": "dia_bank_7",
    "speaker": "Berater",
    "german": "Ja, die Karte kommt in etwa einer Woche mit der Post.",
    "turkish": "Evet, kart yaklaşık bir hafta içinde postayla gelir."
   },
   {
    "id": "dia_bank_8",
    "speaker": "Kunde",
    "german": "Perfekt. Dann unterschreibe ich jetzt den Antrag.",
    "turkish": "Mükemmel. O zaman şimdi başvuruyu imzalıyorum."
   }
  ]
 },
 {
  "id": "dia_auslaender",
  "titleTr": "14. Yabancılar Dairesi: Oturma İzni",
  "titleDe": "Ausländerbehörde: Aufenthaltserlaubnis verlängern",
  "category": "Resmî İşlemler",
  "level": "B1",
  "contextTr": "Oturma izninin uzatılması için yabancılar dairesinde yapılan görüşme.",
  "vocabulary": [
   {
    "german": "Aufenthaltserlaubnis",
    "turkish": "oturma izni"
   },
   {
    "german": "Unterlagen",
    "turkish": "belgeler"
   }
  ],
  "lines": [
   {
    "id": "dia_auslaender_1",
    "speaker": "Sachbearbeiterin",
    "german": "Guten Morgen. Wie kann ich Ihnen helfen?",
    "turkish": "Günaydın. Size nasıl yardımcı olabilirim?"
   },
   {
    "id": "dia_auslaender_2",
    "speaker": "Herr Yilmaz",
    "german": "Guten Morgen. Meine Aufenthaltserlaubnis läuft im März ab. Ich möchte sie verlängern.",
    "turkish": "Günaydın. Oturma iznimin süresi mart ayında doluyor. Uzatmak istiyorum."
   },
   {
    "id": "dia_auslaender_3",
    "speaker": "Sachbearbeiterin",
    "german": "Haben Sie einen Termin?",
    "turkish": "Randevunuz var mı?"
   },
   {
    "id": "dia_auslaender_4",
    "speaker": "Herr Yilmaz",
    "german": "Ja, um zehn Uhr. Hier ist meine Terminbestätigung.",
    "turkish": "Evet, saat onda. Randevu onayım burada."
   },
   {
    "id": "dia_auslaender_5",
    "speaker": "Sachbearbeiterin",
    "german": "Gut. Bitte legen Sie Ihren Pass, ein biometrisches Foto und den Arbeitsvertrag vor.",
    "turkish": "Güzel. Lütfen pasaportunuzu, biyometrik fotoğrafınızı ve iş sözleşmenizi sunun."
   },
   {
    "id": "dia_auslaender_6",
    "speaker": "Herr Yilmaz",
    "german": "Hier sind alle Unterlagen. Brauche ich noch einen Nachweis über meine Krankenversicherung?",
    "turkish": "Tüm belgeler burada. Sağlık sigortası belgesine de ihtiyacım var mı?"
   },
   {
    "id": "dia_auslaender_7",
    "speaker": "Sachbearbeiterin",
    "german": "Ja, das ist erforderlich. Haben Sie den dabei?",
    "turkish": "Evet, gerekli. Yanınızda mı?"
   },
   {
    "id": "dia_auslaender_8",
    "speaker": "Herr Yilmaz",
    "german": "Ja, einen Moment bitte.",
    "turkish": "Evet, bir dakika lütfen."
   }
  ]
 },
 {
  "id": "dia_arbeit",
  "titleTr": "15. İş Yerinde İletişim",
  "titleDe": "Am Arbeitsplatz: Besprechung",
  "category": "İş Hayatı",
  "level": "B1",
  "contextTr": "Toplantıda gecikme ve görev tesliminin yeniden planlanması.",
  "vocabulary": [
   {
    "german": "sich verspäten",
    "turkish": "gecikmek"
   },
   {
    "german": "Zwischenstand",
    "turkish": "ara durum"
   }
  ],
  "lines": [
   {
    "id": "dia_arbeit_1",
    "speaker": "Chefin",
    "german": "Guten Morgen zusammen. Wir haben heute viel zu besprechen.",
    "turkish": "Herkese günaydın. Bugün konuşacak çok şeyimiz var."
   },
   {
    "id": "dia_arbeit_2",
    "speaker": "Kollege",
    "german": "Entschuldigung, ich habe mich leider etwas verspätet. Der Zug hatte Verspätung.",
    "turkish": "Özür dilerim, maalesef biraz geciktim. Trenin rötarı vardı."
   },
   {
    "id": "dia_arbeit_3",
    "speaker": "Chefin",
    "german": "Kein Problem. Können Sie bitte den Bericht bis Freitag fertigstellen?",
    "turkish": "Sorun değil. Raporu cumaya kadar bitirebilir misiniz?"
   },
   {
    "id": "dia_arbeit_4",
    "speaker": "Kollege",
    "german": "Bis Freitag wird knapp, weil ich noch Daten sammeln muss. Geht auch Montag?",
    "turkish": "Cumaya kadar zor olur, çünkü hâlâ veri toplamam gerekiyor. Pazartesi olur mu?"
   },
   {
    "id": "dia_arbeit_5",
    "speaker": "Chefin",
    "german": "Gut, aber dann schicken Sie mir bitte schon am Donnerstag einen Zwischenstand.",
    "turkish": "Peki, ama o zaman lütfen perşembe günü bana ara durumu gönderin."
   },
   {
    "id": "dia_arbeit_6",
    "speaker": "Kollege",
    "german": "Einverstanden. Ich melde mich, wenn ich Fragen habe.",
    "turkish": "Anlaştık. Sorum olursa size haber veririm."
   }
  ]
 },
 {
  "id": "dia_news",
  "titleTr": "16. Radyo Haberi: Bisiklet Yolları",
  "titleDe": "Radionachrichten: Radwege",
  "category": "Haber",
  "level": "B2",
  "contextTr": "Bir şehrin bisiklet yolu planı hakkında kısa radyo haberi.",
  "vocabulary": [
   {
    "german": "ausbauen",
    "turkish": "genişletmek"
   },
   {
    "german": "bemängeln",
    "turkish": "kusur bulmak, eleştirmek"
   }
  ],
  "lines": [
   {
    "id": "dia_news_1",
    "speaker": "Sprecher",
    "german": "Die Stadt Hamburg will in den nächsten fünf Jahren das Radwegenetz deutlich ausbauen.",
    "turkish": "Hamburg şehri önümüzdeki beş yıl içinde bisiklet yolu ağını belirgin biçimde genişletmek istiyor."
   },
   {
    "id": "dia_news_2",
    "speaker": "Sprecher",
    "german": "Insgesamt sollen 100 Kilometer neue Wege entstehen.",
    "turkish": "Toplam 100 kilometre yeni yol yapılması planlanıyor."
   },
   {
    "id": "dia_news_3",
    "speaker": "Sprecher",
    "german": "Die Kosten werden auf rund 40 Millionen Euro geschätzt.",
    "turkish": "Maliyetin yaklaşık 40 milyon euro olduğu tahmin ediliyor."
   },
   {
    "id": "dia_news_4",
    "speaker": "Sprecher",
    "german": "Kritiker bemängeln, dass dafür zahlreiche Parkplätze wegfallen könnten.",
    "turkish": "Eleştirenler bunun için çok sayıda otoparkın ortadan kalkabileceğini söylüyor."
   },
   {
    "id": "dia_news_5",
    "speaker": "Sprecher",
    "german": "Die Stadtverwaltung betont dagegen, dass der Verkehr dadurch sicherer und umweltfreundlicher werde.",
    "turkish": "Belediye ise buna karşılık trafiğin bu sayede daha güvenli ve çevre dostu olacağını vurguluyor."
   }
  ]
 },
 {
  "id": "dia_homeoffice",
  "titleTr": "17. Tartışma: Evden Çalışma",
  "titleDe": "Diskussion: Homeoffice",
  "category": "Tartışma",
  "level": "C1",
  "contextTr": "Bir radyo programında evden çalışmanın artı ve eksileri üzerine resmî bir tartışma.",
  "vocabulary": [
   {
    "german": "meines Erachtens",
    "turkish": "bence"
   },
   {
    "german": "sofern",
    "turkish": "yeter ki, şu şartla"
   }
  ],
  "lines": [
   {
    "id": "dia_homeoffice_1",
    "speaker": "Moderator",
    "german": "Heute diskutieren wir die Frage, ob das Homeoffice zum Normalfall werden sollte.",
    "turkish": "Bugün evden çalışmanın olağan hâle gelip gelmemesi gerektiği sorusunu tartışıyoruz."
   },
   {
    "id": "dia_homeoffice_2",
    "speaker": "Frau Keller",
    "german": "Meines Erachtens überwiegen die Vorteile, da Pendelzeiten entfallen und die Beschäftigten ihre Arbeit flexibler organisieren können.",
    "turkish": "Bence avantajlar ağır basıyor, çünkü yolda geçen süre ortadan kalkıyor ve çalışanlar işlerini daha esnek düzenleyebiliyor."
   },
   {
    "id": "dia_homeoffice_3",
    "speaker": "Herr Brandt",
    "german": "Das mag zutreffen, dennoch darf man nicht außer Acht lassen, dass der persönliche Austausch im Team darunter leidet.",
    "turkish": "Bu doğru olabilir, yine de ekipteki yüz yüze iletişimin bundan zarar gördüğü göz ardı edilmemeli."
   },
   {
    "id": "dia_homeoffice_4",
    "speaker": "Frau Keller",
    "german": "Dem würde ich nicht grundsätzlich widersprechen. Eine hybride Lösung wäre daher sinnvoll.",
    "turkish": "Buna prensipte karşı çıkmam. Bu yüzden hibrit bir çözüm mantıklı olur."
   },
   {
    "id": "dia_homeoffice_5",
    "speaker": "Herr Brandt",
    "german": "Da stimme ich Ihnen zu, sofern klare Regeln für die Anwesenheit gelten.",
    "turkish": "Buna katılıyorum, yeter ki mevcudiyet için net kurallar olsun."
   }
  ]
 }
];
