import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, Send, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AiReply, AiTurn, askTeacher, loadAiConfig, saveAiConfig } from '../../utils/aiClient';
import { weakTopics } from '../../utils/analytics';
import { speakGerman } from '../../utils/audio';
import { CEFRLevel } from '../../types';

interface Msg {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  reply?: AiReply;
}

const CHAT_KEY = 'dm_ai_chat_v1';

const TOPICS: Record<CEFRLevel, string[]> = {
  A1: ['Kendini tanıtma', 'Aile', 'Yemek ve içecek', 'Günlük rutin'],
  A2: ['Alışveriş', 'Seyahat', 'Hobiler', 'Hava ve mevsimler'],
  B1: ['İş hayatı', 'Gelecek planları', 'Sağlık', 'Medya'],
  B2: ['Çevre', 'Eğitim', 'Teknoloji', 'Toplumsal konular'],
  C1: ['Siyaset ve toplum', 'Bilim', 'Kültür ve sanat', 'Ekonomi'],
};

const GREETING: Record<string, { de: string; tr: string }> = {
  A1: { de: 'Hallo! Ich bin dein Deutschlehrer. Wie heißt du?', tr: 'Merhaba! Ben senin Almanca öğretmeninim. Adın ne?' },
  A2: { de: 'Hallo! Schön, dass du da bist. Was hast du gestern gemacht?', tr: 'Merhaba! Gelmene sevindim. Dün ne yaptın?' },
  B1: { de: 'Hallo! Worüber möchtest du heute sprechen? Erzähl mir von deinen Plänen.', tr: 'Merhaba! Bugün ne hakkında konuşmak istersin? Bana planlarını anlat.' },
  B2: { de: 'Guten Tag! Welches Thema beschäftigt dich zurzeit besonders?', tr: 'İyi günler! Şu sıralar seni özellikle hangi konu meşgul ediyor?' },
  C1: { de: 'Guten Tag! Welche aktuelle Debatte findest du besonders interessant, und warum?', tr: 'İyi günler! Güncel hangi tartışmayı özellikle ilginç buluyorsun ve neden?' },
};

export const AiTeacher: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { profile, currentLevel, addAiMistake, recordActivity, addXp } = useApp();
  const [cfg, setCfg] = useState(loadAiConfig());
  const [endpointInput, setEndpointInput] = useState(cfg.endpoint);
  const [tokenInput, setTokenInput] = useState(cfg.token);
  const [topic, setTopic] = useState(TOPICS[currentLevel][0]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showTr, setShowTr] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>(() => {
    try {
      const raw = localStorage.getItem(CHAT_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      /* ignore */
    }
    return [];
  });
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(CHAT_KEY, JSON.stringify(msgs.slice(-40)));
    } catch {
      /* ignore */
    }
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, busy]);

  const configured = !!cfg.endpoint;
  const greeting = GREETING[currentLevel] || GREETING.A1;

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setError(null);
    setInput('');
    const userMsg: Msg = { id: `u${Date.now()}`, role: 'user', text };
    setMsgs((m) => [...m, userMsg]);
    setBusy(true);
    try {
      const history: AiTurn[] = [...msgs, userMsg].slice(-8).map((m) => ({
        role: m.role,
        text: m.role === 'assistant' && m.reply ? [m.reply.reply, m.reply.followUp].filter(Boolean).join(' ') : m.text,
      }));
      const reply = await askTeacher(cfg, {
        message: text,
        history: history.slice(0, -1),
        level: currentLevel,
        topic,
        weakAreas: weakTopics(profile).slice(0, 3).map((w) => w.label),
        knownErrors: (profile.aiMistakes || []).slice(0, 5).map((e) => e.type),
      });
      setMsgs((m) => [...m, { id: `a${Date.now()}`, role: 'assistant', text: reply.reply, reply }]);
      if (reply.correction) {
        addAiMistake({
          original: reply.correction.original,
          corrected: reply.correction.corrected,
          explanationTr: reply.correction.explanationTr,
          type: reply.correction.errorType,
        });
        recordActivity('writing', false, 30);
      } else {
        recordActivity('writing', true, 30);
        addXp(2);
      }
    } catch (e: any) {
      setError(e?.message || 'Bir hata oluştu.');
    } finally {
      setBusy(false);
    }
  };

  const corrections = msgs.filter((m) => m.reply?.correction).length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-50 dark:bg-slate-950 flex flex-col">
      <div className="flex items-center gap-3 px-4 h-14 shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <button onClick={onClose} aria-label="Kapat" className="p-2 -ml-2 text-slate-500 cursor-pointer">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="min-w-0">
          <div className="text-sm font-black text-slate-900 dark:text-white">Yapay zekâ Almanca öğretmeni</div>
          <div className="text-[11px] text-slate-400">Seviye {currentLevel} · {corrections} düzeltme</div>
        </div>
        <button onClick={() => setShowTr((v) => !v)} className={`ml-auto px-2.5 h-8 rounded-lg text-[11px] font-black cursor-pointer ${showTr ? 'bg-amber-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
          Türkçe
        </button>
      </div>

      {!configured ? (
        <div className="flex-1 overflow-y-auto p-4">
          <div className="max-w-md mx-auto rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-5 space-y-3">
            <div className="text-3xl text-center">🤖</div>
            <h3 className="text-lg font-black text-center text-slate-900 dark:text-white">Sunucu bağlantısı gerekli</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Yapay zekâ sohbeti için API anahtarının güvende kalması gerekir. Bu yüzden anahtar uygulamanın içine konmaz, kendi küçük sunucunda durur. Projedeki <b>server/ai-proxy</b> klasörü bu sunucudur (kurulum adımları <b>AI_KURULUM.md</b> dosyasında).
            </p>
            <input
              value={endpointInput}
              onChange={(e) => setEndpointInput(e.target.value)}
              placeholder="https://sunucu-adresin.run.app"
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full h-12 px-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white"
            />
            <input
              value={tokenInput}
              onChange={(e) => setTokenInput(e.target.value)}
              placeholder="Erişim anahtarı (varsa)"
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full h-12 px-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white"
            />
            <button
              onClick={() => {
                const c = { endpoint: endpointInput.trim(), token: tokenInput.trim() };
                saveAiConfig(c);
                setCfg(c);
              }}
              disabled={!endpointInput.trim()}
              className="w-full h-12 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none disabled:opacity-40 cursor-pointer"
            >
              Kaydet
            </button>
            <p className="text-[11px] text-slate-400">Sunucu olmadan da "Rol yapma senaryoları" ve "Dinleme" bölümleri çevrimdışı çalışır.</p>
          </div>
        </div>
      ) : (
        <>
          <div className="px-4 pt-2 flex gap-2 overflow-x-auto shrink-0">
            {TOPICS[currentLevel].map((t) => (
              <button
                key={t}
                onClick={() => setTopic(t)}
                className={`shrink-0 px-3 h-8 rounded-full text-xs font-black cursor-pointer ${topic === t ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
              <div className="text-sm font-bold text-slate-900 dark:text-white">{greeting.de}</div>
              {showTr && <div className="mt-1 text-xs text-slate-500">{greeting.tr}</div>}
            </div>
            {msgs.map((m) =>
              m.role === 'user' ? (
                <div key={m.id} className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-emerald-500 text-white p-3 text-sm font-bold">{m.text}</div>
                </div>
              ) : (
                <div key={m.id} className="max-w-[92%] space-y-2">
                  {m.reply?.correction && (
                    <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900 p-3 text-sm space-y-1">
                      <div><span className="font-black text-rose-600">Yanlış:</span> <span className="line-through text-slate-600 dark:text-slate-300">{m.reply.correction.original}</span></div>
                      <div><span className="font-black text-emerald-600">Doğru:</span> <span className="font-bold text-slate-900 dark:text-white">{m.reply.correction.corrected}</span></div>
                      {m.reply.correction.explanationTr && <div className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">{m.reply.correction.explanationTr}</div>}
                    </div>
                  )}
                  <div className="rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 p-3">
                    <div className="text-sm font-bold text-slate-900 dark:text-white">{m.reply?.reply}</div>
                    {showTr && m.reply?.replyTr && <div className="mt-1 text-xs text-slate-500">{m.reply.replyTr}</div>}
                    {m.reply?.followUp && <div className="mt-2 text-sm font-bold text-emerald-700 dark:text-emerald-300">{m.reply.followUp}</div>}
                    {m.reply?.tipTr && <div className="mt-2 text-[11px] text-amber-700 dark:text-amber-300">💡 {m.reply.tipTr}</div>}
                    <button onClick={() => speakGerman([m.reply?.reply, m.reply?.followUp].filter(Boolean).join(' '), profile.speechSpeed)} className="mt-2 text-xs font-black text-sky-600 dark:text-sky-400 inline-flex items-center gap-1 cursor-pointer">
                      <Volume2 className="w-4 h-4" /> Dinle
                    </button>
                  </div>
                </div>
              )
            )}
            {busy && <div className="text-xs font-bold text-slate-400">Öğretmen yazıyor...</div>}
            {error && <div className="rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-bold p-3">{error}</div>}
            <div ref={endRef} />
          </div>

          <div className="p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shrink-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
            <div className="flex gap-2 max-w-xl mx-auto">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') send();
                }}
                placeholder="Almanca yaz..."
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                className="flex-1 h-12 px-4 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
              <button onClick={send} disabled={busy || !input.trim()} aria-label="Gönder" className="w-12 h-12 rounded-2xl bg-emerald-500 text-white inline-flex items-center justify-center disabled:opacity-40 cursor-pointer">
                <Send className="w-5 h-5" />
              </button>
            </div>
            <div className="max-w-xl mx-auto mt-1 flex justify-between text-[11px] text-slate-400">
              <span>Ä Ö Ü ß için telefon klavyesini kullan</span>
              <button
                onClick={() => {
                  setMsgs([]);
                  try {
                    localStorage.removeItem(CHAT_KEY);
                  } catch {
                    /* ignore */
                  }
                }}
                className="font-bold cursor-pointer"
              >
                Sohbeti temizle
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
