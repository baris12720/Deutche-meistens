import React from 'react';
import { Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Skill } from '../../types';
import { SKILLS, skillAccuracy, todayActivity } from '../../utils/analytics';
import { getDueItems } from '../../utils/srs';

const MINUTE_CHOICES = [10, 15, 20, 30];

interface Step {
  id: string;
  label: string;
  emoji: string;
  skill?: Skill;
}

const STEPS: Step[] = [
  { id: 'review', label: 'Tekrar', emoji: '🔁' },
  { id: 'words', label: 'Yeni kelime', emoji: '📚', skill: 'vocab' },
  { id: 'grammar', label: 'Gramer', emoji: '🧩', skill: 'grammar' },
  { id: 'listening', label: 'Dinleme', emoji: '🎧', skill: 'listening' },
  { id: 'speaking', label: 'Konuşma', emoji: '🎤', skill: 'speaking' },
];

/** Personal daily plan: split of the chosen study time, with extra minutes for the weakest skill. */
export const DailyPlan: React.FC<{ onStartReview: () => void }> = ({ onStartReview }) => {
  const { profile, setDailyMinutes, goTo } = useApp();
  const total = profile.dailyMinutes || 15;
  const today = todayActivity(profile);
  const due = getDueItems(profile).length;
  const acc = skillAccuracy(profile, 30);

  // weakest measurable skill among the four planned ones
  const candidates = (['vocab', 'grammar', 'listening', 'speaking'] as Skill[]).filter((s) => acc[s].pct !== null);
  const weakest = candidates.sort((a, b) => (acc[a].pct as number) - (acc[b].pct as number))[0];
  const weakestStep = STEPS.find((s) => s.skill === weakest);

  const base = total / 5;
  const bonus = weakestStep ? Math.max(1, Math.round(total * 0.1)) : 0;
  const minutesFor = (s: Step) => {
    let m = base;
    if (weakestStep && s.id === weakestStep.id) m += bonus;
    else if (weakestStep && s.id === 'review') m -= bonus;
    return Math.max(1, Math.round(m));
  };

  const isDone = (s: Step): boolean => {
    if (s.id === 'review') return due === 0 || (today.rev || 0) >= 1;
    const done = (today.skills[s.skill as Skill]?.r || 0) + (today.skills[s.skill as Skill]?.w || 0);
    return done >= Math.max(4, minutesFor(s) * 2);
  };
  const doneCount = STEPS.filter(isDone).length;

  const start = (s: Step) => {
    if (s.id === 'review') return onStartReview();
    if (s.id === 'words') return goTo('words', 'sets');
    if (s.id === 'grammar') return goTo('grammar', 'lab');
    if (s.id === 'listening') return goTo('words', 'listening');
    return goTo('words', 'speaking');
  };

  return (
    <div className="mt-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-200 dark:border-emerald-900/60 p-3">
      <div className="flex items-center justify-between gap-2">
        <div>
          <div className="text-[11px] font-black uppercase tracking-wide text-emerald-700 dark:text-emerald-300">Bugünkü planın</div>
          <div className="text-sm font-black text-slate-900 dark:text-white">
            {doneCount}/5 tamam · {total} dakika
          </div>
        </div>
        <div className="flex gap-1" aria-label="Günlük çalışma süresi">
          {MINUTE_CHOICES.map((m) => (
            <button
              key={m}
              onClick={() => setDailyMinutes(m)}
              className={`px-2 h-8 rounded-lg text-[11px] font-black cursor-pointer ${
                total === m ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {m} dk
            </button>
          ))}
        </div>
      </div>
      {weakestStep && (
        <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
          Odak: {SKILLS.find((x) => x.id === weakest)?.label} (%{acc[weakest as Skill].pct}). Bu adıma fazladan süre ayrıldı.
        </p>
      )}
      <ul className="mt-2 space-y-1.5">
        {STEPS.map((s) => {
          const done = isDone(s);
          return (
            <li key={s.id} className="flex items-center gap-3">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs ${done ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700'}`}>
                {done ? <Check className="w-4 h-4" /> : s.emoji}
              </div>
              <div className="flex-1 min-w-0 text-sm font-bold text-slate-800 dark:text-slate-100">
                {s.label}
                <span className="ml-2 text-xs font-bold text-slate-400">
                  {s.id === 'review' && due === 0 ? 'bugün tekrar yok' : `${minutesFor(s)} dk`}
                </span>
              </div>
              {!done && (
                <button onClick={() => start(s)} className="px-3 h-8 rounded-lg bg-emerald-500 text-white text-xs font-black cursor-pointer">
                  Başla
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
};
