import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, Mic, Square, Volume2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { CEFRLevel, Exercise, RealLifeDialogue } from '../../types';
import { REAL_LIFE_DIALOGUES } from '../../data/dialogues';
import { buildRoleplayExercises } from '../../data/dialogueExercises';
import { getLevelWords } from '../../data/vocab/builder';
import { ExerciseRunner } from '../exercise/ExerciseRunner';
import { AiTeacher } from '../ai/AiTeacher';
import { speakGerman } from '../../utils/audio';
import { useBackHandler } from '../../utils/backStack';
import { LEVEL_ORDER } from '../../utils/progress';

type View = 'home' | 'ai' | 'roleplay' | 'pron';

const shuffle = <T,>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

/* ---------------- Role-play ---------------- */
const RolePlay: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { addXp } = useApp();
  const [quiz, setQuiz] = useState<{ d: RealLifeDialogue; ex: Exercise[] } | null>(null);
  const awarded = useRef(false);

  if (quiz) {
    return (
      <div className="fixed inset-0 z-50 bg-white dark:bg-slate-900 flex flex-col">
        <ExerciseRunner
          exercises={quiz.ex}
          allowLengthSelect={false}
          title={`Rol yapma: ${quiz.d.titleTr}`}
          completeLabel="Bitir"
          onExit={() => setQuiz(null)}
          onFinish={(correct) => {
            if (awarded.current) return;
            awarded.current = true;
            addXp(6 + correct * 3);
          }}
          onComplete={() => setQuiz(null)}
        />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <button onClick={onBack} aria-label="Geri" className="p-2 -ml-2 text-slate-500 cursor-pointer">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h3 className="text-lg font-black text-slate-900 dark:text-white">Rol yapma senaryoları</h3>
      </div>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">
        Gerçek hayattan bir durumda karşıdaki kişiye cevap verirsin. Diyalogun önceki cümlelerini oku, rolüne uygun cevabı seç.
      </p>
      <div className="space-y-3">
        {LEVEL_ORDER.flatMap((lvl) => REAL_LIFE_DIALOGUES.filter((d) => d.level === lvl)).map((d) => {
          const ex = buildRoleplayExercises(d);
          return (
            <button
              key={d.id}
              disabled={ex.length === 0}
              onClick={() => {
                awarded.current = false;
                setQuiz({ d, ex });
              }}
              className="w-full text-left rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4 disabled:opacity-50 active:translate-y-0.5 transition cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-[10px] font-black text-slate-600 dark:text-slate-300">{d.level}</span>
                <span className="text-[11px] font-black text-rose-500">{d.category}</span>
              </div>
              <div className="mt-0.5 text-base font-black text-slate-900 dark:text-white">{d.titleTr}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {ex.length > 0 ? `${ex.length} cevap sorusu` : 'Tek konuşmacılı metin: Dinleme bölümünde çalış'}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

/* ---------------- Pronunciation: record yourself and compare ---------------- */
const PronunciationLab: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const { profile, currentLevel, addXp, recordAnswer, recordActivity } = useApp();
  const [level, setLevel] = useState<CEFRLevel>(currentLevel);
  const [round, setRound] = useState(0);
  const items = useMemo(
    () => shuffle(getLevelWords(level).filter((w) => w.exampleGerman.split(' ').length >= 3)).slice(0, 5),
    [level, round]
  );
  const [idx, setIdx] = useState(0);
  const [good, setGood] = useState(0);
  const [recording, setRecording] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const finished = idx >= items.length;
  const item = items[idx];

  const clearAudio = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);
  };
  useEffect(() => () => clearAudio(), []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (finished && items.length) addXp(2 + good * 3);
  }, [finished]); // eslint-disable-line react-hooks/exhaustive-deps

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunks.current = [];
      rec.ondataavailable = (e) => chunks.current.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks.current, { type: rec.mimeType || 'audio/webm' });
        clearAudio();
        setAudioUrl(URL.createObjectURL(blob));
      };
      rec.start();
      mediaRef.current = rec;
      setRecording(true);
      setErr(null);
    } catch {
      setErr('Mikrofon kullanılamadı. Uygulama ayarlarından mikrofon iznini verdiğinden emin ol.');
    }
  };
  const stop = () => {
    mediaRef.current?.stop();
    setRecording(false);
  };

  const rate = (ok: boolean) => {
    if (!item) return;
    recordAnswer(item.id, ok);
    recordActivity('speaking', ok, 30);
    if (ok) setGood((g) => g + 1);
    clearAudio();
    setIdx((i) => i + 1);
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <button onClick={onBack} aria-label="Geri" className="p-2 -ml-2 text-slate-500 cursor-pointer">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h3 className="text-lg font-black text-slate-900 dark:text-white">Telaffuz çalışması</h3>
      </div>
      <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-200 dark:border-amber-900 p-3 text-xs text-amber-900 dark:text-amber-200 leading-relaxed mb-3">
        Dürüst not: Bu bölüm telaffuzuna otomatik fonetik puan <b>vermez</b>. Gerçek fonetik değerlendirme için ses analizi yapan özel bir bulut servisi gerekir. Burada kanıtlanmış bir yöntemi kullanırsın: önce anadili konuşan sesini dinle, sonra kendi sesini kaydet, ikisini karşılaştır ve kendini değerlendir.
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1 mb-3" role="tablist" aria-label="Telaffuz seviyesi">
        {LEVEL_ORDER.map((lvl) => (
          <button
            key={lvl}
            role="tab"
            aria-selected={lvl === level}
            onClick={() => {
              setLevel(lvl);
              setRound((r) => r + 1);
              setIdx(0);
              setGood(0);
              clearAudio();
            }}
            className={`flex-1 min-w-[52px] h-9 rounded-xl text-sm font-black cursor-pointer ${lvl === level ? 'bg-rose-500 text-white' : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}
          >
            {lvl}
          </button>
        ))}
      </div>

      {finished ? (
        <div className="text-center space-y-3 pop-in">
          <div className="text-4xl">{good >= 4 ? '🏆' : '👍'}</div>
          <div className="font-black text-slate-900 dark:text-white">{good} / {items.length} cümle iyiydi</div>
          <div className="text-sm text-slate-500">+{2 + good * 3} XP. Zor gelenler Akıllı tekrara eklendi.</div>
          <button
            onClick={() => {
              setRound((r) => r + 1);
              setIdx(0);
              setGood(0);
            }}
            className="w-full h-14 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_5px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer"
          >
            Yeni cümleler
          </button>
        </div>
      ) : item ? (
        <div className="space-y-4">
          <p className="text-sm text-slate-500">{idx + 1}/{items.length}</p>
          <div className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-6 text-center">
            <div className="text-xl font-black text-slate-900 dark:text-white leading-snug">{item.exampleGerman}</div>
            <div className="mt-2 text-sm text-slate-500">{item.exampleTurkish}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => speakGerman(item.exampleGerman, profile.speechSpeed)} className="h-12 rounded-2xl bg-sky-500 text-white font-black shadow-[0_4px_0_#0369a1] active:translate-y-1 active:shadow-none inline-flex items-center justify-center gap-2 cursor-pointer">
              <Volume2 className="w-5 h-5" /> Dinle
            </button>
            <button onClick={() => speakGerman(item.exampleGerman, 0.6)} className="h-12 rounded-2xl bg-indigo-500 text-white font-black shadow-[0_4px_0_#4338ca] active:translate-y-1 active:shadow-none inline-flex items-center justify-center gap-2 cursor-pointer">
              <Volume2 className="w-5 h-5" /> Yavaş
            </button>
          </div>
          <button
            onClick={() => (recording ? stop() : start())}
            className={`w-full h-14 rounded-2xl text-white font-black inline-flex items-center justify-center gap-2 cursor-pointer ${recording ? 'bg-rose-600 shadow-[0_5px_0_#9f1239]' : 'bg-rose-500 shadow-[0_5px_0_#be123c]'} active:translate-y-1 active:shadow-none`}
          >
            {recording ? (
              <>
                <Square className="w-5 h-5" /> Kaydı durdur
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" /> Sesini kaydet
              </>
            )}
          </button>
          {err && <div className="text-xs font-bold text-rose-600">{err}</div>}
          {audioUrl && (
            <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/60 p-3 space-y-2">
              <div className="text-xs font-black text-slate-500">Kendi sesin</div>
              <audio controls src={audioUrl} className="w-full" />
              <div className="text-[11px] text-slate-400">Ritim, vurgu ve ses uzunluğunu anadili konuşanla karşılaştır.</div>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <button onClick={() => rate(false)} className="h-12 rounded-2xl bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-black border-2 border-rose-300 dark:border-rose-800 cursor-pointer">
              Tekrar çalış
            </button>
            <button onClick={() => rate(true)} className="h-12 rounded-2xl bg-emerald-500 text-white font-black shadow-[0_4px_0_#047857] active:translate-y-1 active:shadow-none cursor-pointer">
              Yakındı
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
};

/* ---------------- Hub ---------------- */
export const SpeakingHub: React.FC = () => {
  const [view, setView] = useState<View>('home');
  useBackHandler(view !== 'home', () => setView('home'));

  if (view === 'ai') return <AiTeacher onClose={() => setView('home')} />;

  const cards: { id: View; emoji: string; title: string; desc: string }[] = [
    { id: 'ai', emoji: '🤖', title: 'Yapay zekâ öğretmen', desc: 'Seviyene uygun sohbet, hata düzeltme ve Türkçe açıklama (sunucu gerekir)' },
    { id: 'roleplay', emoji: '🎭', title: 'Rol yapma senaryoları', desc: 'Restoran, doktor, banka, yabancılar dairesi gibi gerçek durumlar' },
    { id: 'pron', emoji: '🎤', title: 'Telaffuz çalışması', desc: 'Dinle, sesini kaydet, karşılaştır' },
  ];

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28">
      {view === 'home' ? (
        <>
          <h2 className="text-xl font-black text-slate-900 dark:text-white">Konuşma</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Konuşmayı en iyi öğreten şey: gerçek durumlarda cevap vermek ve sesini duymak.</p>
          <div className="mt-4 space-y-3">
            {cards.map((c) => (
              <button
                key={c.id}
                onClick={() => setView(c.id)}
                className="w-full text-left rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4 flex items-center gap-4 active:translate-y-0.5 transition cursor-pointer"
              >
                <div className="text-3xl">{c.emoji}</div>
                <div className="min-w-0">
                  <div className="text-base font-black text-slate-900 dark:text-white">{c.title}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{c.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      ) : view === 'roleplay' ? (
        <RolePlay onBack={() => setView('home')} />
      ) : (
        <PronunciationLab onBack={() => setView('home')} />
      )}
    </div>
  );
};
