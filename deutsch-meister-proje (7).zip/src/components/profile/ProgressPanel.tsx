import React from 'react';
import { useApp } from '../../context/AppContext';
import { LEVEL_ORDER } from '../../utils/progress';
import { SKILLS, levelTargets, memoryStats, minutesOf, skillAccuracy, todayActivity, weakTopics, weeklySeries } from '../../utils/analytics';

const Bar: React.FC<{ pct: number; color: string }> = ({ pct, color }) => (
  <div className="h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
    <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} />
  </div>
);

const Card: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <section className="rounded-3xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 p-4">
    <h3 className="text-sm font-black text-slate-900 dark:text-white">{title}</h3>
    <div className="mt-3">{children}</div>
  </section>
);

export const ProgressPanel: React.FC = () => {
  const { profile, currentLevel } = useApp();
  const today = todayActivity(profile);
  const week = weeklySeries(profile);
  const maxMin = Math.max(5, ...week.map((d) => d.minutes));
  const weekTotal = week.reduce((a, d) => a + d.minutes, 0);
  const acc = skillAccuracy(profile, 30);
  const mem = memoryStats(profile);
  const weak = weakTopics(profile);
  const shownLevels = LEVEL_ORDER.slice(0, LEVEL_ORDER.indexOf(currentLevel) + 2).filter(Boolean);

  return (
    <div className="max-w-xl mx-auto px-4 py-5 pb-28 space-y-4">
      <div className="grid grid-cols-3 gap-3 text-center">
        {[
          ['Bugün', `${minutesOf(today.secs)} dk`],
          ['Bu hafta', `${weekTotal} dk`],
          ['Soru (bugün)', String(today.q)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 py-3">
            <div className="text-xl font-black text-slate-900 dark:text-white tabular-nums">{value}</div>
            <div className="text-[11px] font-bold text-slate-400">{label}</div>
          </div>
        ))}
      </div>

      <Card title="Haftalık çalışma süresi (dakika)">
        <div className="flex items-end justify-between gap-2 h-28">
          {week.map((d) => (
            <div key={d.key} className="flex-1 flex flex-col items-center gap-1">
              <div className="text-[10px] font-bold text-slate-400 tabular-nums">{d.minutes || ''}</div>
              <div className="w-full flex-1 flex items-end">
                <div className="w-full rounded-lg bg-emerald-500" style={{ height: `${d.minutes ? Math.max(8, (d.minutes / maxMin) * 100) : 4}%`, opacity: d.minutes ? 1 : 0.25 }} />
              </div>
              <div className="text-[10px] font-bold text-slate-500">{d.label}</div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Becerilerin (son 30 gün)">
        <div className="space-y-3">
          {SKILLS.map((s) => {
            const a = acc[s.id];
            return (
              <div key={s.id}>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">
                    {s.emoji} {s.label}
                  </span>
                  <span className="text-slate-500 tabular-nums">{a.pct === null ? `veri yok (${a.n}/5)` : `%${a.pct}`}</span>
                </div>
                <div className="mt-1">
                  <Bar pct={a.pct || 0} color={s.color} />
                </div>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11px] text-slate-400">Yüzde, o becerideki ilk denemede doğru cevap oranıdır. En az 5 cevap gerekir.</p>
      </Card>

      <Card title="Hafıza">
        <div className="grid grid-cols-2 gap-3 text-center">
          {[
            ['Öğrenilen kelime', String(mem.wordsLearned)],
            ['Kalıcı hatırlanan', String(mem.wordsRemembered)],
            ['Kelime doğruluğu', mem.vocabRate === null ? '-' : `%${mem.vocabRate}`],
            ['Gramer doğruluğu', mem.grammarRate === null ? '-' : `%${mem.grammarRate}`],
          ].map(([label, value]) => (
            <div key={label} className="rounded-2xl bg-slate-50 dark:bg-slate-900/50 py-3">
              <div className="text-lg font-black text-slate-900 dark:text-white tabular-nums">{value}</div>
              <div className="text-[11px] font-bold text-slate-400">{label}</div>
            </div>
          ))}
        </div>
      </Card>

      <Card title="Zayıf konular">
        {weak.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">Henüz yeterli veri yok. Çözdükçe en çok zorlandığın konular burada görünür.</p>
        ) : (
          <ul className="space-y-2">
            {weak.map((w) => (
              <li key={w.label} className="flex items-center justify-between text-sm">
                <span className="font-bold text-slate-800 dark:text-slate-100">{w.label}</span>
                <span className="text-xs font-black text-rose-500">{w.wrong} yanlış</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {shownLevels.map((lvl) => (
        <Card key={lvl} title={`${lvl} seviye hedefleri`}>
          <div className="space-y-2.5">
            {levelTargets(profile, lvl).map((t) => (
              <div key={t.label}>
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-700 dark:text-slate-200">{t.label}</span>
                  <span className="text-slate-500 tabular-nums">
                    {t.done}/{t.total}
                  </span>
                </div>
                <div className="mt-1">
                  <Bar pct={(t.done / Math.max(1, t.total)) * 100} color="bg-amber-500" />
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
};
