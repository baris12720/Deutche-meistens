# Yapay zekâ öğretmeni kurulumu

Uygulamadaki "Konuşma > Yapay zekâ öğretmen" bölümü bir sunucuya bağlanır. API anahtarı uygulamanın içine konmaz,
çünkü APK içindeki her şey okunabilir. Anahtar sadece bu küçük sunucuda durur.

## 1. API anahtarı
Google AI Studio'dan bir Gemini API anahtarı alın (https://aistudio.google.com). Anahtarı kimseyle paylaşmayın.

## 2. Sunucuyu yayınlayın (Google Cloud Run örneği)
```bash
cd server/ai-proxy
gcloud run deploy deutsch-meister-ai \
  --source . --region europe-west1 --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=ANAHTARINIZ,APP_TOKEN=KENDI_BELIRLEDIGINIZ_SIFRE,ALLOWED_ORIGINS=https://localhost
```
- `APP_TOKEN`: uygulamaya bir kez yazacağınız erişim şifresi. Başkaları sunucunuzu kullanamasın diye.
- `ALLOWED_ORIGINS`: Android uygulaması `https://localhost` adresinden istek gönderir.
- Daha güvenli yol: anahtarı Secret Manager'da saklayıp `--set-secrets` ile bağlamaktır.
- Model adı değişirse `GEMINI_MODEL` ortam değişkenini güncelleyin (varsayılan: gemini-2.5-flash).

Başka bir sunucu kullanırsanız (Render, Railway, kendi VPS'iniz) `node server.mjs` komutu yeterlidir (Node 20+).

## 3. Uygulamaya bağlayın
Uygulamada Kelime > Konuşma > Yapay zekâ öğretmen bölümünü açın, sunucu adresini ve erişim şifresini girin.

## Maliyet ve güvenlik
- Sunucu istek başına en fazla 800 çıktı belirteci (token) ister, IP başına 10 dakikada 40 istekle sınırlıdır.
- Uygulama aynı soruyu ikinci kez sormaz (önbellek) ve istekler arasında 1,5 saniye bekler.
- Kota ve fatura uyarılarını bulut sağlayıcınızın panelinden ayarlayın.

## Doğruluk hakkında
Yapay zekâ yanılabilir. Sunucu şu önlemleri alır: sadece gerçek hataları düzeltmesini ister, doğru alternatifleri hata
saymaz, emin değilse düzeltme yerine ipucu verir ve aynı cümleyi "düzeltilmiş" diye geri göndermesini engeller.
Bu önlemler hatayı azaltır ama sıfırlamaz. Şüpheli bir düzeltme görürseniz öğretmeninize veya bir sözlüğe danışın.

Bu sunucu bu ortamda gerçek bir API anahtarıyla denenmedi. İlk kurulumda `/health` adresini ve bir örnek isteği test edin:
```bash
curl -X POST SUNUCU_ADRESI/teach -H "Content-Type: application/json" -H "Authorization: Bearer SIFRE" \
  -d '{"message":"Ich gehen gestern zur Schule.","history":[],"level":"A2","topic":"Alışveriş","weakAreas":[],"knownErrors":[]}'
```
