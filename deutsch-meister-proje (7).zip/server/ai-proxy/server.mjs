// Small proxy for the AI teacher. It keeps the API key on the server and limits cost and abuse.
// Run: node server.mjs   (Node 20+, no dependencies)
import http from 'node:http';

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.GEMINI_API_KEY || '';
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const APP_TOKEN = process.env.APP_TOKEN || ''; // optional shared secret typed once into the app
const ALLOWED = (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim());
const RATE_LIMIT = Number(process.env.RATE_LIMIT || 40); // requests per IP per 10 minutes
const MAX_BODY = 20 * 1024;

const hits = new Map();
const limited = (ip) => {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  list.push(now);
  hits.set(ip, list);
  return list.length > RATE_LIMIT;
};

const LEVEL_RULES = {
  A1: 'Kısa ve çok basit cümleler kur (en fazla 8 kelime). Sadece günlük temel kelimeler ve şimdiki zaman kullan.',
  A2: 'Basit cümleler kur. Perfekt, modal fiiller ve basit bağlaçlar (weil, denn, aber) kullanabilirsin.',
  B1: 'Orta uzunlukta cümleler kur. Nebensätze, Präteritum ve Konjunktiv II girişi kullanabilirsin.',
  B2: 'Doğal ve akıcı cümleler kur. Passiv, Relativsätze ve soyut konular kullanabilirsin.',
  C1: 'İleri düzey, nüanslı ve akademik/resmî ifadeler kullanabilirsin.',
};

function buildSystem({ level, topic, weakAreas, knownErrors }) {
  return `Sen Türkçe konuşan bir öğrenciye Almanca öğreten sabırlı, motive edici bir Almanca öğretmenisin.
Öğrencinin CEFR seviyesi: ${level}. Sohbet konusu: ${topic}.
${LEVEL_RULES[level] || LEVEL_RULES.A1}
Öğrencinin zayıf alanları: ${weakAreas.join(', ') || 'henüz bilinmiyor'}. Daha önce yaptığı hata türleri: ${knownErrors.join(', ') || 'yok'}. Uygunsa bu alanları pratik ettirecek sorular sor.

KURALLAR:
- Sadece GERÇEK hataları düzelt. Cümle doğruysa veya kabul edilebilir bir alternatifse (farklı ama doğru kelime sırası, eş anlamlı kelime) correction alanını null yap. Doğru cümleyi asla yanlış işaretleme.
- Hata varsa: original (öğrencinin cümlesi), corrected (doğru cümle), explanationTr (Türkçe, kısa ve net: kural + neden), errorType (artikel, kasus, fiil-konjugasyonu, perfekt, kelime-sirasi, yazim, kelime-secimi, edat, diger).
- Emin değilsen confident alanını false yap ve düzeltme yerine tipTr içinde Türkçe ipucu ver.
- reply: öğrencinin söylediğine seviyesine uygun 1-3 cümlelik Almanca doğal cevap. replyTr: bu cevabın Türkçe çevirisi.
- followUp: öğrenciyi konuşmaya teşvik eden, seviyesine uygun yeni bir Almanca soru.
- Öğrenci Türkçe yazarsa nazikçe Almanca denemesini iste ve ifadenin Almancasını tipTr içinde ver.
- Sadece geçerli JSON döndür, başka metin yazma. Şema:
{"reply":string,"replyTr":string,"correction":{"original":string,"corrected":string,"explanationTr":string,"errorType":string}|null,"confident":boolean,"followUp":string,"tipTr":string}`;
}

const clampStr = (v, n) => (typeof v === 'string' ? v.slice(0, n) : '');
const norm = (t) => t.toLowerCase().replace(/[.,!?;:"']/g, '').replace(/\s+/g, ' ').trim();

async function askGemini(payload) {
  const contents = [];
  const push = (role, text) => {
    if (!text) return;
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += `\n${text}`;
    else contents.push({ role, parts: [{ text }] });
  };
  (payload.history || []).slice(-8).forEach((t) => push(t.role === 'assistant' ? 'model' : 'user', clampStr(t.text, 600)));
  push('user', clampStr(payload.message, 500));

  const body = {
    systemInstruction: { parts: [{ text: buildSystem(payload) }] },
    contents,
    generationConfig: { temperature: 0.3, maxOutputTokens: 800, responseMimeType: 'application/json' },
  };
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`upstream ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  return JSON.parse(text.replace(/^```json\s*|```$/g, '').trim());
}

function sanitize(raw, userMessage) {
  const out = {
    reply: clampStr(raw.reply, 600),
    replyTr: clampStr(raw.replyTr, 600),
    followUp: clampStr(raw.followUp, 300),
    tipTr: clampStr(raw.tipTr, 400),
    correction: null,
  };
  const c = raw.correction;
  if (c && typeof c === 'object') {
    const original = clampStr(c.original, 400);
    const corrected = clampStr(c.corrected, 400);
    // never flag a sentence that is already identical, and drop low-confidence corrections
    if (original && corrected && norm(original) !== norm(corrected) && raw.confident !== false) {
      out.correction = { original, corrected, explanationTr: clampStr(c.explanationTr, 600), errorType: clampStr(c.errorType, 40) || 'diger' };
    } else if (raw.confident === false && c.explanationTr) {
      out.tipTr = out.tipTr || clampStr(c.explanationTr, 400);
    }
  }
  if (!out.reply) out.reply = 'Sehr gut! Erzähl mir mehr.';
  return out;
}

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin || '';
  const allow = ALLOWED.includes('*') ? '*' : ALLOWED.includes(origin) ? origin : '';
  const cors = {
    'Access-Control-Allow-Origin': allow || ALLOWED[0] || '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json; charset=utf-8',
  };
  const send = (code, obj) => {
    res.writeHead(code, cors);
    res.end(JSON.stringify(obj));
  };
  if (req.method === 'OPTIONS') return send(204, {});
  if (req.method === 'GET' && req.url === '/health') return send(200, { ok: true });
  if (req.method !== 'POST' || !req.url.startsWith('/teach')) return send(404, { error: 'not found' });
  if (!API_KEY) return send(500, { error: 'server not configured' });
  if (APP_TOKEN && req.headers.authorization !== `Bearer ${APP_TOKEN}`) return send(401, { error: 'unauthorized' });
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  if (limited(ip)) return send(429, { error: 'rate limit' });

  let raw = '';
  let tooBig = false;
  req.on('data', (chunk) => {
    raw += chunk;
    if (raw.length > MAX_BODY) {
      tooBig = true;
      req.destroy();
    }
  });
  req.on('end', async () => {
    if (tooBig) return;
    try {
      const p = JSON.parse(raw || '{}');
      const level = ['A1', 'A2', 'B1', 'B2', 'C1'].includes(p.level) ? p.level : 'A1';
      const payload = {
        message: clampStr(p.message, 500),
        history: Array.isArray(p.history) ? p.history : [],
        level,
        topic: clampStr(p.topic, 80) || 'serbest sohbet',
        weakAreas: (Array.isArray(p.weakAreas) ? p.weakAreas : []).slice(0, 3).map((x) => clampStr(x, 60)),
        knownErrors: (Array.isArray(p.knownErrors) ? p.knownErrors : []).slice(0, 5).map((x) => clampStr(x, 40)),
      };
      if (payload.message.trim().length < 2) return send(400, { error: 'empty message' });
      const result = await askGemini(payload);
      send(200, sanitize(result, payload.message));
    } catch (e) {
      console.error('teach error:', e?.message || e);
      send(502, { error: 'upstream error' });
    }
  });
});

server.listen(PORT, () => console.log(`AI teacher proxy listening on ${PORT}`));
